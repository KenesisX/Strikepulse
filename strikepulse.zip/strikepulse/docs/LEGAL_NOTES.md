# Legal notes for running StrikePulse (plain-language summary)

**This is not legal advice.** It is a checklist from public sources, checked November 2026, so you
know what to ask a lawyer and an accountant. Rules change; verify before you launch or sell.

## 1. Market-data licenses: the biggest real issue

Price data is owned by whoever produces it. Free public feeds are usually free for **personal** use,
not for charging customers.

| Source | What the terms say | What to do |
| --- | --- | --- |
| **Coinbase Exchange** WebSocket/REST | The Market Data Terms limit use to personal or research purposes. You may not build an app for end users, or display data or anything derived from it (charts, analytics) to third parties. Coinbase runs a redistribution-partner program. | Do **not** sell a service built on the free Coinbase feed. Ask Coinbase about redistribution, or use a licensed vendor. |
| **CoinGecko API** | Free Demo key: attribution required, **not** a commercial license. Paid plans (Basic ~$35/mo and up) allow charging for products built on the data, with attribution. No plan lets you resell or redistribute API access itself. | Use a **paid** key for a paid product. The Markets page already shows the attribution link. |
| **CoinMarketCap API** | Sources disagree about the free Basic tier: CoinMarketCap's own articles say it allows commercial use, while others say it is personal only. Paid tiers are commercial; redistribution needs a custom deal. | Read CMC's current API terms yourself before relying on the free tier. |
| **Kraken, Binance.US, Gemini** | Not reviewed in detail here. Gemini requires a signed agreement to redistribute to subscribers. | Read each exchange's market-data terms, or get written permission. |

**How StrikePulse handles this:**
- `MARKET_DATA_PROVIDER` + `COINGECKO_API_KEY` (paid) gives licensed whole-market data for the Markets
  page, big-mover alerts and devices.
- The live-trade detectors (`FEEDS=`) need tick-level trade data. For a paid service, use a source
  whose license covers commercial display: an exchange redistribution agreement or a licensed vendor.
  Commercial crypto data vendors exist; compare their licenses and prices before choosing.
- The Elite REST API and device API serve derived information to *your own subscribers inside your
  product*. Do not sell raw data feeds; that is redistribution under almost every license.
- Running it for yourself only (personal use) is generally what the free feeds allow.

## 2. Investment-adviser rules (SEC and states)

- *Lowe v. SEC* (1985): publishers of **bona fide** publications of **general and regular circulation**
  that give **impersonal** advice are excluded from the Investment Advisers Act. Commentary on specific
  assets doesn't by itself make advice personalized.
- StrikePulse is built to stay on the impersonal side: every subscriber with the same settings gets
  the same algorithmic output, it never considers anyone's finances, and every page and alert carries
  a "not financial advice" notice.
- **Keep it that way:** no one-on-one advice, no "DM me for picks", no managing anyone's money, no
  promises of returns.

## 3. Commodity Trading Advisor rules (CFTC)

- The CFTC treats Bitcoin and Ether as commodities. Paid advice about crypto **derivatives** (futures,
  perpetual swaps, options) can meet the definition of a Commodity Trading Advisor.
- The CFTC's 2023 SignalPush consent order treated a signal service that also automated trading as an
  unregistered CTA. Commentators said it widened the definition. Firms that only aggregate signals are
  argued to be different, but exemptions are read narrowly.
- **Lower your risk:** keep alerts about spot-market data, never auto-trade or connect to customer
  exchange accounts, don't publish derivatives trade calls with entries and stops, and keep the Edge
  Lab framed as market structure information. **Ask a lawyer** before marketing anything as
  "trading signals" for futures or perps.

## 4. Money transmission

- FinCEN guidance says non-custodial software that never holds or controls customer funds is not a
  money transmitter. StrikePulse never touches crypto or customer money; Stripe handles card payments.
- Recent DOJ cases against non-custodial developers created some uncertainty, but they involved
  moving funds, which StrikePulse does not do.
- **Don't add** custody, trading, crypto payments or "copy trading" without legal review.

## 5. App stores (watch apps)

- **Apple:** since May 2025, US-storefront apps may include buttons and links to outside web checkouts
  without a special entitlement. Developers still report companion apps for web subscriptions being
  rejected, so read Guideline 3.1 before submitting. Sideloading to your own watch and TestFlight are fine.
- **Google Play:** read Play's financial-services and subscription policies before publishing the Wear OS
  app. Direct APK install and testing tracks are fine.
- Fees: Apple Developer Program $99/yr, Google Play $25 one-time, Chrome Web Store $5 one-time.

## 6. Taxes (Colorado-based seller)

- Colorado has not taxed SaaS at the **state** level, but a 2026 law makes most SaaS taxable statewide
  starting **January 1, 2027**.
- Home-rule cities set their own rules. Denver, Boulder, Colorado Springs and Aurora already tax SaaS,
  and one guide lists Fort Collins too. Roughly 70 home-rule cities file separately.
- Out-of-state sales: many states use a $100,000 economic-nexus threshold.
- Stripe issues a 1099-K. **Stripe Tax** can calculate and collect sales tax automatically. Ask a CPA
  which Colorado registrations you need, especially before 2027.

## 7. Everyday rules

- **No earnings claims** ("make $500/day"). Show the honest Results page instead.
- **Trademarks:** don't use exchange or coin logos in ways that suggest a partnership. The app shows
  letter avatars, not logos.
- Label paid promotions as ads. Keep the Terms, Privacy and Risk pages up to date and have a lawyer
  review them before you scale.

## Sources
- Coinbase Market Data Terms of Use: https://www.coinbase.com/legal/market_data
- CoinGecko API pricing and license FAQ: https://www.coingecko.com/en/api/pricing
- CoinGecko API Terms: https://www.coingecko.com/en/api_terms
- Lowe v. SEC, 472 U.S. 181 (1985): https://www.law.cornell.edu/supremecourt/text/472/181
- CFTC CTA definition and SignalPush commentary: https://btlaw.com/insights/alerts/2023/does-the-cftc-require-trading-screens-and-technology-providers-to-register-as-ctas
- FinCEN 2019 CVC guidance: https://www.fincen.gov/sites/default/files/2019-05/FinCEN%20Guidance%20CVC%20FINAL%20508.pdf
- Apple US guideline changes (May 2025): https://www.macrumors.com/2025/05/01/apple-updates-u-s-app-review-guidelines-epic/
- Colorado SaaS tax from 2027: https://natlawreview.com/article/colorado-expands-sales-tax-saas-and-downloaded-software-beginning-jan-1-2027
- Colorado home-rule SaaS taxability: https://www.getsphere.com/blog/is-saas-taxable-in-colorado
