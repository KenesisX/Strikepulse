#!/usr/bin/env bash
# Start StrikePulse.  PORT=8000 HOST=0.0.0.0 ./start.sh
cd "$(dirname "$0")"
[[ -d .venv ]] || { echo "Run ./install.sh first"; exit 1; }
[[ -f .env ]] || .venv/bin/python -m app.setup
exec .venv/bin/uvicorn app.main:app --host "${HOST:-0.0.0.0}" --port "${PORT:-8000}" --workers 1 --proxy-headers
