# Changelog

## 1.5.0
- **Every major cryptocurrency:** new whole-market layer (top 250 by market cap) from CoinGecko or CoinMarketCap, with an offline list of 100 major coins as a fallback. New public **Markets** page (search, sort, 7-day sparklines, top gainers/losers) and `/api/universe`.
- `SYMBOLS=auto` live-streams the top N coins (`AUTO_SYMBOLS_TOP`, default 25).
- Watch **any** major coin. Coins that aren't live-streamed get big-move alerts and show on devices.
- New **big-mover alerts** across the whole market (Pro/Elite, adjustable threshold). Watched coins always alert on big moves.
- **Companion devices:** Devices page, 6-digit pairing, per-device read-only keys, compact device API (`/api/device/status|alerts|text|pair|me`). Plan limits: 2 / 10 / 50 devices.
- **Companion apps** in `companions/`: Galaxy Watch / Wear OS (app, Tile, complication), Apple Watch (app + WidgetKit complication), ESP32 desk ticker (CYD, ST7789, OLED), Raspberry Pi monitor (GUI/terminal, GPIO buzzer+LED), MicroPython (Pico W/ESP32), browser extension (MV3), desktop tray app, Home Assistant package. GitHub Actions builds the firmware, APK, watch app and extension.
- **Cloudflare:** `docker compose --profile cloudflare up -d` (Tunnel, no open ports), `deploy/cloudflare/install-tunnel.sh` for Pi/VPS without Docker, `TRUST_CLOUDFLARE` for real visitor IPs, SSE marked no-transform.
- Setup wizard asks for market-data provider and Cloudflare Tunnel token. Signed-in menu collapses to a burger below 1240 px.
- `docs/LEGAL_NOTES.md`: data-licensing, adviser/CTA, money-transmission, app-store and tax notes.

## 1.4.1
- New in-app Help center at /help (getting started, every page explained, billing, FAQ), linked in the top menu and footer, added to the sitemap.
- New scripts/reset_password.py: reset any account's password from the server, no email needed (`--admin` to grant admin).
- Full owner Setup & How-To Guide (demo, accounts, deploy, Stripe payouts, settings reference, operations, selling, troubleshooting, launch checklist).

## 1.4.0 (2026-11-23)
**Faster**
- Vectorised the hot paths: EMA/RSI via C-level IIR filters, O(n) rolling statistics, O(n log w) trailing max/min, GARCH likelihood via `lfilter` (395 ms → 9 ms), BOCPD with precomputed run-length constants, Monte Carlo vectorised across paths (298 ms → 15 ms)
- Retraining 26.7 s → 5.7 s: recency weighting by weighted resampling instead of scikit-learn's slow weighted binning
- Divide and conquer: per-coin feature building runs in a spawn-based process pool (`QUANT_WORKERS`) and is cached, rebuilt only for coins with a new candle
- Attention-based priority scheduler: coins with unusual activity, price moves, watchers, live viewers or fresh events are re-analysed every 10–20 s, quiet coins every few minutes; 5-minute candle closes trigger immediately; stale data (>2 min) forces "stand aside"
- Engine performance panel (priority queue + stage timings); test suite 78 s → 19 s
- Fixed: thread-safety snapshots for live buffers read by worker threads

**New analysis**
- Pattern Memory: last-24h shape + dollar volume matched across every coin's history, de-duplicated, own-coin vs cross-coin outcomes (volatility-rescaled), base-rate comparison, "unlikeliness" (tail probability, 1-in-N days, volume percentile); added as a 5th ensemble voter
- Bet Simulator (`/simulator`): bankroll, stake ($ or %), hold time, strategy (daily, dip, momentum, Quant Engine, DCA), entry hour/day, stop-loss/take-profit, 1-year replay with fees, 5,000-path Monte Carlo, risk of ruin, Kelly, best entry hour/day
- World & Macro (`/world`): Fear & Greed, GDELT world-news tone + crisis-news volume, World Bank GDP / growth / GDP per person / inflation / government debt / unemployment for 20 economies, optional FRED (rates, yield curve, dollar, VIX, S&P 500); conditional forward returns per bucket, 90-day correlations, macro tilt
- Wavelet multi-scale decomposition, volume profile (POC, value area, VWAP), transfer-entropy information flow between coins, mutual-information feature ranking
- One year of hourly history backfilled at boot (`HOURLY_BACKFILL_DAYS`)

## 1.3.0 (2026-11-23)
- **Continuous adaptation**: a challenger model is trained every hour (`QUANT_RETRAIN_MINUTES`) with recency-weighted data (`QUANT_HALF_LIFE_DAYS`) and promoted only if it beats the champion on data the champion never saw; drift monitor (Population Stability Index, 7-day window) triggers early retrains; models persist to `data/quant_model.pkl` and survive restarts; online learner and regime-weighted ensemble keep learning between retrains
- **Adaptive conformal prediction**: 95% (configurable) 4-hour price ranges whose live hit rate self-corrects under changing volatility; live coverage displayed
- **Precision dial**: accuracy vs how often the model speaks; stances require a minimum historical precision at that confidence (`QUANT_MIN_PRECISION`)
- **Math Lab** (all from first principles): Kalman local-linear-trend filter, GARCH(1,1) MLE volatility forecasts, Hurst exponent (DFA), permutation entropy, Bayesian online change-point detection, Ornstein-Uhlenbeck mean reversion, Hawkes self-excitation of trade flow, FFT dominant cycle, Engle-Granger cointegration across all coin pairs
- Five Math Lab signals added as model features (43 total)
- Live feed formats re-verified against current Coinbase Exchange and Kraken v2 docs

## 1.2.0 (2026-11-23)
- **Quant Engine** (`/quant`, Pro+): signal detection separated from sizing and execution
  - Gradient-boosted trees (scikit-learn HistGradientBoosting, i.e. the LightGBM algorithm; real LightGBM used if installed) on 38 engineered features: multi-timeframe momentum, realized volatility, variance ratio, autocorrelation, trend distance, calendar, BTC beta/correlation, and graph message-passing features over the live coin-correlation network
  - Purged, embargoed walk-forward validation; cross-fitted isotonic calibration; fee + slippage-aware backtest; automatic deploy gate that benches the model when it can't beat the base rate after costs
  - Regime classifier (Gaussian mixture): trending up / trending down / range / high-volatility stress
  - Online logistic learner (AdaGrad) on live order-flow features with Page-Hinkley drift detection
  - Hedge (exponential-weights) ensemble with separate weights per regime over GBDT, online learner, historical analogs and rule confluence
  - Decision layer: probability → stance, quarter-Kelly volatility-capped risk budget, stress-regime and drawdown circuit breakers, expected edge after costs
  - Live paper track of the engine's own calls; model card with OOS metrics, equity curves, permutation feature importance
- **Edge Lab** (Elite): hidden TWAP/iceberg buyer & seller detection, wash-trade forensics per exchange (Benford, round-lot clustering, repeated sizes), stop-loss cluster map, stop-run detection, bull/bear trap detector, pump signatures, cross-exchange premium + lead-lag, perpetual funding/OI (Kraken Futures), estimated liquidation zones, options max pain / put-call / top strikes (Deribit)
- New alert types: Quant stance flips (Pro+), hidden orders / pump signatures / stop runs (Elite)
- Company name shown as "Strikebacktech"

## 1.1.0 (2026-11-23)
- **Deep Analysis page** (`/analysis`): Pulse Score, Probability Engine (k-nearest historical analogs with base rate, edge, typical move, 10-90% range and confidence interval), price + probability cone, target-odds calculator, order-flow X-ray (taker buy/sell, cumulative delta, whale vs retail), trend matrix with regime, hour x weekday timing heatmap, attention & money rotation, CoinGecko trending, plain-English "what just changed" feed
- Every market alert now carries its historical odds
- Free plan gets full Deep Analysis on BTC-USD; Pro/Elite unlock every coin
- New red / black / grey / white theme across site, charts, emails and Discord embeds
- New pricing: Pro $9.99/mo ($99/yr), Elite $24.99/mo ($249/yr), under TradingView Essential, Whale Alert and CryptoQuant
- About page (founder story, values, contact; all configurable)
- Optional give-back: `CHARITY_NAME` / `CHARITY_PERCENT` shows the donation on pricing, about and footer and tracks the monthly amount in Admin

## 1.0.0 (2026-11-23)
First commercial release.
- Live feeds: Coinbase, Kraken, Binance.US (+ simulator for demos)
- 9 detectors, confluence scoring, cooldowns; backtester (`python -m app.replay`)
- On-chain: whale exchange flows, watched wallets, LP-burn / mint / ownership / flagged-address security alerts, gas, de-peg, new listings
- SaaS: accounts, password reset by email, Free/Pro/Elite plans, Stripe monthly + yearly subscriptions, trials, promo codes, customer portal
- Delivery: Telegram bot, Discord, email, ntfy push, signed webhooks, live dashboard (SSE)
- Growth: public live-accuracy page, free promo channel auto-poster, SEO (sitemap, robots, social cards)
- Admin: MRR, feed health, user management, temp passwords, CSV export, event injection
- Ops: one-command installers (Linux/macOS/Pi/Windows), setup wizard, Docker + Caddy HTTPS, systemd unit, hot backups, automatic schema upgrades
- White-label: name, colors, logo, tagline via .env
