#!/usr/bin/env bash
# Put StrikePulse online through Cloudflare without Docker (VPS, Raspberry Pi at home, any Debian/Ubuntu).
# No router ports to open, free HTTPS, DDoS protection.
#
#   1. Add your domain to Cloudflare (free plan) and switch its nameservers to Cloudflare's.
#   2. Cloudflare dashboard > Zero Trust > Networks > Tunnels > Create a tunnel > Cloudflared.
#      Copy the token from the install command it shows.
#   3. In the tunnel, add a Public Hostname:  yourdomain.com  ->  HTTP  ->  localhost:8000
#   4. Run:  sudo ./install-tunnel.sh <TOKEN>
set -euo pipefail
TOKEN="${1:-}"
if [ -z "$TOKEN" ]; then echo "Usage: sudo $0 <tunnel-token>"; exit 1; fi
if ! command -v cloudflared >/dev/null; then
  mkdir -p --mode=0755 /usr/share/keyrings
  curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg | tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null
  echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main" \
    | tee /etc/apt/sources.list.d/cloudflared.list >/dev/null
  apt-get update -qq && apt-get install -y -qq cloudflared
fi
cloudflared service install "$TOKEN"
systemctl enable --now cloudflared
echo "Tunnel running. Check: systemctl status cloudflared"
echo "In .env set BASE_URL=https://yourdomain.com and TRUST_CLOUDFLARE=true, then restart StrikePulse."
