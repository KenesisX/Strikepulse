@echo off
REM StrikePulse installer for Windows. Requires Python 3.10+ from python.org (tick "Add to PATH").
cd /d "%~dp0"
where python >nul 2>nul || (echo Python not found. Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH". & pause & exit /b 1)
python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" || (echo Python 3.10 or newer is required. & pause & exit /b 1)
echo Creating virtual environment...
python -m venv .venv || (pause & exit /b 1)
.venv\Scripts\python -m pip install --upgrade pip -q
echo Installing dependencies...
.venv\Scripts\pip install -r requirements.txt -q || (pause & exit /b 1)
if not exist data mkdir data
if "%1"=="--demo" (
  .venv\Scripts\python -m app.setup --demo
) else (
  if not exist .env .venv\Scripts\python -m app.setup
)
echo.
echo Installed. Double-click start.bat, then open http://localhost:8000
pause
