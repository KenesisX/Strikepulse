import re
import time

import pytest
from fastapi.testclient import TestClient

from app.main import app


def csrf(html: str) -> str:
    return re.search(r'name="csrf" value="([^"]+)"', html).group(1)


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        from app.services import get_services
        get_services().universe.synthesize()
        yield c


def signup(c, email):
    t = csrf(c.get("/signup").text)
    return c.post("/signup", data={"csrf": t, "email": email, "password": "password123", "agree": "on"})


# ------------------------------------------------------------------ universe
def test_bundled_list_and_auto_symbols():
    from app.coins import auto_symbols, top_coins
    coins = top_coins()
    assert len(coins) >= 90 and coins[0]["symbol"] == "BTC"
    syms = auto_symbols(25)
    assert len(syms) == 25 and syms[0] == "BTC-USD" and "USDT-USD" not in syms


def test_parse_coingecko_and_cmc():
    from app.universe import parse_cmc, parse_coingecko
    cg = parse_coingecko([{"id": "bitcoin", "symbol": "btc", "name": "Bitcoin", "market_cap_rank": 1,
                           "current_price": 90000, "market_cap": 1.8e12, "total_volume": 3e10,
                           "price_change_percentage_1h_in_currency": 0.4, "price_change_percentage_24h_in_currency": -2.1,
                           "price_change_percentage_7d_in_currency": 5.0, "sparkline_in_7d": {"price": list(range(168))}}])
    assert cg[0].symbol == "BTC" and cg[0].ch24h == -2.1 and len(cg[0].spark) == 42 and cg[0].spark[-1] == 167
    cmc = parse_cmc([{"symbol": "ETH", "name": "Ethereum", "slug": "ethereum", "cmc_rank": 2,
                      "quote": {"USD": {"price": 3000, "market_cap": 3.6e11, "volume_24h": 1e10, "percent_change_1h": 1,
                                        "percent_change_24h": 2, "percent_change_7d": 3}}}])
    assert cmc[0].price == 3000 and cmc[0].ch7d == 3


def test_movers_fire_once_and_skip_stables():
    from app.config import settings
    from app.universe import Coin, MarketUniverse
    u = MarketUniverse(settings)
    u._install([Coin("PEPE", "Pepe", "pepe", 30, price=0.00001, ch1h=9.5, ch24h=3),
                Coin("USDT", "Tether", "tether", 3, price=1.0, ch1h=12, stable=True),
                Coin("BTC", "Bitcoin", "bitcoin", 1, price=90000, ch1h=0.2, ch24h=-1)], "test")
    ev = u.detect_movers(now=1000)
    assert [e.symbol for e in ev] == ["PEPE-USD"] and ev[0].kind == "mover" and ev[0].direction == 1
    assert u.detect_movers(now=2000) == []                 # 6 h cooldown
    assert len(u.detect_movers(now=1000 + 7 * 3600)) == 1


def test_mover_matching_rules():
    from app.alerts.dispatcher import UserView, WatchView, match
    from app.engine.types import MarketEvent
    from app.plans import PLANS
    e = MarketEvent(kind="mover", symbol="DOGE-USD", title="x", direction=1, score=80, meta={"pct": 10})
    base = dict(id=1, email="a@b.c", api_key="k", telegram_chat_id=None, discord_webhook=None, ntfy_topic=None,
                webhook_url=None, email_to=None, timezone="UTC", quiet_start=None, quiet_end=None,
                paused_until=None, want_depeg=True, want_listings=False, gas_below=None)
    free = UserView(plan=PLANS["free"], **base)
    assert match(e, free) is None
    free.watches = [WatchView("DOGE-USD", 60, {"15m"}, "both", set())]
    assert match(e, free) == 80                               # watched coin: every plan
    pro = UserView(plan=PLANS["pro"], want_movers=True, movers_min_pct=8, **base)
    assert match(e, pro) == 80
    pro.movers_min_pct = 12
    assert match(e, pro) is None


def test_markets_page_and_api(client):
    r = client.get("/markets")
    assert r.status_code == 200 and "Markets" in r.text and "BTC" in r.text and "<polyline" in r.text
    j = client.get("/api/universe?limit=20&spark=1").json()
    assert j["count"] >= 20 and len(j["coins"]) == 20 and j["coins"][0]["symbol"] == "BTC" and j["coins"][0]["spark"]
    assert "/markets" in client.get("/sitemap.xml").text


def test_watch_any_major_coin(client):
    signup(client, "uni@example.com")
    page = client.get("/dashboard").text
    assert "Every other major coin" in page
    t = csrf(page)
    r = client.post("/watches", data={"csrf": t, "symbol": "TRX-USD", "timeframes": "15m", "from": "markets"},
                    follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/markets"
    assert "Watching TRX-USD" in client.get("/markets").text or "Watching" in client.get("/markets").text


# ------------------------------------------------------------------ devices
def test_device_pair_status_text_revoke(client):
    signup(client, "dev@example.com")
    page = client.get("/devices")
    assert page.status_code == 200 and "Add device" in page.text
    r = client.post("/devices", data={"csrf": csrf(page.text), "kind": "esp32", "name": "Desk ESP32"},
                    follow_redirects=True)
    code = re.search(r'class="pair-code"[^>]*>(\d{3}) (\d{3})<', r.text)
    assert code, "pairing code shown"
    code = code.group(1) + code.group(2)
    token = re.search(r'<pre class="token-box">(spd_[^<]+)</pre>', r.text).group(1)

    bad = client.post("/api/device/pair", json={"code": "000000" if code != "000000" else "111111"})
    assert bad.status_code == 404
    ok = client.post("/api/device/pair", json={"code": code}).json()
    assert ok["token"] == token and ok["kind"] == "esp32"
    assert client.post("/api/device/pair", json={"code": code}).status_code == 404     # one-time

    h = {"Authorization": f"Bearer {token}"}
    assert client.get("/api/device/me", headers=h).json()["ok"] is True
    st = client.get("/api/device/status?symbols=BTC,ETH,DOGE&spark=1", headers=h).json()
    assert st["v"] == 1 and {p["s"] for p in st["prices"]} >= {"BTC", "ETH", "DOGE"}
    assert "alerts" in st and st["refresh"] in (15, 60)
    assert any("sp" in p for p in st["prices"])
    txt = client.get(f"/api/device/text?token={token}&symbols=BTC").text
    assert txt.startswith("BTC ")
    assert client.get("/api/device/alerts", headers={"X-Device-Token": token}).json()["v"] == 1
    assert client.get("/api/device/status").status_code == 401
    assert client.get("/api/device/status", headers={"Authorization": "Bearer spd_nope"}).status_code == 401

    # the token is no longer displayed after first use
    page = client.get("/devices").text
    assert token not in page and "Desk ESP32" in page and "min ago" in page

    did = re.search(r'/devices/(\d+)/revoke', page).group(1)
    client.post(f"/devices/{did}/revoke", data={"csrf": csrf(page)})
    assert client.get("/api/device/me", headers=h).status_code == 401


def test_device_limit_and_rearm(client):
    signup(client, "limit@example.com")
    for i in range(2):
        p = client.get("/devices").text
        client.post("/devices", data={"csrf": csrf(p), "kind": "pi", "name": f"Pi {i}"})
    p = client.get("/devices").text
    assert "Device limit reached" in p
    did = re.search(r'/devices/(\d+)/rearm', p).group(1)
    r = client.post(f"/devices/{did}/rearm", data={"csrf": csrf(p)}, follow_redirects=True)
    assert "pair-code" in r.text


def test_companions_page(client):
    r = client.get("/companions")
    assert r.status_code == 200 and "Galaxy Watch" in r.text and "Apple Watch" in r.text and "ESP32" in r.text


def test_cloudflare_ip_trust(monkeypatch):
    from starlette.requests import Request

    from app.config import settings
    from app.security import client_ip
    req = Request({"type": "http", "headers": [(b"cf-connecting-ip", b"9.9.9.9"), (b"x-forwarded-for", b"1.1.1.1")],
                   "client": ("127.0.0.1", 1)})
    monkeypatch.setattr(settings, "trust_cloudflare", False)
    assert client_ip(req) == "1.1.1.1"
    monkeypatch.setattr(settings, "trust_cloudflare", True)
    assert client_ip(req) == "9.9.9.9"
