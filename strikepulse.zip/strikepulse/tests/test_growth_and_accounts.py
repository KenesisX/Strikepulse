import re
import time

from fastapi.testclient import TestClient

from app.engine.types import Candle, MarketEvent


def csrf(html):
    return re.search(r'name="csrf" value="([^"]+)"', html).group(1)


# ---------------------------------------------------------------- performance tracking
class FakeSeries:
    def __init__(self, candles):
        self.c = candles

    def history(self, include_current=False):
        return self.c


class FakeBook:
    def __init__(self, series):
        self.series = series


class FakeEngine:
    def __init__(self, t0):
        cs = [Candle("BTC-USD", 60, t0 + i * 60, 100, 100, 100, 100 + i, 1) for i in range(300)]
        self.book = FakeBook({("BTC-USD", 60): FakeSeries(cs)})
        self.prices = {}


def test_performance_tracker_resolves_and_summarizes():
    from app import db
    from app.config import settings
    from app.growth import PerformanceTracker, performance_summary
    from app.main import app  # noqa: F401  (ensures DB init via conftest env)
    db.init_db(settings.database_url)
    t0 = time.time() - 300 * 60
    tr = PerformanceTracker(settings, bus=None, engine=FakeEngine(t0))
    e = MarketEvent(kind="market", symbol="BTC-USD", title="t", direction=1, score=82, price=100.0, timeframe="5m", ts=t0)
    tr.schedule(e)
    tr.schedule(MarketEvent(kind="market", symbol="BTC-USD", title="m", direction=1, score=90, price=1, meta={"manual": True}))
    assert tr.status["scheduled"] == len(settings.outcome_horizons)
    assert tr.resolve_due() == len(settings.outcome_horizons)
    perf = performance_summary(30)
    h = settings.outcome_horizons[0]
    assert perf["overall"][h]["n"] >= 1 and perf["overall"][h]["hit"] == 1.0
    assert perf["by_score"][h]["80-100"]["n"] >= 1


# ---------------------------------------------------------------- promo poster
def test_promo_filters_rate_limits_and_renders(monkeypatch):
    from app.config import settings
    from app.growth import PromoPoster
    monkeypatch.setattr(settings, "promo_max_per_hour", 2)
    p = PromoPoster(settings, bus=None)
    strong = MarketEvent(kind="market", symbol="BTC-USD", title="BTC up", direction=1, score=85, price=1)
    assert p.wants(strong)
    assert not p.wants(MarketEvent(kind="market", symbol="X", title="weak", score=50))
    assert not p.wants(MarketEvent(kind="security", symbol="X", title="sec", score=99))
    assert p._rate_ok() and p._rate_ok() and not p._rate_ok()
    tg, dc = p.render(strong)
    assert "/pricing" in tg and "/pricing" in dc["content"]


# ---------------------------------------------------------------- billing
def test_yearly_price_mapping(monkeypatch):
    from app import billing
    from app.config import settings
    monkeypatch.setattr(settings, "stripe_price_pro_yearly", "price_pro_y")
    assert billing.plan_for_price("price_pro_y") == "pro"
    assert billing.price_for("pro", "year") == "price_pro_y"
    assert billing.plan_for_price("price_unknown") == "free"


# ---------------------------------------------------------------- web: reset, seo, admin
def test_reset_token_and_pages():
    from app.db import session_scope
    from app.main import app
    from app.models import User
    from app.routes.auth import make_reset_token, read_reset_token
    from app.security import hash_password
    from sqlalchemy import select
    with TestClient(app) as c:
        for p in ("/robots.txt", "/sitemap.xml", "/manifest.webmanifest", "/performance", "/forgot", "/api/performance"):
            assert c.get(p).status_code == 200, p
        t = csrf(c.get("/forgot").text)
        r = c.post("/forgot", data={"csrf": t, "email": "x@y.com"})
        assert "isn&#39;t enabled" in r.text or "isn't enabled" in r.text     # no SMTP in tests
        with session_scope() as db:
            u = db.scalar(select(User).where(User.email == "reset@test.com"))
            if not u:
                u = User(email="reset@test.com", password_hash=hash_password("oldpassword"))
                db.add(u)
                db.flush()
            token = make_reset_token(u)
        assert "invalid or has expired" in c.get("/reset?token=garbage").text
        r = c.get(f"/reset?token={token}")
        assert "Choose a new password" in r.text and 'name="password"' in r.text
        r = c.post("/reset", data={"csrf": csrf(r.text), "token": token, "password": "brandnew123"})
        assert r.url.path == "/dashboard"
        with session_scope() as db:
            u = db.scalar(select(User).where(User.email == "reset@test.com"))
            assert read_reset_token(token, db) is None          # one-time: dead after the change


def test_admin_tools():
    from app.main import app
    with TestClient(app) as c:
        t = csrf(c.get("/signup").text)
        c.post("/signup", data={"csrf": t, "email": "admintools@test.com", "password": "password123", "agree": "on"})
        from app.db import session_scope
        from app.models import User
        from sqlalchemy import select
        with session_scope() as db:
            u = db.scalar(select(User).where(User.email == "admintools@test.com"))
            u.is_admin = True
            uid = u.id
        r = c.get("/admin/export.csv")
        assert r.status_code == 200 and "admintools@test.com" in r.text
        t = csrf(c.get("/admin").text)
        r = c.post(f"/admin/users/{uid}/reset-password", data={"csrf": t})
        assert "Temporary password" in r.text


def test_setup_demo_writes_env(tmp_path, monkeypatch):
    from app import setup
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(setup, "ENV", tmp_path / ".env")
    assert setup.main(["--demo"]) == 0
    text = (tmp_path / ".env").read_text()
    assert "FEEDS=simulator" in text and "SECRET_KEY=" in text
