import math
import random
import re
import time

import numpy as np
from fastapi.testclient import TestClient

from app.engine.types import Candle, Trade
from app.quant.edge import (AuthenticityScorer, Derivatives, HiddenOrderDetector, detect_stop_run, stop_clusters,
                            trap_score)
from app.quant.features import FEATURES, HORIZON, build_panel
from app.quant.models import (DirectionModel, HedgeEnsemble, OnlineLogit, RegimeModel, backtest, decide,
                              purged_walk_forward)


def coins(n=1400, signal=0.0, seed=1, k=4):
    """Hourly candles for k coins. With signal>0, returns are predictable from the previous 3h move."""
    rng = random.Random(seed)
    start = int(time.time() // 3600) * 3600 - n * 3600
    out = {}
    common = [rng.gauss(0, 0.004) for _ in range(n)]
    for j, s in enumerate(["BTC-USD", "ETH-USD", "SOL-USD", "XRP-USD"][:k]):
        p, cs, rets = 100.0 * (j + 1), [], []
        for i in range(n):
            mom = sum(rets[-3:]) if len(rets) >= 3 else 0
            r = common[i] * 0.6 + rng.gauss(0, 0.004) + signal * np.sign(mom) * 0.004
            o = p
            p *= math.exp(r)
            rets.append(r)
            cs.append(Candle(s, 3600, start + i * 3600, o, max(o, p) * 1.001, min(o, p) * 0.999, p, 100 * rng.lognormvariate(0, .3), 50, 10))
        out[s] = cs
    return out


def test_panel_no_lookahead_and_shape():
    series = coins(600)
    panel = build_panel(series)
    T, X, fwd, close = panel["ETH-USD"]
    assert X.shape[1] == len(FEATURES)
    # features at t must not change if the future is removed
    cut = {s: cs[:500] for s, cs in series.items()}
    T2, X2, _, _ = build_panel(cut)["ETH-USD"]
    i = 450
    j = int(np.where(T2 == T[i])[0][0])
    a, b = X[i], X2[j]
    m = np.isfinite(a) & np.isfinite(b)
    assert np.allclose(a[m], b[m], atol=1e-9)
    assert np.isnan(fwd[-HORIZON:]).all()


def test_purged_walk_forward_has_gap():
    t = np.repeat(np.arange(0, 3000) * 3600.0, 3)
    for tr, te in purged_walk_forward(t):
        assert t[tr].max() + (HORIZON + 24) * 3600 <= t[te].min()


def test_model_deploys_with_signal_and_benches_without():
    good = DirectionModel().train(build_panel(coins(1400, signal=0.9, seed=3)))
    assert good["status"] == "deployed", good.get("oos")
    assert good["oos"]["auc"] > 0.6
    bad = DirectionModel().train(build_panel(coins(1400, signal=0.0, seed=4)))
    assert bad["status"] == "benched"


def test_regime_model_labels():
    panel = build_panel(coins(900, seed=5))
    X = np.vstack([p[1] for p in panel.values()])
    rm = RegimeModel()
    rm.fit(X)
    assert set(rm.labels.values()) == set(RegimeModel.NAMES)
    name, probs = rm.predict(X[-1])
    assert name in RegimeModel.NAMES and abs(sum(probs.values()) - 1) < 1e-6


def test_online_logit_learns_and_hedge_reweights():
    ol = OnlineLogit(2)
    rng = random.Random(1)
    for _ in range(3000):
        x = [rng.gauss(0, 1), rng.gauss(0, 1)]
        ol.update(x, int(x[0] + 0.3 * rng.gauss(0, 1) > 0))
    assert ol.predict([2, 0]) > 0.8 and ol.predict([-2, 0]) < 0.2
    h = HedgeEnsemble(["good", "bad"])
    for i in range(200):
        y = i % 2
        h.update("r", {"good": 0.8 if y else 0.2, "bad": 0.2 if y else 0.8}, y)
    w = h.weights("r")
    assert w["good"] > 0.95
    p, _ = h.combine("r", {"good": 0.7, "bad": 0.3})
    assert p > 0.65


def test_decide_respects_costs_and_breakers():
    card = {"backtest": {"trades": 100, "avg_win": 0.01, "avg_loss": -0.01}}
    assert decide(0.51, 0.005, "range / mean-reverting", card)["stance"] == "STAND ASIDE"
    strong = decide(0.68, 0.01, "trending up", card)
    assert strong["stance"] == "LONG BIAS" and 0 < strong["size"] <= 0.2
    assert decide(0.68, 0.01, "trending up", card, live_dd=-0.2)["size"] == 0
    assert decide(0.32, 0.01, "trending down", card)["stance"] == "SHORT / CASH BIAS"


def test_backtest_charges_costs():
    t = np.arange(100) * 3600.0 * HORIZON
    r = np.zeros(100)
    bt = backtest(np.full(100, 0.9), r, t, np.array(["X"] * 100))
    assert bt["total_return"] < 0                     # flat market + fees = loss


def test_hidden_order_detector():
    d = HiddenOrderDetector(min_usd=10_000)
    now = time.time()
    rng = random.Random(2)
    for i in range(400):
        d.on_trade(Trade("x", "BTC-USD", 100, rng.uniform(.1, 3), rng.choice(["buy", "sell"]), now - 800 + i * 2))
    for i in range(40):
        d.on_trade(Trade("x", "BTC-USD", 100, 7.5, "buy", now - 600 + i * 12 + rng.uniform(-1, 1)))
    found = d.scan("BTC-USD", now)
    assert found and found[0]["side"] == "buy" and found[0]["unit_size"] == 7.5 and found[0]["prints"] >= 30
    assert d.new_events("BTC-USD", found, alert_usd=1000)


def test_authenticity_flags_wash_pattern():
    rng = np.random.default_rng(0)
    genuine = rng.lognormal(0, 1.2, 3000)
    genuine[::7] = np.round(genuine[::7]) + 1
    wash = np.concatenate([np.full(1500, 0.4537), rng.uniform(0.6, 0.9, 1500)])
    g, w = AuthenticityScorer.analyse(genuine), AuthenticityScorer.analyse(wash)
    assert g["score"] > w["score"] and w["verdict"] != "looks genuine"


def test_stop_run_and_clusters_and_trap():
    base = [Candle("X", 900, i * 900, 100, 100.5, 99.5, 100, 10) for i in range(50)]
    sweep = Candle("X", 900, 50 * 900, 100, 100.2, 99.0, 100.1, 30)
    sr = detect_stop_run(base + [sweep])
    assert sr and sr["direction"] == 1
    hourly = [Candle("X", 3600, i * 3600, 100, 101 + (i % 7 == 0) * 2, 99 - (i % 5 == 0) * 2, 100, 1) for i in range(200)]
    sc = stop_clusters(hourly, 100)
    assert sc["above"] and sc["below"] and all(l["price"] > 100 for l in sc["above"])
    tr = trap_score(1, -0.5, 0.3, 0.5)
    assert tr["risk"] >= 0.99 and tr["type"] == "bull trap"


def test_options_max_pain_and_liquidations():
    exp = time.strftime("%d%b%y", time.gmtime(time.time() + 5 * 86400)).upper()
    rows = [{"instrument_name": f"BTC-{exp}-{k}-{t}", "open_interest": oi}
            for k, t, oi in [(90000, "P", 500), (100000, "C", 500), (95000, "C", 50), (95000, "P", 50)]]
    s = Derivatives.options_summary(rows)
    assert s["max_pain"] == 95000 and s["put_call_oi"] == 1.0
    d = Derivatives(False, lambda s: 100.0)
    d._record_oi("BTC", 100.0, 1000, 0)
    d._record_oi("BTC", 100.0, 2000, 300)
    z = d.liq_zones("BTC", 100.0)
    assert sum(z["longs"]) > 0 and sum(z["shorts"]) > 0
    d._record_oi("BTC", 85.0, 2000, 600)              # crash through the 10x long level
    assert all(abs(k) < 90 or k < 0 for k in d.liq["BTC"])


def csrf(h):
    return re.search(r'name="csrf" value="([^"]+)"', h).group(1)


def test_quant_page_and_gating():
    from app.main import app
    with TestClient(app) as c:
        t = csrf(c.get("/signup").text)
        c.post("/signup", data={"csrf": t, "email": "quant@test.com", "password": "password123", "agree": "on"})
        assert c.get("/quant").status_code == 200
        j = c.get("/api/quant?symbol=BTC-USD").json()
        assert j["quant_ok"] is False and "teaser" in j and "model" not in j
        t = csrf(c.get("/dashboard").text)
        c.post("/billing/checkout/pro", data={"csrf": t})
        j = c.get("/api/quant?symbol=BTC-USD").json()
        assert j["quant_ok"] and "model" in j and "edge" not in j
        c.post("/billing/checkout/elite", data={"csrf": csrf(c.get("/dashboard").text)})
        j = c.get("/api/quant?symbol=BTC-USD").json()
        assert j["edge_ok"] is True


def test_champion_challenger_and_persistence(tmp_path, monkeypatch):
    from app.config import settings
    from app.quant import service as svc_mod
    from app.quant.service import QuantEngine
    monkeypatch.setattr(svc_mod, "MODEL_PATH", str(tmp_path / "m.pkl"))
    full = coins(1500, signal=0.9, seed=7)

    class StubAnalytics:
        def __init__(self, n):
            self.n = n
            self.hourly = {s: None for s in full}

        def candles(self, s, tf):
            return full[s][: self.n] if tf == 3600 else []

    class StubEngine:
        stable_symbols = set()
        prices = {}

    an = StubAnalytics(1300)
    q = QuantEngine(StubEngine(), an, settings, bus=None)
    q.train_now()
    assert q.history[-1]["promoted"] and q.direction.card["status"] == "deployed"
    first_end = q.direction.card["data_end"]
    an.n = 1500                                  # 200 new hours arrive
    q.train_now()
    h = q.history[-1]
    assert "forward" in h["why"] or "refreshed" in h["why"]
    assert q.direction.card["data_end"] >= first_end
    q2 = QuantEngine(StubEngine(), an, settings, bus=None)
    q2._load_model()
    assert q2.direction.model is not None and q2.direction.card["status"] == "deployed"
    q.check_drift()
    assert "share_drifting" in q.drift
