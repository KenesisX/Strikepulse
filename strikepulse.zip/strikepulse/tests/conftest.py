import os
import sys
import tempfile
from pathlib import Path

_tmp = tempfile.mkdtemp()
os.environ.update({
    "DATABASE_URL": f"sqlite:///{_tmp}/test.db",
    "DISABLE_BACKGROUND": "1",
    "SECRET_KEY": "test-secret",
    "FEEDS": "simulator",
    "DEV_FAKE_BILLING": "1",
    "STRIPE_WEBHOOK_SECRET": "whsec_test123",
    "STRIPE_PRICE_PRO": "price_pro_test",
    "STRIPE_PRICE_ELITE": "price_elite_test",
    "ADMIN_EMAIL": "",
    "ADMIN_PASSWORD": "",
})
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402


@pytest.fixture(autouse=True)
def _reset_rate_limits():
    """Every test signs up from the same fake IP; don't let the sign-up limiter leak between tests."""
    from app import security
    from app.routes import devices
    for lim in (security.login_limiter, security.signup_limiter, devices.pair_limiter, devices.status_limiter):
        lim.hits.clear()
    yield
