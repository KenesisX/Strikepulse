import math
import random
import re
import time

import numpy as np
from fastapi.testclient import TestClient

from app.engine.types import Candle
from app.quant import mathlab as M
from app.quant.betsim import simulate
from app.quant.macro import FNG_ZONES, conditional_stats
from app.quant.patterns import PatternMemory
from app.quant.scheduler import PriorityScheduler


def year(seed=1, drift=0.0, sym="X", n=24 * 370, vol=0.008):
    rng = random.Random(seed)
    start = int(time.time() // 3600) * 3600 - n * 3600
    p, out = 100.0, []
    for i in range(n):
        o = p
        p *= math.exp(drift + rng.gauss(0, vol))
        v = 1000 * rng.lognormvariate(0, .4)
        out.append(Candle(sym, 3600, start + i * 3600, o, max(o, p) * 1.001, min(o, p) * 0.999, p, v, v / 2, 1))
    return out


def test_pattern_memory_finds_repeating_motif():
    # a coin where a sharp 24h dip is always followed by a rebound
    cs = year(1)
    rng = random.Random(9)
    closes = [c.close for c in cs]
    for start in range(500, len(cs) - 200, 300):
        for k in range(24):
            closes[start + k] *= math.exp(-0.004 * k)
        for k in range(24, 100):
            closes[start + k] = closes[start + 23] * math.exp(0.004 * (k - 23) + rng.gauss(0, .001))
    last = len(cs) - 30
    for k in range(24):
        closes[last + k] = closes[last - 1] * math.exp(-0.004 * k)
    cs = cs[: last + 24]
    cs = [Candle("X", 3600, c.start, cl, cl * 1.001, cl * 0.999, cl, c.volume, c.buy_volume, 1) for c, cl in zip(cs, closes)]
    pm = PatternMemory()
    pm.build({"X": cs, "Y": year(2, sym="Y")})
    r = pm.query("X")
    assert r["own"]["24"]["p_up"] > 0.7 and r["own"]["n"] >= 10
    assert r["unlikeliness"]["label"] in ("rare", "extremely rare", "uncommon")


def test_pattern_memory_is_calibrated_on_noise():
    pm = PatternMemory()
    pm.build({"A": year(3, sym="A"), "B": year(4, sym="B"), "C": year(5, sym="C")})
    r = pm.query("A")
    assert 0.3 < r["combined"]["24"]["p_up"] < 0.7
    assert r["own"]["n"] == 30 and r["cross"]["n"] == 30


def test_bet_simulator_math():
    up = year(6, drift=0.0003)
    r = simulate(up, 1000, 100, "fixed", 24, "every_day")
    assert r["trades"] > 100 and r["monte_carlo"]["prob_profit"] > 0.5 and r["expected_return_per_bet"] > 0
    flat = year(7, vol=1e-6)
    f = simulate(flat, 1000, 100, "fixed", 24, "every_day")
    assert abs(f["expected_return_per_bet"] + 0.003) < 1e-3          # flat market: you pay fees
    d = simulate(up, 1000, 50, "fixed", 24, "dca")
    assert d["buys"] >= 50 and d["final_value"] > d["invested"]
    s = simulate(year(8), 1000, 10, "percent", 72, "every_day", stop=0.02, take=0.02)
    assert s["avg_win"] <= 0.02 and s["avg_loss"] >= -0.02 - 0.0031
    assert set(s["timing"]["by_hour"]) == set(range(24))


def test_conditional_stats_buckets():
    prices = {d: 100 * math.exp(0.001 * d) for d in range(19000, 19600)}
    fng = {d: (10 if d % 2 else 90) for d in prices}
    st = conditional_stats(fng, prices, FNG_ZONES)
    names = [b["bucket"] for b in st["buckets"] if b["days"]]
    assert names == ["extreme fear", "extreme greed"] and st["current_bucket"] in names
    assert st["buckets"][0]["fwd_30d"]["p_up"] == 1.0


def test_wavelets_volume_profile_transfer_entropy():
    rng = np.random.default_rng(0)
    p = 100 * np.exp(np.cumsum(rng.normal(0, .002, 900)) + 0.04 * np.sin(np.arange(900) * 2 * np.pi / 32))
    assert M.wavelet_scales(p)["dominant_hours"] in (16, 32)
    x = rng.normal(size=2000)
    y = np.concatenate([[0], x[:-1]]) + rng.normal(size=2000) * 0.5
    assert M.transfer_entropy(x, y) > 10 * M.transfer_entropy(y, x)
    cs = [Candle("X", 900, i, 100, 100.5, 99.5, 100, 10) for i in range(100)]
    vp = M.volume_profile(cs)
    assert vp["value_low"] <= vp["poc"] <= vp["value_high"]


def test_scheduler_prioritises_activity():
    s = PriorityScheduler(base_interval=300, min_interval=10, per_tick=2)
    s.score("HOT", heat=3.0, move_z=3.0, watchers=10)
    s.score("COLD", heat=1.0, move_z=0.0, watchers=0)
    assert s.due(["COLD", "HOT"])[0] == "HOT"
    s.done("HOT")
    s.done("COLD")
    assert s.next_due["HOT"] < s.next_due["COLD"]
    s.trigger("COLD")
    assert "COLD" in s.due(["COLD", "HOT"])


def csrf(h):
    return re.search(r'name="csrf" value="([^"]+)"', h).group(1)


def test_simulator_and_world_pages():
    from app.main import app
    from app.services import get_services
    with TestClient(app) as c:
        svc = get_services()
        svc.analytics.hourly_series("BTC-USD").seed(year(11, sym="BTC-USD"))
        svc.analytics.hourly_series("ETH-USD").seed(year(12, sym="ETH-USD"))
        t = csrf(c.get("/signup").text)
        c.post("/signup", data={"csrf": t, "email": "sim@test.com", "password": "password123", "agree": "on"})
        for p in ("/simulator", "/world"):
            assert c.get(p).status_code == 200
        r = c.post("/api/simulate", json={"symbol": "BTC-USD", "days": 90})
        assert r.status_code == 200 and r.json()["trades"] > 10
        assert c.post("/api/simulate", json={"symbol": "ETH-USD", "days": 90}).status_code == 403
        assert c.post("/api/simulate", json={"symbol": "BTC-USD", "days": 365}).status_code == 403
        c.post("/billing/checkout/pro", data={"csrf": csrf(c.get("/dashboard").text)})
        r = c.post("/api/simulate", json={"symbol": "ETH-USD", "days": 365, "strategy": "dip", "threshold": 0.02})
        assert r.status_code == 200 and r.json()["monte_carlo"]["paths"] == 5000
        assert c.get("/api/macro").json()["locked"] is False
