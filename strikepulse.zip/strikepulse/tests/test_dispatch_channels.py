import pytest

from app.alerts import formatting
from app.alerts.channels import sign, validate_outbound_url
from app.alerts.dispatcher import UserView, WatchView, effective_score, match
from app.engine.types import MarketEvent
from app.plans import PLANS


def user(plan="pro", watches=None, **kw):
    base = dict(id=1, email="a@b.c", plan=PLANS[plan], api_key="k", telegram_chat_id="1", discord_webhook=None,
                ntfy_topic=None, webhook_url=None, email_to=None, timezone="UTC", quiet_start=None, quiet_end=None,
                paused_until=None, want_depeg=True, want_listings=True, gas_below=5,
                watches=watches if watches is not None else [WatchView("BTC-USD", 60, {"5m", "15m"}, "both", set())],
                onchain={})
    base.update(kw)
    return UserView(**base)


def market(score_sigs=(("ema_cross", 1.0), ("cusum_shift", 1.0)), tf="15m", direction=1, symbol="BTC-USD"):
    return MarketEvent(kind="market", symbol=symbol, title="t", direction=direction, score=90, timeframe=tf,
                       signals=[{"detector": d, "direction": direction, "strength": s, "detail": d} for d, s in score_sigs],
                       meta={"interval": {"1m": 60, "5m": 300, "15m": 900}[tf]})


def test_match_market_basic_and_filters():
    assert match(market(), user()) is not None
    assert match(market(tf="1m"), user()) is None                       # tf not on watch
    assert match(market(symbol="ETH-USD"), user()) is None
    assert match(market(direction=-1), user(watches=[WatchView("BTC-USD", 0, {"15m"}, "up", set())])) is None


def test_free_plan_rescored_without_pro_detectors():
    ev = market((("cusum_shift", 1.0), ("momentum", 1.0)))             # both Pro-only detectors
    assert match(ev, user()) is not None
    free = user("free", watches=[WatchView("BTC-USD", 60, {"15m"}, "both", set())])
    assert match(ev, free) is None
    assert effective_score(ev, {"ema_cross"}) == 0


def test_watch_detector_subset():
    ev = market((("ema_cross", 1.0), ("volume_spike", 1.0)))
    only_cusum = user(watches=[WatchView("BTC-USD", 30, {"15m"}, "both", {"cusum_shift"})])
    assert match(ev, only_cusum) is None


def test_other_kinds_gating():
    dep = MarketEvent(kind="depeg", symbol="USDT-USD", title="x", score=80)
    assert match(dep, user("free")) == 80
    lst = MarketEvent(kind="listing", symbol="NEW-USD", title="x", score=70)
    assert match(lst, user("free", want_listings=True)) is None and match(lst, user()) == 70
    gas = MarketEvent(kind="gas", symbol="ETH-GAS", title="x", score=50, meta={"threshold": 5})
    assert match(gas, user()) == 50 and match(gas, user(gas_below=10)) is None
    sec = MarketEvent(kind="security", symbol="X", title="x", score=90, meta={"addresses": ["0xabc"]})
    assert match(sec, user("pro", onchain={"0xabc": 0})) is None
    assert match(sec, user("elite", onchain={"0xabc": 0})) == 90
    whale = MarketEvent(kind="onchain", symbol="BTC-USD", title="w", score=70,
                        meta={"addresses": ["0xdef"], "pattern": "exchange_inflow", "usd": 5e6})
    assert match(whale, user()) == 70                                   # watches BTC-USD
    assert match(whale, user("free")) is None


def test_quiet_hours_wraparound():
    u = user(quiet_start=22, quiet_end=7)
    import datetime as dt
    ts = lambda h: dt.datetime(2026, 1, 1, h, tzinfo=dt.timezone.utc).timestamp()
    assert u.in_quiet_hours(ts(23)) and u.in_quiet_hours(ts(3)) and not u.in_quiet_hours(ts(12))


def test_formatting_escapes_html():
    e = MarketEvent(kind="market", symbol="BTC-USD", title="<b>x</b>", direction=1, score=70, price=123.4,
                    reasons=["a < b"])
    html = formatting.telegram_html(e)
    assert "&lt;b&gt;x" in html and "a &lt; b" in html
    assert formatting.discord_payload(e, "https://x")["embeds"][0]["color"] == 0xF5F5F5


def test_validate_outbound_url():
    assert validate_outbound_url("https://discord.com/api/webhooks/1/abc", "discord", resolve=False)
    for bad in ("http://discord.com/api/webhooks/1", "https://evil.com/api/webhooks/1"):
        with pytest.raises(ValueError):
            validate_outbound_url(bad, "discord", resolve=False)
    for bad in ("https://127.0.0.1/x", "https://localhost/x", "https://10.0.0.5/hook", "https://169.254.169.254/latest"):
        with pytest.raises(ValueError):
            validate_outbound_url(bad, "webhook")


def test_webhook_signature():
    assert sign(b"{}", "k") == "sha256=" + __import__("hmac").new(b"k", b"{}", "sha256").hexdigest()


def test_dispatcher_delivers_to_every_channel(monkeypatch):
    import asyncio
    import httpx
    from app.alerts import channels as ch
    from app.alerts.dispatcher import Dispatcher
    from app.config import settings

    monkeypatch.setattr(ch, "_is_public_host", lambda host: True)
    monkeypatch.setattr(settings, "telegram_bot_token", "123:abc")
    seen = []

    def handler(request: httpx.Request):
        seen.append((request.url.host, request.headers.get("X-StrikePulse-Signature"), request.headers.get("Title")))
        return httpx.Response(200, json={"ok": True})

    d = Dispatcher(settings, bus=None)
    d.client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    d._log_deliveries = lambda rows: None
    u = user("elite", discord_webhook="https://discord.com/api/webhooks/1/x", ntfy_topic="sp-topic123",
             webhook_url="https://hooks.example.com/sp")
    q = d.open_stream(u.id)
    res = asyncio.run(d.deliver(u, market(), 88))
    assert res == {"telegram": "sent", "discord": "sent", "ntfy": "sent", "webhook": "sent"}
    hosts = {h for h, _, _ in seen}
    assert {"api.telegram.org", "discord.com", "ntfy.sh", "hooks.example.com"} <= hosts
    assert any(sig and sig.startswith("sha256=") for _, sig, _ in seen)
    assert q.get_nowait()["score"] == 88                       # live dashboard stream got it too


def test_dispatcher_respects_pause_and_cap():
    import asyncio
    import time as _t
    from app.alerts.dispatcher import Dispatcher
    from app.config import settings
    d = Dispatcher(settings, bus=None)
    assert asyncio.run(d.deliver(user(paused_until=_t.time() + 60), market(), 80)) == {"all": "paused"}
    u = user()
    d.daily[(u.id, _t.strftime("%Y-%m-%d"))] = u.plan.daily_cap
    assert asyncio.run(d.deliver(u, market(), 80)) == {"all": "daily cap reached"}
