import hashlib
import hmac
import json
import re
import time

import pytest
from fastapi.testclient import TestClient

from app.main import app


def csrf(html: str) -> str:
    return re.search(r'name="csrf" value="([^"]+)"', html).group(1)


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def signup(c, email):
    t = csrf(c.get("/signup").text)
    return c.post("/signup", data={"csrf": t, "email": email, "password": "password123", "agree": "on"})


def test_public_pages(client):
    for p in ("/", "/pricing", "/how-it-works", "/legal/terms", "/legal/privacy", "/legal/disclaimer", "/login"):
        r = client.get(p)
        assert r.status_code == 200, p
        assert "Content-Security-Policy" in r.headers
    assert client.get("/missing").status_code == 404
    assert client.get("/api/health").json()["ok"]


def test_auth_required_redirects(client):
    r = client.get("/dashboard", follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"].startswith("/login")
    assert client.get("/api/candles?symbol=BTC-USD").status_code == 401


def test_signup_login_and_first_user_admin(client):
    r = signup(client, "first@test.com")
    assert r.url.path == "/dashboard" and "Welcome" in r.text
    assert client.get("/admin").status_code == 200        # first account becomes admin
    t = csrf(client.get("/dashboard").text)
    client.post("/logout", data={"csrf": t})
    r = signup(client, "first@test.com")
    assert "already exists" in r.text
    t = csrf(client.get("/login").text)
    r = client.post("/login", data={"csrf": t, "email": "first@test.com", "password": "wrong"})
    assert r.status_code == 400
    r = client.post("/login", data={"csrf": t, "email": "FIRST@test.com", "password": "password123"})
    assert r.url.path == "/dashboard"


def test_csrf_enforced(client):
    assert client.post("/watches", data={"csrf": "nope", "symbol": "SOL-USD"}).status_code == 400


def test_plan_limits_and_fake_upgrade(client):
    signup(client, "free@test.com")
    t = csrf(client.get("/dashboard").text)
    assert client.get("/admin").status_code == 403
    r = client.post("/watches", data={"csrf": t, "symbol": "SOL-USD", "timeframes": ["1m", "15m"], "min_score": "10"})
    assert "Watching SOL-USD" in r.text and "≥60 · 15m" in r.text    # free floor + tf clamp
    r = client.post("/watches", data={"csrf": t, "symbol": "XRP-USD"})
    assert "allows 3 watches" in r.text
    r = client.post("/watches", data={"csrf": t, "symbol": "FAKE-USD"})
    assert "tracked. Pick one" in r.text
    r = client.post("/billing/checkout/pro", data={"csrf": t})
    assert "Switched to Pro" in r.text
    r = client.post("/watches", data={"csrf": t, "symbol": "XRP-USD", "timeframes": ["1m"]})
    assert "Watching XRP-USD" in r.text


def test_settings_validation(client):
    t = csrf(client.get("/settings").text)
    r = client.post("/settings", data={"csrf": t, "discord_webhook": "https://evil.example/x", "ntfy_topic": "x"})
    assert "Discord webhook URL" in r.text and "ntfy topic must be" in r.text
    r = client.post("/settings", data={"csrf": t, "ntfy_topic": "sp-goodtopic1", "timezone": "America/Denver",
                                       "quiet_start": "22", "quiet_end": "6", "want_depeg": "on", "gas_below": "5"})
    assert "Settings saved" in r.text and 'value="sp-goodtopic1"' in r.text


def test_onchain_watch_rules(client):
    t = csrf(client.get("/onchain").text)
    r = client.post("/onchain", data={"csrf": t, "kind": "wallet", "address": "0x123"})
    assert "valid Ethereum address" in r.text
    r = client.post("/onchain", data={"csrf": t, "kind": "wallet", "address": "0x" + "a" * 40, "label": "whale"})
    assert "Address added" in r.text
    r = client.post("/onchain", data={"csrf": t, "kind": "token", "address": "0x" + "b" * 40})
    assert "Elite feature" in r.text


def test_api_key_requires_elite(client):
    key = re.search(r"sp_[A-Za-z0-9_-]+", client.get("/settings").text)
    assert key is None                                   # not shown to non-Elite users
    assert client.get("/api/v1/alerts", headers={"X-API-Key": "bad"}).status_code == 401


def _stripe_sig(payload: bytes, secret: str) -> str:
    ts = int(time.time())
    sig = hmac.new(secret.encode(), f"{ts}.".encode() + payload, hashlib.sha256).hexdigest()
    return f"t={ts},v1={sig}"


def test_stripe_webhook_flow(client):
    from app.db import session_scope
    from app.models import User
    from sqlalchemy import select
    with session_scope() as db:
        uid = db.scalar(select(User.id).where(User.email == "free@test.com"))
    bad = client.post("/billing/webhook", content=b"{}", headers={"stripe-signature": "t=1,v1=bad"})
    assert bad.status_code == 400
    events = [
        {"id": "evt_1", "type": "checkout.session.completed", "data": {"object": {
            "client_reference_id": str(uid), "customer": "cus_123", "subscription": "sub_123",
            "metadata": {"user_id": str(uid), "plan": "elite"}}}},
        {"id": "evt_2", "type": "customer.subscription.updated", "data": {"object": {
            "id": "sub_123", "customer": "cus_123", "status": "active", "current_period_end": time.time() + 1e6,
            "metadata": {}, "items": {"data": [{"price": {"id": "price_elite_test"}}]}}}},
    ]
    for ev in events:
        body = json.dumps(ev).encode()
        r = client.post("/billing/webhook", content=body, headers={"stripe-signature": _stripe_sig(body, "whsec_test123")})
        assert r.status_code == 200, r.text
    with session_scope() as db:
        u = db.get(User, uid)
        assert (u.plan, u.plan_status, u.stripe_customer_id) == ("elite", "active", "cus_123")
    # elite now sees the API key and can call the API
    key = re.search(r'id="apikey">([^<]+)<', client.get("/settings").text).group(1)
    assert client.get("/api/v1/alerts", headers={"X-API-Key": key}).status_code == 200
    body = json.dumps({"id": "evt_3", "type": "customer.subscription.deleted",
                       "data": {"object": {"id": "sub_123", "customer": "cus_123"}}}).encode()
    client.post("/billing/webhook", content=body, headers={"stripe-signature": _stripe_sig(body, "whsec_test123")})
    with session_scope() as db:
        assert db.get(User, uid).plan == "free"


def test_admin_broadcast_persists_alert(client):
    t = csrf(client.get("/login").text)
    client.post("/login", data={"csrf": t, "email": "first@test.com", "password": "password123"})
    t = csrf(client.get("/admin").text)
    r = client.post("/admin/broadcast", data={"csrf": t, "kind": "depeg", "symbol": "USDT-USD",
                                              "title": "USDT de-peg test", "score": "85", "body": "x"})
    assert "Published" in r.text


def test_account_deletion(client):
    signup(client, "gone@test.com")
    t = csrf(client.get("/settings").text)
    r = client.post("/settings/delete", data={"csrf": t, "confirm": "wrong"})
    assert "Type your email" in r.text
    r = client.post("/settings/delete", data={"csrf": t, "confirm": "gone@test.com"})
    assert r.url.path == "/"
    t = csrf(client.get("/login").text)
    r = client.post("/login", data={"csrf": t, "email": "gone@test.com", "password": "password123"})
    assert r.status_code == 400


def test_help_center(client):
    r = client.get("/help")
    assert r.status_code == 200
    for s in ("Help center", "Getting started", "Quant Engine", "Simulator", "FAQ", "Manage subscription"):
        assert s in r.text
    assert "/help" in client.get("/sitemap.xml").text
    assert 'href="/help"' in client.get("/").text
