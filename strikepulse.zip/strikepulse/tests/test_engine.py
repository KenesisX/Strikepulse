import math
import random

import numpy as np

from app.engine import indicators as ind
from app.engine.candles import CandleSeries
from app.engine.detectors import (AnomalyDetector, BollingerBreakout, CUSUMShift, EMACross, MomentumBurst,
                                  RSIReversal, TakerFlowImbalance, VolumeSpike)
from app.engine.isoforest import IsolationForest
from app.engine.scoring import SignalPipeline, confluence
from app.engine.types import Candle, Signal, Trade


def series(closes, vols=None, buys=None, tf=60):
    vols = vols or [10.0] * len(closes)
    buys = buys or [v / 2 for v in vols]
    out, prev = [], closes[0]
    for i, (c, v, b) in enumerate(zip(closes, vols, buys)):
        out.append(Candle("T-USD", tf, i * tf, prev, max(prev, c) * 1.0005, min(prev, c) * 0.9995, c, v, b, 20))
        prev = c
    return out


def noisy(n, seed=1, start=100.0, drift=0.0, sigma=0.001):
    rng = random.Random(seed)
    p, out = start, []
    for _ in range(n):
        p *= math.exp(drift + rng.gauss(0, sigma))
        out.append(p)
    return out


# ---------------------------------------------------------------- indicators
def test_ema_matches_definition():
    x = np.array([1, 2, 3, 4, 5], float)
    e = ind.ema(x, 3)
    assert e[0] == 1 and abs(e[1] - 1.5) < 1e-12 and abs(e[-1] - 4.0625) < 1e-9


def test_rsi_extremes():
    up = np.arange(1, 50, dtype=float)
    assert ind.rsi(up)[-1] == 100.0
    down = up[::-1].copy()
    assert ind.rsi(down)[-1] < 1


def test_bollinger_contains_mean():
    c = np.array(noisy(60), float)
    mid, up, lo = ind.bollinger(c)
    assert np.all(up[19:] >= mid[19:]) and np.all(lo[19:] <= mid[19:])


# ---------------------------------------------------------------- candles
def test_candles_roll_and_gap_fill():
    s = CandleSeries("BTC-USD", 60)
    assert s.add_trade(Trade("x", "BTC-USD", 100, 1, "buy", 0)) == []
    s.add_trade(Trade("x", "BTC-USD", 101, 2, "sell", 30))
    closed = s.add_trade(Trade("x", "BTC-USD", 103, 1, "buy", 200))  # skips 60-119 and 120-179
    assert [c.start for c in closed] == [0, 60, 120]
    first = closed[0]
    assert (first.open, first.high, first.low, first.close, first.volume, first.buy_volume) == (100, 101, 100, 101, 3, 1)
    assert closed[1].volume == 0 and closed[1].close == 101   # flat gap candle
    assert s.current.start == 180 and s.current.close == 103


def test_candle_tick_closes_quiet_candles():
    s = CandleSeries("BTC-USD", 60)
    s.add_trade(Trade("x", "BTC-USD", 100, 1, "buy", 10))
    assert len(s.tick(70)) == 1


# ---------------------------------------------------------------- detectors
def test_ema_cross_fires_on_reversal():
    closes = [100 - i * 0.1 for i in range(60)] + [94 + i * 0.6 for i in range(15)]
    d = EMACross()
    fired = [d.evaluate(series(closes[:i]), {}) for i in range(d.min_history, len(closes) + 1)]
    sigs = [s for s in fired if s]
    assert sigs and sigs[0].direction == 1 and "bullish" in sigs[0].detail


def test_volume_spike():
    vols = [10 + (i % 3) for i in range(40)] + [120]
    closes = noisy(40) + [noisy(40)[-1] * 1.01]
    s = VolumeSpike().evaluate(series(closes, vols), {})
    assert s and s.direction == 1 and "x normal" in s.detail


def test_cusum_detects_shift_once():
    closes = noisy(130, seed=3) + noisy(30, seed=4, start=noisy(130, seed=3)[-1], drift=0.004)
    d = CUSUMShift()
    hits = [i for i in range(d.min_history, len(closes) + 1) if d.evaluate(series(closes[:i]), {})]
    assert hits, "should detect the regime change"
    assert hits[0] > 130, "should not fire during the calm period"
    assert d.evaluate(series(closes[:hits[0]]), {}).direction == 1


def test_bollinger_breakout_down():
    closes = noisy(60, sigma=0.0005) + [noisy(60, sigma=0.0005)[-1] * 0.98]
    s = BollingerBreakout().evaluate(series(closes), {})
    assert s and s.direction == -1


def test_rsi_reversal_from_oversold():
    closes = [100 - i * 0.5 for i in range(45)] + [78.5, 80.5, 83]
    d = RSIReversal()
    sigs = [d.evaluate(series(closes[:i]), {}) for i in range(d.min_history, len(closes) + 1)]
    assert any(s and s.direction == 1 for s in sigs)


def test_momentum_burst_only_first_bar():
    base = noisy(120, seed=9)
    closes = base + [base[-1] * 1.02, base[-1] * 1.04, base[-1] * 1.05]
    d, ctx = MomentumBurst(), {}
    res = [d.evaluate(series(closes[:i]), ctx) for i in range(len(base), len(closes) + 1)]
    assert sum(1 for r in res if r) == 1


def test_taker_flow():
    n = 60
    vols = [10.0] * n
    buys = [5.0] * (n - 5) + [9.5] * 5
    s = TakerFlowImbalance().evaluate(series(noisy(n), vols, buys), {})
    assert s and s.direction == 1


def test_isolation_forest_scores_outlier_higher():
    rng = np.random.default_rng(0)
    X = rng.normal(0, 1, (300, 4))
    f = IsolationForest(n_trees=80).fit(X)
    normal, outlier = f.score(np.zeros((1, 4)))[0], f.score(np.full((1, 4), 6.0))[0]
    assert outlier > 0.65 > normal


def test_anomaly_detector_flags_crash():
    closes = noisy(200, seed=5)
    vols = [10 + random.Random(i).random() for i in range(200)]
    closes.append(closes[-1] * 0.93)
    vols.append(400)
    s = AnomalyDetector().evaluate(series(closes, vols), {})
    assert s and s.direction == -1


# ---------------------------------------------------------------- scoring
def test_confluence_more_agreement_scores_higher():
    one = confluence([Signal("ema_cross", 1, 1.0, "")], 300)[0]
    two = confluence([Signal("ema_cross", 1, 1.0, ""), Signal("volume_spike", 1, 1.0, "")], 300)[0]
    conflicted = confluence([Signal("ema_cross", 1, 1.0, ""), Signal("volume_spike", 1, 1.0, ""),
                             Signal("cusum_shift", -1, 1.0, "")], 300)[0]
    assert two > one and conflicted < two
    assert confluence([Signal("ema_cross", -1, 1, "")], 300)[1] == -1


def test_pipeline_end_to_end_and_cooldown():
    closes = noisy(150, seed=2) + noisy(25, seed=8, start=noisy(150, seed=2)[-1], drift=0.006)
    vols = [10.0] * 150 + [40.0] * 25
    cs = series(closes, vols, [v * 0.8 if i >= 150 else v / 2 for i, v in enumerate(vols)])
    pipe = SignalPipeline(min_score=40)
    events = [e for i in range(len(cs)) if (e := pipe.on_candle(cs[i], cs[: i + 1]))]
    assert events, "uptrend should produce at least one bullish event"
    assert all(e.direction == 1 for e in events[:1])
    assert events[0].score >= 40 and events[0].reasons
    # cooldown: never two same-direction events within 4 bars unless the score jumped 15+
    ts = [(e.ts, e.score) for e in events if e.direction == 1]
    for (t1, s1), (t2, s2) in zip(ts, ts[1:]):
        assert t2 - t1 >= 4 * 60 or s2 >= s1 + 15
