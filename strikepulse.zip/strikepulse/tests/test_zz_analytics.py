import math
import random
import re
import time

import pytest
from fastapi.testclient import TestClient

from app.analytics import (Analytics, FlowTracker, cone, probability_engine, seasonality, target_odds,
                           trend_state)
from app.engine.types import Candle, MarketEvent, Trade


def hourly(n=900, seed=1, drift=0.0, start=None):
    rng = random.Random(seed)
    start = start or (int(time.time() // 3600) * 3600 - n * 3600)
    p, out = 100.0, []
    for i in range(n):
        o = p
        p *= math.exp(drift + rng.gauss(0, 0.006))
        out.append(Candle("BTC-USD", 3600, start + i * 3600, o, max(o, p) * 1.001, min(o, p) * 0.999, p,
                          100 * rng.lognormvariate(0, .3), 50, 10))
    return out


def test_probability_engine_shapes_and_bounds():
    r = probability_engine(hourly(), (1, 4, 24))
    assert r and r["n"] == 40 and set(r["horizons"]) == {"1", "4", "24"}
    for v in r["horizons"].values():
        assert 0 <= v["p_up"] <= 1 and v["ci_low"] <= v["p_up"] <= v["ci_high"]
        assert v["p10"] <= v["median"] <= v["p90"]
    assert probability_engine(hourly(50), (1, 4, 24)) is None


def test_probability_engine_finds_persistent_pattern():
    # market where positive hours are always followed by positive hours: analogs must see it
    start = int(time.time() // 3600) * 3600 - 900 * 3600
    p, cs, prev = 100.0, [], 1
    rng = random.Random(4)
    for i in range(900):
        sign = prev if rng.random() < 0.9 else -prev
        o = p
        p *= math.exp(sign * 0.005)
        prev = sign
        cs.append(Candle("X", 3600, start + i * 3600, o, max(o, p), min(o, p), p, 100, 50, 1))
    r = probability_engine(cs, (1,))
    last_up = cs[-1].close > cs[-1].open
    p_up = r["horizons"]["1"]["p_up"]
    assert (p_up > 0.7) if last_up else (p_up < 0.3)


def test_target_odds_and_cone():
    t = target_odds(100, 100, 0.01, 24)
    assert t["touch"] == 1.0
    far = target_odds(100, 150, 0.01, 1)
    assert far["touch"] < 0.001
    mid = target_odds(100, 102, 0.01, 4)
    assert 0 < mid["close_beyond"] < mid["touch"] <= 2 * mid["close_beyond"] + 1e-9
    c = cone(100, 0.01, (1, 4))
    assert c[0]["p68"][0] < 100 < c[0]["p68"][1] and c[1]["p95"][1] > c[0]["p95"][1]


def test_flow_tracker_whales_and_windows():
    f = FlowTracker()
    now = time.time()
    rng = random.Random(1)
    for i in range(600):
        f.on_trade(Trade("x", "BTC-USD", 100, rng.uniform(0.5, 1.5), "buy" if i % 2 else "sell", now - 600 + i))
    for i in range(5):
        f.on_trade(Trade("x", "BTC-USD", 100, 50, "buy", now - 5 + i))       # whale buys
    w = f.window("BTC-USD", 30, now=now + 1)
    assert w["whale_net"] > 0 and w["buy_share"] > 0.5 and w["whale_threshold"]
    assert f.series("BTC-USD")[-1]["cvd"] > 0


def test_seasonality_and_trend():
    s = seasonality(hourly(24 * 30), "America/Denver")
    assert len(s["avg"]) == 7 and len(s["avg"][0]) == 24 and 0 <= s["best_hour"] < 24
    assert trend_state(hourly(200, drift=0.004), "1h")["direction"] == 1
    assert trend_state(hourly(200, drift=-0.004), "1h")["direction"] == -1


class _Eng:
    def __init__(self):
        from app.engine.candles import CandleBook
        self.book = CandleBook([60, 300, 900])
        self.prices = {}
        self.stable_symbols = set()


def test_analytics_full_and_enrich():
    from app.config import settings
    eng = _Eng()
    an = Analytics(eng, settings, simulated=True)
    now = time.time()
    rng = random.Random(2)
    price = 100.0
    for i in range(3000):
        price *= math.exp(rng.gauss(0, 0.0008))
        t = Trade("sim", "BTC-USD", price, rng.uniform(.1, 2), "buy" if rng.random() < .55 else "sell", now - 3000 + i)
        an.on_trade(t)
        eng.book.add_trade(t)
        eng.prices["BTC-USD"] = {"price": price, "ts": t.ts}
    d = an.full("BTC-USD", "UTC")
    assert d["pulse"]["score"] is not None and d["cone"] and d["odds"].get("hourly")
    assert d["season"] and d["rotation"][0]["symbol"] == "BTC-USD"
    e = MarketEvent(kind="market", symbol="BTC-USD", title="t", direction=1, score=70)
    an.enrich(e)
    assert e.meta.get("odds") and any("Historical odds" in r for r in e.reasons)


def csrf(html):
    return re.search(r'name="csrf" value="([^"]+)"', html).group(1)


def test_analysis_pages_and_gating():
    from app.main import app
    with TestClient(app) as c:
        assert c.get("/about").status_code == 200
        t = csrf(c.get("/signup").text)
        c.post("/signup", data={"csrf": t, "email": "analyst@test.com", "password": "password123", "agree": "on"})
        assert c.get("/analysis").status_code == 200
        assert c.get("/analysis?symbol=ETH-USD").status_code == 200
        free_btc = c.get("/api/analysis?symbol=BTC-USD").json()
        assert free_btc["locked"] is False and "odds" in free_btc
        free_eth = c.get("/api/analysis?symbol=ETH-USD").json()
        assert free_eth["locked"] is True and "odds" not in free_eth
        assert c.get("/api/analysis/target?symbol=ETH-USD&price=1").status_code == 403
        t = csrf(c.get("/dashboard").text)
        c.post("/billing/checkout/pro", data={"csrf": t})
        assert c.get("/api/analysis?symbol=ETH-USD").json()["locked"] is False
        assert c.get("/api/analysis?symbol=NOPE-USD").status_code == 404
        r = c.get("/pricing")
        assert "$9.99" in r.text and "More analysis, lower price" in r.text
