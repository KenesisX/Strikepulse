import math
import time

import numpy as np

from app.quant import mathlab as M
from app.quant.models import decide, feature_bins, psi


def test_hurst_kalman_entropy():
    rng = np.random.default_rng(0)
    r = rng.normal(0, 0.01, 3000)
    assert 0.4 < M.hurst_dfa(r) < 0.6
    assert M.hurst_dfa(np.convolve(r, np.ones(12) / 12, "same")) > 0.8
    up = 100 * np.exp(np.cumsum(np.full(400, 0.002) + rng.normal(0, 0.002, 400)))
    lvl, slope, sd = M.kalman_trend(up)
    assert slope[-1] / sd[-1] > 3
    pe = M.perm_entropy_series(r, 4, 48)
    assert 0.9 < np.nanmean(pe) <= 1.0
    pe_struct = M.perm_entropy_series(np.sin(np.arange(600) / 3.0), 4, 48)
    assert np.nanmean(pe_struct) < 0.6


def test_garch_bocpd_ou():
    rng = np.random.default_rng(1)
    n, w, a, b = 3000, 1e-6, 0.1, 0.85
    s2, r = w / (1 - a - b), []
    for _ in range(n):
        x = rng.normal(0, math.sqrt(s2))
        r.append(x)
        s2 = w + a * x * x + b * s2
    g = M.garch_fit(np.array(r))
    assert 0.85 < g["persistence"] < 0.99 and g["sigma_24"] > g["sigma_1"]
    x = np.concatenate([rng.normal(0, 1, 400), rng.normal(4, 1, 50)])
    cp, rl = M.bocpd(x)
    assert cp[401:405].max() > 0.3 and rl[-1] < 60
    ou = np.zeros(1000)
    for i in range(1, 1000):
        ou[i] = ou[i - 1] - 0.1 * ou[i - 1] + rng.normal(0, 0.01)
    f = M.ou_fit(ou + 5)
    assert f["mean_reverting"] and 4 < f["half_life"] < 12


def test_hawkes_detects_clustering():
    rng = np.random.default_rng(2)
    poisson = np.cumsum(rng.exponential(1, 800))
    assert M.hawkes_fit(poisson)["branching_ratio"] < 0.3
    ev, t = [], 0.0
    while len(ev) < 800:        # cluster process: each event spawns quick followers
        t += rng.exponential(5)
        ev.append(t)
        for _ in range(rng.poisson(3)):
            ev.append(t + rng.exponential(0.3))
    assert M.hawkes_fit(np.array(ev))["branching_ratio"] > 0.5


def test_cycle_and_cointegration():
    rng = np.random.default_rng(3)
    c = M.dominant_cycle(100 * np.exp(0.03 * np.sin(np.arange(600) * 2 * np.pi / 36) + rng.normal(0, .002, 600)))
    assert 30 < c["period_bars"] < 42
    a = np.cumsum(rng.normal(0, .01, 900))
    pairs = M.cointegration({"A-USD": np.exp(a + rng.normal(0, .005, 900)), "B-USD": np.exp(a),
                             "C-USD": np.exp(np.cumsum(rng.normal(0, .01, 900)))})
    assert [p["pair"] for p in pairs] == ["A/B"]


def test_adaptive_conformal_holds_coverage_under_regime_change():
    rng = np.random.default_rng(4)
    c = M.AdaptiveConformal(alpha=0.05, gamma=0.01)
    c.seed(rng.normal(0, 0.01, 500), np.full(500, 0.01))
    hits = []
    for i in range(3000):
        vol = 0.01 if i < 1000 else 0.025          # market suddenly 2.5x wilder, model still says 1%
        iv = c.interval(100, 0.01)
        r = rng.normal(0, vol)
        inside = iv["low"] <= 100 * math.exp(r) <= iv["high"]
        hits.append(inside)
        c.update(r, 0.01, low_hit=inside)
    assert abs(np.mean(hits[-1500:]) - 0.95) < 0.03     # back on target after the shock


def test_precision_table_and_dial():
    rng = np.random.default_rng(5)
    p = rng.uniform(0.3, 0.7, 5000)
    y = (rng.uniform(size=5000) < p).astype(int)
    tab = M.precision_table(p, y)
    assert tab[0]["coverage"] == 1.0 and tab[-1]["precision"] > tab[0]["precision"]
    card = {"status": "deployed", "precision_table": [{"min_confidence": 0.0, "precision": 0.52, "n": 900},
                                                      {"min_confidence": 0.2, "precision": 0.61, "n": 120}],
            "backtest": {"trades": 100, "avg_win": 0.01, "avg_loss": -0.01}}
    weak = decide(0.56, 0.01, "trending up", card, min_precision=0.56)
    assert weak["size"] == 0 and weak["stance"] == "STAND ASIDE"
    strong = decide(0.65, 0.01, "trending up", card, min_precision=0.56)
    assert strong["hist_precision"] == 0.61 and strong["stance"] == "LONG BIAS"


def test_psi_detects_shift():
    rng = np.random.default_rng(6)
    base = rng.normal(0, 1, (3000, 2))
    bins = feature_bins(base)
    same = psi(bins, rng.normal(0, 1, (800, 2)))
    moved = psi(bins, np.column_stack([rng.normal(2, 1, 800), rng.normal(0, 1, 800)]))
    assert max(same) < 0.1 and moved[0] > 0.25 and moved[1] < 0.1
