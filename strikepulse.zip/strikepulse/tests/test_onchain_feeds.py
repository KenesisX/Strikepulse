import time

from app.engine.types import BookTop, Trade
from app.feeds.base import parse_iso
from app.feeds.exchanges import BinanceUSFeed, CoinbaseFeed, KrakenFeed
from app.onchain.bloom import AddressSet, BloomFilter
from app.onchain.ethereum import (OWNERSHIP, TRANSFER, UNIV2_BURN, ZERO, EthWatcher, Registry,
                                  address_to_topic)
from app.onchain.monitors import DepegMonitor, ListingWatcher


class FakeEngine:
    def __init__(self):
        self.feed_status = {}

    def status_for(self, name):
        return self.feed_status.setdefault(name, {"messages": 0, "errors": 0, "reconnects": 0})


# ---------------------------------------------------------------- bloom
def test_bloom_no_false_negatives_and_low_fp():
    bf = BloomFilter(10_000, 0.01)
    items = [f"0x{i:040x}" for i in range(10_000)]
    bf.update(items)
    assert all(i in bf for i in items)
    fp = sum(f"0x{(i + 10 ** 9):040x}" in bf for i in range(20_000)) / 20_000
    assert fp < 0.03


def test_address_set_case_insensitive_and_confirms():
    s = AddressSet(100)
    s.add("0xABCDEF0000000000000000000000000000000001", "Binance")
    assert s.get("0xabcdef0000000000000000000000000000000001") == "Binance"
    assert s.get("0x0000000000000000000000000000000000000002") is None


# ---------------------------------------------------------------- ethereum
WETH = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
BINANCE = "0x28c6c06298d514db089934071355e5743bf21d60"
WHALE = "0x1111111111111111111111111111111111111111"


def watcher(user=None):
    reg = Registry(lambda: user or {"wallets": {}, "tokens": {}, "pairs": {}})
    reg.refresh()
    events = []
    w = EthWatcher("wss://x", reg, events.append, lambda s: {"ETH-USD": 3000.0}.get(s), whale_min_usd=1_000_000)
    return w, events


def transfer_log(token, frm, to, amount, tx="0xabc", idx="0x1"):
    return {"address": token, "topics": [TRANSFER, address_to_topic(frm), address_to_topic(to)],
            "data": hex(amount), "transactionHash": tx, "logIndex": idx}


def test_whale_deposit_to_exchange():
    w, _ = watcher()
    evs = w.handle_log(transfer_log(WETH, WHALE, BINANCE, 1000 * 10 ** 18))   # 1000 ETH = $3M
    assert len(evs) == 1 and evs[0].kind == "onchain"
    assert "Whale deposit" in evs[0].title and evs[0].direction == -1 and evs[0].meta["usd"] == 3_000_000


def test_small_transfer_ignored_and_dedup():
    w, _ = watcher()
    assert w.handle_log(transfer_log(WETH, WHALE, BINANCE, 10 ** 18, tx="0x1")) == []
    log = transfer_log(WETH, WHALE, BINANCE, 1000 * 10 ** 18, tx="0x2")
    assert w.handle_log(log) and w.handle_log(log) == []   # same log twice → once


def test_watched_wallet_and_security_events():
    pair = "0x2222222222222222222222222222222222222222"
    token = "0x3333333333333333333333333333333333333333"
    w, _ = watcher({"wallets": {WHALE: "Smart money"}, "tokens": {token: "MEME"}, "pairs": {pair: "MEME/WETH"}})
    evs = w.handle_log(transfer_log(WETH, WHALE, "0x4444444444444444444444444444444444444444", 5 * 10 ** 18, tx="0x3"))
    assert any(e.kind == "onchain" and "Smart money" in e.title for e in evs)
    burn = {"address": pair, "topics": [UNIV2_BURN, address_to_topic(WHALE), address_to_topic(WHALE)],
            "data": "0x" + hex(5)[2:].rjust(64, "0") + hex(7)[2:].rjust(64, "0"), "transactionHash": "0x4", "logIndex": "0x0"}
    evs = w.handle_log(burn)
    assert evs[0].kind == "security" and "Liquidity removed" in evs[0].title
    own = {"address": token, "topics": [OWNERSHIP, address_to_topic(WHALE), address_to_topic(BINANCE)],
           "data": "0x", "transactionHash": "0x5", "logIndex": "0x0"}
    assert "ownership transferred" in w.handle_log(own)[0].title
    mint = transfer_log(token, ZERO, WHALE, 10 ** 24, tx="0x6")
    assert any("minted" in e.title for e in w.handle_log(mint))


def test_gas_alerts_on_downward_band_cross_only():
    w, _ = watcher()
    head = lambda gwei: {"baseFeePerGas": hex(int(gwei * 1e9)), "number": "0x10"}
    assert w.handle_head(head(30))[0].meta["threshold"] == 50
    assert w.handle_head(head(31)) == []
    assert w.handle_head(head(4))[0].meta["threshold"] == 5
    assert w.handle_head(head(12)) == []           # going up never alerts


# ---------------------------------------------------------------- depeg / listings
def test_depeg_alert_and_recovery():
    out = []
    m = DepegMonitor(["USDT-USD"], out.append, threshold=0.005, confirm=60, recover=120)
    t = 1000.0
    m.on_price("USDT-USD", 0.99, t)
    m.on_price("USDT-USD", 0.988, t + 61)
    assert len(out) == 1 and out[0].kind == "depeg" and out[0].direction == -1
    m.on_price("USDT-USD", 0.9999, t + 100)
    m.on_price("USDT-USD", 1.0, t + 230)
    assert len(out) == 2 and out[1].meta.get("recovered")


def test_listing_diff():
    store = {}
    lw = ListingWatcher(lambda e: None, store.get, store.__setitem__)
    assert lw.diff("coinbase", {"BTC-USD"}) == []          # first run silent
    evs = lw.diff("coinbase", {"BTC-USD", "NEW-USD"})
    assert [e.symbol for e in evs] == ["NEW-USD"]


# ---------------------------------------------------------------- feeds
def test_parse_iso():
    assert abs(parse_iso("2024-01-01T00:00:00.123456789Z") - 1704067200.123456) < 1e-5


def test_coinbase_parse_maker_side_inverted():
    f = CoinbaseFeed(FakeEngine(), ["BTC-USD"])
    [t] = f.parse({"type": "match", "product_id": "BTC-USD", "price": "100", "size": "2", "side": "sell",
                   "time": "2024-01-01T00:00:00Z"})
    assert isinstance(t, Trade) and t.side == "buy" and t.price == 100
    [b] = f.parse({"type": "ticker", "product_id": "BTC-USD", "best_bid": "99", "best_bid_size": "1",
                   "best_ask": "101", "best_ask_size": "2", "time": "2024-01-01T00:00:00Z"})
    assert isinstance(b, BookTop) and b.ask_size == 2
    assert f.parse({"type": "last_match"}) == []


def test_kraken_parse():
    f = KrakenFeed(FakeEngine(), ["BTC-USD"])
    out = f.parse({"channel": "trade", "type": "update", "data": [
        {"symbol": "BTC/USD", "side": "sell", "price": 50000.5, "qty": 0.1, "timestamp": "2024-01-01T00:00:00.5Z"}]})
    assert out[0].symbol == "BTC-USD" and out[0].side == "sell"


def test_binance_parse_and_url():
    f = BinanceUSFeed(FakeEngine(), ["BTC-USD"], ["USDT-USD"])
    assert "btcusd@trade" in f.ws_url() and "usdtusd@bookTicker" in f.ws_url()
    [t] = f.parse({"stream": "btcusd@trade", "data": {"e": "trade", "s": "BTCUSD", "p": "1", "q": "2", "T": 1700000000000, "m": True}})
    assert t.side == "sell" and t.ts == 1700000000
