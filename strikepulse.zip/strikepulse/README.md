# ⚡ StrikePulse: crypto trend & on-chain alert SaaS

StrikePulse watches crypto markets around the clock and alerts subscribers when a trend shifts, volume explodes, a whale moves or a token shows rug-pull signs. It delivers to **Telegram, Discord, email, phone push (ntfy) and signed webhooks**, and charges **$9.99 or $24.99/month through Stripe**. Its **Deep Analysis** page shows things other apps don't: odds from similar past moments, whale vs retail order flow, hour-by-weekday timing maps, price-target odds and money rotation.

```
 Coinbase ─┐  WebSockets                ┌─ 9 detectors per candle close ─┐
 Kraken   ─┼─► trades + book ─► candles ┤  EMA cross · volume spike ·    ├─► confluence score 0-100
 Binance.US┘    (1m / 5m / 15m)         │  CUSUM change-point · Bollinger│     + cooldowns
                                        │  RSI · momentum · taker flow · │
 Ethereum node ─► Bloom-filtered        │  book imbalance · IsolationFor.│
   transfers / LP burns / ownership     └────────────────────────────────┘
   / gas / de-peg / new listings ────────────────────────┐            │
                                                          ▼            ▼
                         dispatcher: per-user watchlists, plan gating, re-scoring,
                         quiet hours, pause, daily caps, free-tier delay
                                                          │
                     Telegram · Discord · Email · ntfy push · signed webhook · live dashboard (SSE)
```

---

> **Selling it?** Read **[SELLING.md](SELLING.md)**: the launch plan for running it as your own subscription business, plus ready-to-paste listing copy and pricing for selling the source code.

## 1. Try it in 60 seconds (fake market data)

**Linux / macOS / Raspberry Pi**
```bash
cd strikepulse
./install.sh --demo      # creates .venv, installs everything, writes a demo .env
./start.sh               # open http://localhost:8000
```
**Windows:** double-click `install.bat`, then `start.bat`.

For a real install run `./install.sh` (no flag). A setup wizard asks for your name, domain, Stripe, Telegram and email, then writes `.env` for you.

Open http://localhost:8000 and sign up. **The first account becomes the admin.** The simulator makes up 4 hours of history in about 20 seconds, then streams pumps, dumps and trends live, so alerts start flowing within minutes. With `DEV_FAKE_BILLING=1` the upgrade buttons switch plans instantly, so you can test every tier.

Demo admin login: `admin@example.com` / `admin12345`. Run the tests: `.venv/bin/pip install pytest && .venv/bin/python -m pytest -q` (89 tests).

## 2. Go live

### a) Configure
```bash
cp .env.example .env
python -c "import secrets;print(secrets.token_urlsafe(48))"   # paste into SECRET_KEY
```
Set `BASE_URL` to your https domain, `FEEDS=coinbase,kraken` (add `binanceus` if you like), and set `ADMIN_EMAIL`/`ADMIN_PASSWORD`.

### b) Stripe (this is how you get paid)
1. Create a Stripe account → complete business verification. You can sell as **Strikebacktech** or as a sole proprietor.
2. Run the setup script with your **test** key first:
   ```bash
   STRIPE_SECRET_KEY=sk_test_xxx python scripts/setup_stripe.py https://yourdomain.com
   ```
   It creates the Pro/Elite products and the webhook endpoint, then prints the `STRIPE_*` lines for `.env`.
3. Stripe Dashboard → Settings → Billing → **Customer portal**: enable cancellation and plan switching.
4. Stripe Dashboard → Settings → **Payouts**: add your bank account (routing + account number). Stripe deposits on a rolling schedule, usually 2 business days.
   * **The name on the bank account should match the Stripe account.** If Stripe is in the business's name, payouts to a personal account can be rejected. A free business checking account (Mercury, Relay, Bluevine), then a transfer to Chime, avoids that and keeps business money separate.
   * Set aside about 25-30% for taxes. Stripe issues a 1099-K.
5. Test with card `4242 4242 4242 4242`, then repeat steps 2-4 with your **live** key.

### c) Telegram bot (free, the channel most users choose)
1. Message **@BotFather** → `/newbot` → copy the token.
2. `.env`: `TELEGRAM_BOT_TOKEN=...` and `TELEGRAM_BOT_USERNAME=YourBotName`.
3. Users press **Connect Telegram** in Settings, which links their account automatically. Bot commands: `/watches /pause 2h /resume /status /unlink`.

### d) Optional extras
| Feature | What to set |
|---|---|
| On-chain whale and security alerts | `ETH_WS_URL=wss://eth-mainnet.g.alchemy.com/v2/KEY` (Alchemy, Infura and QuickNode all have free tiers) |
| Email alerts | `SMTP_*` (Resend, SendGrid, Postmark, or a Gmail app password) |
| Phone push | Nothing. Users install the free ntfy app and enter a topic |
| Postgres | `DATABASE_URL=postgresql://...` and `pip install psycopg[binary]` |

### e) Deploy (pick one)
**VPS with Docker and automatic HTTPS** ($5-6/mo on Hetzner, DigitalOcean or Vultr):
```bash
DOMAIN=alerts.yourdomain.com docker compose --profile https up -d --build
```
Point your domain's A record at the server first. Caddy fetches the TLS certificate automatically.

**Raspberry Pi or VPS without Docker:** clone to `/home/pi/strikepulse`, create `.venv`, then
`sudo cp deploy/strikepulse.service /etc/systemd/system/ && sudo systemctl enable --now strikepulse`.
Put Caddy or Cloudflare Tunnel in front for HTTPS.

**PaaS (Render, Railway, Fly.io):** use the Dockerfile and mount a volume at `/app/data` (or use Postgres).

> Run exactly **one** worker. The market engine, dispatcher and live streams live in one process.
> One small server handles thousands of users. The work grows with the number of coins, not users.

## 3. Plans (edit `app/plans.py`)

| | Free | Pro $9.99 | Elite $24.99 |
|---|---|---|---|
| Deep Analysis | BTC only | every coin | every coin |
| Quant Engine | preview | ✓ | ✓ |
| Edge Lab | – | – | ✓ |
| Coins | 3 | 25 | 200 |
| Timeframes | 15m | 1m/5m/15m | 1m/5m/15m |
| Alert delay | 5 min | real-time | real-time |
| Detectors | 4 core | all 9 | all 9 |
| Channels | Telegram, email, push | + Discord | + signed webhooks + REST API |
| Whale wallets | – | 5 | 50 |
| Rug-pull, mint and ownership alerts | – | – | ✓ |
| Listings and gas alerts | – | ✓ | ✓ |

The free plan is re-scored using only its own detectors, so free users never see Pro signals early.

## 4. Tune the signals (backtest)

```bash
python -m app.replay --coinbase --symbol BTC-USD --tf 300 --pages 10     # ~3,000 real 5m candles
python -m app.replay --csv candles.csv --symbol SOL-USD --tf 900 --out results.json
python -m app.replay --synthetic --days 4
```
It prints, for each score bucket and each detector, how often price moved in the alert's direction 3, 6 and 12 bars later, and by how much. Adjust detector weights and thresholds in `app/engine/detectors.py` and `GLOBAL_MIN_SCORE`. Watch that the 80+ bucket beats 40-59. If it doesn't, a detector is adding noise.

> Synthetic data has momentum built in, so its hit rates look better than real markets. Judge only by real-data backtests.

## 5. Deep Analysis (`/analysis`)
| Panel | What it shows |
|---|---|
| Pulse Score | Trend, buy pressure, whale flow, historical odds and timing combined into 0-100, every part visible |
| Probability Engine | The 40 most similar past moments (k-nearest neighbours on returns, volume, RSI, trend distance, volatility) and how often price was higher 1h/4h/24h later vs the coin's normal rate, with typical move, 10-90% range and confidence |
| Probability cone | Last 7 days of hourly candles plus 68% / 95% price ranges for the next 24h (EWMA volatility) |
| Target odds | Chance to touch, or end beyond, any price within 1h-7d |
| Order-flow X-ray | Taker buy vs sell dollars per minute, cumulative delta, whale (top 3% trade size) vs retail net flow, divergences |
| Trend matrix | 1m/5m/15m/1h direction, strength, regime (trending / ranging / volatile), RSI |
| Timing map | Hour x weekday heatmap of average move, up-probability and activity, in the user's time zone |
| Attention & rotation | Each coin's share of tracked dollar volume vs normal, volume pace, trade heat, CoinGecko trending |
| What just changed | Plain-English numbers: buy share jumps, whale net flow, unusual volume, timing and odds edges |

Live mode backfills a year of hourly candles from Coinbase at boot; demo mode generates realistic history. Free users get the full page on BTC-USD and a blurred preview elsewhere.

## 5a. Quant Engine (`/quant`) + Edge Lab
Signal detection, regime detection and position sizing are separate layers, like professional quant systems:

| Layer | What runs |
|---|---|
| Features | 38 per coin per hour: momentum (1-72h), realized vol (6/24/72h), variance ratio, autocorrelation, efficiency, EMA distances, calendar, BTC beta/correlation, graph message-passing over the correlation network |
| Batch model | Gradient-boosted trees, purged + embargoed walk-forward CV, cross-fitted isotonic calibration, retrained every 6h |
| Guardrails | Fees (0.10%/side) + slippage (0.05%/side) in every backtest; deploy gate benches the model unless OOS AUC ≥ 0.52, calibrated log-loss beats the base rate, and after-cost Sharpe > 0 |
| Online model | AdaGrad logistic on live order flow, whales, book, exchange premium, funding, OI, hidden orders; Page-Hinkley drift resets |
| Regimes | Gaussian mixture → trending up / trending down / range / stress |
| Ensemble | Hedge exponential weights per regime over GBDT, online, kNN analogs, rules |
| Decision | Stance + ¼-Kelly risk budget, volatility cap, stress halving, -10% live-drawdown circuit breaker, "stand aside" when edge < costs |
| Edge Lab | Hidden TWAP/iceberg orders, wash-trade forensics, stop clusters, stop runs, trap detector, pump signatures, exchange premium + lead-lag, funding/OI, liquidation zones, options max pain |

On the demo simulator (random-walk data) the batch model is correctly **benched**: there's nothing real to learn. On data with genuine structure it deploys (see `tests/test_zz_quant.py`). Expect the same honesty on live markets: when it can't find an edge after costs, it says so.

Why not deep RL / transformers / GNN training in-app? They need far more data and GPU time than a $6 server or a Raspberry Pi has, and they overfit crypto's few regimes easily. The graph features give the cross-asset "contagion" benefit cheaply. A PyTorch research add-on can plug in later as another ensemble component.

### Continuous learning + Math Lab (v1.3)
- **Always adapting:** challenger retrain every `QUANT_RETRAIN_MINUTES` (default 60) on recency-weighted data. Promoted only if it beats the current model on data that model never saw. Early retrain when the market drifts away from the training distribution. Models are saved to disk and survive restarts. The online learner and the regime-weighted ensemble update continuously in between.
- **Honest "near-100%":** direction can't be predicted near 100% in crypto, and anything claiming it is overfit. Instead you get (1) **adaptive conformal price ranges** that land inside the range about 95% of the time and self-correct as volatility changes, and (2) a **precision dial** that only issues stances when the model's historical hit rate at that confidence clears `QUANT_MIN_PRECISION`.
- **Math Lab:** Kalman trend, GARCH volatility, Hurst exponent, permutation entropy, Bayesian change-points, Ornstein-Uhlenbeck mean reversion, Hawkes self-excitation, FFT cycles, cointegrated pairs.

### Speed, Pattern Memory, Bet Simulator, World (v1.4)
- **Speed:** C-level vectorised indicators, a process pool for per-coin features (`QUANT_WORKERS`) with incremental caching, and an attention-based scheduler that re-analyses busy coins every 10–20 s. Retrain ≈ 6 s, inference ≈ 50 ms per coin, simulator ≈ 20–30 ms. See Admin → Quant Engine → *Engine performance*.
- **Pattern Memory:** "what happened before" across every coin, matched on chart shape and dollars traded. Shows own-coin vs other-coin outcomes, the difference between them, and how rare today's move is.
- **Bet Simulator** (`/simulator`): bankroll + stake + coin + hold + strategy → one-year replay with fees, 5,000 Monte Carlo years, chance of profit / losing half, best hour to enter.
- **World** (`/world`): how crypto behaved under today's sentiment, news tone, crisis headlines, dollar, VIX and rates, plus 20 economies' GDP, debt, income and inflation. Set `FRED_API_KEY` (free) for US rates, VIX and S&P 500.

### Running on real market data
Live data is the default (`FEEDS=coinbase,kraken`; add `binanceus` if you like). The setup wizard picks it unless you choose the demo. On boot it backfills a year of hourly candles and recent 1m/5m/15m candles from Coinbase, then streams every trade over WebSockets. Kraken Futures (funding/OI), Deribit (options) and CoinGecko (trending) are polled automatically. The first model trains as soon as ~400 hourly candles are available (immediately after the backfill).

## 5b. Built-in growth tools
* **Public accuracy page (`/performance`)** measures what price actually did 15/60/240 minutes after every market alert: hit rate and average move by score bucket, with no cherry-picking. Toggle with `PUBLIC_PERFORMANCE`.
* **Free promo channel** (`PROMO_TELEGRAM_CHAT` and/or `PROMO_DISCORD_WEBHOOK`) auto-posts strong alerts 15 minutes late with an upgrade link, capped at 4 posts an hour.
* **Yearly plans** appear automatically once `STRIPE_PRICE_*_YEARLY` are set (setup_stripe.py creates them).
* **SEO**: sitemap.xml, robots.txt, social-share cards (`app/static/og.png`), installable web app manifest.
* **White-label**: `APP_NAME`, `ACCENT_COLOR`, `ACCENT_COLOR_2`, `LOGO_URL`, `TAGLINE`, `COMPANY_NAME`, plus the About page (`FOUNDER_*`, `COMPANY_LOCATION`, `SOCIAL_*`).
* **Give-back**: set `CHARITY_NAME`, `CHARITY_URL`, `CHARITY_PERCENT` to show a donation pledge site-wide. Only enable it if you donate.
* **Accounts**: password reset by email (needs SMTP). Without SMTP, admins can issue a temporary password from the Admin page.

## 6. Operations
* Backups: `python scripts/backup.py` (hot SQLite backup, keeps the last 14). Add it to cron nightly.
* Upgrades: replace the code and restart. New database columns are added automatically on boot.
* Logs: `journalctl -u strikepulse -f` (systemd) or `docker compose logs -f`.
* Health check for uptime monitors: `GET /api/health`.

## 7. API and webhooks (Elite)
* Docs: `/api/docs`. Auth: `X-API-Key` header (key shown in Settings).
* `GET /api/v1/alerts?since=&symbol=&kind=&min_score=` · `/api/v1/prices` · `/api/v1/candles?symbol=&tf=` · `/api/v1/watches`
* Webhook POSTs are signed: `X-StrikePulse-Signature: sha256=HMAC_SHA256(body, api_key)`
```python
import hmac, hashlib
ok = hmac.compare_digest(request.headers["X-StrikePulse-Signature"],
                         "sha256=" + hmac.new(API_KEY.encode(), raw_body, hashlib.sha256).hexdigest())
```

## 8. Security built in
scrypt password hashing · CSRF on every form · login and sign-up rate limits · signed, `HttpOnly`, `SameSite` session cookies (Secure on https) · strict CSP (no inline JS) · HSTS · SSRF protection on user webhooks (private, loopback and metadata IPs blocked) · Stripe signature verification · Telegram link codes rotate after use · HTML-escaped alert content · per-user daily caps.

## 9. Project map
```
app/
  engine/      candles, indicators, 9 detectors, Isolation Forest, confluence scoring, engine loop
  feeds/       Coinbase, Kraken, Binance.US WebSockets + simulator
  onchain/     Bloom filter, Ethereum watcher (whales, LP burns, mints, ownership, gas), de-peg, listings
  alerts/      dispatcher (matching, delays, caps), channels (Telegram/Discord/email/ntfy/webhook), Telegram bot
  routes/      pages, auth, dashboard/settings, API + SSE, billing, admin
  templates/   Jinja pages (landing, pricing, dashboard, settings, on-chain, admin, legal)
  replay.py    backtester
data/          token registry, exchange wallets, flagged-address list (extend these)
scripts/       setup_stripe.py, backup.py
install.sh / install.bat / start.sh / start.bat   one-command install + run
SELLING.md     launch + sales playbook · LICENSE.txt commercial license template
deploy/        Caddyfile, systemd unit
tests/         89 tests: detectors, analytics, quant models, math lab, pattern memory, simulator,, scoring, feeds parsing, on-chain decoding, dispatch rules, web flows, Stripe webhooks
```

## 10. Launch checklist
- [ ] `SECRET_KEY` set, `BASE_URL` is https, admin password changed
- [ ] Stripe live keys, webhook and Customer portal configured, payout bank added
- [ ] Telegram bot token set; test alert received
- [ ] Terms, privacy and disclaimer pages reviewed by a lawyer (`app/templates/legal/`)
- [ ] `data/flagged_addresses.csv` populated from a threat-intel source you trust
- [ ] Backtest on real data and set thresholds
- [ ] Uptime monitor on `/api/health`, and nightly backups of `data/strikepulse.db`

## 11. More growth ideas
* **Referral program**: Stripe promotion codes are already enabled at checkout; give partners recurring codes.
* More chains: add Solana/Base WebSocket watchers alongside `onchain/ethereum.py`.
* AI summaries: one plain-English sentence per alert using an LLM API (watch the per-alert cost).
* Portfolio mode: users enter holdings, and alerts are weighted by their exposure.

---
**Not financial advice.** StrikePulse sends automated, general market data. It never holds funds or exchange keys.

## Help and support tools

- Customers: the built-in Help center is at `/help`.
- Owners: reset any password with `python scripts/reset_password.py you@example.com` (add `--admin` to grant admin).
- Backups: `python scripts/backup.py` (see the script header for a daily cron line).

## Every major coin (v1.5)
- `SYMBOLS=auto` live-streams the top 25 coins by market cap (`AUTO_SYMBOLS_TOP` to change).
- `MARKET_DATA_PROVIDER=coingecko` (+ `COINGECKO_API_KEY`) or `coinmarketcap` (+ `CMC_API_KEY`) adds the
  top 250 coins: the **Markets** page, big-mover alerts, watches on any coin, and data for devices.
- Read `docs/LEGAL_NOTES.md` before charging customers: free exchange feeds and free API keys are
  usually licensed for personal use only.

## Companion apps (v1.5)
Galaxy Watch / Wear OS, Apple Watch, ESP32 ticker, Raspberry Pi monitor, MicroPython, browser
extension, desktop tray and Home Assistant are in `companions/` (see `companions/README.md`). Users pair them on
the **Devices** page with a 6-digit code. GitHub Actions (`.github/workflows/companions.yml`) builds the
firmware, APK, watch app and extension.

## Cloudflare (v1.5)
- Docker: put `TUNNEL_TOKEN=` in `.env`, then `docker compose --profile cloudflare up -d`. In the
  Cloudflare tunnel, add a public hostname → `http://app:8000`.
- No Docker (VPS or a Pi at home): `sudo deploy/cloudflare/install-tunnel.sh <token>`, hostname → `http://localhost:8000`.
- Set `TRUST_CLOUDFLARE=true` and `BASE_URL=https://yourdomain.com`. In Cloudflare, turn **off** Rocket Loader
  and Email Obfuscation (they inject scripts the strict security policy blocks), and add a cache rule
  to bypass `/api/*`.
