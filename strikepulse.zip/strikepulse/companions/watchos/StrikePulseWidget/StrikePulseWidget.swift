import SwiftUI
import WidgetKit

struct Entry: TimelineEntry {
    let date: Date
    let symbol: String
    let price: Double?
    let change: Double?
    let alert: String?
}

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> Entry { Entry(date: .now, symbol: "BTC", price: 97000, change: 2.1, alert: nil) }

    func getSnapshot(in context: Context, completion: @escaping (Entry) -> Void) {
        completion(entry(from: Store.cached) ?? placeholder(in: context))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> Void) {
        Task {
            let st = Store.paired ? ((try? await Api.refresh()) ?? Store.cached) : nil
            let e = entry(from: st) ?? Entry(date: .now, symbol: "SP", price: nil, change: nil, alert: "Open to pair")
            completion(Timeline(entries: [e], policy: .after(Date().addingTimeInterval(15 * 60))))
        }
    }

    private func entry(from st: Status?) -> Entry? {
        guard let p = st?.prices.first else { return nil }
        return Entry(date: .now, symbol: p.s, price: p.p, change: p.c24, alert: st?.alerts.first?.ti)
    }
}

struct ComplicationView: View {
    @Environment(\.widgetFamily) var family
    let entry: Entry

    var body: some View {
        switch family {
        case .accessoryCircular:
            VStack(spacing: 0) {
                Text(entry.symbol).font(.caption2).bold()
                Text(fmtPct(entry.change)).font(.caption2)
            }
        case .accessoryInline:
            Text("\(entry.symbol) \(fmtPct(entry.change))")
        case .accessoryCorner:
            Text(fmtPct(entry.change)).widgetLabel(entry.symbol)
        default:
            VStack(alignment: .leading) {
                HStack {
                    Text(entry.symbol).bold()
                    Text(entry.price.map(fmtPrice) ?? "—")
                    Text(fmtPct(entry.change)).foregroundStyle((entry.change ?? 0) >= 0 ? .primary : Color.red)
                }
                if let a = entry.alert { Text(a).font(.caption2).lineLimit(2) }
            }
        }
    }
}

@main
struct StrikePulseWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "StrikePulseComplication", provider: Provider()) { entry in
            ComplicationView(entry: entry).containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("StrikePulse")
        .description("Your first coin's 24h move and the latest alert.")
        .supportedFamilies([.accessoryCircular, .accessoryRectangular, .accessoryInline, .accessoryCorner])
    }
}
