import SwiftUI

struct PairView: View {
    var onPaired: () -> Void
    @State private var url = Store.baseURL
    @State private var code = ""
    @State private var message = "Code from the Devices page"
    @State private var busy = false

    private let keys = [["1", "2", "3"], ["4", "5", "6"], ["7", "8", "9"], ["⌫", "0", "OK"]]

    var body: some View {
        ScrollView {
            VStack(spacing: 6) {
                Text("StrikePulse").font(.headline).foregroundStyle(spRed)
                TextField("Server address", text: $url)
                    .textContentType(.URL)
                    .font(.footnote)
                    .onSubmit {
                        if !url.hasPrefix("http") { url = "https://" + url }
                        Store.baseURL = url
                    }
                Text(String(code.padding(toLength: 6, withPad: "•", startingAt: 0).enumerated().map { $0.offset == 3 ? " \($0.element)" : "\($0.element)" }.joined()))
                    .font(.system(size: 24, weight: .bold, design: .monospaced))
                Text(message).font(.caption2).foregroundStyle(.secondary).multilineTextAlignment(.center)
                ForEach(keys, id: \.self) { row in
                    HStack(spacing: 4) {
                        ForEach(row, id: \.self) { k in
                            Button(k) { press(k) }
                                .buttonStyle(.bordered)
                                .tint(k == "OK" ? spRed : .gray)
                                .disabled(busy)
                        }
                    }
                }
            }
        }
    }

    private func press(_ k: String) {
        switch k {
        case "⌫": code = String(code.dropLast())
        case "OK":
            guard code.count == 6 else { return }
            if !url.hasPrefix("http") { url = "https://" + url }
            Store.baseURL = url
            busy = true
            message = "Pairing…"
            Task {
                do {
                    try await Api.pair(code: code)
                    onPaired()
                } catch {
                    message = error.localizedDescription
                    code = ""
                }
                busy = false
            }
        default: if code.count < 6 { code += k }
        }
    }
}
