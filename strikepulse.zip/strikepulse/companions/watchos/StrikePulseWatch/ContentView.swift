import SwiftUI
import UserNotifications
import WidgetKit

let spRed = Color(red: 0.882, green: 0.114, blue: 0.180)

struct ContentView: View {
    @State private var paired = Store.paired

    var body: some View {
        NavigationStack {
            if paired { PricesView(onUnpair: { Store.clear(); paired = false }) }
            else { PairView(onPaired: { paired = true }) }
        }
        .task {
            _ = try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound])
        }
    }
}

struct PricesView: View {
    var onUnpair: () -> Void
    @State private var status: Status? = Store.cached
    @State private var error: String?

    var body: some View {
        List {
            if let error { Text(error).font(.footnote).foregroundStyle(spRed) }
            if let fng = status?.fng { Text("Fear & Greed \(fng)").font(.footnote).foregroundStyle(.secondary) }
            ForEach(status?.prices ?? []) { p in
                VStack(alignment: .leading, spacing: 2) {
                    HStack {
                        Text(p.s).font(.headline)
                        Spacer()
                        Text(fmtPct(p.c24)).foregroundStyle((p.c24 ?? 0) >= 0 ? Color.white : spRed)
                    }
                    HStack {
                        Text(fmtPrice(p.p)).font(.footnote)
                        if let st = status?.stance?[p.s]?.st { Text("· \(st)").font(.footnote).foregroundStyle(.secondary) }
                    }
                }
            }
            if let alerts = status?.alerts, !alerts.isEmpty {
                Section("Latest alerts") {
                    ForEach(alerts) { a in
                        VStack(alignment: .leading) {
                            Text("\(a.s) · \(a.sc)").font(.caption2).foregroundStyle(.secondary)
                            Text(a.ti).font(.footnote).foregroundStyle(a.d < 0 ? spRed : .white)
                        }
                    }
                }
            }
            if let src = status?.src { Text(src).font(.caption2).foregroundStyle(.secondary) }
            Button("Unpair", role: .destructive, action: onUnpair)
        }
        .navigationTitle("StrikePulse")
        .task {
            BackgroundSync.schedule()
            while !Task.isCancelled {                       // live refresh while the app is open
                do {
                    let st = try await Api.refresh()
                    await BackgroundSync.announce(st)
                    status = st
                    error = nil
                    WidgetCenter.shared.reloadAllTimelines()
                } catch {
                    self.error = error.localizedDescription
                }
                try? await Task.sleep(for: .seconds(max(15, status?.refresh ?? 15)))
            }
        }
    }
}
