import SwiftUI
import UserNotifications
import WatchKit
import WidgetKit

@main
struct StrikePulseApp: App {
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup { ContentView() }
            .backgroundTask(.appRefresh("sp-refresh")) {
                await BackgroundSync.run()
            }
            .onChange(of: phase) { _, newPhase in
                if newPhase == .background { BackgroundSync.schedule() }
            }
    }
}

enum BackgroundSync {
    /// watchOS decides the exact time; asking for ~15 minutes keeps the complication and buzzes fresh.
    static func schedule() {
        WKApplication.shared().scheduleBackgroundRefresh(withPreferredDate: Date().addingTimeInterval(15 * 60),
                                                       userInfo: "sp-refresh" as NSSecureCoding & NSObjectProtocol) { _ in }
    }

    static func run() async {
        defer { schedule() }
        guard Store.paired, let st = try? await Api.refresh() else { return }
        await announce(st)
        WidgetCenter.shared.reloadAllTimelines()
    }

    /// Buzz + local notification for alerts newer than the last one seen (not on the very first sync).
    @MainActor
    static func announce(_ st: Status) async {
        let last = Store.lastAlert
        let fresh = st.alerts.filter { $0.t > last }
        if let newest = st.newest, newest > last { Store.lastAlert = newest }
        guard last > 0, !fresh.isEmpty else { return }
        WKInterfaceDevice.current().play(fresh.contains { $0.sc >= 80 } ? .notification : .click)
        let center = UNUserNotificationCenter.current()
        for a in fresh.prefix(3) {
            let c = UNMutableNotificationContent()
            c.title = "\(a.s) · score \(a.sc)"
            c.body = a.ti
            c.sound = .default
            try? await center.add(UNNotificationRequest(identifier: a.id, content: c, trigger: nil))
        }
    }
}
