import Foundation

let appGroup = "group.com.strikebacktech.strikepulse"

struct Price: Codable, Identifiable, Hashable {
    let s: String
    let p: Double
    let c1h: Double?
    let c24: Double?
    let live: Bool?
    let sp: [Double]?
    var id: String { s }
}

struct AlertItem: Codable, Identifiable, Hashable {
    let id: String
    let t: Int
    let k: String
    let s: String
    let d: Int
    let sc: Int
    let ti: String
}

struct Stance: Codable, Hashable { let st: String?; let cf: Double?; let pu: Double? }

struct Status: Codable {
    let prices: [Price]
    let alerts: [AlertItem]
    let stance: [String: Stance]?
    let fng: Int?
    let newest: Int?
    let refresh: Int?
    let src: String?
}

struct ApiError: LocalizedError {
    let code: Int
    let detail: String
    var errorDescription: String? { code == 401 ? "Key revoked. Pair again." : detail }
}

/// Settings + cached status shared between the app and the complication (App Group defaults).
enum Store {
    static var defaults: UserDefaults { UserDefaults(suiteName: appGroup) ?? .standard }
    static var defaultURL: String { (Bundle.main.object(forInfoDictionaryKey: "SPDefaultURL") as? String) ?? "https://yourdomain.com" }
    static var baseURL: String {
        get { defaults.string(forKey: "base_url") ?? defaultURL }
        set { defaults.set(newValue.trimmingCharacters(in: .whitespaces).trimmingCharacters(in: CharacterSet(charactersIn: "/")), forKey: "base_url") }
    }
    static var token: String {
        get { defaults.string(forKey: "token") ?? "" }
        set { defaults.set(newValue, forKey: "token") }
    }
    static var lastAlert: Int {
        get { defaults.integer(forKey: "last_alert") }
        set { defaults.set(newValue, forKey: "last_alert") }
    }
    static var cached: Status? {
        get { defaults.data(forKey: "cached").flatMap { try? JSONDecoder().decode(Status.self, from: $0) } }
        set { defaults.set(newValue.flatMap { try? JSONEncoder().encode($0) }, forKey: "cached") }
    }
    static var paired: Bool { !token.isEmpty }
    static func clear() { ["token", "cached", "last_alert"].forEach { defaults.removeObject(forKey: $0) } }
}

enum Api {
    private static func request(_ path: String, method: String = "GET", body: [String: Any]? = nil, token: String? = nil) async throws -> Data {
        guard let url = URL(string: Store.baseURL + path) else { throw ApiError(code: 0, detail: "Bad server address") }
        var req = URLRequest(url: url, timeoutInterval: 15)
        req.httpMethod = method
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.setValue("StrikePulse-watchOS/1.0", forHTTPHeaderField: "User-Agent")
        if let token, !token.isEmpty { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body {
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        let (data, resp) = try await URLSession.shared.data(for: req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard (200..<300).contains(code) else {
            let detail = (try? JSONSerialization.jsonObject(with: data) as? [String: Any])?["detail"] as? String ?? "HTTP \(code)"
            throw ApiError(code: code, detail: detail)
        }
        return data
    }

    static func pair(code: String) async throws {
        let data = try await request("/api/device/pair", method: "POST", body: ["code": code])
        let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        guard let token = obj?["token"] as? String else { throw ApiError(code: 0, detail: "No key returned") }
        Store.token = token
    }

    @discardableResult
    static func refresh() async throws -> Status {
        let data = try await request("/api/device/status?limit=5&n=8&spark=1", token: Store.token)
        let st = try JSONDecoder().decode(Status.self, from: data)
        Store.cached = st
        return st
    }
}

func fmtPrice(_ p: Double) -> String {
    if p >= 1000 { return "$" + p.formatted(.number.precision(.fractionLength(0))) }
    if p >= 1 { return "$" + p.formatted(.number.precision(.fractionLength(2))) }
    return "$" + p.formatted(.number.precision(.significantDigits(4)))
}

func fmtPct(_ v: Double?) -> String {
    guard let v else { return "—" }
    return (v >= 0 ? "+" : "") + v.formatted(.number.precision(.fractionLength(1))) + "%"
}
