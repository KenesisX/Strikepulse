// Copy to config.h and fill in. Never commit config.h (it holds your Wi-Fi password and device key).
#pragma once

#define WIFI_SSID      "your-wifi"
#define WIFI_PASSWORD  "your-wifi-password"

// Your StrikePulse address (https recommended).
#define SP_BASE_URL    "https://yourdomain.com"

// Pair one of two ways:
//  a) leave SP_TOKEN empty and put the 6-digit code from the Devices page in SP_PAIR_CODE.
//     The board pairs on first boot and stores the key in flash (NVS). Then clear the code.
//  b) paste the device key ("No keypad? Use the device key instead") into SP_TOKEN.
#define SP_PAIR_CODE   ""
#define SP_TOKEN       ""

// "" = your watchlist (up to 6 coins), or e.g. "BTC,ETH,SOL,DOGE"
#define SP_SYMBOLS     ""

// Optional active buzzer pin (-1 = none). The CYD's speaker connector is GPIO 26.
#define SP_BUZZER_PIN  -1

// TLS: 1 = encrypt but skip certificate checks (simplest; works behind Cloudflare and any host).
//      0 = verify against SP_ROOT_CA below (paste your site's root CA in PEM format).
#define SP_TLS_INSECURE 1
#define SP_ROOT_CA ""
