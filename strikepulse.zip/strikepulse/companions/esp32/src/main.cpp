// StrikePulse ESP32 desk ticker.
// Shows your coins (price + 24h change), the latest alert, and lights/beeps on new alerts.
// Displays: ILI9341/ST7789 via TFT_eSPI (SP_DISPLAY_TFT) or SSD1306 OLED (SP_DISPLAY_OLED).
#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include "config.h"

#if defined(SP_DISPLAY_TFT)
#include <TFT_eSPI.h>
TFT_eSPI tft;
#define SP_RED   0xE0C5   // close to #e11d2e in RGB565
#define SP_WHITE TFT_WHITE
#define SP_GREY  0x8410
#define SP_BLACK TFT_BLACK
#elif defined(SP_DISPLAY_OLED)
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
#endif

#ifndef SP_LED_ACTIVE_LOW
#define SP_LED_ACTIVE_LOW 0
#endif

static const int MAX_COINS = 6;
struct Coin { char s[8]; double p; float c24; bool hasC24; };
Coin coins[MAX_COINS];
int coinCount = 0;
char alertTitle[96] = "";
int alertScore = 0;
int alertDir = 0;
long newestAlert = 0;
long lastSeenAlert = 0;
int refreshSec = 30;
int fng = -1;
char token[80] = "";
char statusLine[64] = "Starting...";
Preferences prefs;
unsigned long nextFetch = 0;
unsigned long flashUntil = 0;
int page = 0;

void ledSet(bool on) {
#ifdef SP_LED_R
  pinMode(SP_LED_R, OUTPUT);
  digitalWrite(SP_LED_R, (on ^ SP_LED_ACTIVE_LOW) ? HIGH : LOW);
#endif
}

void beep(int times) {
  for (int i = 0; i < times; i++) {
    ledSet(true);
    if (SP_BUZZER_PIN >= 0) { pinMode(SP_BUZZER_PIN, OUTPUT); digitalWrite(SP_BUZZER_PIN, HIGH); }
    delay(120);
    ledSet(false);
    if (SP_BUZZER_PIN >= 0) digitalWrite(SP_BUZZER_PIN, LOW);
    delay(120);
  }
}

void fmtPrice(double p, char *out, size_t n) {
  if (p >= 1000) snprintf(out, n, "$%.0f", p);
  else if (p >= 1) snprintf(out, n, "$%.2f", p);
  else if (p >= 0.01) snprintf(out, n, "$%.4f", p);
  else snprintf(out, n, "$%.7f", p);
}

// ------------------------------------------------------------------ display
void displayBegin() {
#if defined(SP_DISPLAY_TFT)
  tft.init();
  tft.setRotation(1);
  tft.fillScreen(SP_BLACK);
#ifdef TFT_BL
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);
#endif
#elif defined(SP_DISPLAY_OLED)
  Wire.begin();
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.clearDisplay();
  oled.display();
#endif
}

void drawMessage(const char *a, const char *b) {
  Serial.printf("%s %s\n", a, b);
#if defined(SP_DISPLAY_TFT)
  tft.fillScreen(SP_BLACK);
  tft.setTextColor(SP_RED, SP_BLACK);
  tft.drawString("StrikePulse", 10, 10, 4);
  tft.setTextColor(SP_WHITE, SP_BLACK);
  tft.drawString(a, 10, 60, 2);
  tft.drawString(b, 10, 85, 2);
#elif defined(SP_DISPLAY_OLED)
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(1);
  oled.setCursor(0, 0); oled.print("StrikePulse");
  oled.setCursor(0, 20); oled.print(a);
  oled.setCursor(0, 34); oled.print(b);
  oled.display();
#endif
}

void drawTicker() {
  char buf[32];
  bool flashing = millis() < flashUntil && ((millis() / 400) % 2 == 0);
#if defined(SP_DISPLAY_TFT)
  int W = tft.width(), H = tft.height();
  uint16_t bg = flashing ? SP_RED : SP_BLACK;
  tft.fillScreen(bg);
  tft.setTextColor(flashing ? SP_WHITE : SP_RED, bg);
  tft.drawString("StrikePulse", 8, 6, 2);
  tft.setTextColor(SP_GREY, bg);
  if (fng >= 0) { snprintf(buf, sizeof buf, "Mood %d", fng); tft.drawRightString(buf, W - 8, 6, 2); }
  int rows = (H - 80) / 34;
  if (rows < 1) rows = 1;
  int pages = (coinCount + rows - 1) / rows;
  if (pages < 1) pages = 1;
  int start = (page % pages) * rows;
  int y = 30;
  for (int i = start; i < coinCount && i < start + rows; i++) {
    tft.setTextColor(SP_WHITE, bg);
    tft.drawString(coins[i].s, 8, y, 4);
    fmtPrice(coins[i].p, buf, sizeof buf);
    tft.drawRightString(buf, W - 80, y, 4);
    if (coins[i].hasC24) {
      snprintf(buf, sizeof buf, "%+.1f%%", coins[i].c24);
      tft.setTextColor(coins[i].c24 >= 0 ? SP_WHITE : SP_RED, bg);
      tft.drawRightString(buf, W - 8, y + 4, 2);
    }
    y += 34;
  }
  tft.drawFastHLine(8, H - 46, W - 16, SP_GREY);
  tft.setTextColor(alertDir < 0 ? SP_RED : SP_WHITE, bg);
  if (alertTitle[0]) {
    snprintf(buf, sizeof buf, "Alert  score %d", alertScore);
    tft.setTextColor(SP_GREY, bg);
    tft.drawString(buf, 8, H - 40, 1);
    tft.setTextColor(alertDir < 0 ? SP_RED : SP_WHITE, bg);
    tft.drawString(String(alertTitle).substring(0, 38), 8, H - 26, 2);
  } else {
    tft.setTextColor(SP_GREY, bg);
    tft.drawString(statusLine, 8, H - 26, 2);
  }
  page++;
#elif defined(SP_DISPLAY_OLED)
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(1);
  if (flashing) oled.fillRect(0, 0, 128, 10, SSD1306_WHITE), oled.setTextColor(SSD1306_BLACK);
  oled.setCursor(0, 1); oled.print("StrikePulse");
  oled.setTextColor(SSD1306_WHITE);
  int pages = (coinCount + 3) / 4; if (pages < 1) pages = 1;
  int start = (page % pages) * 4;
  int y = 13;
  for (int i = start; i < coinCount && i < start + 4; i++) {
    fmtPrice(coins[i].p, buf, sizeof buf);
    oled.setCursor(0, y); oled.print(coins[i].s);
    oled.setCursor(34, y); oled.print(buf);
    if (coins[i].hasC24) { snprintf(buf, sizeof buf, "%+.1f", coins[i].c24); oled.setCursor(98, y); oled.print(buf); }
    y += 10;
  }
  oled.setCursor(0, 55);
  oled.print(alertTitle[0] ? String(alertTitle).substring(0, 21) : String(statusLine).substring(0, 21));
  oled.display();
  page++;
#endif
}

// ------------------------------------------------------------------ network
bool wifiUp() {
  if (WiFi.status() == WL_CONNECTED) return true;
  drawMessage("Connecting to Wi-Fi", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  for (int i = 0; i < 40 && WiFi.status() != WL_CONNECTED; i++) delay(500);
  return WiFi.status() == WL_CONNECTED;
}

void secure(WiFiClientSecure &c) {
#if SP_TLS_INSECURE
  c.setInsecure();
#else
  c.setCACert(SP_ROOT_CA);
#endif
}

bool begin(HTTPClient &http, WiFiClientSecure &sc, WiFiClient &plain, const String &url) {
  if (url.startsWith("https")) { secure(sc); return http.begin(sc, url); }
  return http.begin(plain, url);
}

bool pairDevice() {
  if (strlen(SP_PAIR_CODE) != 6) return false;
  drawMessage("Pairing with code", SP_PAIR_CODE);
  WiFiClientSecure sc; WiFiClient plain; HTTPClient http;
  if (!begin(http, sc, plain, String(SP_BASE_URL) + "/api/device/pair")) return false;
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(String("{\"code\":\"") + SP_PAIR_CODE + "\"}");
  if (code != 200) {
    snprintf(statusLine, sizeof statusLine, "Pair failed (HTTP %d)", code);
    drawMessage("Pairing failed", "Make a new code on the Devices page");
    http.end();
    return false;
  }
  JsonDocument doc;
  if (deserializeJson(doc, http.getString())) { http.end(); return false; }
  http.end();
  strlcpy(token, doc["token"] | "", sizeof token);
  prefs.putString("token", token);
  drawMessage("Paired!", "Clear SP_PAIR_CODE in config.h");
  delay(1500);
  return token[0] != 0;
}

bool fetchStatus() {
  String url = String(SP_BASE_URL) + "/api/device/status?limit=1&n=" + MAX_COINS;
  if (strlen(SP_SYMBOLS)) url += String("&symbols=") + SP_SYMBOLS;
  WiFiClientSecure sc; WiFiClient plain; HTTPClient http;
  if (!begin(http, sc, plain, url)) return false;
  http.addHeader("Authorization", String("Bearer ") + token);
  http.setUserAgent("StrikePulse-ESP32/1.0");
  int code = http.GET();
  if (code != 200) {
    snprintf(statusLine, sizeof statusLine, code == 401 ? "Key revoked: re-pair" : "HTTP %d", code);
    if (code == 401) { prefs.remove("token"); token[0] = 0; }
    http.end();
    return false;
  }
  JsonDocument filter;
  filter["prices"][0]["s"] = true; filter["prices"][0]["p"] = true; filter["prices"][0]["c24"] = true;
  filter["alerts"][0]["ti"] = true; filter["alerts"][0]["sc"] = true; filter["alerts"][0]["d"] = true; filter["alerts"][0]["t"] = true;
  filter["newest"] = true; filter["refresh"] = true; filter["fng"] = true;
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (err) { snprintf(statusLine, sizeof statusLine, "JSON: %s", err.c_str()); return false; }

  coinCount = 0;
  for (JsonObject p : doc["prices"].as<JsonArray>()) {
    if (coinCount >= MAX_COINS) break;
    strlcpy(coins[coinCount].s, p["s"] | "?", sizeof coins[coinCount].s);
    coins[coinCount].p = p["p"] | 0.0;
    coins[coinCount].hasC24 = !p["c24"].isNull();
    coins[coinCount].c24 = p["c24"] | 0.0f;
    coinCount++;
  }
  JsonArray al = doc["alerts"].as<JsonArray>();
  if (al.size() > 0) {
    strlcpy(alertTitle, al[0]["ti"] | "", sizeof alertTitle);
    alertScore = al[0]["sc"] | 0;
    alertDir = al[0]["d"] | 0;
  }
  fng = doc["fng"].isNull() ? -1 : (int)(doc["fng"] | -1);
  refreshSec = max(15, (int)(doc["refresh"] | 30));
  newestAlert = doc["newest"] | 0L;
  if (lastSeenAlert && newestAlert > lastSeenAlert) {
    flashUntil = millis() + 8000;
    beep(alertScore >= 80 ? 3 : 1);
  }
  if (newestAlert > lastSeenAlert) lastSeenAlert = newestAlert;
  snprintf(statusLine, sizeof statusLine, "Live  Wi-Fi %d dBm", (int)WiFi.RSSI());
  return true;
}

// ------------------------------------------------------------------ main
void setup() {
  Serial.begin(115200);
  ledSet(false);
  displayBegin();
  prefs.begin("strikepulse", false);
  if (strlen(SP_TOKEN)) strlcpy(token, SP_TOKEN, sizeof token);
  else strlcpy(token, prefs.getString("token", "").c_str(), sizeof token);
  drawMessage("Starting", SP_BASE_URL);
}

void loop() {
  if (!wifiUp()) { drawMessage("Wi-Fi failed", "Retrying in 10 s"); delay(10000); return; }
  if (!token[0]) {
    if (!pairDevice()) {
      drawMessage("Not paired", "Set SP_PAIR_CODE or SP_TOKEN");
      delay(15000);
      return;
    }
  }
  if (millis() >= nextFetch) {
    fetchStatus();
    nextFetch = millis() + (unsigned long)refreshSec * 1000UL;
  }
  drawTicker();
  delay(millis() < flashUntil ? 400 : 5000);
}
