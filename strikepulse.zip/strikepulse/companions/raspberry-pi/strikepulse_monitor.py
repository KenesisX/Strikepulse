#!/usr/bin/env python3
"""StrikePulse monitor for Raspberry Pi (any model) and any Linux box.

Modes
  gui   full-screen dashboard with pygame (HDMI, DSI, or SPI LCDs like 3.5" Waveshare/ILI9486 via fbcp)
  text  live terminal dashboard (works over SSH, no screen needed)
  once  print one snapshot and exit (cron, scripts, testing)

First run:  python3 strikepulse_monitor.py --url https://yourdomain.com --pair 123456
Then:       python3 strikepulse_monitor.py            (auto picks gui if a display is available)

Optional hardware (BCM pin numbers in config.json):
  buzzer_pin  active buzzer: 1 beep on a new alert, 3 beeps when score >= 80
  led_pin     LED: lights while the newest alert is under 10 minutes old
"""
from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from strikepulse_client import ApiError, Client, fmt_pct, fmt_price, pair  # noqa: E402

CONFIG = Path(os.environ.get("STRIKEPULSE_CONFIG", Path(__file__).resolve().parent / "config.json"))
DEFAULTS = {"base_url": "", "token": "", "symbols": "", "refresh": 15, "buzzer_pin": None, "led_pin": None,
            "fullscreen": True, "width": 480, "height": 320, "rotate_seconds": 0}

RED, WHITE, GREY, DARK, BLACK = (225, 29, 46), (245, 245, 245), (150, 150, 150), (40, 40, 40), (10, 10, 10)


def load_config() -> dict:
    cfg = dict(DEFAULTS)
    if CONFIG.exists():
        cfg.update(json.loads(CONFIG.read_text()))
    return cfg


def save_config(cfg: dict) -> None:
    CONFIG.write_text(json.dumps(cfg, indent=2))
    try:
        os.chmod(CONFIG, 0o600)          # the device key is a secret
    except OSError:
        pass


# ------------------------------------------------------------------ hardware
class Hardware:
    def __init__(self, cfg: dict):
        self.buzzer = self.led = None
        try:
            from gpiozero import LED, Buzzer   # type: ignore
            if cfg.get("buzzer_pin") is not None:
                self.buzzer = Buzzer(int(cfg["buzzer_pin"]))
            if cfg.get("led_pin") is not None:
                self.led = LED(int(cfg["led_pin"]))
        except Exception:
            pass

    def beep(self, times: int = 1) -> None:
        if not self.buzzer:
            return

        def run():
            for _ in range(times):
                self.buzzer.on()
                time.sleep(0.12)
                self.buzzer.off()
                time.sleep(0.12)
        threading.Thread(target=run, daemon=True).start()

    def light(self, on: bool) -> None:
        if self.led:
            self.led.on() if on else self.led.off()


# ------------------------------------------------------------------ polling
class Poller:
    def __init__(self, client: Client, cfg: dict, hw: Hardware):
        self.client, self.cfg, self.hw = client, cfg, hw
        self.data: dict = {}
        self.error = ""
        self.last_alert_ts = 0
        self.flash_until = 0.0
        self._stop = threading.Event()

    def poll_once(self) -> None:
        try:
            d = self.client.status(symbols=self.cfg.get("symbols") or None, spark=True, limit=4)
            self.data, self.error = d, ""
            newest = d.get("newest") or 0
            if self.last_alert_ts and newest > self.last_alert_ts:
                strong = any(a["sc"] >= 80 for a in d.get("alerts", []) if a["t"] > self.last_alert_ts)
                self.hw.beep(3 if strong else 1)
                self.flash_until = time.time() + 8
            if newest:
                self.last_alert_ts = max(self.last_alert_ts, newest)
            self.hw.light(bool(newest and time.time() - newest < 600))
        except ApiError as e:
            self.error = e.detail if e.status else str(e.detail)
            if e.status == 401:
                self.error = "Device key revoked or wrong. Re-pair from the Devices page."

    def run(self) -> None:
        while not self._stop.is_set():
            self.poll_once()
            wait = max(int(self.cfg.get("refresh") or 15), int(self.data.get("refresh") or 15))
            self._stop.wait(wait)

    def stop(self) -> None:
        self._stop.set()


def ago(ts: float) -> str:
    s = max(0, int(time.time() - ts))
    return f"{s}s" if s < 60 else f"{s // 60}m" if s < 3600 else f"{s // 3600}h"


def lines_for(d: dict) -> list[str]:
    out = [f"{d.get('app', 'StrikePulse')}  ·  {d.get('device', '')}  ·  {time.strftime('%H:%M:%S')}"]
    if d.get("fng") is not None:
        out.append(f"Market mood (Fear & Greed): {d['fng']}")
    out.append("")
    for p in d.get("prices", []):
        st = (d.get("stance") or {}).get(p["s"])
        stance = f"  [{st['st']}]" if st and st.get("st") else ""
        out.append(f"{p['s']:<6} {fmt_price(p['p']):>14}  1h {fmt_pct(p.get('c1h')):>7}  24h {fmt_pct(p.get('c24')):>7}{stance}")
    out.append("")
    out.append("Latest alerts:")
    for a in d.get("alerts", []):
        out.append(f"  {ago(a['t']):>4} ago  {a.get('sc', 0):>3}  {a['ti']}")
    if not d.get("alerts"):
        out.append("  (none yet)")
    if d.get("src"):
        out.append("")
        out.append(d["src"])
    return out


# ------------------------------------------------------------------ text UI
def run_text(poller: Poller) -> None:
    import curses

    def ui(scr):
        curses.curs_set(0)
        scr.nodelay(True)
        if curses.has_colors():
            curses.start_color()
            curses.use_default_colors()
            curses.init_pair(1, curses.COLOR_RED, -1)
            curses.init_pair(2, curses.COLOR_WHITE, -1)
        while True:
            scr.erase()
            h, w = scr.getmaxyx()
            rows = lines_for(poller.data) if poller.data else ["Connecting…"]
            if poller.error:
                rows = [f"! {poller.error}"] + rows
            for i, line in enumerate(rows[: h - 1]):
                color = curses.color_pair(1) if ("-" in line and "%" in line and "24h -" in line) or line.startswith("!") else 0
                try:
                    scr.addnstr(i, 0, line, w - 1, color)
                except curses.error:
                    pass
            scr.addnstr(h - 1, 0, "q = quit", w - 1)
            scr.refresh()
            for _ in range(10):
                if scr.getch() in (ord("q"), ord("Q")):
                    return
                time.sleep(0.1)
    curses.wrapper(ui)


# ------------------------------------------------------------------ GUI
def run_gui(poller: Poller, cfg: dict) -> None:
    import pygame  # type: ignore
    pygame.init()
    flags = pygame.FULLSCREEN if cfg.get("fullscreen", True) else 0
    size = (0, 0) if flags else (int(cfg["width"]), int(cfg["height"]))
    screen = pygame.display.set_mode(size, flags)
    pygame.display.set_caption("StrikePulse")
    pygame.mouse.set_visible(False)
    W, H = screen.get_size()
    scale = max(0.6, min(W / 480, H / 320))
    f_big = pygame.font.SysFont("dejavusans", int(30 * scale), bold=True)
    f_mid = pygame.font.SysFont("dejavusans", int(20 * scale))
    f_small = pygame.font.SysFont("dejavusans", int(14 * scale))
    clock = pygame.time.Clock()

    def text(s, font, color, x, y, right=False):
        img = font.render(s, True, color)
        screen.blit(img, (x - img.get_width(), y) if right else (x, y))
        return img.get_height()

    def spark(points, rect, color):
        if len(points) < 2:
            return
        lo, hi = min(points), max(points)
        rng = (hi - lo) or 1
        x0, y0, w, h = rect
        pts = [(x0 + i * w / (len(points) - 1), y0 + h - (v - lo) / rng * h) for i, v in enumerate(points)]
        pygame.draw.lines(screen, color, False, pts, 2)

    running = True
    while running:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT or (ev.type == pygame.KEYDOWN and ev.key in (pygame.K_q, pygame.K_ESCAPE)):
                running = False
        flashing = time.time() < poller.flash_until and int(time.time() * 2) % 2 == 0
        screen.fill(RED if flashing else BLACK)
        d = poller.data
        pad = int(10 * scale)
        y = pad
        text(d.get("app", "StrikePulse") if d else "StrikePulse", f_mid, RED if not flashing else WHITE, pad, y)
        text(time.strftime("%H:%M"), f_mid, GREY, W - pad, y, right=True)
        y += int(30 * scale)
        if poller.error and not d:
            text(poller.error[:60], f_small, RED, pad, y)
        prices = d.get("prices", []) if d else []
        rows = max(1, min(len(prices), int((H * 0.62) // (44 * scale))))
        for p in prices[:rows]:
            up = (p.get("c24") or 0) >= 0
            col = WHITE if up else RED
            text(p["s"], f_big, WHITE, pad, y)
            text(fmt_price(p["p"]), f_big, WHITE, int(W * 0.62), y, right=True)
            text(fmt_pct(p.get("c24")), f_mid, col, W - pad, y + int(6 * scale), right=True)
            spark(p.get("sp", []), (int(W * 0.25), y + int(6 * scale), int(W * 0.18), int(24 * scale)), col)
            y += int(44 * scale)
        pygame.draw.line(screen, DARK, (pad, y), (W - pad, y), 1)
        y += pad
        alerts = d.get("alerts", []) if d else []
        if alerts:
            a = alerts[0]
            text(f"{ago(a['t'])} ago · score {a['sc']}", f_small, GREY, pad, y)
            y += int(18 * scale)
            text(a["ti"][:48], f_mid, RED if a["d"] < 0 else WHITE, pad, y)
        else:
            text("No alerts yet", f_small, GREY, pad, y)
        foot = []
        if d.get("fng") is not None if d else False:
            foot.append(f"Fear & Greed {d['fng']}")
        if poller.error:
            foot.append(poller.error[:40])
        if foot:
            text("  ·  ".join(foot), f_small, GREY, pad, H - int(20 * scale))
        pygame.display.flip()
        clock.tick(4)
    pygame.quit()


# ------------------------------------------------------------------ main
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="StrikePulse Raspberry Pi monitor")
    ap.add_argument("--url", help="your StrikePulse address, e.g. https://strikepulse.app")
    ap.add_argument("--pair", metavar="CODE", help="6-digit code from the Devices page")
    ap.add_argument("--token", help="device key (instead of pairing)")
    ap.add_argument("--symbols", help="comma list, e.g. BTC,ETH,SOL (default: your watchlist)")
    ap.add_argument("--mode", choices=["auto", "gui", "text", "once"], default="auto")
    ap.add_argument("--windowed", action="store_true", help="GUI in a window instead of full screen")
    args = ap.parse_args(argv)

    cfg = load_config()
    if args.url:
        cfg["base_url"] = args.url.rstrip("/")
    if args.symbols is not None:
        cfg["symbols"] = args.symbols
    if args.windowed:
        cfg["fullscreen"] = False
    if args.pair:
        if not cfg["base_url"]:
            print("Add --url https://yourdomain.com when pairing.")
            return 2
        try:
            cfg["token"] = pair(cfg["base_url"], args.pair)
        except ApiError as e:
            print(f"Pairing failed: {e.detail}")
            return 1
        print("Paired. Key saved to", CONFIG)
    if args.token:
        cfg["token"] = args.token
    if args.pair or args.token or args.url or args.symbols is not None:
        save_config(cfg)
    if not (cfg["base_url"] and cfg["token"]):
        print("Not set up yet. Run:  python3 strikepulse_monitor.py --url https://yourdomain.com --pair 123456")
        return 2

    client = Client(cfg["base_url"], cfg["token"])
    hw = Hardware(cfg)
    poller = Poller(client, cfg, hw)

    if args.mode == "once":
        poller.poll_once()
        if poller.error:
            print("Error:", poller.error)
            return 1
        print("\n".join(lines_for(poller.data)))
        return 0

    mode = args.mode
    if mode == "auto":
        has_display = bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")) or Path("/dev/fb0").exists()
        try:
            import pygame  # noqa: F401  type: ignore
            mode = "gui" if has_display else "text"
        except ImportError:
            mode = "text"

    t = threading.Thread(target=poller.run, daemon=True)
    t.start()
    signal.signal(signal.SIGTERM, lambda *_: (poller.stop(), sys.exit(0)))
    try:
        run_gui(poller, cfg) if mode == "gui" else run_text(poller)
    except KeyboardInterrupt:
        pass
    finally:
        poller.stop()
        hw.light(False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
