#!/usr/bin/env bash
# StrikePulse Raspberry Pi monitor installer.
#   ./install.sh https://yourdomain.com 123456      (address + 6-digit code from the Devices page)
set -euo pipefail
URL="${1:-}"; CODE="${2:-}"
DEST="$HOME/strikepulse-monitor"
echo "Installing to $DEST"
sudo apt-get update -qq
sudo apt-get install -y -qq python3 python3-pygame python3-gpiozero fonts-dejavu-core >/dev/null || \
  sudo apt-get install -y -qq python3 python3-pygame fonts-dejavu-core
mkdir -p "$DEST"
cp strikepulse_monitor.py strikepulse_client.py "$DEST/"
[ -f "$DEST/config.json" ] || cp config.example.json "$DEST/config.json"
if [ -n "$URL" ] && [ -n "$CODE" ]; then
  python3 "$DEST/strikepulse_monitor.py" --url "$URL" --pair "$CODE"
fi
sed "s#/home/pi#$HOME#g; s#User=pi#User=$USER#" strikepulse-monitor.service | sudo tee /etc/systemd/system/strikepulse-monitor.service >/dev/null
sudo systemctl daemon-reload
sudo systemctl enable --now strikepulse-monitor
echo "Done. It starts on boot. Logs: journalctl -u strikepulse-monitor -f"
echo "Terminal view over SSH: python3 $DEST/strikepulse_monitor.py --mode text"
