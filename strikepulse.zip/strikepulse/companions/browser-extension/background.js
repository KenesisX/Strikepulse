import { fetchStatus, getConfig } from './api.js';

const ALARM = 'strikepulse-poll';

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARM, { periodInMinutes: 1 });
  chrome.runtime.openOptionsPage();
});
chrome.runtime.onStartup.addListener(() => chrome.alarms.create(ALARM, { periodInMinutes: 1 }));
chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM) poll(); });
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg && msg.type === 'poll') { poll().then(reply); return true; }
  return false;
});
chrome.notifications.onClicked.addListener(async () => {
  const cfg = await getConfig();
  if (cfg.baseUrl) chrome.tabs.create({ url: new URL('/alerts', cfg.baseUrl).href });
});

async function poll() {
  const cfg = await getConfig();
  if (!cfg.baseUrl || !cfg.token) {
    await chrome.action.setBadgeText({ text: '?' });
    return { error: 'not paired' };
  }
  try {
    const d = await fetchStatus(cfg);
    await chrome.storage.local.set({ last: d, lastError: '' });
    const first = (d.prices || [])[0];
    if (first && first.c24 !== null && first.c24 !== undefined) {
      const t = (first.c24 >= 0 ? '+' : '') + (Math.abs(first.c24) >= 10 ? first.c24.toFixed(0) : first.c24.toFixed(1));
      await chrome.action.setBadgeText({ text: t.slice(0, 4) });
      await chrome.action.setBadgeBackgroundColor({ color: first.c24 >= 0 ? '#2b2b2b' : '#e11d2e' });
      if (chrome.action.setBadgeTextColor) await chrome.action.setBadgeTextColor({ color: '#ffffff' });
    }
    const title = (d.prices || []).slice(0, 4).map((p) => `${p.s} ${p.p}`).join(' · ');
    await chrome.action.setTitle({ title: 'StrikePulse\n' + title });
    const newest = d.newest || 0;
    if (cfg.lastAlert && newest > cfg.lastAlert && cfg.notify) {
      for (const a of (d.alerts || []).filter((x) => x.t > cfg.lastAlert).slice(0, 3)) {
        chrome.notifications.create('sp-' + a.id, {
          type: 'basic', iconUrl: 'icons/icon128.png', title: `StrikePulse · ${a.s} · score ${a.sc}`, message: a.ti, priority: a.sc >= 80 ? 2 : 0,
        });
      }
    }
    if (newest > cfg.lastAlert) await chrome.storage.local.set({ lastAlert: newest });
    return { ok: true };
  } catch (e) {
    await chrome.storage.local.set({ lastError: String(e.message || e) });
    await chrome.action.setBadgeText({ text: '!' });
    await chrome.action.setBadgeBackgroundColor({ color: '#e11d2e' });
    return { error: String(e.message || e) };
  }
}
