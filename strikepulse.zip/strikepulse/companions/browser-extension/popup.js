import { fmtPct, fmtPrice, getConfig } from './api.js';

function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
function ago(t) { const s = Math.max(0, Date.now() / 1000 - t); return s < 60 ? `${Math.round(s)}s` : s < 3600 ? `${Math.round(s / 60)}m` : `${Math.round(s / 3600)}h`; }

function spark(points, up) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 60 18'); svg.setAttribute('width', '60'); svg.setAttribute('height', '18');
  if (points && points.length > 1) {
    const lo = Math.min(...points), hi = Math.max(...points), rng = (hi - lo) || 1;
    const pl = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
    pl.setAttribute('points', points.map((v, i) => `${(i * 60 / (points.length - 1)).toFixed(1)},${(17 - (v - lo) / rng * 16).toFixed(1)}`).join(' '));
    pl.setAttribute('class', up ? 'sp-up' : 'sp-down');
    svg.append(pl);
  }
  return svg;
}

async function render() {
  const cfg = await getConfig();
  const { last, lastError } = await chrome.storage.local.get(['last', 'lastError']);
  document.getElementById('open').onclick = () => cfg.baseUrl && chrome.tabs.create({ url: new URL('/dashboard', cfg.baseUrl).href });
  document.getElementById('opts').onclick = () => chrome.runtime.openOptionsPage();
  const err = document.getElementById('err');
  if (!cfg.token) { err.hidden = false; err.textContent = 'Not paired yet. Open Options to connect.'; return; }
  if (lastError) { err.hidden = false; err.textContent = lastError; }
  if (!last) return;
  const t = document.getElementById('prices'); t.replaceChildren();
  for (const p of last.prices || []) {
    const tr = el('tr'); const up = (p.c24 || 0) >= 0;
    tr.append(el('td', 'sym', p.s), el('td', 'num', fmtPrice(p.p)));
    const sp = el('td'); sp.append(spark(p.sp, up)); tr.append(sp);
    tr.append(el('td', 'num ' + (up ? 'up' : 'down'), fmtPct(p.c24)));
    const st = (last.stance || {})[p.s]; tr.append(el('td', 'stance', st && st.st ? st.st : ''));
    t.append(tr);
  }
  const ul = document.getElementById('alerts'); ul.replaceChildren();
  for (const a of last.alerts || []) {
    const li = el('li', a.d < 0 ? 'down' : 'up'); li.append(el('span', 'ago', ago(a.t)), el('span', 'sc', String(a.sc)), el('span', '', a.ti)); ul.append(li);
  }
  if (!(last.alerts || []).length) ul.append(el('li', 'muted', 'No alerts yet'));
  document.getElementById('mood').textContent = last.fng !== null && last.fng !== undefined ? `Fear & Greed ${last.fng}` : (last.src || '');
}

render();
chrome.runtime.sendMessage({ type: 'poll' }).then(render).catch(() => {});
