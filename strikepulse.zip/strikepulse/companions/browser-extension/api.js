// Shared helpers for the StrikePulse extension.
export async function getConfig() {
  const c = await chrome.storage.local.get(['baseUrl', 'token', 'symbols', 'lastAlert', 'notify']);
  return { baseUrl: c.baseUrl || '', token: c.token || '', symbols: c.symbols || '', lastAlert: c.lastAlert || 0, notify: c.notify !== false };
}

export async function fetchStatus(cfg) {
  const u = new URL('/api/device/status', cfg.baseUrl);
  u.searchParams.set('limit', '5');
  u.searchParams.set('spark', '1');
  if (cfg.symbols) u.searchParams.set('symbols', cfg.symbols);
  const r = await fetch(u, { headers: { Authorization: 'Bearer ' + cfg.token, Accept: 'application/json' }, cache: 'no-store' });
  if (!r.ok) {
    let detail = r.statusText;
    try { detail = (await r.json()).detail || detail; } catch (e) { /* not json */ }
    throw new Error(r.status === 401 ? 'Device key revoked. Pair again in Options.' : detail);
  }
  return r.json();
}

export function fmtPrice(p) {
  if (p >= 1000) return '$' + Math.round(p).toLocaleString();
  if (p >= 1) return '$' + p.toFixed(2);
  return '$' + p.toPrecision(4);
}

export function fmtPct(v) {
  return v === null || v === undefined ? 'n/a' : (v >= 0 ? '+' : '') + v.toFixed(1) + '%';
}
