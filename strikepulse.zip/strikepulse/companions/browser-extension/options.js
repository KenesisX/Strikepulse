import { getConfig } from './api.js';

const $ = (id) => document.getElementById(id);
const msg = (t, bad) => { $('msg').textContent = t; $('msg').className = bad ? 'err' : 'ok'; };

(async () => {
  const c = await getConfig();
  $('url').value = c.baseUrl; $('symbols').value = c.symbols; $('notify').checked = c.notify;
  if (c.token) msg('Connected to ' + c.baseUrl);
})();

$('pair').onclick = async () => {
  let base;
  try { base = new URL($('url').value.trim()).origin; } catch (e) { return msg('Enter the full address, like https://yourdomain.com', true); }
  const granted = await chrome.permissions.request({ origins: [base + '/*'] });
  if (!granted) return msg('Permission is needed to reach your StrikePulse site.', true);
  try {
    const r = await fetch(base + '/api/device/pair', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: $('code').value.replace(/\D/g, '') }),
    });
    const j = await r.json();
    if (!r.ok) return msg(j.detail || 'Pairing failed', true);
    await chrome.storage.local.set({ baseUrl: base, token: j.token, lastAlert: 0 });
    msg('Connected as "' + j.name + '". You can close this tab.');
    chrome.runtime.sendMessage({ type: 'poll' });
  } catch (e) { msg('Could not reach ' + base + ': ' + e.message, true); }
};

$('save').onclick = async () => {
  await chrome.storage.local.set({ symbols: $('symbols').value.trim().toUpperCase(), notify: $('notify').checked });
  chrome.runtime.sendMessage({ type: 'poll' });
  msg('Saved.');
};

$('unpair').onclick = async () => {
  await chrome.storage.local.remove(['token', 'last', 'lastAlert']);
  await chrome.action.setBadgeText({ text: '?' });
  msg('Disconnected. Remove the device on the Devices page too.');
};
