# Copy to config.py on the board and fill in.
WIFI_SSID = "your-wifi"
WIFI_PASSWORD = "your-wifi-password"
BASE_URL = "https://yourdomain.com"
TOKEN = "spd_paste_your_device_key_here"
SYMBOLS = ""            # "" = your watchlist, or "BTC,ETH,SOL"

# Pins. Pico W defaults shown; for ESP32 try I2C_ID=0, I2C_SCL=22, I2C_SDA=21, LED_PIN=2
OLED = True
I2C_ID = 0
I2C_SCL = 5
I2C_SDA = 4
LED_PIN = "LED"         # Pico W on-board LED; use a number like 2 on ESP32, or None
BUZZER_PIN = None       # e.g. 15
