# StrikePulse ticker for MicroPython boards: Raspberry Pi Pico W / Pico 2 W, ESP32, ESP32-S3.
#
# Hardware (all optional): SSD1306 128x64 I2C OLED, an LED, an active buzzer.
# 1. Flash MicroPython, copy main.py + config.py (from config_example.py) + ssd1306.py to the board.
#    `mpremote mip install ssd1306` installs the OLED driver.
# 2. Put your Wi-Fi and device key in config.py. (Get the key on the Devices page:
#    add a "MicroPython board", open "No keypad? Use the device key instead".)
# The board refreshes every 30 s, scrolls prices, and blinks/beeps on new alerts.

import time
import gc
import network
import machine

try:
    import urequests as requests
except ImportError:
    import requests  # newer MicroPython

import config

led = machine.Pin(config.LED_PIN, machine.Pin.OUT) if getattr(config, "LED_PIN", None) is not None else None
buzzer = machine.Pin(config.BUZZER_PIN, machine.Pin.OUT) if getattr(config, "BUZZER_PIN", None) is not None else None

oled = None
try:
    if getattr(config, "OLED", True):
        import ssd1306
        i2c = machine.I2C(config.I2C_ID, scl=machine.Pin(config.I2C_SCL), sda=machine.Pin(config.I2C_SDA), freq=400000)
        oled = ssd1306.SSD1306_I2C(128, 64, i2c)
except Exception as e:
    print("No OLED:", e)


def show(lines):
    for ln in lines:
        print(ln)
    if not oled:
        return
    oled.fill(0)
    for i, ln in enumerate(lines[:6]):
        oled.text(ln[:16], 0, i * 10 + 2)
    oled.show()


def blink(times=1, beep=False):
    for _ in range(times):
        if led:
            led.value(1)
        if buzzer and beep:
            buzzer.value(1)
        time.sleep_ms(120)
        if led:
            led.value(0)
        if buzzer:
            buzzer.value(0)
        time.sleep_ms(120)


def wifi():
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    if not sta.isconnected():
        show(["StrikePulse", "Wi-Fi...", config.WIFI_SSID[:16]])
        sta.connect(config.WIFI_SSID, config.WIFI_PASSWORD)
        for _ in range(40):
            if sta.isconnected():
                break
            time.sleep(0.5)
    return sta.isconnected()


def fmt(p):
    if p >= 1000:
        return "{:.0f}".format(p)  # no thousands separator in MicroPython
    if p >= 1:
        return "{:.2f}".format(p)
    return "{:.5f}".format(p)


def fetch():
    url = config.BASE_URL.rstrip("/") + "/api/device/status?limit=2&n=6"
    if getattr(config, "SYMBOLS", ""):
        url += "&symbols=" + config.SYMBOLS
    r = requests.get(url, headers={"Authorization": "Bearer " + config.TOKEN, "User-Agent": "StrikePulse-MPY/1.0"})
    try:
        if r.status_code != 200:
            raise OSError("HTTP %d" % r.status_code)
        return r.json()
    finally:
        r.close()


last_alert = 0
page = 0
data = None
next_fetch = 0
while True:
    try:
        if time.time() >= next_fetch:
            if not wifi():
                show(["StrikePulse", "Wi-Fi failed", "retrying..."])
                time.sleep(10)
                continue
            data = fetch()
            gc.collect()
            newest = data.get("newest") or 0
            if last_alert and newest > last_alert:
                strong = any(a["sc"] >= 80 for a in data.get("alerts", []) if a["t"] > last_alert)
                blink(3 if strong else 1, beep=True)
            last_alert = max(last_alert, newest)
            next_fetch = time.time() + max(30, data.get("refresh", 30))
        if data:
            prices = data.get("prices", [])
            lines = ["StrikePulse"]
            chunk = prices[page * 4:(page + 1) * 4] or prices[:4]
            for p in chunk:
                ch = p.get("c24")
                lines.append("{} {}{}".format(p["s"][:4], fmt(p["p"]), "" if ch is None else (" +" if ch >= 0 else " ") + "{:.1f}".format(ch)))
            if data.get("alerts"):
                lines.append("!" + data["alerts"][0]["ti"][:15])
            show(lines)
            page = (page + 1) % max(1, (len(prices) + 3) // 4)
        time.sleep(5)
    except Exception as e:
        show(["StrikePulse", "Error:", str(e)[:16], str(e)[16:32]])
        next_fetch = time.time() + 30
        time.sleep(10)
