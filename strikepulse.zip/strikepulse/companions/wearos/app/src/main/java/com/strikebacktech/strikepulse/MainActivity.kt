package com.strikebacktech.strikepulse

import android.app.RemoteInput
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.items
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.CompactChip
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Scaffold
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.TimeText
import androidx.wear.input.RemoteInputIntentHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val SpRed = Color(0xFFE11D2E)
val SpGrey = Color(0xFF9A9A9A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        Notifier.ensureChannel(this)
        setContent { MaterialTheme { App(store) } }
    }
}

@Composable
fun App(store: Store) {
    var paired by remember { mutableStateOf(store.paired) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(paired) {
        if (paired && Build.VERSION.SDK_INT >= 33) notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }
    Scaffold(timeText = { TimeText() }) {
        if (paired) PricesScreen(store) { store.clear(); paired = false }
        else PairScreen(store) { paired = true }
    }
}

@Composable
fun PairScreen(store: Store, onPaired: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var url by remember { mutableStateOf(store.baseUrl) }
    var code by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("Enter the code from the Devices page") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val urlInput = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        res.data?.let { RemoteInput.getResultsFromIntent(it)?.getCharSequence("url")?.toString() }?.let {
            url = (if (it.startsWith("http")) it else "https://$it").trimEnd('/')
            store.baseUrl = url
        }
    }
    ScalingLazyColumn(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        item { Text("StrikePulse", color = SpRed, fontWeight = FontWeight.Bold) }
        item {
            CompactChip(onClick = {
                val i = RemoteInputIntentHelper.createActionRemoteInputIntent()
                RemoteInputIntentHelper.putRemoteInputsExtra(i, listOf(RemoteInput.Builder("url").setLabel("Server address").build()))
                urlInput.launch(i)
            }, label = { Text(url.removePrefix("https://"), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp) },
                colors = ChipDefaults.secondaryChipColors())
        }
        item {
            Text(code.padEnd(6, '•').chunked(3).joinToString(" "), fontSize = 26.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 4.dp))
        }
        item { Text(msg, fontSize = 11.sp, color = SpGrey, textAlign = TextAlign.Center) }
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "OK")).forEach { row ->
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { k ->
                        Button(
                            onClick = {
                                when (k) {
                                    "⌫" -> code = code.dropLast(1)
                                    "OK" -> if (code.length == 6 && !busy) {
                                        busy = true; msg = "Pairing…"
                                        scope.launch {
                                            try {
                                                store.token = Api.pair(url, code)
                                                RefreshWorker.schedule(ctx)
                                                onPaired()
                                            } catch (e: Exception) {
                                                msg = e.message ?: "Pairing failed"; code = ""
                                            } finally { busy = false }
                                        }
                                    }
                                    else -> if (code.length < 6) code += k
                                }
                            },
                            modifier = Modifier.size(ButtonDefaults.SmallButtonSize),
                            colors = if (k == "OK") ButtonDefaults.primaryButtonColors(backgroundColor = SpRed)
                            else ButtonDefaults.secondaryButtonColors(),
                        ) { Text(k) }
                    }
                }
            }
        }
    }
}

@Composable
fun PricesScreen(store: Store, onUnpair: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var status by remember { mutableStateOf(store.cached()) }
    var error by remember { mutableStateOf<String?>(null) }
    val listState = rememberScalingLazyListState()
    LaunchedEffect(Unit) {
        RefreshWorker.schedule(ctx)
        while (true) {                                    // live refresh while the app is open
            try {
                val st = Api.refresh(store)
                Notifier.announceNew(ctx, store, st)
                status = st; error = null
                RefreshWorker.pushSurfaces(ctx)
            } catch (e: ApiException) {
                error = if (e.code == 401) "Key revoked. Pair again." else e.message
            } catch (e: Exception) {
                error = "Offline"
            }
            delay(((status?.refreshSec ?: 15).coerceAtLeast(15)) * 1000L)
        }
    }
    ScalingLazyColumn(state = listState, modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        item { Text("StrikePulse", color = SpRed, fontWeight = FontWeight.Bold) }
        error?.let { item { Text(it, color = SpRed, fontSize = 11.sp, textAlign = TextAlign.Center) } }
        status?.fearGreed?.let { item { Text("Fear & Greed $it", fontSize = 11.sp, color = SpGrey) } }
        items(status?.prices ?: emptyList()) { p ->
            val up = (p.change24h ?: 0.0) >= 0
            Chip(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ChipDefaults.secondaryChipColors(),
                label = {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(p.symbol, fontWeight = FontWeight.Bold)
                        Text(fmtPct(p.change24h), color = if (up) Color.White else SpRed)
                    }
                },
                secondaryLabel = {
                    val st = status?.stance?.get(p.symbol)
                    Text(fmtPrice(p.price) + (st?.let { "  ·  $it" } ?: ""), maxLines = 1)
                })
        }
        if ((status?.alerts ?: emptyList()).isNotEmpty()) item { Text("Latest alerts", fontSize = 12.sp, color = SpGrey) }
        items(status?.alerts ?: emptyList()) { a ->
            Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp)) {
                Column {
                    Text("${a.symbol} · ${a.score}", fontSize = 11.sp, color = SpGrey)
                    Text(a.title, fontSize = 12.sp, color = if (a.direction < 0) SpRed else Color.White, maxLines = 3)
                }
            }
        }
        status?.source?.let { item { Text(it, fontSize = 9.sp, color = SpGrey) } }
        item {
            CompactChip(onClick = onUnpair, label = { Text("Unpair") }, colors = ChipDefaults.secondaryChipColors(),
                modifier = Modifier.padding(top = 6.dp))
        }
    }
}
