package com.strikebacktech.strikepulse

import androidx.wear.protolayout.ActionBuilders
import androidx.wear.protolayout.ColorBuilders.argb
import androidx.wear.protolayout.DimensionBuilders
import androidx.wear.protolayout.LayoutElementBuilders
import androidx.wear.protolayout.ModifiersBuilders
import androidx.wear.protolayout.ResourceBuilders
import androidx.wear.protolayout.TimelineBuilders
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileBuilders
import androidx.wear.tiles.TileService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/** Swipe-left Tile: up to 4 coins with 24h change and the latest alert. Tapping opens the app. */
class PricesTileService : TileService() {
    private val white = 0xFFF5F5F5.toInt()
    private val red = 0xFFE11D2E.toInt()
    private val grey = 0xFF9A9A9A.toInt()

    private fun text(s: String, color: Int, size: Float, bold: Boolean = false): LayoutElementBuilders.LayoutElement =
        LayoutElementBuilders.Text.Builder()
            .setText(s)
            .setMaxLines(1)
            .setFontStyle(
                LayoutElementBuilders.FontStyle.Builder()
                    .setColor(argb(color))
                    .setSize(DimensionBuilders.sp(size))
                    .setWeight(if (bold) LayoutElementBuilders.FONT_WEIGHT_BOLD else LayoutElementBuilders.FONT_WEIGHT_NORMAL)
                    .build()
            ).build()

    override fun onTileRequest(requestParams: RequestBuilders.TileRequest): ListenableFuture<TileBuilders.Tile> {
        val store = Store(this)
        val st = store.cached()
        val col = LayoutElementBuilders.Column.Builder()
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .addContent(text("StrikePulse", red, 13f, true))
        when {
            !store.paired -> col.addContent(text("Tap to pair", white, 14f))
            st == null -> col.addContent(text("Loading…", grey, 14f))
            else -> {
                st.prices.take(4).forEach { p ->
                    val up = (p.change24h ?: 0.0) >= 0
                    col.addContent(
                        LayoutElementBuilders.Row.Builder()
                            .addContent(text("${p.symbol} ${fmtPrice(p.price)} ", white, 14f, true))
                            .addContent(text(fmtPct(p.change24h), if (up) white else red, 13f))
                            .build()
                    )
                }
                st.alerts.firstOrNull()?.let { col.addContent(text(it.title.take(28), if (it.direction < 0) red else grey, 11f)) }
            }
        }
        val open = ModifiersBuilders.Clickable.Builder()
            .setId("open")
            .setOnClick(
                ActionBuilders.LaunchAction.Builder()
                    .setAndroidActivity(
                        ActionBuilders.AndroidActivity.Builder()
                            .setPackageName(packageName)
                            .setClassName(MainActivity::class.java.name)
                            .build()
                    ).build()
            ).build()
        val root = LayoutElementBuilders.Box.Builder()
            .setWidth(DimensionBuilders.expand())
            .setHeight(DimensionBuilders.expand())
            .setModifiers(ModifiersBuilders.Modifiers.Builder().setClickable(open).build())
            .addContent(col.build())
            .build()
        val tile = TileBuilders.Tile.Builder()
            .setResourcesVersion("1")
            .setFreshnessIntervalMillis(15 * 60 * 1000L)
            .setTileTimeline(TimelineBuilders.Timeline.fromLayoutElement(root))
            .build()
        return Futures.immediateFuture(tile)
    }

    override fun onTileResourcesRequest(requestParams: RequestBuilders.ResourcesRequest): ListenableFuture<ResourceBuilders.Resources> =
        Futures.immediateFuture(ResourceBuilders.Resources.Builder().setVersion("1").build())
}
