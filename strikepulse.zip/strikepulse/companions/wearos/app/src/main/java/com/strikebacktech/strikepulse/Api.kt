package com.strikebacktech.strikepulse

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Price(val symbol: String, val price: Double, val change1h: Double?, val change24h: Double?, val live: Boolean)
data class AlertItem(val id: String, val time: Long, val symbol: String, val direction: Int, val score: Int, val title: String)
data class Status(
    val prices: List<Price>, val alerts: List<AlertItem>, val stance: Map<String, String>,
    val fearGreed: Int?, val newest: Long, val refreshSec: Int, val source: String?, val fetchedAt: Long,
)

class ApiException(val code: Int, message: String) : Exception(message)

/** Settings + last good response, shared by the app, tile, complication and worker. */
class Store(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("strikepulse", Context.MODE_PRIVATE)
    var baseUrl: String
        get() = prefs.getString("base_url", BuildConfig.DEFAULT_URL) ?: BuildConfig.DEFAULT_URL
        set(v) = prefs.edit().putString("base_url", v.trim().trimEnd('/')).apply()
    var token: String
        get() = prefs.getString("token", "") ?: ""
        set(v) = prefs.edit().putString("token", v).apply()
    var lastAlert: Long
        get() = prefs.getLong("last_alert", 0L)
        set(v) = prefs.edit().putLong("last_alert", v).apply()
    var cachedJson: String
        get() = prefs.getString("cached", "") ?: ""
        set(v) = prefs.edit().putString("cached", v).apply()
    val paired get() = token.isNotEmpty()
    fun cached(): Status? = cachedJson.takeIf { it.isNotEmpty() }?.let { runCatching { parseStatus(JSONObject(it)) }.getOrNull() }
    fun clear() = prefs.edit().remove("token").remove("cached").remove("last_alert").apply()
}

private fun JSONObject.optDoubleOrNull(k: String): Double? = if (isNull(k) || !has(k)) null else optDouble(k)

fun parseStatus(j: JSONObject): Status {
    val prices = buildList {
        val arr = j.optJSONArray("prices")
        for (i in 0 until (arr?.length() ?: 0)) {
            val p = arr!!.getJSONObject(i)
            add(Price(p.getString("s"), p.getDouble("p"), p.optDoubleOrNull("c1h"), p.optDoubleOrNull("c24"), p.optBoolean("live")))
        }
    }
    val alerts = buildList {
        val arr = j.optJSONArray("alerts")
        for (i in 0 until (arr?.length() ?: 0)) {
            val a = arr!!.getJSONObject(i)
            add(AlertItem(a.optString("id"), a.optLong("t"), a.optString("s"), a.optInt("d"), a.optInt("sc"), a.optString("ti")))
        }
    }
    val stance = buildMap {
        val o = j.optJSONObject("stance")
        o?.keys()?.forEach { k -> o.optJSONObject(k)?.optString("st")?.let { put(k, it) } }
    }
    return Status(prices, alerts, stance, if (j.isNull("fng")) null else j.optInt("fng"), j.optLong("newest"),
        j.optInt("refresh", 15), j.optString("src").ifEmpty { null }, System.currentTimeMillis())
}

object Api {
    private fun open(url: String, token: String?): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000; readTimeout = 15_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "StrikePulse-WearOS/1.0")
            if (!token.isNullOrEmpty()) setRequestProperty("Authorization", "Bearer $token")
        }

    private fun read(c: HttpURLConnection): JSONObject {
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val detail = runCatching { JSONObject(body).optString("detail") }.getOrNull().orEmpty().ifEmpty { "HTTP $code" }
            throw ApiException(code, detail)
        }
        return JSONObject(body)
    }

    suspend fun pair(baseUrl: String, code: String): String = withContext(Dispatchers.IO) {
        val c = open("${baseUrl.trimEnd('/')}/api/device/pair", null)
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(JSONObject().put("code", code).toString().toByteArray()) }
        read(c).getString("token")
    }

    /** Fetches status and caches it. Returns the parsed result. */
    suspend fun refresh(store: Store): Status = withContext(Dispatchers.IO) {
        val c = open("${store.baseUrl}/api/device/status?limit=5&n=8", store.token)
        val j = read(c)
        store.cachedJson = j.toString()
        parseStatus(j)
    }
}

fun fmtPrice(p: Double): String = when {
    p >= 1000 -> "$" + String.format("%,.0f", p)
    p >= 1 -> "$" + String.format("%,.2f", p)
    else -> "$" + String.format("%.6f", p).trimEnd('0')
}

fun fmtPct(v: Double?): String = v?.let { (if (it >= 0) "+" else "") + String.format("%.1f%%", it) } ?: "—"
