package com.strikebacktech.strikepulse

import android.app.PendingIntent
import android.content.Intent
import androidx.wear.watchface.complications.data.ComplicationData
import androidx.wear.watchface.complications.data.ComplicationType
import androidx.wear.watchface.complications.data.LongTextComplicationData
import androidx.wear.watchface.complications.data.PlainComplicationText
import androidx.wear.watchface.complications.data.ShortTextComplicationData
import androidx.wear.watchface.complications.datasource.ComplicationRequest
import androidx.wear.watchface.complications.datasource.SuspendingComplicationDataSourceService

/** Watch-face complication: first coin and its 24h move ("BTC +2.1%"). */
class PriceComplicationService : SuspendingComplicationDataSourceService() {
    private fun plain(s: String) = PlainComplicationText.Builder(s).build()

    private fun build(type: ComplicationType, symbol: String, pct: String, price: String): ComplicationData? {
        val tap = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return when (type) {
            ComplicationType.SHORT_TEXT -> ShortTextComplicationData.Builder(plain(pct), plain("$symbol $pct"))
                .setTitle(plain(symbol)).setTapAction(tap).build()
            ComplicationType.LONG_TEXT -> LongTextComplicationData.Builder(plain("$symbol $price $pct"), plain("$symbol $price $pct"))
                .setTapAction(tap).build()
            else -> null
        }
    }

    override fun getPreviewData(type: ComplicationType): ComplicationData? = build(type, "BTC", "+2.1%", "$97,000")

    override suspend fun onComplicationRequest(request: ComplicationRequest): ComplicationData? {
        val store = Store(this)
        val st = runCatching { if (store.paired) Api.refresh(store) else null }.getOrNull() ?: store.cached()
        val p = st?.prices?.firstOrNull() ?: return build(request.complicationType, "SP", "pair", "tap to pair")
        return build(request.complicationType, p.symbol, fmtPct(p.change24h), fmtPrice(p.price))
    }
}
