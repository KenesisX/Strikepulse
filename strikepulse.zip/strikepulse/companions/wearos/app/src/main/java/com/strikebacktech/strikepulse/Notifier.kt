package com.strikebacktech.strikepulse

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    private const val CHANNEL = "alerts"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Market alerts", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    fun buzz(ctx: Context, strong: Boolean) {
        val vib = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(VibratorManager::class.java).defaultVibrator
        else @Suppress("DEPRECATION") ctx.getSystemService(Vibrator::class.java)
        val pattern = if (strong) longArrayOf(0, 180, 120, 180, 120, 180) else longArrayOf(0, 200)
        vib?.vibrate(VibrationEffect.createWaveform(pattern, -1))
    }

    /** Notifies for alerts newer than the last one seen. Returns true if any were new. */
    fun announceNew(ctx: Context, store: Store, status: Status): Boolean {
        val last = store.lastAlert
        val fresh = status.alerts.filter { it.time > last }
        if (status.newest > last) store.lastAlert = status.newest
        if (last == 0L || fresh.isEmpty()) return false       // first sync: don't buzz for old alerts
        ensureChannel(ctx)
        buzz(ctx, fresh.any { it.score >= 80 })
        val canPost = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (canPost) {
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            fresh.take(3).forEach { a ->
                val n = NotificationCompat.Builder(ctx, CHANNEL)
                    .setSmallIcon(R.drawable.ic_bolt)
                    .setContentTitle("${a.symbol} · score ${a.score}")
                    .setContentText(a.title)
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build()
                NotificationManagerCompat.from(ctx).notify(a.id.hashCode(), n)
            }
        }
        return true
    }
}
