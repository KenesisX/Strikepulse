package com.strikebacktech.strikepulse

import android.content.ComponentName
import android.content.Context
import androidx.wear.tiles.TileService
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Background sync every 15 minutes (Android's minimum): cache, buzz on new alerts, refresh tile + complication. */
class RefreshWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val store = Store(applicationContext)
        if (!store.paired) return Result.success()
        return try {
            val st = Api.refresh(store)
            Notifier.announceNew(applicationContext, store, st)
            pushSurfaces(applicationContext)
            Result.success()
        } catch (e: ApiException) {
            if (e.code == 401) Result.failure() else Result.retry()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<RefreshWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("sp-refresh", ExistingPeriodicWorkPolicy.UPDATE, req)
        }

        fun pushSurfaces(ctx: Context) {
            TileService.getUpdater(ctx).requestUpdate(PricesTileService::class.java)
            ComplicationDataSourceUpdateRequester
                .create(ctx, ComponentName(ctx, PriceComplicationService::class.java))
                .requestUpdateAll()
        }
    }
}
