# org.json and platform classes need no rules. Keep service class names referenced from the manifest.
-keep class com.strikebacktech.strikepulse.** { *; }
