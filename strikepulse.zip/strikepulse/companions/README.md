# StrikePulse companion apps

All companions read from the same small device API. Pair each one from the **Devices** page of your
StrikePulse site: add a device, then type the 6-digit code on it, or paste the device key into its
config file. Every device has its own read-only key, which you can remove at any time.

| Folder | What it is | Build here? | How to get it on the device |
| --- | --- | --- | --- |
| `raspberry-pi/` | Full-screen dashboard (HDMI/SPI LCD) or terminal view, GPIO buzzer + LED | Plain Python | `./install.sh https://yourdomain.com 123456` |
| `esp32/` | Desk ticker: CYD 2.8", ST7789, or SSD1306 OLED | PlatformIO / CI | `pio run -e cyd -t upload` |
| `micropython/` | Pico W / ESP32 + OLED + LED | Copy files | `mpremote cp main.py config.py :` |
| `wearos/` | Galaxy Watch / Wear OS app + Tile + complication | Android Studio / CI | `adb install app-debug.apk` |
| `watchos/` | Apple Watch app + WidgetKit complication | Xcode (Mac) / CI | Xcode → Run on your watch |
| `browser-extension/` | Chrome/Edge/Brave toolbar ticker + notifications | Nothing to build | Load unpacked |
| `desktop-tray/` | Windows/macOS/Linux tray ticker | Plain Python | `python strikepulse_tray.py` |
| `home-assistant/` | REST sensors + alert automation | YAML | copy to `/config/packages/` |

**Build everything in the cloud:** push this project to GitHub. `.github/workflows/companions.yml`
builds the ESP32 firmware, the Wear OS APK, the Apple Watch app (simulator) and the extension zip, and
attaches them to each run under **Artifacts**. Set the repository variable `STRIKEPULSE_URL` to bake your
address into the watch apps.

---

## Raspberry Pi monitor
Works on every Pi from the Zero 2 W up, and on any Linux box.
```bash
cd raspberry-pi
./install.sh https://yourdomain.com 123456     # installs, pairs, starts on boot
python3 strikepulse_monitor.py --mode text      # live view over SSH
python3 strikepulse_monitor.py --mode once      # one snapshot (cron, scripts)
```
- 3.5" SPI LCDs (Waveshare, ILI9486, the cyberdeck screen): install the screen's driver so it shows the
  desktop or console, then the monitor runs full screen.
- Buzzer and LED: set `buzzer_pin` / `led_pin` (BCM numbers) in `config.json`. It beeps once on a new
  alert and three times when the score is 80 or higher.
- Pick coins: `--symbols BTC,ETH,SOL` (default: your watchlist).

## ESP32 desk ticker
1. Install [PlatformIO](https://platformio.org/install) (VS Code extension or `pip install platformio`).
2. `cp src/config.example.h src/config.h`, then fill in Wi-Fi, your address, and either the 6-digit
   `SP_PAIR_CODE` (the board pairs on first boot and stores the key) or `SP_TOKEN`.
3. Flash: `pio run -e cyd -t upload` (ESP32-2432S028R "Cheap Yellow Display"), `-e st7789`, or `-e oled`.

Pins for the ST7789 and OLED builds are in `platformio.ini`. The CYD's RGB LED flashes red on new alerts;
add an active buzzer on GPIO 26 (`SP_BUZZER_PIN`). TLS is on. Set `SP_TLS_INSECURE 0` and paste your root CA
to also verify the certificate.

## MicroPython (Pico W, ESP32)
```bash
mpremote mip install ssd1306
cp config_example.py config.py      # Wi-Fi, address, device key, pins
mpremote cp main.py config.py :
```

## Galaxy Watch / Wear OS
Needs Wear OS 3+ (Galaxy Watch4 and newer, Pixel Watch).
- **Easiest:** download `wearos-apk` from the GitHub Actions run. Enable *Developer options → ADB/Wireless
  debugging* on the watch, then `adb connect <watch-ip>:<port>` and `adb install app-debug.apk`.
- **Android Studio:** open `wearos/` (it creates the Gradle wrapper on first sync), set `strikepulseUrl` in
  `gradle.properties`, and press Run with the watch connected.
- On the watch: open StrikePulse, check the server address (tap to edit), type the code, press OK.
- Add the **Tile** (swipe left → +) and the **complication** (long-press the watch face → Edit).
- Publishing on Google Play: `gradle bundleRelease`, sign it, and upload to a Play Console account
  ($25 one-time). Choose the Wear OS form factor.

## Apple Watch
Needs a Mac with Xcode 15+ and watchOS 10+.
```bash
brew install xcodegen
cd watchos && xcodegen          # creates StrikePulse.xcodeproj
open StrikePulse.xcodeproj
```
Set your Team in *Signing & Capabilities* for both targets (a free Apple ID can install on your own watch
for 7 days; the $99/yr Developer Program removes the limit and allows TestFlight/App Store). Change
`SP_DEFAULT_URL` in `project.yml` to your address. The app runs on its own over Wi-Fi or cellular. Add the
complication from the watch face editor.

> App Store note: on the US storefront, apps may link to an outside web checkout. A watch app that only
> shows data to signed-in subscribers can still be reviewed strictly, so read Guideline 3.1 before you
> submit. Sideloading for yourself and TestFlight testing don't have this issue.

## Browser extension
Chrome/Edge/Brave: open `chrome://extensions`, turn on Developer mode, click **Load unpacked** and select
`browser-extension/`. The Options page opens: enter your address and the code. To publish, zip the
folder and upload it to the Chrome Web Store ($5 one-time).

## Desktop tray
```bash
pip install -r desktop-tray/requirements.txt
python desktop-tray/strikepulse_tray.py --url https://yourdomain.com --pair 123456
# single-file app:  pip install pyinstaller && pyinstaller --onefile --noconsole strikepulse_tray.py
```

## Home Assistant
See the comments at the top of `home-assistant/strikepulse.yaml`. You get price sensors, Fear & Greed,
the latest alert, and an automation you can point at lights, speakers, or your phone and watch.

## No-install options
- **Any smartwatch** (Galaxy, Apple, Garmin, Fitbit, Amazfit): connect Telegram or ntfy in Settings.
  Alerts arrive as phone notifications and show on the watch automatically.
- **Siri Shortcuts / Tasker / Pebble / e-ink:** `GET /api/device/text` with header
  `Authorization: Bearer <device key>` returns one plain-text line.

## Device API
```
POST /api/device/pair     {"code":"123456"}        -> {"token":"spd_...","base_url":...}
GET  /api/device/status   ?symbols=BTC,ETH&n=6&limit=3&spark=1
GET  /api/device/alerts   ?since=<unix seconds>
GET  /api/device/text     ?symbols=BTC,ETH
GET  /api/device/me
```
Send the key as `Authorization: Bearer <key>` (or `X-Device-Token`, or `?token=` for simple clients).
Status refresh: 15 s on paid plans, 60 s on Free (`refresh` field). Responses are small enough for an ESP32.
