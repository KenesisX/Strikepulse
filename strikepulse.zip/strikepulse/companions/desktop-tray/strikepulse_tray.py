#!/usr/bin/env python3
"""StrikePulse system-tray ticker for Windows, macOS and Linux.

  pip install -r requirements.txt
  python strikepulse_tray.py --url https://yourdomain.com --pair 123456     (first time)
  python strikepulse_tray.py                                                 (after that)

The tray icon shows the first coin's 24h direction (white = up, red = down). Hover for prices; the
menu lists every coin and the latest alerts. New alerts pop a desktop notification.
Build a single .exe / app:  pip install pyinstaller && pyinstaller --onefile --noconsole strikepulse_tray.py
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from strikepulse_client import ApiError, Client, fmt_pct, fmt_price, pair  # noqa: E402

CONFIG = Path(os.environ.get("STRIKEPULSE_CONFIG", Path.home() / ".strikepulse_tray.json"))


def load() -> dict:
    return json.loads(CONFIG.read_text()) if CONFIG.exists() else {"base_url": "", "token": "", "symbols": ""}


def save(cfg: dict) -> None:
    CONFIG.write_text(json.dumps(cfg, indent=2))
    try:
        os.chmod(CONFIG, 0o600)
    except OSError:
        pass


def tooltip(d: dict) -> str:
    rows = [f"{p['s']} {fmt_price(p['p'])} {fmt_pct(p.get('c24'))}" for p in d.get("prices", [])[:4]]
    return ("StrikePulse\n" + "\n".join(rows))[:120]      # Windows caps tooltips at 128 chars


def make_icon(up: bool | None, alert: bool):
    from PIL import Image, ImageDraw  # type: ignore
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    dr = ImageDraw.Draw(img)
    dr.ellipse((2, 2, 62, 62), fill=(17, 17, 17, 255), outline=(225, 29, 46, 255), width=4)
    col = (245, 245, 245, 255) if up else (225, 29, 46, 255) if up is False else (150, 150, 150, 255)
    if up is False:
        dr.polygon([(16, 22), (48, 22), (32, 46)], fill=col)
    else:
        dr.polygon([(16, 42), (48, 42), (32, 18)], fill=col)
    if alert:
        dr.ellipse((44, 2, 62, 20), fill=(225, 29, 46, 255))
    return img


def notify(icon, title: str, msg: str) -> None:
    try:
        icon.notify(msg, title)
        return
    except Exception:
        pass
    try:
        from plyer import notification  # type: ignore
        notification.notify(title=title, message=msg, app_name="StrikePulse", timeout=8)
    except Exception:
        print(f"[alert] {title}: {msg}")


def run(cfg: dict) -> None:
    import pystray  # type: ignore
    client = Client(cfg["base_url"], cfg["token"])
    state = {"d": {}, "err": "", "last": 0}

    def menu_items():
        d = state["d"]
        items = [pystray.MenuItem(f"{p['s']}  {fmt_price(p['p'])}  {fmt_pct(p.get('c24'))}", None, enabled=False)
                 for p in d.get("prices", [])]
        if d.get("alerts"):
            items.append(pystray.Menu.SEPARATOR)
            items += [pystray.MenuItem(a["ti"][:60], None, enabled=False) for a in d["alerts"][:3]]
        if state["err"]:
            items.append(pystray.MenuItem(f"! {state['err'][:60]}", None, enabled=False))
        items += [pystray.Menu.SEPARATOR,
                  pystray.MenuItem("Open dashboard", lambda: webbrowser.open(cfg["base_url"] + "/dashboard")),
                  pystray.MenuItem("Refresh now", lambda: threading.Thread(target=tick, daemon=True).start()),
                  pystray.MenuItem("Quit", lambda: icon.stop())]
        return items

    icon = pystray.Icon("strikepulse", make_icon(None, False), "StrikePulse", menu=pystray.Menu(menu_items))

    def tick():
        try:
            d = client.status(symbols=cfg.get("symbols") or None, limit=3)
            state["d"], state["err"] = d, ""
            newest = d.get("newest") or 0
            fresh = state["last"] and newest > state["last"]
            if fresh:
                for a in [a for a in d["alerts"] if a["t"] > state["last"]][:3]:
                    notify(icon, f"StrikePulse · {a['s']} · score {a['sc']}", a["ti"])
            state["last"] = max(state["last"], newest)
            first = (d.get("prices") or [{}])[0]
            up = None if first.get("c24") is None else first["c24"] >= 0
            icon.icon = make_icon(up, bool(newest and time.time() - newest < 900))
            icon.title = tooltip(d)
        except ApiError as e:
            state["err"] = e.detail
            icon.title = f"StrikePulse: {e.detail}"[:120]
        icon.update_menu()

    def loop():
        while True:
            tick()
            time.sleep(max(15, int(state["d"].get("refresh") or 15)))

    def setup(ic):
        ic.visible = True
        threading.Thread(target=loop, daemon=True).start()

    icon.run(setup)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="StrikePulse tray ticker")
    ap.add_argument("--url")
    ap.add_argument("--pair", metavar="CODE")
    ap.add_argument("--token")
    ap.add_argument("--symbols")
    ap.add_argument("--once", action="store_true", help="print prices and exit (no tray)")
    a = ap.parse_args(argv)
    cfg = load()
    if a.url:
        cfg["base_url"] = a.url.rstrip("/")
    if a.symbols is not None:
        cfg["symbols"] = a.symbols
    if a.token:
        cfg["token"] = a.token
    if a.pair:
        try:
            cfg["token"] = pair(cfg["base_url"], a.pair)
            print("Paired.")
        except ApiError as e:
            print("Pairing failed:", e.detail)
            return 1
    if a.url or a.pair or a.token or a.symbols is not None:
        save(cfg)
    if not (cfg.get("base_url") and cfg.get("token")):
        print("First run: python strikepulse_tray.py --url https://yourdomain.com --pair 123456")
        return 2
    if a.once:
        d = Client(cfg["base_url"], cfg["token"]).status(symbols=cfg.get("symbols") or None)
        print(tooltip(d))
        return 0
    run(cfg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
