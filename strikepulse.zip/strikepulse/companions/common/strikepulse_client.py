"""Tiny dependency-free client for the StrikePulse device API (Python 3.8+).

Shared by the Raspberry Pi monitor and the desktop tray app. Copy it anywhere.

    from strikepulse_client import Client, pair
    token = pair("https://yourdomain.com", "123456")
    c = Client("https://yourdomain.com", token)
    print(c.status())
"""
from __future__ import annotations

import json
import ssl
import urllib.error
import urllib.parse
import urllib.request

UA = "StrikePulse-Companion/1.0"


class ApiError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(f"{status}: {detail}")
        self.status = status
        self.detail = detail


def _request(method: str, url: str, token: str | None = None, body: dict | None = None, timeout: float = 15):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("User-Agent", UA)
    req.add_header("Accept", "application/json")
    if data is not None:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    ctx = ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx if url.startswith("https") else None) as r:
            raw = r.read().decode()
            ctype = r.headers.get("Content-Type", "")
            return json.loads(raw) if "json" in ctype else raw
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read().decode()).get("detail", e.reason)
        except Exception:
            detail = str(e.reason)
        raise ApiError(e.code, str(detail)) from None
    except urllib.error.URLError as e:
        raise ApiError(0, f"cannot reach server: {e.reason}") from None


def pair(base_url: str, code: str) -> str:
    out = _request("POST", base_url.rstrip("/") + "/api/device/pair", body={"code": code.replace(" ", "")})
    return out["token"]


class Client:
    def __init__(self, base_url: str, token: str):
        self.base = base_url.rstrip("/")
        self.token = token

    def _get(self, path: str, **params):
        q = {k: v for k, v in params.items() if v not in (None, "")}
        url = self.base + path + ("?" + urllib.parse.urlencode(q) if q else "")
        return _request("GET", url, self.token)

    def status(self, symbols: str | None = None, spark: bool = False, limit: int = 3, since: float = 0) -> dict:
        return self._get("/api/device/status", symbols=symbols, spark=int(spark), limit=limit, since=int(since))

    def alerts(self, since: float = 0) -> list:
        return self._get("/api/device/alerts", since=int(since)).get("alerts", [])

    def text(self, symbols: str | None = None) -> str:
        return self._get("/api/device/text", symbols=symbols)

    def me(self) -> dict:
        return self._get("/api/device/me")


def fmt_price(p: float) -> str:
    if p >= 1000:
        return f"${p:,.0f}"
    if p >= 1:
        return f"${p:,.2f}"
    return f"${p:.6f}".rstrip("0")


def fmt_pct(v) -> str:
    return "  n/a" if v is None else f"{v:+.1f}%"
