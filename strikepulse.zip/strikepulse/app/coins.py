"""Bundled list of major cryptocurrencies (no network needed) and SYMBOLS=auto resolution.

Kept import-light so config.py can use it at startup.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


@lru_cache(maxsize=1)
def top_coins() -> list[dict]:
    try:
        data = json.loads((ROOT / "data" / "top_coins.json").read_text())
        coins = data.get("coins", [])
    except Exception:
        coins = []
    out = []
    for i, c in enumerate(coins, 1):
        out.append({"symbol": c["s"].upper(), "name": c.get("n", c["s"]), "id": c.get("id", c["s"].lower()),
                    "coinbase": bool(c.get("cb")), "stable": bool(c.get("stable")), "rank": i})
    return out


def auto_symbols(top: int = 25) -> list[str]:
    """Top-N non-stable coins that trade as USD pairs on the default live exchanges."""
    picks = [f"{c['symbol']}-USD" for c in top_coins() if c["coinbase"] and not c["stable"]]
    return picks[: max(1, top)] or ["BTC-USD", "ETH-USD"]


def name_for(symbol: str) -> str:
    base = symbol.split("-")[0].upper()
    for c in top_coins():
        if c["symbol"] == base:
            return c["name"]
    return base
