"""Whole-market coverage: every major cryptocurrency (top 250 by market cap), refreshed on a timer.

Live exchange WebSockets give tick-level data for the coins in SYMBOLS. This module adds a lighter
"snapshot" layer for the rest of the market from a licensed aggregator (CoinGecko or CoinMarketCap):
price, market cap, volume, 1h/24h/7d change and a 7-day sparkline. It powers the Markets page,
companion devices, watches on any coin, and market-wide "big mover" alerts.

Demo mode (no live feeds) synthesizes a believable universe so every page works offline.
"""
from __future__ import annotations

import asyncio
import logging
import math
import random
import time
from dataclasses import asdict, dataclass, field

import httpx

from .coins import top_coins
from .engine.types import MarketEvent

log = logging.getLogger(__name__)

CG_FREE = "https://api.coingecko.com/api/v3"
CG_PRO = "https://pro-api.coingecko.com/api/v3"
CMC = "https://pro-api.coinmarketcap.com/v1"
# Rough reference prices so demo mode looks believable (never used with live data).
DEMO_PRICES = {"BTC": 97000, "ETH": 3400, "XRP": 2.3, "BNB": 650, "SOL": 190, "DOGE": 0.35, "TRX": 0.25, "ADA": 0.9,
               "HYPE": 25, "LINK": 22, "XLM": 0.4, "SUI": 3.5, "BCH": 450, "AVAX": 35, "HBAR": 0.25, "LTC": 100,
               "TON": 5, "SHIB": 0.000022, "DOT": 7, "XMR": 200, "UNI": 12, "AAVE": 300, "PEPE": 0.000018,
               "NEAR": 5, "APT": 9, "ICP": 10, "ETC": 25, "BONK": 0.00003, "WIF": 2, "TRUMP": 15, "PENGU": 0.03,
               "PAXG": 2650, "MKR": 1500, "TAO": 450, "QNT": 100, "YFI": 8000, "COMP": 70, "1INCH": 0.4}
STABLES = {"USDT", "USDC", "DAI", "FDUSD", "TUSD", "USDE", "USDS", "PYUSD", "USD1", "BUSD", "USDD", "FRAX", "RLUSD"}


@dataclass
class Coin:
    symbol: str
    name: str
    id: str
    rank: int
    price: float | None = None
    mcap: float | None = None
    volume: float | None = None
    ch1h: float | None = None
    ch24h: float | None = None
    ch7d: float | None = None
    spark: list[float] = field(default_factory=list)
    streamed: bool = False
    stable: bool = False

    @property
    def pair(self) -> str:
        return f"{self.symbol}-USD"

    def to_dict(self, spark: bool = True) -> dict:
        d = asdict(self)
        d["pair"] = self.pair
        if not spark:
            d.pop("spark", None)
        return d


def _downsample(xs: list[float], n: int = 42) -> list[float]:
    xs = [float(x) for x in xs if x is not None and math.isfinite(float(x))]
    if len(xs) <= n:
        return xs
    step = len(xs) / n
    return [xs[min(len(xs) - 1, int(i * step))] for i in range(n - 1)] + [xs[-1]]


def parse_coingecko(rows: list[dict]) -> list[Coin]:
    out = []
    for i, r in enumerate(rows, 1):
        sym = str(r.get("symbol", "")).upper()
        if not sym:
            continue
        out.append(Coin(
            symbol=sym, name=r.get("name") or sym, id=r.get("id") or sym.lower(),
            rank=int(r.get("market_cap_rank") or i), price=r.get("current_price"), mcap=r.get("market_cap"),
            volume=r.get("total_volume"), ch1h=r.get("price_change_percentage_1h_in_currency"),
            ch24h=r.get("price_change_percentage_24h_in_currency", r.get("price_change_percentage_24h")),
            ch7d=r.get("price_change_percentage_7d_in_currency"),
            spark=_downsample(((r.get("sparkline_in_7d") or {}).get("price")) or []),
            stable=sym in STABLES))
    return out


def parse_cmc(rows: list[dict]) -> list[Coin]:
    out = []
    for i, r in enumerate(rows, 1):
        q = (r.get("quote") or {}).get("USD") or {}
        sym = str(r.get("symbol", "")).upper()
        out.append(Coin(symbol=sym, name=r.get("name") or sym, id=str(r.get("slug") or r.get("id")),
                        rank=int(r.get("cmc_rank") or i), price=q.get("price"), mcap=q.get("market_cap"),
                        volume=q.get("volume_24h"), ch1h=q.get("percent_change_1h"),
                        ch24h=q.get("percent_change_24h"), ch7d=q.get("percent_change_7d"),
                        stable=sym in STABLES))
    return out


class MarketUniverse:
    def __init__(self, settings, publish=None, live_price=None, simulated: bool = False):
        self.settings = settings
        self.publish = publish                    # callable(MarketEvent)
        self.live_price = live_price              # callable("BTC-USD") -> float | None
        self.simulated = simulated
        self.coins: list[Coin] = []
        self.by_symbol: dict[str, Coin] = {}
        self.updated: float = 0.0
        self.source = "none"
        self.status = "starting"
        self._fired: dict[tuple[str, int, str], float] = {}
        self._rng = random.Random(7)
        self._seed_offline()

    # ------------------------------------------------------------------ data
    @property
    def attribution(self) -> dict | None:
        if self.source == "coingecko":
            return {"text": "Market data by CoinGecko", "url": "https://www.coingecko.com"}
        if self.source == "coinmarketcap":
            return {"text": "Market data by CoinMarketCap", "url": "https://coinmarketcap.com"}
        return None

    def _streamed(self) -> set[str]:
        return set(self.settings.symbols)

    def _install(self, coins: list[Coin], source: str) -> None:
        streamed = self._streamed()
        seen, clean = set(), []
        for c in sorted(coins, key=lambda c: c.rank or 10**9):
            if c.symbol in seen:            # keep the larger coin when two share a ticker
                continue
            seen.add(c.symbol)
            c.streamed = c.pair in streamed
            if c.streamed and self.live_price:
                lp = self.live_price(c.pair)
                if lp:
                    if self.simulated and c.spark and c.spark[-1]:
                        k = lp / c.spark[-1]            # keep the demo sparkline consistent with the live price
                        c.spark = [x * k for x in c.spark]
                    c.price = lp
            clean.append(c)
        self.coins = clean[: self.settings.universe_size]
        self.by_symbol = {c.symbol: c for c in self.coins}
        self.updated = time.time()
        self.source = source

    def _seed_offline(self) -> None:
        """Names/ranks from the bundled list so pages render before the first fetch."""
        self._install([Coin(symbol=c["symbol"], name=c["name"], id=c["id"], rank=c["rank"], stable=c["stable"])
                       for c in top_coins()], "bundled")

    def synthesize(self) -> None:
        """Demo data: a deterministic-ish random walk around plausible magnitudes."""
        coins = []
        for c in top_coins():
            prev = self.by_symbol.get(c["symbol"])
            base = prev.price if prev and prev.price else (
                1.0 if c["stable"] else DEMO_PRICES.get(c["symbol"]) or round(40.0 / (c["rank"] ** 0.8) * self._rng.uniform(0.3, 3.0), 4))
            if c["stable"]:
                spark = [1 + self._rng.gauss(0, 0.0005) for _ in range(42)]
                price = 1 + self._rng.gauss(0, 0.0004)
            else:
                spark = list(prev.spark) if prev and len(prev.spark) >= 42 else []
                p = spark[-1] if spark else base
                while len(spark) < 42:
                    p *= math.exp(self._rng.gauss(0, 0.02))
                    spark.append(p)
                price = spark[-1] * math.exp(self._rng.gauss(0, 0.006))
                spark = spark[1:] + [price]
            ch7d = (spark[-1] / spark[0] - 1) * 100
            ch24h = (spark[-1] / spark[-7] - 1) * 100
            ch1h = self._rng.gauss(0, 0.8 if not c["stable"] else 0.02)
            mcap = 1.9e12 / (c["rank"] ** 1.25) * self._rng.uniform(0.85, 1.15)
            coins.append(Coin(symbol=c["symbol"], name=c["name"], id=c["id"], rank=c["rank"], price=price,
                              mcap=mcap, volume=mcap * self._rng.uniform(0.02, 0.15), ch1h=ch1h, ch24h=ch24h,
                              ch7d=ch7d, spark=spark, stable=c["stable"]))
        self._install(coins, "demo")
        self.status = "demo"

    async def fetch(self, client: httpx.AsyncClient) -> None:
        s = self.settings
        prov = s.market_data_provider
        if prov == "coinmarketcap":
            if not s.cmc_api_key:
                raise RuntimeError("CMC_API_KEY not set")
            r = await client.get(f"{CMC}/cryptocurrency/listings/latest",
                                 params={"start": 1, "limit": s.universe_size, "convert": "USD"},
                                 headers={"X-CMC_PRO_API_KEY": s.cmc_api_key, "Accept": "application/json"})
            r.raise_for_status()
            self._install(parse_cmc(r.json().get("data", [])), "coinmarketcap")
            return
        if prov == "coingecko":
            base = CG_PRO if s.coingecko_pro else CG_FREE
            headers = {"Accept": "application/json"}
            if s.coingecko_api_key:
                headers["x-cg-pro-api-key" if s.coingecko_pro else "x-cg-demo-api-key"] = s.coingecko_api_key
            r = await client.get(f"{base}/coins/markets", headers=headers, params={
                "vs_currency": "usd", "order": "market_cap_desc", "per_page": s.universe_size, "page": 1,
                "sparkline": "true", "price_change_percentage": "1h,24h,7d"})
            r.raise_for_status()
            self._install(parse_coingecko(r.json()), "coingecko")
            return
        raise RuntimeError("MARKET_DATA_PROVIDER is 'none'")

    # ------------------------------------------------------------------ movers
    def detect_movers(self, now: float | None = None) -> list[MarketEvent]:
        """Market-wide big moves. One alert per coin, window and direction every 6 hours."""
        now = now or time.time()
        s = self.settings
        out = []
        for c in self.coins:
            if c.stable or c.price is None:
                continue
            for window, pct, limit in (("1h", c.ch1h, s.mover_1h_pct), ("24h", c.ch24h, s.mover_24h_pct)):
                if pct is None or abs(pct) < limit:
                    continue
                direction = 1 if pct > 0 else -1
                key = (c.symbol, direction, window)
                last = self._fired.get(key)
                if last is not None and now - last < 6 * 3600:
                    continue
                self._fired[key] = now
                strength = min(1.0, abs(pct) / (limit * 3))
                score = int(60 + 35 * strength)
                verb = "up" if direction > 0 else "down"
                out.append(MarketEvent(
                    kind="mover", symbol=c.pair, direction=direction, score=score, price=c.price, timeframe=window,
                    title=f"{c.name} ({c.symbol}) {verb} {abs(pct):.1f}% in {window}",
                    reasons=[f"Rank #{c.rank} by market cap", f"{window} change {pct:+.1f}% (alert level {limit:g}%)",
                             f"24h volume ${c.volume:,.0f}" if c.volume else "volume n/a"],
                    meta={"pct": round(pct, 2), "window": window, "rank": c.rank, "source": self.source}))
        return out

    def top_movers(self, n: int = 6) -> dict:
        live = [c for c in self.coins if c.ch24h is not None and not c.stable]
        up = sorted(live, key=lambda c: c.ch24h, reverse=True)[:n]
        down = sorted(live, key=lambda c: c.ch24h)[:n]
        return {"up": [c.to_dict(spark=False) for c in up], "down": [c.to_dict(spark=False) for c in down]}

    def get(self, symbol_or_pair: str) -> Coin | None:
        return self.by_symbol.get(symbol_or_pair.split("-")[0].upper())

    def pairs(self) -> list[str]:
        return [c.pair for c in self.coins if not c.stable]

    def snapshot(self, spark: bool = True) -> dict:
        return {"updated": self.updated, "source": self.source, "status": self.status,
                "attribution": self.attribution, "count": len(self.coins),
                "coins": [c.to_dict(spark) for c in self.coins]}

    # ------------------------------------------------------------------ loop
    async def run(self) -> None:
        if self.simulated or self.settings.market_data_provider == "none":
            if not self.simulated:
                self.status = "off (MARKET_DATA_PROVIDER=none)"
                return
            while True:
                self.synthesize()
                self._emit(self.detect_movers())
                await asyncio.sleep(60)
        backoff = self.settings.universe_refresh
        async with httpx.AsyncClient(timeout=20, headers={"User-Agent": "StrikePulse/1.5"}) as client:
            while True:
                try:
                    await self.fetch(client)
                    self.status = "ok"
                    backoff = self.settings.universe_refresh
                    self._emit(self.detect_movers())
                except Exception as e:
                    self.status = f"error: {str(e)[:120]}"
                    log.warning("universe fetch failed: %s", e)
                    backoff = min(backoff * 2, 3600)
                await asyncio.sleep(backoff)

    def _emit(self, events: list[MarketEvent]) -> None:
        if not self.publish:
            return
        for e in events:
            try:
                self.publish(e)
            except Exception:
                log.exception("mover publish failed")
