"""Wires the long-running background services together and owns their tasks."""
from __future__ import annotations

import asyncio
import logging

from sqlalchemy import select

from .alerts.dispatcher import Dispatcher
from .alerts.telegram_bot import TelegramBot
from .bus import bus
from .config import settings
from .db import session_scope
from .engine.engine import Engine
from .feeds.manager import build_feeds
from .analytics import Analytics
from .quant.macro import MacroContext
from .quant.service import QuantEngine
from .growth import PerformanceTracker, PromoPoster
from .models import KV, OnchainWatch
from .onchain.ethereum import EthWatcher, Registry
from .onchain.monitors import DepegMonitor, ListingWatcher
from .universe import MarketUniverse

log = logging.getLogger(__name__)


def load_onchain_watches() -> dict:
    out = {"wallets": {}, "tokens": {}, "pairs": {}}
    with session_scope() as db:
        for w in db.scalars(select(OnchainWatch)):
            out.setdefault(w.kind + "s", {})[w.address.lower()] = w.label
    return out


def kv_load(key: str):
    with session_scope() as db:
        row = db.get(KV, key)
        return set(row.value) if row and row.value is not None else None


def kv_save(key: str, value: set) -> None:
    with session_scope() as db:
        row = db.get(KV, key)
        if row:
            row.value = sorted(value)
        else:
            db.add(KV(key=key, value=sorted(value)))


def kv_get(key: str):
    with session_scope() as db:
        row = db.get(KV, key)
        return row.value if row else None


def kv_put(key: str, value) -> None:
    with session_scope() as db:
        row = db.get(KV, key)
        if row:
            row.value = value
        else:
            db.add(KV(key=key, value=value))


class Services:
    def __init__(self) -> None:
        self.bus = bus
        self.engine = Engine(settings.timeframes, bus, settings.global_min_score, settings.event_max_age,
                             settings.stable_symbols)
        self.dispatcher = Dispatcher(settings, bus)
        self.depeg = DepegMonitor(settings.stable_symbols, self.engine.publish, settings.depeg_threshold)
        self.engine.price_listeners.append(self.depeg.on_price)
        self.registry = Registry(load_onchain_watches)
        self.eth: EthWatcher | None = None
        self.telegram: TelegramBot | None = None
        self.listings_status: dict = {}
        self.performance = PerformanceTracker(settings, bus, self.engine)
        self.promo = PromoPoster(settings, bus)
        live_feeds = [f for f in settings.feeds if f != "simulator"]
        self.analytics = Analytics(self.engine, settings, simulated=not live_feeds)
        self.engine.trade_listeners.append(self.analytics.on_trade)
        self.engine.enricher = self.analytics.enrich
        self.quant = QuantEngine(self.engine, self.analytics, settings, bus, simulated=not live_feeds,
                                 kv_load=kv_get, kv_save=kv_put)
        self.engine.trade_listeners.append(self.quant.on_trade)
        self.engine.candle_listeners.append(self.quant.on_candle)
        self.macro = MacroContext(settings, simulated=not live_feeds,
                                  hourly_provider=lambda sym: self.analytics.candles(sym, 3600))
        self.universe = MarketUniverse(settings, publish=self.engine.publish,
                                       live_price=lambda s: self.engine.prices.get(s, {}).get("price"),
                                       simulated=not live_feeds)
        self.tasks: list[asyncio.Task] = []

    def _task(self, coro, name: str) -> None:
        t = asyncio.create_task(coro, name=name)
        self.tasks.append(t)

    async def start(self) -> None:
        self._task(self.engine.run(), "engine")
        self._task(self.dispatcher.run(), "dispatcher")
        self._task(self.performance.run(), "performance")
        self._task(self.quant.run_training(), "quant-train")
        self._task(self.quant.run(), "quant")
        self._task(self.quant.deriv.poll(), "derivatives")
        self._task(self.macro.run(), "macro")
        self._task(self.universe.run(), "universe")
        if settings.promo_enabled:
            self._task(self.promo.run(), "promo")
        live = [f for f in settings.feeds if f != "simulator"]
        self._task(self._boot_feeds(bool(settings.backfill and live)), "feeds-boot")
        if live and settings.trending_poll:
            self._task(self.analytics.poll_trending(), "trending")
        if settings.eth_ws_url:
            self.eth = EthWatcher(settings.eth_ws_url, self.registry, self.engine.publish,
                                  lambda s: self.engine.prices.get(s, {}).get("price"),
                                  settings.whale_min_usd, self.engine.status_for("ethereum"))
            self._task(self.eth.run(), "ethereum")
        if settings.telegram_enabled:
            self.telegram = TelegramBot(settings, on_change=self.dispatcher.invalidate)
            self._task(self.telegram.run(), "telegram")
        if settings.listings_poll and live:
            lw = ListingWatcher(self.engine.publish, lambda ex: kv_load(f"listings:{ex}"),
                                lambda ex, v: kv_save(f"listings:{ex}", v), settings.listings_interval,
                                self.listings_status)
            self._task(lw.run(), "listings")
        log.info("services started: feeds=%s eth=%s telegram=%s", settings.feeds, bool(self.eth), bool(self.telegram))

    async def _boot_feeds(self, backfill: bool) -> None:
        """Backfill history first (so detectors are warm), then open the live feeds.
        Runs in the background so the website is up immediately."""
        if backfill:
            try:
                await asyncio.wait_for(self.engine.backfill_coinbase(settings.symbols), timeout=120)
            except Exception as e:
                log.warning("backfill skipped: %s", e)
            try:
                syms = [x for x in settings.symbols if x not in settings.stable_symbols]
                await asyncio.wait_for(self.analytics.backfill_hourly(syms), timeout=900)
            except Exception as e:
                log.warning("hourly backfill skipped: %s", e)
        for feed in build_feeds(self.engine, settings):
            self._task(feed.run(), f"feed:{feed.name}")

    async def stop(self) -> None:
        from .quant.features import shutdown_pool
        shutdown_pool()
        for t in self.tasks:
            t.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        self.tasks.clear()


services: Services | None = None


def get_services() -> Services:
    global services
    if services is None:
        services = Services()
    return services
