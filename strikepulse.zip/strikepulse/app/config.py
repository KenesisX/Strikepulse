"""Central configuration. Every value comes from environment variables (see .env.example)."""
from __future__ import annotations

import os
from pathlib import Path


def _load_dotenv(path: str = ".env") -> None:
    """Tiny .env loader so no extra dependency is needed. Real env vars win."""
    p = Path(path)
    if not p.exists():
        return
    for raw in p.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def _bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None or v.strip() == "":
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _list(name: str, default: str) -> list[str]:
    v = os.getenv(name)
    raw = v if v not in (None, "") else default
    return [x.strip() for x in raw.split(",") if x.strip()]


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


class Settings:
    def __init__(self) -> None:
        _load_dotenv()
        g = os.getenv
        # --- App -----------------------------------------------------------
        self.app_name = g("APP_NAME", "StrikePulse")
        self.base_url = g("BASE_URL", "http://localhost:8000").rstrip("/")
        self.secret_key = g("SECRET_KEY", "dev-insecure-change-me")
        self.cookie_secure = _bool("COOKIE_SECURE", self.base_url.startswith("https"))
        self.database_url = g("DATABASE_URL", "sqlite:///./data/strikepulse.db")
        self.admin_email = g("ADMIN_EMAIL", "")
        self.admin_password = g("ADMIN_PASSWORD", "")
        self.support_email = g("SUPPORT_EMAIL", "support@example.com")
        self.company_name = g("COMPANY_NAME", "Strikebacktech")

        # --- Market data ---------------------------------------------------
        # coinbase, kraken, binanceus, simulator
        self.feeds = _list("FEEDS", "coinbase,kraken")
        self.symbols = _list(
            "SYMBOLS",
            "BTC-USD,ETH-USD,SOL-USD,XRP-USD,DOGE-USD,ADA-USD,AVAX-USD,LINK-USD,LTC-USD,DOT-USD",
        )
        if [x.lower() for x in self.symbols] == ["auto"]:
            from .coins import auto_symbols
            self.symbols = auto_symbols(_int("AUTO_SYMBOLS_TOP", 25))
        self.stable_symbols = _list("STABLE_SYMBOLS", "USDT-USD,USDC-USD")
        # --- Whole-market coverage (every major coin, snapshot data) -------
        # coingecko (free Demo key = attribution, non-commercial; paid key = commercial) | coinmarketcap | none
        self.market_data_provider = g("MARKET_DATA_PROVIDER", "coingecko").strip().lower()
        self.coingecko_api_key = g("COINGECKO_API_KEY", "")
        self.coingecko_pro = _bool("COINGECKO_PRO", False)          # true when the key is a paid (pro-api) key
        self.cmc_api_key = g("CMC_API_KEY", "")
        self.universe_size = max(10, min(_int("UNIVERSE_SIZE", 250), 250))
        self.universe_refresh = max(60, _int("UNIVERSE_REFRESH", 300))   # seconds; 300 keeps a free key under its monthly cap
        self.mover_1h_pct = _float("MOVER_1H_PCT", 6.0)
        self.mover_24h_pct = _float("MOVER_24H_PCT", 15.0)
        # --- Companion devices / Cloudflare -----------------------------------
        self.device_pair_minutes = _int("DEVICE_PAIR_MINUTES", 15)
        self.trust_cloudflare = _bool("TRUST_CLOUDFLARE", False)      # use CF-Connecting-IP for rate limits
        self.timeframes = [int(x) for x in _list("TIMEFRAMES", "60,300,900")]
        self.backfill = _bool("BACKFILL", True)
        self.global_min_score = _int("GLOBAL_MIN_SCORE", 40)
        self.event_max_age = _int("EVENT_MAX_AGE", 600)
        self.sim_volatility = _float("SIM_VOLATILITY", 1.0)
        self.sim_trades_per_sec = _float("SIM_TRADES_PER_SEC", 4.0)

        # --- On-chain ------------------------------------------------------
        self.eth_ws_url = g("ETH_WS_URL", "")
        self.whale_min_usd = _float("WHALE_MIN_USD", 1_000_000)
        self.listings_poll = _bool("LISTINGS_POLL", True)
        self.trending_poll = _bool("TRENDING_POLL", True)
        self.hourly_backfill_days = _int("HOURLY_BACKFILL_DAYS", 365)
        self.fred_api_key = g("FRED_API_KEY", "")                          # optional: US macro series
        # --- Quant Engine adaptation ----------------------------------------------
        self.quant_retrain_minutes = _int("QUANT_RETRAIN_MINUTES", 60)     # challenger model cadence
        self.quant_half_life_days = _float("QUANT_HALF_LIFE_DAYS", 45)     # recency weighting
        self.quant_drift_psi = _float("QUANT_DRIFT_PSI", 0.25)             # retrain early above this drift
        self.quant_min_precision = _float("QUANT_MIN_PRECISION", 0.56)     # precision dial for stances
        self.conformal_alpha = _float("CONFORMAL_ALPHA", 0.05)             # 0.05 → 95% price ranges
        self.listings_interval = _int("LISTINGS_INTERVAL", 600)
        self.depeg_threshold = _float("DEPEG_THRESHOLD", 0.005)

        # --- Billing -------------------------------------------------------
        self.stripe_secret_key = g("STRIPE_SECRET_KEY", "")
        self.stripe_webhook_secret = g("STRIPE_WEBHOOK_SECRET", "")
        self.stripe_price_pro = g("STRIPE_PRICE_PRO", "")
        self.stripe_price_elite = g("STRIPE_PRICE_ELITE", "")
        self.trial_days = _int("TRIAL_DAYS", 7)
        self.dev_fake_billing = _bool("DEV_FAKE_BILLING", False)

        # --- Delivery ------------------------------------------------------
        self.telegram_bot_token = g("TELEGRAM_BOT_TOKEN", "")
        self.telegram_bot_username = g("TELEGRAM_BOT_USERNAME", "")
        self.smtp_host = g("SMTP_HOST", "")
        self.smtp_port = _int("SMTP_PORT", 587)
        self.smtp_user = g("SMTP_USER", "")
        self.smtp_password = g("SMTP_PASSWORD", "")
        self.smtp_from = g("SMTP_FROM", "alerts@example.com")
        self.smtp_starttls = _bool("SMTP_STARTTLS", True)
        self.ntfy_server = g("NTFY_SERVER", "https://ntfy.sh").rstrip("/")

        # --- Growth / marketing ----------------------------------------------
        self.public_performance = _bool("PUBLIC_PERFORMANCE", True)
        self.outcome_horizons = [int(x) for x in _list("OUTCOME_HORIZONS", "15,60,240")]
        self.promo_telegram_chat = g("PROMO_TELEGRAM_CHAT", "")      # @yourchannel or -100123...
        self.promo_discord_webhook = g("PROMO_DISCORD_WEBHOOK", "")
        self.promo_min_score = _int("PROMO_MIN_SCORE", 75)
        self.promo_delay = _int("PROMO_DELAY", 900)
        self.promo_max_per_hour = _int("PROMO_MAX_PER_HOUR", 4)
        self.stripe_price_pro_yearly = g("STRIPE_PRICE_PRO_YEARLY", "")
        self.stripe_price_elite_yearly = g("STRIPE_PRICE_ELITE_YEARLY", "")

        # --- Branding ----------------------------------------------------------
        self.accent_color = g("ACCENT_COLOR", "#e11d2e")
        self.accent_color_2 = g("ACCENT_COLOR_2", "#ffffff")
        self.logo_url = g("LOGO_URL", "")                          # optional image instead of the ⚡ mark
        self.tagline = g("TAGLINE", "Know the moment the market shifts.")
        # --- Give-back (optional) ---------------------------------------------
        self.charity_name = g("CHARITY_NAME", "")
        self.charity_url = g("CHARITY_URL", "")
        self.charity_percent = _float("CHARITY_PERCENT", 0)       # 0 = off; e.g. 5 = 5% of subscription revenue
        # --- About page ----------------------------------------------------------
        self.founder_name = g("FOUNDER_NAME", "Jordan Kniffen")
        self.founder_handle = g("FOUNDER_HANDLE", "Kenesis_X")
        self.founder_title = g("FOUNDER_TITLE", "Founder")
        self.company_location = g("COMPANY_LOCATION", "Northern Colorado, USA")
        self.founder_photo = g("FOUNDER_PHOTO", "")          # e.g. /static/founder.jpg
        self.social_x = g("SOCIAL_X", "")
        self.social_telegram = g("SOCIAL_TELEGRAM", "")
        self.social_discord = g("SOCIAL_DISCORD", "")
        self.google_analytics_id = g("GA_MEASUREMENT_ID", "")       # reserved; CSP must be widened to use it

    @property
    def billing_enabled(self) -> bool:
        return bool(self.stripe_secret_key and (self.stripe_price_pro or self.stripe_price_elite))

    @property
    def charity_enabled(self) -> bool:
        return bool(self.charity_name and self.charity_percent > 0)

    @property
    def promo_enabled(self) -> bool:
        return bool((self.promo_telegram_chat and self.telegram_bot_token) or self.promo_discord_webhook)

    @property
    def yearly_enabled(self) -> bool:
        return bool(self.stripe_price_pro_yearly or self.stripe_price_elite_yearly)

    @property
    def email_enabled(self) -> bool:
        return bool(self.smtp_host)

    @property
    def telegram_enabled(self) -> bool:
        return bool(self.telegram_bot_token)

    def reload(self) -> None:
        self.__init__()


settings = Settings()
