"""Routes every published event to the right users, on the channels their plan allows,
honouring delays, quiet hours, pauses and daily caps. Also persists alerts and feeds
each user's live dashboard stream."""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from zoneinfo import ZoneInfo

import httpx
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from ..config import Settings
from ..db import session_scope
from ..engine.scoring import confluence
from ..engine.types import MarketEvent, Signal
from ..models import Alert, Delivery, User
from ..plans import Plan, plan_for
from . import channels, formatting

log = logging.getLogger(__name__)


@dataclass
class WatchView:
    symbol: str
    min_score: int
    timeframes: set[str]
    direction: str
    detectors: set[str]


@dataclass
class UserView:
    id: int
    email: str
    plan: Plan
    api_key: str
    telegram_chat_id: str | None
    discord_webhook: str | None
    ntfy_topic: str | None
    webhook_url: str | None
    email_to: str | None
    timezone: str
    quiet_start: int | None
    quiet_end: int | None
    paused_until: float | None
    want_depeg: bool
    want_listings: bool
    gas_below: int | None
    want_movers: bool = False
    movers_min_pct: float = 8.0
    watches: list[WatchView] = field(default_factory=list)
    onchain: dict[str, float] = field(default_factory=dict)   # address -> min_usd

    @classmethod
    def from_user(cls, u: User) -> "UserView":
        plan = plan_for(u)
        return cls(
            id=u.id, email=u.email, plan=plan, api_key=u.api_key, telegram_chat_id=u.telegram_chat_id,
            discord_webhook=u.discord_webhook, ntfy_topic=u.ntfy_topic, webhook_url=u.webhook_url,
            email_to=(u.alert_email or u.email) if u.email_alerts else None, timezone=u.timezone or "UTC",
            quiet_start=u.quiet_start, quiet_end=u.quiet_end, paused_until=u.paused_until,
            want_depeg=u.want_depeg, want_listings=u.want_listings, gas_below=u.gas_below,
            want_movers=bool(u.want_movers), movers_min_pct=float(u.movers_min_pct or 8.0),
            watches=[WatchView(w.symbol, w.min_score, set(w.tf_list), w.direction, set(w.detector_list))
                     for w in u.watches if w.enabled][: plan.max_watches],
            onchain={o.address.lower(): o.min_usd for o in u.onchain_watches[: plan.onchain_wallets]},
        )

    def in_quiet_hours(self, now: float | None = None) -> bool:
        if self.quiet_start is None or self.quiet_end is None or self.quiet_start == self.quiet_end:
            return False
        try:
            hour = datetime.fromtimestamp(now or time.time(), ZoneInfo(self.timezone)).hour
        except Exception:
            hour = datetime.utcfromtimestamp(now or time.time()).hour
        if self.quiet_start < self.quiet_end:
            return self.quiet_start <= hour < self.quiet_end
        return hour >= self.quiet_start or hour < self.quiet_end


def effective_score(event: MarketEvent, allowed: set[str]) -> int:
    """Re-score a market event using only the detectors this user is allowed / chose."""
    sigs = [Signal(s["detector"], s["direction"], s["strength"], s["detail"]) for s in event.signals
            if s["detector"] in allowed]
    if not sigs:
        return 0
    score, direction = confluence(sigs, int(event.meta.get("interval", 300)))
    return score if direction == event.direction else 0


def match(event: MarketEvent, u: UserView) -> int | None:
    """Return the score to show this user, or None if they shouldn't get the event."""
    p = u.plan
    if event.kind == "market":
        best = None
        for w in u.watches:
            if w.symbol != event.symbol:
                continue
            if event.timeframe not in w.timeframes or event.timeframe not in p.timeframes:
                continue
            if w.direction == "up" and event.direction < 0 or w.direction == "down" and event.direction > 0:
                continue
            allowed = set(p.detectors) & (w.detectors or set(p.detectors))
            s = effective_score(event, allowed)
            if s >= max(w.min_score, p.min_score_floor) and (best is None or s > best):
                best = s
        return best
    if event.kind == "mover":
        if any(w.symbol == event.symbol for w in u.watches):      # a coin you watch moved hard: every plan
            return event.score
        if p.movers and u.want_movers and abs(float(event.meta.get("pct", 0))) >= u.movers_min_pct:
            return event.score
        return None
    if event.kind == "depeg":
        return event.score if p.depeg and u.want_depeg else None
    if event.kind == "listing":
        return event.score if p.listings and u.want_listings else None
    if event.kind == "gas":
        return event.score if p.gas and u.gas_below and event.meta.get("threshold") == u.gas_below else None
    if event.kind in ("quant", "edge"):
        need = p.edge_lab if event.kind == "edge" else p.quant
        if need and any(w.symbol == event.symbol for w in u.watches):
            return event.score
        return None
    if event.kind in ("onchain", "security"):
        if event.kind == "security" and not p.security:
            return None
        if p.onchain_wallets <= 0:
            return None
        usd = event.meta.get("usd")
        for addr in event.meta.get("addresses", []):
            min_usd = u.onchain.get(str(addr).lower())
            if min_usd is not None and (not min_usd or usd is None or usd >= min_usd):
                return event.score
        # whale exchange flows for coins the user already watches
        if event.kind == "onchain" and event.meta.get("pattern") in ("exchange_inflow", "exchange_outflow"):
            if any(w.symbol == event.symbol for w in u.watches):
                return event.score
        return None
    return None


class Dispatcher:
    def __init__(self, settings: Settings, bus):
        self.s = settings
        self.bus = bus
        self.users: list[UserView] = []
        self._users_at = 0.0
        self._dirty = True
        self.daily: dict[tuple[int, str], int] = defaultdict(int)
        self.streams: dict[int, set[asyncio.Queue]] = defaultdict(set)
        self.client: httpx.AsyncClient | None = None
        self.sent = 0
        self.failed = 0
        self._tasks: set[asyncio.Task] = set()

    # -------------------------------------------------------------- users cache
    def invalidate(self) -> None:
        self._dirty = True

    def _load_users(self) -> list[UserView]:
        with session_scope() as db:
            rows = db.scalars(select(User).where(User.disabled.is_(False))
                              .options(selectinload(User.watches), selectinload(User.onchain_watches))).all()
            return [UserView.from_user(u) for u in rows]

    async def users_view(self) -> list[UserView]:
        if self._dirty or time.time() - self._users_at > 30:
            self.users = await asyncio.to_thread(self._load_users)
            self._users_at = time.time()
            self._dirty = False
        return self.users

    # -------------------------------------------------------------- streams
    def open_stream(self, user_id: int) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=200)
        self.streams[user_id].add(q)
        return q

    def close_stream(self, user_id: int, q: asyncio.Queue) -> None:
        self.streams[user_id].discard(q)

    def _push_stream(self, user_id: int, payload: dict) -> None:
        for q in list(self.streams.get(user_id, ())):
            try:
                q.put_nowait(payload)
            except asyncio.QueueFull:
                pass

    # -------------------------------------------------------------- main loop
    async def run(self) -> None:
        q = self.bus.subscribe(maxsize=10_000)
        self.client = httpx.AsyncClient(timeout=15, headers={"User-Agent": f"{self.s.app_name}/1.0"})
        try:
            while True:
                event: MarketEvent = await q.get()
                try:
                    await self.handle(event)
                except Exception:
                    log.exception("dispatch failed for %s", event.id)
        finally:
            self.bus.unsubscribe(q)
            await self.client.aclose()

    def _persist(self, e: MarketEvent) -> None:
        with session_scope() as db:
            if db.get(Alert, e.id) is None:
                db.add(Alert(id=e.id, kind=e.kind, symbol=e.symbol, title=e.title, direction=e.direction,
                             score=e.score, price=e.price, timeframe=e.timeframe, reasons=e.reasons,
                             signals=e.signals, meta=_jsonable(e.meta), ts=e.ts))

    async def handle(self, event: MarketEvent) -> None:
        if event.kind != "test":
            await asyncio.to_thread(self._persist, event)
        for u in await self.users_view():
            score = match(event, u)
            if score is None:
                continue
            if u.plan.delay_seconds:
                self._spawn(self._delayed(u, event, score, u.plan.delay_seconds))
            else:
                self._spawn(self.deliver(u, event, score))

    def _spawn(self, coro) -> None:
        t = asyncio.create_task(coro)
        self._tasks.add(t)
        t.add_done_callback(self._tasks.discard)

    async def _delayed(self, u: UserView, e: MarketEvent, score: int, delay: int) -> None:
        await asyncio.sleep(delay)
        await self.deliver(u, e, score)

    # -------------------------------------------------------------- delivery
    def _cap_ok(self, u: UserView) -> bool:
        day = time.strftime("%Y-%m-%d")
        key = (u.id, day)
        if self.daily[key] >= u.plan.daily_cap:
            return False
        self.daily[key] += 1
        if len(self.daily) > 50_000:
            self.daily = defaultdict(int, {k: v for k, v in self.daily.items() if k[1] == day})
        return True

    async def deliver(self, u: UserView, e: MarketEvent, score: int, force: bool = False) -> dict[str, str]:
        payload = e.to_dict()
        payload["score"] = score
        self._push_stream(u.id, payload)
        results: dict[str, str] = {}
        if not force:
            if u.paused_until and u.paused_until > time.time():
                return {"all": "paused"}
            if u.in_quiet_hours() and not e.critical:
                return {"all": "quiet hours"}
            if not self._cap_ok(u):
                return {"all": "daily cap reached"}
        allowed = u.plan.channels
        jobs: list[tuple[str, asyncio.Future]] = []
        base = self.s.base_url
        if "telegram" in allowed and u.telegram_chat_id and self.s.telegram_enabled:
            jobs.append(("telegram", channels.send_telegram(self.client, self.s.telegram_bot_token, u.telegram_chat_id,
                                                            formatting.telegram_html(e, score), formatting.chart_url(base, e))))
        if "discord" in allowed and u.discord_webhook:
            jobs.append(("discord", channels.send_discord(self.client, u.discord_webhook,
                                                          formatting.discord_payload(e, base, score, self.s.app_name))))
        if "ntfy" in allowed and u.ntfy_topic:
            prio = 5 if e.critical else 4 if score >= 75 else 3
            tags = "rotating_light" if e.critical else ("chart_with_upwards_trend" if e.direction > 0 else
                                                        "chart_with_downwards_trend" if e.direction < 0 else "bell")
            body = "\n".join(e.reasons[:5]) + f"\n{formatting.DISCLAIMER}"
            jobs.append(("ntfy", channels.send_ntfy(self.client, self.s.ntfy_server, u.ntfy_topic,
                                                    formatting.headline(e, score), body, prio, tags,
                                                    formatting.chart_url(base, e))))
        if "email" in allowed and u.email_to and self.s.email_enabled:
            jobs.append(("email", channels.send_email(self.s, u.email_to, formatting.headline(e, score),
                                                      formatting.plain(e, base, score),
                                                      formatting.email_html(e, base, score, self.s.app_name))))
        if "webhook" in allowed and u.webhook_url:
            jobs.append(("webhook", channels.send_webhook(self.client, u.webhook_url,
                                                          formatting.webhook_payload(e, score), u.api_key)))
        if not jobs:
            return {"all": "no channels configured"}
        outcomes = await asyncio.gather(*(j for _, j in jobs), return_exceptions=True)
        log_rows = []
        for (name, _), out in zip(jobs, outcomes):
            ok = not isinstance(out, BaseException)
            results[name] = "sent" if ok else f"failed: {out}"
            if ok:
                self.sent += 1
            else:
                self.failed += 1
                log.warning("delivery %s to user %s failed: %s", name, u.id, out)
            log_rows.append(Delivery(alert_id=e.id, user_id=u.id, channel=name, ok=ok,
                                     error=None if ok else str(out)[:500]))
        if e.kind != "test":
            await asyncio.to_thread(self._log_deliveries, log_rows)
        return results

    @staticmethod
    def _log_deliveries(rows: list[Delivery]) -> None:
        with session_scope() as db:
            db.add_all(rows)

    async def send_test(self, user: User) -> dict[str, str]:
        u = UserView.from_user(user)
        e = MarketEvent(kind="test", symbol="BTC-USD", title="Test alert: your channels work", direction=1,
                        score=77, price=None, timeframe="5m",
                        reasons=["This is what a real alert looks like", "EMA 9/21 bullish cross (example)",
                                 "Volume 3.4x normal (example)"])
        if self.client is None:
            self.client = httpx.AsyncClient(timeout=15)
        return await self.deliver(u, e, 77, force=True)


def _jsonable(d: dict) -> dict:
    out = {}
    for k, v in d.items():
        if isinstance(v, (str, int, float, bool)) or v is None:
            out[k] = v
        elif isinstance(v, (list, tuple)):
            out[k] = [x if isinstance(x, (str, int, float, bool)) or x is None else str(x) for x in v]
        elif isinstance(v, dict):
            out[k] = _jsonable(v)
        else:
            out[k] = str(v)
    return out
