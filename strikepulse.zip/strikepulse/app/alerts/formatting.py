"""Render an event for each delivery channel."""
from __future__ import annotations

import html
from datetime import datetime, timezone

from ..engine.types import MarketEvent

KIND_EMOJI = {"quant": "🧠", "edge": "🕵️", "security": "🛡️", "depeg": "⚠️", "listing": "🆕", "gas": "⛽", "onchain": "🐋", "test": "🔔"}
DISCLAIMER = "Market data alert, not financial advice."


def emoji(e: MarketEvent) -> str:
    if e.kind == "market":
        return "⚪" if e.direction > 0 else "🔴"
    if e.kind == "mover":
        return "🚀" if e.direction > 0 else "📉"
    return KIND_EMOJI.get(e.kind, "🔔")


def fmt_price(p: float | None) -> str:
    if p is None:
        return ""
    if p >= 1000:
        return f"${p:,.2f}"
    if p >= 1:
        return f"${p:,.4f}"
    if p >= 0.01:
        return f"${p:.5f}"
    return f"${p:.10f}".rstrip("0")


def chart_url(base_url: str, e: MarketEvent) -> str:
    if e.kind == "market":
        return f"{base_url}/dashboard?symbol={e.symbol}&tf={e.timeframe}&alert={e.id}"
    if e.meta.get("tx"):
        return f"https://etherscan.io/tx/{e.meta['tx']}"
    return f"{base_url}/alerts"


def headline(e: MarketEvent, score: int | None = None) -> str:
    s = score if score is not None else e.score
    parts = [f"{emoji(e)} {e.title}"]
    if e.kind != "gas" and s:
        parts.append(f"score {s}")
    return " · ".join(parts)


def plain(e: MarketEvent, base_url: str, score: int | None = None) -> str:
    lines = [headline(e, score)]
    if e.price is not None:
        lines.append(f"Price {fmt_price(e.price)}")
    lines += [f"• {r}" for r in e.reasons[:6]]
    if e.meta.get("opposing"):
        lines.append("Against: " + "; ".join(e.meta["opposing"][:2]))
    lines.append(chart_url(base_url, e))
    lines.append(DISCLAIMER)
    return "\n".join(lines)


def telegram_html(e: MarketEvent, score: int | None = None) -> str:
    esc = html.escape
    lines = [f"<b>{esc(headline(e, score))}</b>"]
    if e.price is not None:
        lines.append(f"Price <code>{esc(fmt_price(e.price))}</code>")
    lines += [f"• {esc(r)}" for r in e.reasons[:6]]
    if e.meta.get("opposing"):
        lines.append(f"<i>Against: {esc('; '.join(e.meta['opposing'][:2]))}</i>")
    lines.append(f"<i>{DISCLAIMER}</i>")
    return "\n".join(lines)


def discord_payload(e: MarketEvent, base_url: str, score: int | None = None, app_name: str = "StrikePulse") -> dict:
    color = 0xF5F5F5 if e.direction > 0 else 0xE11D2E if e.direction < 0 else 0x8A8A8A
    if e.kind == "security":
        color = 0xFF4D5E
    fields = []
    if e.price is not None:
        fields.append({"name": "Price", "value": fmt_price(e.price), "inline": True})
    if e.timeframe:
        fields.append({"name": "Timeframe", "value": e.timeframe, "inline": True})
    s = score if score is not None else e.score
    if s:
        fields.append({"name": "Score", "value": f"{s}/100", "inline": True})
    return {
        "username": app_name,
        "embeds": [{
            "title": f"{emoji(e)} {e.title}"[:256],
            "url": chart_url(base_url, e),
            "description": "\n".join(f"• {r}" for r in e.reasons[:8])[:4000],
            "color": color,
            "fields": fields,
            "footer": {"text": DISCLAIMER},
            "timestamp": datetime.fromtimestamp(e.ts, tz=timezone.utc).isoformat(),
        }],
    }


def email_html(e: MarketEvent, base_url: str, score: int | None = None, app_name: str = "StrikePulse") -> str:
    esc = html.escape
    color = "#111111" if e.direction > 0 else "#e11d2e" if e.direction < 0 else "#555555"
    items = "".join(f"<li style='margin:4px 0'>{esc(r)}</li>" for r in e.reasons[:8])
    price = f"<p style='font-size:18px;margin:8px 0'><b>{esc(fmt_price(e.price))}</b></p>" if e.price is not None else ""
    return f"""<div style="font-family:system-ui,Segoe UI,Arial;max-width:560px;margin:auto;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden">
<div style="background:{color};color:#fff;padding:14px 18px;font-size:17px;font-weight:600">{esc(headline(e, score))}</div>
<div style="padding:16px 18px;color:#111">{price}<ul style="padding-left:18px">{items}</ul>
<p><a href="{esc(chart_url(base_url, e))}" style="background:#111;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none">Open chart</a></p>
<p style="color:#6b7280;font-size:12px">{DISCLAIMER} You're receiving this because you set up alerts on {esc(app_name)}.
<a href="{esc(base_url)}/settings">Manage alerts</a></p></div></div>"""


def webhook_payload(e: MarketEvent, score: int | None = None) -> dict:
    d = e.to_dict()
    if score is not None:
        d["score"] = score
    d["disclaimer"] = DISCLAIMER
    return d
