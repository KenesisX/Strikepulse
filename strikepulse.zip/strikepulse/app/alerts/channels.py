"""Delivery channels + outbound URL validation (SSRF protection for user-supplied webhooks)."""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import ipaddress
import json
import os
import smtplib
import socket
import ssl
from email.message import EmailMessage
from urllib.parse import urlparse

import httpx

from ..config import Settings


class DeliveryError(Exception):
    pass


ALLOW_PRIVATE = os.getenv("ALLOW_PRIVATE_WEBHOOKS", "").lower() in ("1", "true", "yes")


def _is_public_host(host: str) -> bool:
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            return False
    return True


def validate_outbound_url(url: str, kind: str = "webhook", resolve: bool = True) -> str:
    """Raise ValueError if a user-supplied URL is unsafe to POST to."""
    url = (url or "").strip()
    p = urlparse(url)
    if p.scheme not in ("https",) and not (ALLOW_PRIVATE and p.scheme == "http"):
        raise ValueError("URL must start with https://")
    if not p.hostname:
        raise ValueError("URL has no host")
    if kind == "discord":
        if p.hostname not in ("discord.com", "discordapp.com", "ptb.discord.com", "canary.discord.com") \
                or not p.path.startswith("/api/webhooks/"):
            raise ValueError("That doesn't look like a Discord webhook URL (https://discord.com/api/webhooks/…)")
    if resolve and not ALLOW_PRIVATE and not _is_public_host(p.hostname):
        raise ValueError("Webhook host must be a public internet address")
    return url


def sign(body: bytes, secret: str) -> str:
    return "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


async def send_telegram(client: httpx.AsyncClient, token: str, chat_id: str, text: str, button_url: str | None = None) -> None:
    payload: dict = {"chat_id": chat_id, "text": text[:4096], "parse_mode": "HTML", "disable_web_page_preview": True}
    if button_url and button_url.startswith("https://"):
        payload["reply_markup"] = {"inline_keyboard": [[{"text": "Open chart", "url": button_url}]]}
    r = await client.post(f"https://api.telegram.org/bot{token}/sendMessage", json=payload)
    if r.status_code != 200:
        raise DeliveryError(f"telegram {r.status_code}: {r.text[:200]}")


async def send_discord(client: httpx.AsyncClient, url: str, payload: dict) -> None:
    validate_outbound_url(url, "discord", resolve=False)
    r = await client.post(url, json=payload)
    if r.status_code == 429:
        retry = float(r.json().get("retry_after", 1))
        await asyncio.sleep(min(retry, 5))
        r = await client.post(url, json=payload)
    if r.status_code >= 300:
        raise DeliveryError(f"discord {r.status_code}: {r.text[:200]}")


async def send_ntfy(client: httpx.AsyncClient, server: str, topic: str, title: str, body: str,
                    priority: int = 3, tags: str = "", click: str = "") -> None:
    # JSON publishing keeps emoji/UTF-8 intact (HTTP headers must be ASCII)
    payload: dict = {"topic": topic, "title": title[:250], "message": body[:4000], "priority": priority}
    if tags:
        payload["tags"] = [t for t in tags.split(",") if t]
    if click:
        payload["click"] = click
    r = await client.post(server, json=payload)
    if r.status_code >= 300:
        raise DeliveryError(f"ntfy {r.status_code}: {r.text[:200]}")


async def send_webhook(client: httpx.AsyncClient, url: str, payload: dict, secret: str) -> None:
    validate_outbound_url(url, "webhook")
    body = json.dumps(payload, default=str).encode()
    r = await client.post(url, content=body, headers={
        "Content-Type": "application/json", "User-Agent": "StrikePulse-Webhook/1.0",
        "X-StrikePulse-Signature": sign(body, secret), "X-StrikePulse-Event": payload.get("kind", "")})
    if r.status_code >= 300:
        raise DeliveryError(f"webhook {r.status_code}")


def _smtp_send(s: Settings, to: str, subject: str, text: str, html_body: str) -> None:
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = s.smtp_from, to, subject
    msg.set_content(text)
    msg.add_alternative(html_body, subtype="html")
    if s.smtp_port == 465:
        with smtplib.SMTP_SSL(s.smtp_host, s.smtp_port, context=ssl.create_default_context(), timeout=20) as srv:
            if s.smtp_user:
                srv.login(s.smtp_user, s.smtp_password)
            srv.send_message(msg)
    else:
        with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=20) as srv:
            if s.smtp_starttls:
                srv.starttls(context=ssl.create_default_context())
            if s.smtp_user:
                srv.login(s.smtp_user, s.smtp_password)
            srv.send_message(msg)


async def send_email(s: Settings, to: str, subject: str, text: str, html_body: str) -> None:
    if not s.email_enabled:
        raise DeliveryError("SMTP not configured")
    await asyncio.to_thread(_smtp_send, s, to, subject, text, html_body)
