"""Telegram bot (long polling): links chats to accounts and handles simple commands.

Users click "Connect Telegram" on the settings page → opens t.me/<bot>?start=<code>
→ the bot receives "/start <code>" and stores the chat id on the matching account.
"""
from __future__ import annotations

import asyncio
import logging
import time

import httpx
from sqlalchemy import select

from ..config import Settings
from ..db import session_scope
from ..models import User
from ..plans import plan_for

log = logging.getLogger(__name__)

HELP = ("<b>StrikePulse bot</b>\n"
        "/watches: your watchlist\n"
        "/pause 2h: pause alerts (e.g. 30m, 2h, 1d)\n"
        "/resume: resume alerts\n"
        "/status: plan and channel status\n"
        "/unlink: disconnect this chat")


def parse_duration(s: str) -> int | None:
    s = s.strip().lower()
    if not s:
        return None
    unit = s[-1]
    mult = {"m": 60, "h": 3600, "d": 86400}.get(unit)
    try:
        return int(float(s[:-1]) * mult) if mult else int(s) * 60
    except ValueError:
        return None


class TelegramBot:
    def __init__(self, settings: Settings, on_change=None):
        self.s = settings
        self.api = f"https://api.telegram.org/bot{settings.telegram_bot_token}"
        self.on_change = on_change or (lambda: None)
        self.offset = 0
        self.status = {"connected": False, "errors": 0}

    async def reply(self, client: httpx.AsyncClient, chat_id, text: str) -> None:
        await client.post(f"{self.api}/sendMessage", json={"chat_id": chat_id, "text": text, "parse_mode": "HTML"})

    def handle_command(self, chat_id: str, text: str) -> str:
        parts = text.strip().split(maxsplit=1)
        cmd = parts[0].split("@")[0].lower() if parts else ""
        arg = parts[1] if len(parts) > 1 else ""
        with session_scope() as db:
            if cmd == "/start":
                if not arg:
                    user = db.scalar(select(User).where(User.telegram_chat_id == chat_id))
                    return ("You're connected. " + HELP) if user else \
                        f"Open {self.s.base_url}/settings and press <b>Connect Telegram</b> to link this chat."
                user = db.scalar(select(User).where(User.telegram_link_code == arg.strip()))
                if not user:
                    return "That link code is invalid or expired. Generate a new one on the settings page."
                for other in db.scalars(select(User).where(User.telegram_chat_id == chat_id)):
                    other.telegram_chat_id = None
                user.telegram_chat_id = chat_id
                import secrets
                user.telegram_link_code = secrets.token_hex(6)
                self.on_change()
                return f"✅ Linked to <b>{user.email}</b>. Alerts will arrive here.\n\n{HELP}"
            user = db.scalar(select(User).where(User.telegram_chat_id == chat_id))
            if not user:
                return f"This chat isn't linked yet. Open {self.s.base_url}/settings → Connect Telegram."
            if cmd == "/watches":
                if not user.watches:
                    return "No watches yet. Add some on your dashboard."
                lines = [f"• <b>{w.symbol}</b>  min score {w.min_score}  [{w.timeframes}]  {w.direction}"
                         + ("" if w.enabled else " (off)") for w in user.watches]
                return "<b>Your watchlist</b>\n" + "\n".join(lines)
            if cmd == "/pause":
                secs = parse_duration(arg or "1h")
                if not secs:
                    return "Usage: /pause 30m | 2h | 1d"
                user.paused_until = time.time() + secs
                self.on_change()
                return f"⏸ Alerts paused for {arg or '1h'}. /resume to turn them back on."
            if cmd == "/resume":
                user.paused_until = None
                self.on_change()
                return "▶️ Alerts resumed."
            if cmd == "/status":
                p = plan_for(user)
                paused = "yes" if user.paused else "no"
                return (f"<b>{user.email}</b>\nPlan: {p.name}\nWatches: {len(user.watches)}/{p.max_watches}\n"
                        f"Paused: {paused}")
            if cmd == "/unlink":
                user.telegram_chat_id = None
                self.on_change()
                return "Chat unlinked. You won't get alerts here anymore."
            return HELP

    async def run(self) -> None:
        async with httpx.AsyncClient(timeout=40) as client:
            # make sure no webhook is set, otherwise getUpdates fails
            try:
                await client.post(f"{self.api}/deleteWebhook")
            except Exception:
                pass
            while True:
                try:
                    r = await client.get(f"{self.api}/getUpdates", params={"timeout": 30, "offset": self.offset})
                    data = r.json()
                    self.status["connected"] = bool(data.get("ok"))
                    for upd in data.get("result", []):
                        self.offset = upd["update_id"] + 1
                        msg = upd.get("message") or upd.get("edited_message") or {}
                        text = msg.get("text", "")
                        chat_id = str(msg.get("chat", {}).get("id", ""))
                        if text.startswith("/") and chat_id:
                            answer = await asyncio.to_thread(self.handle_command, chat_id, text)
                            await self.reply(client, chat_id, answer)
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    self.status["connected"] = False
                    self.status["errors"] += 1
                    self.status["last_error"] = str(e)[:200]
                    log.warning("telegram poll error: %s", e)
                    await asyncio.sleep(5)
