"""StrikePulse Deep Analysis: the views other alert apps don't offer.

* Probability Engine: finds the most similar past market moments (k-nearest-neighbour
  "analogs") and reports how often price was higher 1h / 4h / 24h later, with the
  typical move and the 10th-90th percentile range, versus the coin's base rate.
* Probability cone + target calculator: volatility-based price ranges and the odds of
  touching / closing beyond any price you type.
* Order-flow X-ray: taker buy vs sell dollars, cumulative volume delta, and whale
  (top-3% trade size) vs retail flow, including divergence between the two.
* Timing map: hour-of-day x weekday heatmap of average move, up-probability and volume.
* Trend matrix + regime: 1m/5m/15m/1h trend direction and strength, trending/ranging/volatile.
* Attention & rotation: which coins are gaining share of total dollar volume and trade
  activity right now, plus optional CoinGecko trending list.
* Shift feed: plain-English numbers about what just changed.
* Pulse Score: one 0-100 read that combines all of the above.
"""
from __future__ import annotations

import asyncio
import logging
import math
import random
import time
from collections import deque
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

import httpx
import numpy as np

from .engine import indicators as ind
from .engine.candles import CandleSeries
from .engine.types import Candle, MarketEvent, Trade

log = logging.getLogger(__name__)
WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
FULL_DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def _phi(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _r(x, n=4):
    return None if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))) else round(float(x), n)


# ============================================================================ order flow
class FlowTracker:
    """Per-minute taker buy/sell dollars, split into whale (top-percentile trade size) and retail."""

    def __init__(self, whale_pct: float = 97.0, minutes: int = 1440):
        self.whale_pct = whale_pct
        self.minutes = minutes
        self.buckets: dict[str, deque] = {}
        self.sizes: dict[str, deque] = {}
        self.threshold: dict[str, float] = {}
        self._since: dict[str, int] = {}

    def on_trade(self, t: Trade) -> None:
        usd = t.price * t.size
        if usd <= 0:
            return
        sizes = self.sizes.setdefault(t.symbol, deque(maxlen=5000))
        sizes.append(usd)
        n = self._since.get(t.symbol, 0) + 1
        self._since[t.symbol] = n
        if n >= 250 and len(sizes) >= 300:
            self.threshold[t.symbol] = float(np.percentile(np.fromiter(sizes, float), self.whale_pct))
            self._since[t.symbol] = 0
        thr = self.threshold.get(t.symbol)
        whale = thr is not None and usd >= thr
        minute = int(t.ts // 60) * 60
        dq = self.buckets.setdefault(t.symbol, deque(maxlen=self.minutes))
        if not dq or dq[-1]["t"] < minute:
            dq.append({"t": minute, "buy": 0.0, "sell": 0.0, "wbuy": 0.0, "wsell": 0.0, "n": 0, "wn": 0})
        b = dq[-1] if dq[-1]["t"] == minute else next((x for x in reversed(dq) if x["t"] == minute), dq[-1])
        side = "buy" if t.side == "buy" else "sell"
        b[side] += usd
        b["n"] += 1
        if whale:
            b["w" + side] += usd
            b["wn"] += 1

    def window(self, symbol: str, minutes: int, offset: int = 0, now: float | None = None) -> dict:
        now = now or time.time()
        end = now - offset * 60
        start = end - minutes * 60
        agg = {"buy": 0.0, "sell": 0.0, "wbuy": 0.0, "wsell": 0.0, "n": 0, "wn": 0}
        for b in tuple(self.buckets.get(symbol, ())):
            if start <= b["t"] < end:
                for k in agg:
                    agg[k] += b[k]
        tot = agg["buy"] + agg["sell"]
        wt = agg["wbuy"] + agg["wsell"]
        rb, rs = agg["buy"] - agg["wbuy"], agg["sell"] - agg["wsell"]
        return {**{k: _r(v, 2) for k, v in agg.items()}, "total": _r(tot, 2),
                "buy_share": _r(agg["buy"] / tot) if tot else None,
                "net": _r(agg["buy"] - agg["sell"], 2),
                "whale_net": _r(agg["wbuy"] - agg["wsell"], 2),
                "whale_buy_share": _r(agg["wbuy"] / wt) if wt else None,
                "retail_net": _r(rb - rs, 2),
                "retail_buy_share": _r(rb / (rb + rs)) if (rb + rs) > 0 else None,
                "whale_threshold": _r(self.threshold.get(symbol), 2)}

    def series(self, symbol: str, minutes: int = 240) -> list[dict]:
        out, cvd, wcvd = [], 0.0, 0.0
        for b in tuple(self.buckets.get(symbol, ()))[-minutes:]:
            cvd += b["buy"] - b["sell"]
            wcvd += b["wbuy"] - b["wsell"]
            out.append({"t": b["t"], "buy": round(b["buy"], 2), "sell": round(b["sell"], 2), "cvd": round(cvd, 2),
                        "wcvd": round(wcvd, 2), "n": b["n"]})
        return out


# ============================================================================ helpers
def _arr(cs: list[Candle], a: str) -> np.ndarray:
    return np.fromiter((getattr(c, a) for c in cs), float, len(cs))


def analog_features(cs: list[Candle]) -> np.ndarray:
    """Per-bar description of the market state used to find similar moments."""
    c = _arr(cs, "close")
    v = _arr(cs, "volume")
    lc = np.log(np.maximum(c, 1e-12))
    n = len(c)

    def lag_ret(k):
        out = np.zeros(n)
        out[k:] = lc[k:] - lc[:-k]
        return out

    r1, r4, r24 = lag_ret(1), lag_ret(4), lag_ret(24)
    vol_mean = np.convolve(v, np.ones(24) / 24, "same")
    vrel = np.log1p(v) - np.log1p(np.maximum(vol_mean, 1e-12))
    rsi = np.nan_to_num(ind.rsi(c, 14), nan=50.0) / 100.0
    ema50 = ind.ema(c, 50)
    dist = (c - ema50) / np.maximum(ema50, 1e-12)
    rv = ind.rolling_std(np.concatenate([[0], np.diff(lc)]), 24)
    rv = np.nan_to_num(rv, nan=np.nanmean(rv) if np.any(~np.isnan(rv)) else 0.0)
    rvz = (rv - rv.mean()) / (rv.std() + 1e-12)
    return np.column_stack([r1, r4, r24, vrel, rsi, dist, rvz])


def probability_engine(cs: list[Candle], horizons: tuple[int, ...], k: int = 40, warmup: int = 50) -> dict | None:
    """k-nearest historical analogs of the latest closed bar, and what happened next."""
    n = len(cs)
    hmax = max(horizons)
    if n < warmup + hmax + k + 5:
        return None
    X = analog_features(cs)
    mu, sd = X[warmup:].mean(axis=0), X[warmup:].std(axis=0) + 1e-9
    Z = (X - mu) / sd
    weights = np.array([1.2, 1.2, 1.0, 0.8, 0.8, 1.0, 0.6])
    cur = Z[-1]
    cand = np.arange(warmup, n - hmax - 1)
    d = np.sqrt((((Z[cand] - cur) * weights) ** 2).sum(axis=1))
    order = cand[np.argsort(d)[:k]]
    c = _arr(cs, "close")
    res = {"n": int(len(order)), "history_bars": n, "similarity": _r(float(1 / (1 + np.mean(np.sort(d)[:k]))), 3),
           "horizons": {}, "matches": []}
    for h in horizons:
        fwd = c[order + h] / c[order] - 1
        allf = c[warmup + h: n] / c[warmup: n - h] - 1
        base = float((allf > 0).mean()) if len(allf) else 0.5
        p = float((fwd > 0).mean())
        # Wilson 80% interval to show how sure the estimate is
        z = 1.2816
        den = 1 + z * z / k
        centre = (p + z * z / (2 * k)) / den
        half = z * math.sqrt(p * (1 - p) / k + z * z / (4 * k * k)) / den
        res["horizons"][str(h)] = {"p_up": _r(p, 3), "base_rate": _r(base, 3), "edge": _r(p - base, 3),
                                   "median": _r(float(np.median(fwd)), 5), "p10": _r(float(np.percentile(fwd, 10)), 5),
                                   "p90": _r(float(np.percentile(fwd, 90)), 5),
                                   "ci_low": _r(centre - half, 3), "ci_high": _r(centre + half, 3)}
    for i in order[:5]:
        h = horizons[len(horizons) // 2]
        res["matches"].append({"t": int(cs[i].start), "price": _r(c[i], 6), "fwd": _r(float(c[i + h] / c[i] - 1), 5)})
    return res


def ewma_sigma(cs: list[Candle], lam: float = 0.94) -> float | None:
    if len(cs) < 30:
        return None
    r = np.diff(np.log(np.maximum(_arr(cs, "close"), 1e-12)))
    var = float(np.var(r[:20])) or 1e-8
    for x in r[20:]:
        var = lam * var + (1 - lam) * x * x
    return math.sqrt(var)


def cone(price: float, sigma_h: float, hours=(1, 4, 24)) -> list[dict]:
    out = []
    for h in hours:
        s = sigma_h * math.sqrt(h)
        out.append({"hours": h, "sigma": _r(s, 5),
                    "p68": [_r(price * math.exp(-s), 8), _r(price * math.exp(s), 8)],
                    "p95": [_r(price * math.exp(-2 * s), 8), _r(price * math.exp(2 * s), 8)]})
    return out


def target_odds(price: float, target: float, sigma_h: float, hours: float) -> dict:
    """Driftless log-normal model. Touch probability via the reflection principle."""
    s = sigma_h * math.sqrt(max(hours, 1e-6))
    if price <= 0 or target <= 0 or s <= 0:
        return {"touch": None, "close_beyond": None}
    x = math.log(target / price)
    beyond = 1 - _phi(abs(x) / s)
    return {"touch": _r(min(1.0, 2 * beyond), 4), "close_beyond": _r(beyond, 4),
            "move_pct": _r(x, 5), "sigmas": _r(abs(x) / s, 2)}


def seasonality(cs: list[Candle], tz: str = "UTC") -> dict | None:
    if len(cs) < 24 * 14:
        return None
    try:
        zone = ZoneInfo(tz)
    except Exception:
        zone = ZoneInfo("UTC")
    ret = np.zeros((7, 24))
    up = np.zeros((7, 24))
    vol = np.zeros((7, 24))
    cnt = np.zeros((7, 24))
    vols = _arr(cs, "volume")
    vmean = vols.mean() or 1.0
    for c in cs:
        if c.open <= 0:
            continue
        dt = datetime.fromtimestamp(c.start, zone)
        d, h = dt.weekday(), dt.hour
        r = c.close / c.open - 1
        ret[d, h] += r
        up[d, h] += r > 0
        vol[d, h] += c.volume / vmean
        cnt[d, h] += 1
    m = np.maximum(cnt, 1)
    avg, pup, vrel = ret / m, up / m, vol / m
    hour_avg = (ret.sum(0) / np.maximum(cnt.sum(0), 1))
    hour_up = (up.sum(0) / np.maximum(cnt.sum(0), 1))
    day_avg = (ret.sum(1) / np.maximum(cnt.sum(1), 1))
    now = datetime.now(zone)
    best = int(np.argmax(hour_avg))
    worst = int(np.argmin(hour_avg))
    busiest = int(np.argmax(vol.sum(0) / np.maximum(cnt.sum(0), 1)))
    return {"tz": str(zone), "weeks": round(len(cs) / 168, 1),
            "avg": [[_r(x, 5) for x in row] for row in avg],
            "p_up": [[_r(x, 3) for x in row] for row in pup],
            "vol": [[_r(x, 2) for x in row] for row in vrel],
            "count": cnt.astype(int).tolist(),
            "hour_avg": [_r(x, 5) for x in hour_avg], "hour_up": [_r(x, 3) for x in hour_up],
            "day_avg": [_r(x, 5) for x in day_avg],
            "best_hour": best, "worst_hour": worst, "busiest_hour": busiest,
            "best_day": WEEKDAYS[int(np.argmax(day_avg))], "worst_day": WEEKDAYS[int(np.argmin(day_avg))],
            "now": {"weekday": WEEKDAYS[now.weekday()], "hour": now.hour,
                    "avg": _r(avg[now.weekday(), now.hour], 5), "p_up": _r(pup[now.weekday(), now.hour], 3),
                    "vol": _r(vrel[now.weekday(), now.hour], 2), "n": int(cnt[now.weekday(), now.hour])}}


def trend_state(cs: list[Candle], label: str) -> dict | None:
    if len(cs) < 60:
        return None
    c = _arr(cs, "close")
    e20, e50 = ind.ema(c, 20), ind.ema(c, 50)
    slope = (e20[-1] / e20[-6] - 1) if e20[-6] else 0.0
    w = c[-21:]
    path = np.abs(np.diff(w)).sum()
    er = abs(w[-1] - w[0]) / path if path > 0 else 0.0
    lr = np.diff(np.log(np.maximum(c, 1e-12)))
    rv = ind.rolling_std(lr, 20)
    valid = rv[~np.isnan(rv)]
    vol_pct = float((valid <= valid[-1]).mean()) if len(valid) else 0.5
    direction = 1 if (c[-1] > e50[-1] and slope > 0) else -1 if (c[-1] < e50[-1] and slope < 0) else 0
    if vol_pct > 0.85 and er < 0.35:
        regime = "volatile"
    elif er >= 0.35 and direction != 0:
        regime = "trending up" if direction > 0 else "trending down"
    else:
        regime = "ranging"
    return {"tf": label, "direction": direction, "strength": _r(min(1.0, er * 1.6), 3), "slope": _r(slope, 5),
            "above_ema50": bool(c[-1] > e50[-1]), "efficiency": _r(er, 3), "vol_percentile": _r(vol_pct, 3),
            "regime": regime, "rsi": _r(float(np.nan_to_num(ind.rsi(c, 14)[-1], nan=50)), 1)}


# ============================================================================ main service
class Analytics:
    def __init__(self, engine, settings, simulated: bool = False):
        self.engine = engine
        self.s = settings
        self.simulated = simulated
        self.flow = FlowTracker()
        self.hourly: dict[str, CandleSeries] = {}
        self.trending: list[dict] = []
        self.trending_at = 0.0
        self._cache: dict[tuple, tuple[float, dict]] = {}
        self.status = {"hourly_backfill": "pending"}

    # -------------------------------------------------------------- inputs
    def hourly_series(self, symbol: str) -> CandleSeries:
        s = self.hourly.get(symbol)
        if s is None:
            s = self.hourly[symbol] = CandleSeries(symbol, 3600, maxlen=24 * 400)
        return s

    def on_trade(self, t: Trade) -> None:
        self.flow.on_trade(t)
        s = self.hourly_series(t.symbol)
        if self.simulated and not s.closed and s.current is None:
            self._seed_synthetic(t.symbol, t.price, t.ts)
        s.add_trade(t)

    def _seed_synthetic(self, symbol: str, price: float, ts: float, days: int = 370) -> None:
        """Demo mode only: realistic hourly history with mild time-of-day patterns."""
        rng = random.Random(hash(symbol) & 0xFFFF)
        n = days * 24
        sig = 0.006
        if symbol.startswith(("USDT", "USDC", "DAI")):
            sig = 0.0004
        start = int(ts // 3600) * 3600 - n * 3600
        hour_bias = {13: .0009, 14: .0012, 15: .0007, 20: -.0005, 2: -.0008, 3: -.0006}
        hour_vol = {13: 1.6, 14: 1.9, 15: 1.7, 16: 1.4, 1: .6, 2: .55, 3: .5, 4: .6}
        rets = []
        market = random.Random(start)          # shared "market factor": coins move together like real crypto
        beta = 0.0 if symbol.startswith(("USDT", "USDC", "DAI")) else rng.uniform(0.6, 1.3)
        for i in range(n):
            dt = datetime.fromtimestamp(start + i * 3600, timezone.utc)
            common = market.gauss(0, 0.007)
            rets.append(hour_bias.get(dt.hour, 0) + beta * common * 0.8
                        + rng.gauss(0, sig * 0.7 * hour_vol.get(dt.hour, 1) ** .5))
        p = price / math.exp(sum(rets))
        cs = []
        for i, r in enumerate(rets):
            dt = datetime.fromtimestamp(start + i * 3600, timezone.utc)
            o, c = p, p * math.exp(r)
            hi, lo = max(o, c) * (1 + abs(rng.gauss(0, sig / 3))), min(o, c) * (1 - abs(rng.gauss(0, sig / 3)))
            v = 1000 * hour_vol.get(dt.hour, 1) * (0.75 if dt.weekday() >= 5 else 1) * rng.lognormvariate(0, .35)
            cs.append(Candle(symbol, 3600, start + i * 3600, o, hi, lo, c, v, v / 2, int(v)))
            p = c
        self.hourly_series(symbol).seed(cs)

    async def backfill_hourly(self, symbols: list[str], pages: int | None = None) -> int:
        """Live mode: up to HOURLY_BACKFILL_DAYS (default 365) of 1h candles from Coinbase's public API (no key)."""
        pages = pages or max(1, int(getattr(self.s, "hourly_backfill_days", 365) * 24 / 300) + 1)
        loaded = 0
        fails = 0
        async with httpx.AsyncClient(timeout=20, headers={"User-Agent": "StrikePulse/1.1"}) as client:
            for sym in symbols:
                end = int(time.time() // 3600) * 3600
                rows: dict[float, Candle] = {}
                for _ in range(pages):
                    start = end - 300 * 3600
                    try:
                        r = await client.get(f"https://api.exchange.coinbase.com/products/{sym}/candles", params={
                            "granularity": 3600,
                            "start": datetime.fromtimestamp(start, timezone.utc).isoformat(),
                            "end": datetime.fromtimestamp(end, timezone.utc).isoformat()})
                        r.raise_for_status()
                        for t, lo, hi, o, c, v in r.json():
                            rows[float(t)] = Candle(sym, 3600, float(t), o, hi, lo, c, v, v / 2, 0)
                    except Exception as e:
                        fails += 1
                        log.warning("hourly backfill %s failed: %s", sym, e)
                        if fails >= 3 and loaded == 0:
                            self.status["hourly_backfill"] = f"unavailable: {e}"
                            return 0
                        break
                    end = start
                    await asyncio.sleep(0.35)
                now_bucket = int(time.time() // 3600) * 3600
                cs = [c for c in rows.values() if c.start < now_bucket]
                self.hourly_series(sym).seed(cs)
                loaded += len(cs)
        self.status["hourly_backfill"] = f"{loaded} candles"
        return loaded

    async def poll_trending(self) -> None:
        """Optional popularity signal from CoinGecko's free trending endpoint."""
        async with httpx.AsyncClient(timeout=15, headers={"User-Agent": "StrikePulse/1.1"}) as client:
            while True:
                try:
                    r = await client.get("https://api.coingecko.com/api/v3/search/trending")
                    r.raise_for_status()
                    coins = r.json().get("coins", [])
                    self.trending = [{"symbol": c["item"].get("symbol", "").upper(), "name": c["item"].get("name"),
                                      "rank": c["item"].get("market_cap_rank"), "score": c["item"].get("score")}
                                     for c in coins[:15]]
                    self.trending_at = time.time()
                    self.status["trending"] = "ok"
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    self.status["trending"] = f"unavailable: {str(e)[:80]}"
                await asyncio.sleep(900)

    # -------------------------------------------------------------- analysis pieces
    def candles(self, symbol: str, tf: int) -> list[Candle]:
        if tf == 3600:
            s = self.hourly.get(symbol)
            return s.history() if s else []
        s = self.engine.book.series.get((symbol, tf))
        return s.history() if s else []

    def odds(self, symbol: str) -> dict:
        out = {}
        h1 = self.candles(symbol, 3600)
        r = probability_engine(h1, (1, 4, 24)) if h1 else None
        if r:
            out["hourly"] = r
        m5 = self.candles(symbol, 300)
        r5 = probability_engine(m5, (3, 12), k=30) if m5 else None
        if r5:
            out["intraday"] = r5
        return out

    def sigma_hourly(self, symbol: str) -> float | None:
        h = self.candles(symbol, 3600)
        s = ewma_sigma(h[-500:]) if len(h) >= 30 else None
        if s is None:
            m = self.candles(symbol, 300)
            s5 = ewma_sigma(m[-300:]) if len(m) >= 30 else None
            s = s5 * math.sqrt(12) if s5 else None
        return s

    def trends(self, symbol: str) -> list[dict]:
        out = []
        for tf, label in ((60, "1m"), (300, "5m"), (900, "15m"), (3600, "1h")):
            st = trend_state(self.candles(symbol, tf), label)
            if st:
                out.append(st)
        return out

    def rotation(self) -> list[dict]:
        """Share of total dollar volume per coin: last hour vs the prior 24h average."""
        now = time.time()
        rows = []
        for sym in self.engine.book.symbols():
            if sym in self.engine.stable_symbols:
                continue
            m1 = self.candles(sym, 60)
            if not m1:
                continue
            last = [c for c in m1 if c.start >= now - 3600]
            prior = [c for c in m1 if now - 25 * 3600 <= c.start < now - 3600]
            usd_1h = sum(c.volume * c.close for c in last)
            hrs = max(1.0, len(prior) / 60)
            usd_prior = sum(c.volume * c.close for c in prior) / hrs
            tr_15 = sum(c.trades for c in m1 if c.start >= now - 900) / 15
            tr_prior = sum(c.trades for c in m1 if now - 7200 <= c.start < now - 900) / 105
            rows.append({"symbol": sym, "usd_1h": usd_1h, "usd_prior_hourly": usd_prior,
                         "trades_per_min": tr_15, "trades_prior": tr_prior})
        tot1 = sum(r["usd_1h"] for r in rows) or 1
        totp = sum(r["usd_prior_hourly"] for r in rows) or 1
        for r in rows:
            r["share"] = r["usd_1h"] / tot1
            r["share_prior"] = r["usd_prior_hourly"] / totp
            r["share_change"] = r["share"] - r["share_prior"]
            r["rel_volume"] = r["usd_1h"] / r["usd_prior_hourly"] if r["usd_prior_hourly"] else None
            r["heat"] = r["trades_per_min"] / r["trades_prior"] if r["trades_prior"] else None
            r["trending"] = any(t["symbol"] == r["symbol"].split("-")[0] for t in self.trending)
        rows.sort(key=lambda r: -r["share"])
        for i, r in enumerate(rows):
            r["rank"] = i + 1
            for k in ("usd_1h", "usd_prior_hourly", "trades_per_min", "trades_prior"):
                r[k] = _r(r[k], 2)
            for k in ("share", "share_prior", "share_change", "rel_volume", "heat"):
                r[k] = _r(r[k], 4)
        return rows

    def shifts(self, symbol: str, flow_now: dict, flow_prev: dict, rot: list[dict], season: dict | None,
               odds: dict) -> list[dict]:
        out = []
        bs, pbs = flow_now.get("buy_share"), flow_prev.get("buy_share")
        if bs is not None and pbs is not None and abs(bs - pbs) >= 0.05:
            out.append({"dir": 1 if bs > pbs else -1,
                        "text": f"Buy share {'jumped' if bs > pbs else 'dropped'} from {pbs * 100:.0f}% to {bs * 100:.0f}% "
                                f"vs the previous 30 minutes ({(bs - pbs) * 100:+.0f} pts)"})
        wn, rn = flow_now.get("whale_net") or 0, flow_now.get("retail_net") or 0
        if abs(wn) > 0:
            out.append({"dir": 1 if wn > 0 else -1,
                        "text": f"Whales net {'bought' if wn > 0 else 'sold'} ${abs(wn):,.0f} in the last 30 min"})
        if wn and rn and (wn > 0) != (rn > 0):
            out.append({"dir": 1 if wn > 0 else -1,
                        "text": f"Divergence: big traders are {'buying' if wn > 0 else 'selling'} while small traders "
                                f"{'sell' if wn > 0 else 'buy'}. Historically the big side tends to lead"})
        me = next((r for r in rot if r["symbol"] == symbol), None)
        if me:
            if me.get("rel_volume") and me["rel_volume"] >= 1.5:
                out.append({"dir": 0, "text": f"Dollar volume is {me['rel_volume']:.1f}x its usual hourly pace"})
            if me.get("share_change") and abs(me["share_change"]) >= 0.02:
                out.append({"dir": 1 if me["share_change"] > 0 else -1,
                            "text": f"{'Gaining' if me['share_change'] > 0 else 'Losing'} attention: "
                                    f"{me['share'] * 100:.1f}% of tracked market volume vs {me['share_prior'] * 100:.1f}% normally "
                                    f"(rank #{me['rank']})"})
            if me.get("heat") and me["heat"] >= 1.8:
                out.append({"dir": 0, "text": f"Trade count running {me['heat']:.1f}x faster than the last 2 hours"})
            if me.get("trending"):
                out.append({"dir": 0, "text": "On CoinGecko's trending list right now"})
        if season and season["now"]["n"] >= 4:
            p = season["now"]["p_up"]
            if p is not None and abs(p - 0.5) >= 0.1:
                out.append({"dir": 1 if p > 0.5 else -1,
                            "text": f"Timing: {FULL_DAYS[WEEKDAYS.index(season['now']['weekday'])]}s at {season['now']['hour']:02d}:00 closed higher "
                                    f"{p * 100:.0f}% of the time ({season['now']['n']} samples)"})
        h = (odds.get("hourly") or {}).get("horizons", {}).get("4")
        if h and h["edge"] is not None and abs(h["edge"]) >= 0.08:
            out.append({"dir": 1 if h["edge"] > 0 else -1,
                        "text": f"Odds: {h['p_up'] * 100:.0f}% of the {odds['hourly']['n']} most similar past setups were "
                                f"higher 4h later (normal: {h['base_rate'] * 100:.0f}%)"})
        return out

    def pulse(self, trends: list[dict], flow_now: dict, odds: dict, season: dict | None) -> dict:
        parts = []
        if trends:
            t = sum(x["direction"] * (0.5 + x["strength"]) for x in trends) / (1.5 * len(trends))
            parts.append(("Trend alignment", t, 0.35))
        if flow_now.get("buy_share") is not None:
            f = (flow_now["buy_share"] - 0.5) * 4
            parts.append(("Buy/sell pressure", max(-1, min(1, f)), 0.25))
        if flow_now.get("whale_buy_share") is not None:
            w = (flow_now["whale_buy_share"] - 0.5) * 4
            parts.append(("Whale flow", max(-1, min(1, w)), 0.15))
        h = (odds.get("hourly") or {}).get("horizons", {}).get("4")
        if h and h["edge"] is not None:
            parts.append(("Historical odds", max(-1, min(1, h["edge"] * 5)), 0.2))
        if season and season["now"]["p_up"] is not None and season["now"]["n"] >= 4:
            parts.append(("Time-of-day pattern", max(-1, min(1, (season["now"]["p_up"] - 0.5) * 4)), 0.05))
        if not parts:
            return {"score": None, "label": "Gathering data", "parts": []}
        wsum = sum(w for _, _, w in parts)
        raw = sum(v * w for _, v, w in parts) / wsum
        score = int(round(50 + 50 * raw))
        label = ("Strongly bullish conditions" if score >= 75 else "Bullish lean" if score >= 58 else
                 "Strongly bearish conditions" if score <= 25 else "Bearish lean" if score <= 42 else "Neutral / mixed")
        return {"score": score, "label": label,
                "parts": [{"name": n, "value": _r(v, 3), "weight": w} for n, v, w in parts]}

    # -------------------------------------------------------------- public
    def full(self, symbol: str, tz: str = "UTC") -> dict:
        key = (symbol, tz)
        hit = self._cache.get(key)
        if hit and time.time() - hit[0] < 15:
            return hit[1]
        price = self.engine.prices.get(symbol, {}).get("price")
        sigma = self.sigma_hourly(symbol)
        flow_now = self.flow.window(symbol, 30)
        flow_prev = self.flow.window(symbol, 30, offset=30)
        odds = self.odds(symbol)
        season = seasonality(self.candles(symbol, 3600), tz)
        trends = self.trends(symbol)
        rot = self.rotation()
        data = {
            "symbol": symbol, "price": price, "ts": time.time(), "simulated": self.simulated,
            "pulse": self.pulse(trends, flow_now, odds, season),
            "odds": odds,
            "sigma_hourly": _r(sigma, 6),
            "cone": cone(price, sigma) if price and sigma else [],
            "flow": {"m30": flow_now, "prev30": flow_prev, "h1": self.flow.window(symbol, 60),
                     "h4": self.flow.window(symbol, 240), "h24": self.flow.window(symbol, 1440),
                     "series": self.flow.series(symbol, 240)},
            "season": season, "trends": trends, "rotation": rot,
            "trending": self.trending, "shifts": self.shifts(symbol, flow_now, flow_prev, rot, season, odds),
            "hourly_candles": [c.to_dict() for c in self.candles(symbol, 3600)[-168:]],
        }
        self._cache[key] = (time.time(), data)
        return data

    def enrich(self, e: MarketEvent) -> None:
        """Add historical odds to market alerts, e.g. '64% of 40 similar setups were higher 4h later'."""
        if e.kind != "market" or not e.direction:
            return
        try:
            r = probability_engine(self.candles(e.symbol, 3600), (1, 4, 24))
        except Exception:
            log.exception("odds enrichment failed")
            return
        if not r:
            return
        h = r["horizons"]["4"]
        p = h["p_up"] if e.direction > 0 else 1 - h["p_up"]
        base = h["base_rate"] if e.direction > 0 else 1 - h["base_rate"]
        word = "higher" if e.direction > 0 else "lower"
        e.reasons.append(f"Historical odds: {p * 100:.0f}% of {r['n']} similar setups were {word} 4h later (normal {base * 100:.0f}%)")
        e.meta["odds"] = {"p": round(p, 3), "base": round(base, 3), "n": r["n"], "horizon_h": 4,
                          "median": h["median"], "p10": h["p10"], "p90": h["p90"]}
