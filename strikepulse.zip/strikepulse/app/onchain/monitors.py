"""Stablecoin de-peg monitor and new-listing poller."""
from __future__ import annotations

import asyncio
import logging
from typing import Callable

import httpx

from ..engine.types import MarketEvent

log = logging.getLogger(__name__)


class DepegMonitor:
    """Watches stablecoin prices. Alerts when a stable stays off $1.00 by more than
    `threshold` for `confirm` seconds, and again when it recovers."""

    def __init__(self, stables: list[str], publish: Callable[[MarketEvent], None],
                 threshold: float = 0.005, confirm: float = 60, recover: float = 180):
        self.stables = set(stables)
        self.publish = publish
        self.threshold, self.confirm, self.recover = threshold, confirm, recover
        self.state: dict[str, dict] = {}

    def on_price(self, symbol: str, price: float, ts: float) -> None:
        if symbol not in self.stables or price <= 0:
            return
        st = self.state.setdefault(symbol, {"off_since": None, "alerted": False, "ok_since": None, "worst": 1.0})
        dev = price - 1.0
        if abs(dev) >= self.threshold:
            st["ok_since"] = None
            st["off_since"] = st["off_since"] or ts
            if abs(dev) > abs(st["worst"] - 1.0):
                st["worst"] = price
            if not st["alerted"] and ts - st["off_since"] >= self.confirm:
                st["alerted"] = True
                score = int(min(100, 70 + abs(dev) * 3000))
                self.publish(MarketEvent(
                    kind="depeg", symbol=symbol, title=f"{symbol.split('-')[0]} de-peg: ${price:.4f}",
                    direction=-1, score=score, price=price,
                    reasons=[f"Trading {dev * 100:+.2f}% from $1.00 for over {int(self.confirm)}s",
                             "Consider your exposure: de-pegs can cascade through DeFi"],
                    meta={"deviation": dev}, ts=ts))
        else:
            if st["alerted"] and abs(dev) < self.threshold / 2:
                st["ok_since"] = st["ok_since"] or ts
                if ts - st["ok_since"] >= self.recover:
                    self.publish(MarketEvent(
                        kind="depeg", symbol=symbol, title=f"{symbol.split('-')[0]} re-pegged at ${price:.4f}",
                        direction=1, score=50, price=price,
                        reasons=[f"Back within {self.threshold / 2 * 100:.2f}% of $1.00 (worst ${st['worst']:.4f})"],
                        meta={"recovered": True, "worst": st["worst"]}, ts=ts))
                    st.update(off_since=None, alerted=False, ok_since=None, worst=1.0)
            elif not st["alerted"]:
                st["off_since"] = None


class ListingWatcher:
    """Polls exchanges' public product lists and alerts on newly listed markets."""

    def __init__(self, publish: Callable[[MarketEvent], None], load: Callable[[str], set | None],
                 save: Callable[[str, set], None], interval: int = 600, status: dict | None = None):
        self.publish, self.load, self.save, self.interval = publish, load, save, interval
        self.status = status if status is not None else {}

    @staticmethod
    async def fetch_coinbase(client: httpx.AsyncClient) -> set[str]:
        r = await client.get("https://api.exchange.coinbase.com/products")
        r.raise_for_status()
        return {p["id"] for p in r.json() if p.get("status") == "online" and not p.get("trading_disabled")}

    @staticmethod
    async def fetch_kraken(client: httpx.AsyncClient) -> set[str]:
        r = await client.get("https://api.kraken.com/0/public/AssetPairs")
        r.raise_for_status()
        res = r.json().get("result", {})
        return {v["wsname"].replace("/", "-").replace("XBT", "BTC") for v in res.values()
                if v.get("wsname") and v.get("status", "online") == "online"}

    def diff(self, exchange: str, current: set[str]) -> list[MarketEvent]:
        known = self.load(exchange)
        self.save(exchange, current)
        if known is None:          # first run: just remember what exists
            return []
        events = []
        for sym in sorted(current - known):
            events.append(MarketEvent(
                kind="listing", symbol=sym, title=f"New listing: {sym} on {exchange.title()}",
                direction=1, score=70,
                reasons=[f"{sym} just appeared on {exchange.title()}'s market list",
                         "New listings often see sharp, volatile moves; size positions carefully"],
                meta={"exchange": exchange}))
        return events

    async def run(self) -> None:
        async with httpx.AsyncClient(timeout=20, headers={"User-Agent": "StrikePulse/1.0"}) as client:
            while True:
                for name, fn in (("coinbase", self.fetch_coinbase), ("kraken", self.fetch_kraken)):
                    try:
                        current = await fn(client)
                        if current:
                            for e in await asyncio.to_thread(self.diff, name, current):
                                self.publish(e)
                        self.status[name] = {"ok": True, "markets": len(current)}
                    except asyncio.CancelledError:
                        raise
                    except Exception as e:
                        self.status[name] = {"ok": False, "error": str(e)[:200]}
                        log.warning("listing poll %s failed: %s", name, e)
                await asyncio.sleep(self.interval)
