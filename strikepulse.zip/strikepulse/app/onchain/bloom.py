"""Bloom filter: a compact, very fast "is this address possibly in my set?" check.

Used as a pre-filter on the firehose of on-chain transfers: thousands of exchange,
whale and flagged addresses can be checked in microseconds. A "no" is always right;
a "maybe" is confirmed against the exact set (false-positive rate is configurable).
"""
from __future__ import annotations

import hashlib
import math
from typing import Iterable


class BloomFilter:
    def __init__(self, capacity: int = 100_000, error_rate: float = 0.001):
        if capacity <= 0 or not 0 < error_rate < 1:
            raise ValueError("capacity > 0 and 0 < error_rate < 1 required")
        self.capacity = capacity
        self.error_rate = error_rate
        self.m = max(8, int(math.ceil(-capacity * math.log(error_rate) / (math.log(2) ** 2))))
        self.k = max(1, int(round(self.m / capacity * math.log(2))))
        self.bits = bytearray((self.m + 7) // 8)
        self.count = 0

    @staticmethod
    def _norm(item: str) -> bytes:
        return item.strip().lower().encode()

    def _positions(self, item: str):
        d = hashlib.blake2b(self._norm(item), digest_size=16).digest()
        h1 = int.from_bytes(d[:8], "little")
        h2 = int.from_bytes(d[8:], "little") | 1
        for i in range(self.k):
            yield (h1 + i * h2) % self.m

    def add(self, item: str) -> None:
        for p in self._positions(item):
            self.bits[p >> 3] |= 1 << (p & 7)
        self.count += 1

    def update(self, items: Iterable[str]) -> None:
        for it in items:
            self.add(it)

    def __contains__(self, item: str) -> bool:
        return all(self.bits[p >> 3] & (1 << (p & 7)) for p in self._positions(item))

    def __len__(self) -> int:
        return self.count

    @property
    def expected_fp_rate(self) -> float:
        return (1 - math.exp(-self.k * self.count / self.m)) ** self.k


class AddressSet:
    """Bloom filter + exact dict: fast negative checks, exact positive answers with labels."""

    def __init__(self, capacity: int = 50_000, error_rate: float = 0.001):
        self.bloom = BloomFilter(capacity, error_rate)
        self.labels: dict[str, str] = {}
        self.bloom_hits = 0
        self.false_positives = 0

    def add(self, address: str, label: str = "") -> None:
        a = address.strip().lower()
        if not a:
            return
        self.bloom.add(a)
        self.labels[a] = label or self.labels.get(a, "")

    def get(self, address: str) -> str | None:
        a = address.lower()
        if a not in self.bloom:
            return None
        self.bloom_hits += 1
        if a in self.labels:
            return self.labels[a]
        self.false_positives += 1
        return None

    def __contains__(self, address: str) -> bool:
        return self.get(address) is not None

    def __len__(self) -> int:
        return len(self.labels)
