"""Ethereum on-chain watcher (any JSON-RPC WebSocket: Alchemy, Infura, QuickNode, own node).

Subscriptions:
  * newHeads           -> gas price alerts
  * logs on tokens     -> whale transfers to/from exchanges, mints, flagged-address contact
  * logs on wallets    -> any ERC-20 movement by wallets users follow
  * logs on LP pairs   -> liquidity removal (rug-pull warning)
  * OwnershipTransferred on watched tokens -> contract control changes
"""
from __future__ import annotations

import asyncio
import csv
import json
import logging
import time
from pathlib import Path
from typing import Callable

import websockets

from ..engine.types import MarketEvent
from .bloom import AddressSet

log = logging.getLogger(__name__)

TRANSFER = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
UNIV2_BURN = "0xdccd412f0b1252819cb1fd330b93224ca42612892bb3f4f789976e6d81936496"
OWNERSHIP = "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"
ZERO = "0x" + "0" * 40
GAS_THRESHOLDS = [2, 3, 5, 10, 20, 50]
DATA = Path(__file__).resolve().parents[2] / "data"


def topic_to_address(topic: str) -> str:
    return "0x" + topic[-40:].lower()


def address_to_topic(addr: str) -> str:
    return "0x" + addr.lower().replace("0x", "").rjust(64, "0")


def short(addr: str) -> str:
    return f"{addr[:6]}…{addr[-4:]}"


def load_csv_addresses(path: Path, target: AddressSet) -> None:
    if not path.exists():
        return
    with path.open() as f:
        for row in csv.reader(line for line in f if line.strip() and not line.lstrip().startswith("#")):
            if row and row[0].startswith("0x"):
                target.add(row[0], row[1].strip() if len(row) > 1 else "")


class Registry:
    """Everything the watcher needs to know. `user_loader` returns the users' watches:
    {"wallets": {addr: label}, "tokens": {addr: label}, "pairs": {addr: label}}"""

    def __init__(self, user_loader: Callable[[], dict] | None = None):
        self.tokens: dict[str, dict] = {}
        tok_file = DATA / "tokens.json"
        if tok_file.exists():
            self.tokens = {k.lower(): v for k, v in json.loads(tok_file.read_text()).items()}
        self.exchanges = AddressSet()
        load_csv_addresses(DATA / "exchange_wallets.csv", self.exchanges)
        self.flagged = AddressSet()
        load_csv_addresses(DATA / "flagged_addresses.csv", self.flagged)
        self.user_loader = user_loader
        self.wallets = AddressSet(capacity=20_000)
        self.user_tokens: dict[str, str] = {}
        self.pairs: dict[str, str] = {}
        self.version = 0

    def refresh(self) -> bool:
        """Reload user watches. Returns True when the subscription set changed."""
        if not self.user_loader:
            return False
        data = self.user_loader() or {}
        wallets = {k.lower(): v for k, v in data.get("wallets", {}).items()}
        tokens = {k.lower(): v for k, v in data.get("tokens", {}).items()}
        pairs = {k.lower(): v for k, v in data.get("pairs", {}).items()}
        changed = (set(wallets) != set(self.wallets.labels) or set(tokens) != set(self.user_tokens)
                   or set(pairs) != set(self.pairs))
        if changed:
            ws = AddressSet(capacity=max(20_000, len(wallets) * 2))
            for a, label in wallets.items():
                ws.add(a, label)
            self.wallets, self.user_tokens, self.pairs = ws, tokens, pairs
            self.version += 1
        return changed

    def token_addresses(self) -> list[str]:
        return sorted(set(self.tokens) | set(self.user_tokens))


class EthWatcher:
    name = "ethereum"

    def __init__(self, ws_url: str, registry: Registry, publish: Callable[[MarketEvent], None],
                 price_of: Callable[[str], float | None], whale_min_usd: float = 1_000_000,
                 status: dict | None = None):
        self.ws_url = ws_url
        self.reg = registry
        self.publish = publish
        self.price_of = price_of
        self.whale_min_usd = whale_min_usd
        self.status = status if status is not None else {}
        self.status.setdefault("connected", False)
        self.status.setdefault("messages", 0)
        self.status.setdefault("errors", 0)
        self.gas_gwei: float | None = None
        self._last_gas_band: int | None = None
        self._subs: dict[str, str] = {}
        self._seen: dict[str, float] = {}

    # ----------------------------------------------------------------- decoding
    def usd_value(self, token: str, raw_amount: int) -> tuple[float, float | None, dict]:
        info = self.reg.tokens.get(token, {})
        dec = int(info.get("decimals", 18))
        amount = raw_amount / (10 ** dec)
        if info.get("stable"):
            px = self.price_of(info.get("price_symbol", "")) or 1.0
        else:
            px = self.price_of(info.get("price_symbol", "")) if info.get("price_symbol") else None
        return amount, (amount * px if px else None), info

    def handle_log(self, lg: dict) -> list[MarketEvent]:
        topics = [t.lower() for t in lg.get("topics", [])]
        if not topics:
            return []
        key = f"{lg.get('transactionHash')}:{lg.get('logIndex')}"
        if key in self._seen:
            return []  # same log can arrive on several subscriptions
        self._seen[key] = time.time()
        if len(self._seen) > 50_000:
            cutoff = time.time() - 600
            self._seen = {k: v for k, v in self._seen.items() if v > cutoff}

        contract = lg.get("address", "").lower()
        tx = lg.get("transactionHash", "")
        t0 = topics[0]
        if t0 == TRANSFER and len(topics) == 3:
            return self._transfer(contract, topic_to_address(topics[1]), topic_to_address(topics[2]),
                                  int(lg.get("data", "0x0") or "0x0", 16), tx)
        if t0 == UNIV2_BURN and contract in self.reg.pairs:
            data = (lg.get("data") or "0x")[2:]
            a0 = int(data[:64] or "0", 16)
            a1 = int(data[64:128] or "0", 16)
            label = self.reg.pairs[contract] or short(contract)
            return [MarketEvent(kind="security", symbol=label, title=f"Liquidity removed from {label}",
                                direction=-1, score=85,
                                reasons=["Uniswap-V2-style Burn: LP tokens redeemed for the underlying assets",
                                         f"amount0={a0}, amount1={a1} (raw units)",
                                         "Large or repeated removals can precede a rug pull"],
                                meta={"addresses": [contract], "tx": tx, "pair": contract})]
        if t0 == OWNERSHIP and len(topics) >= 3 and (contract in self.reg.user_tokens or contract in self.reg.tokens):
            new_owner = topic_to_address(topics[2])
            label = self.reg.user_tokens.get(contract) or self.reg.tokens.get(contract, {}).get("symbol") or short(contract)
            renounced = new_owner == ZERO
            return [MarketEvent(kind="security", symbol=label,
                                title=f"{label} ownership {'renounced' if renounced else 'transferred'}",
                                direction=0 if renounced else -1, score=60 if renounced else 88,
                                reasons=[f"Previous owner {short(topic_to_address(topics[1]))}",
                                         "Owner set to the zero address (no admin control)" if renounced
                                         else f"New owner {short(new_owner)}: verify this was planned"],
                                meta={"addresses": [contract, new_owner], "tx": tx, "token": contract})]
        return []

    def _transfer(self, token: str, frm: str, to: str, raw: int, tx: str) -> list[MarketEvent]:
        amount, usd, info = self.usd_value(token, raw)
        sym = info.get("symbol") or self.reg.user_tokens.get(token) or short(token)
        usd_s = f"${usd:,.0f}" if usd is not None else f"{amount:,.4f} {sym}"
        out: list[MarketEvent] = []
        base_meta = {"tx": tx, "token": token, "from": frm, "to": to, "amount": amount, "usd": usd}

        flagged = self.reg.flagged.get(frm) or self.reg.flagged.get(to)
        if flagged is not None:
            out.append(MarketEvent(kind="security", symbol=sym, title=f"{sym} moved with a flagged address",
                                   direction=-1, score=95,
                                   reasons=[f"{usd_s} {short(frm)} → {short(to)}", f"Flagged: {flagged or 'listed address'}"],
                                   meta={**base_meta, "addresses": [token, frm, to]}))

        if frm == ZERO and token in self.reg.user_tokens:
            out.append(MarketEvent(kind="security", symbol=sym, title=f"New {sym} tokens minted",
                                   direction=-1, score=70,
                                   reasons=[f"{amount:,.2f} {sym} minted to {short(to)} ({usd_s})",
                                            "Unexpected minting dilutes holders"],
                                   meta={**base_meta, "addresses": [token, to]}))

        fw, tw = self.reg.wallets.get(frm), self.reg.wallets.get(to)
        if fw is not None or tw is not None:
            who = fw if fw is not None else tw
            verb = "sent" if fw is not None else "received"
            out.append(MarketEvent(kind="onchain", symbol=sym,
                                   title=f"Watched wallet {who or short(frm if fw is not None else to)} {verb} {sym}",
                                   direction=-1 if (fw is not None and self.reg.exchanges.get(to) is not None) else 0,
                                   score=65, reasons=[f"{usd_s} {short(frm)} → {short(to)}"],
                                   meta={**base_meta, "addresses": [a for a in (frm, to) if self.reg.wallets.get(a) is not None] + [token]}))

        if usd is not None and usd >= self.whale_min_usd and not info.get("stable_ignore"):
            ex_to, ex_from = self.reg.exchanges.get(to), self.reg.exchanges.get(frm)
            if ex_to is not None and ex_from is None:
                out.append(MarketEvent(kind="onchain", symbol=info.get("price_symbol") or sym,
                                       title=f"Whale deposit: {usd_s} {sym} → {ex_to}", direction=-1 if not info.get("stable") else 1,
                                       score=min(95, 60 + int(usd / self.whale_min_usd) * 5),
                                       reasons=[f"{short(frm)} sent {amount:,.2f} {sym} to {ex_to}",
                                                "Coins moving onto an exchange often precede selling" if not info.get("stable")
                                                else "Stablecoins moving onto an exchange often precede buying"],
                                       meta={**base_meta, "addresses": [token, frm], "pattern": "exchange_inflow"}))
            elif ex_from is not None and ex_to is None:
                out.append(MarketEvent(kind="onchain", symbol=info.get("price_symbol") or sym,
                                       title=f"Whale withdrawal: {usd_s} {sym} ← {ex_from}", direction=1 if not info.get("stable") else 0,
                                       score=min(90, 55 + int(usd / self.whale_min_usd) * 5),
                                       reasons=[f"{amount:,.2f} {sym} withdrawn from {ex_from} to {short(to)}",
                                                "Coins leaving exchanges are usually moved to long-term storage"],
                                       meta={**base_meta, "addresses": [token, to], "pattern": "exchange_outflow"}))
        return out

    def handle_head(self, head: dict) -> list[MarketEvent]:
        fee = head.get("baseFeePerGas")
        if not fee:
            return []
        gwei = int(fee, 16) / 1e9
        self.gas_gwei = gwei
        band = next((t for t in GAS_THRESHOLDS if gwei <= t), None)
        prev, self._last_gas_band = self._last_gas_band, band
        if band is None or prev == band or (prev is not None and band > prev):
            return []
        return [MarketEvent(kind="gas", symbol="ETH-GAS", title=f"Ethereum gas under {band} gwei ({gwei:.1f})",
                            score=50, reasons=[f"Base fee {gwei:.2f} gwei at block {int(head.get('number', '0x0'), 16)}",
                                               "Good time to move funds or interact with contracts"],
                            meta={"gwei": gwei, "threshold": band})]

    # ----------------------------------------------------------------- network
    async def _sub(self, ws, rid: int, params: list) -> None:
        await ws.send(json.dumps({"jsonrpc": "2.0", "id": rid, "method": "eth_subscribe", "params": params}))

    async def run(self) -> None:
        backoff = 2.0
        while True:
            try:
                self.reg.refresh()
                version = self.reg.version
                async with websockets.connect(self.ws_url, ping_interval=30, max_size=2 ** 24, open_timeout=20) as ws:
                    self.status["connected"] = True
                    pending: dict[int, str] = {1: "heads"}
                    await self._sub(ws, 1, ["newHeads"])
                    tokens = self.reg.token_addresses()
                    rid = 2
                    if tokens:
                        pending[rid] = "tokens"
                        await self._sub(ws, rid, ["logs", {"address": tokens, "topics": [[TRANSFER, OWNERSHIP]]}])
                        rid += 1
                    if self.reg.pairs:
                        pending[rid] = "pairs"
                        await self._sub(ws, rid, ["logs", {"address": sorted(self.reg.pairs), "topics": [UNIV2_BURN]}])
                        rid += 1
                    wallets = [address_to_topic(a) for a in self.reg.wallets.labels]
                    if wallets:
                        pending[rid] = "wallets_out"
                        await self._sub(ws, rid, ["logs", {"topics": [TRANSFER, wallets]}])
                        pending[rid + 1] = "wallets_in"
                        await self._sub(ws, rid + 1, ["logs", {"topics": [TRANSFER, None, wallets]}])
                    backoff = 2.0
                    last_refresh = time.time()
                    while True:
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=30)
                        except asyncio.TimeoutError:
                            raw = None
                        if time.time() - last_refresh > 60:
                            last_refresh = time.time()
                            if await asyncio.to_thread(self.reg.refresh) or self.reg.version != version:
                                log.info("on-chain watch list changed; resubscribing")
                                break
                        if raw is None:
                            continue
                        msg = json.loads(raw)
                        self.status["messages"] += 1
                        self.status["last_message"] = time.time()
                        if "id" in msg and msg.get("id") in pending:
                            if "result" in msg:
                                self._subs[msg["result"]] = pending[msg["id"]]
                            else:
                                self.status["last_error"] = str(msg.get("error"))[:300]
                            continue
                        params = msg.get("params") or {}
                        kind = self._subs.get(params.get("subscription"))
                        result = params.get("result") or {}
                        events = self.handle_head(result) if kind == "heads" else self.handle_log(result)
                        for e in events:
                            self.publish(e)
            except asyncio.CancelledError:
                self.status["connected"] = False
                raise
            except Exception as e:
                self.status["errors"] += 1
                self.status["last_error"] = f"{type(e).__name__}: {e}"[:300]
                log.warning("ethereum watcher error: %s", e)
            self.status["connected"] = False
            await asyncio.sleep(backoff)
            backoff = min(60.0, backoff * 2)
