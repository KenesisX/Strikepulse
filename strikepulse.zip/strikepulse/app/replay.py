"""Replay / backtest: run the detectors over historical candles and measure how alerts
performed afterwards. Use it to tune GLOBAL_MIN_SCORE, detector weights and thresholds.

Examples
  python -m app.replay --synthetic --days 3 --symbol BTC-USD
  python -m app.replay --coinbase --symbol ETH-USD --tf 300 --pages 10
  python -m app.replay --csv my_candles.csv --symbol SOL-USD --tf 900 --out results.json

CSV format (header required): time,open,high,low,close,volume[,buy_volume]
  time = unix seconds or ISO-8601
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import json
import math
import random
import statistics
import sys
import time
from collections import defaultdict

from .engine.scoring import SignalPipeline
from .engine.types import Candle, MarketEvent
from .feeds.base import parse_iso


def load_csv(path: str, symbol: str, tf: int) -> list[Candle]:
    out = []
    with open(path) as f:
        for row in csv.DictReader(f):
            t = row.get("time") or row.get("timestamp") or row.get("t")
            ts = float(t) if t and t.replace(".", "", 1).isdigit() else parse_iso(t)
            if ts > 1e12:
                ts /= 1000
            v = float(row.get("volume", 0) or 0)
            out.append(Candle(symbol, tf, ts, float(row["open"]), float(row["high"]), float(row["low"]),
                              float(row["close"]), v, float(row.get("buy_volume") or v / 2), int(float(row.get("trades", 0) or 0))))
    return sorted(out, key=lambda c: c.start)


async def load_coinbase(symbol: str, tf: int, pages: int) -> list[Candle]:
    import httpx
    out: dict[float, Candle] = {}
    end = int(time.time() // tf * tf)
    async with httpx.AsyncClient(timeout=20, headers={"User-Agent": "StrikePulse-replay/1.0"}) as client:
        for _ in range(pages):
            start = end - 300 * tf
            r = await client.get(f"https://api.exchange.coinbase.com/products/{symbol}/candles",
                                 params={"granularity": tf, "start": start, "end": end})
            r.raise_for_status()
            for t, l, h, o, c, v in r.json():
                out[float(t)] = Candle(symbol, tf, float(t), o, h, l, c, v, v / 2, 0)
            end = start
            await asyncio.sleep(0.35)
    return sorted(out.values(), key=lambda c: c.start)


def synthetic(symbol: str, tf: int, days: float, seed: int = 11) -> list[Candle]:
    """Regime-switching candles (same generator idea as the live simulator)."""
    rng = random.Random(seed)
    n = int(days * 86400 / tf)
    price, out = 100.0, []
    regime, left = "calm", 0
    params = {"calm": (0, 1, 1, .5), "up": (.25, 1.2, 1.4, .56), "down": (-.25, 1.2, 1.4, .44),
              "pump": (1.5, 2.6, 4, .72), "dump": (-1.5, 2.6, 4, .28)}
    sig = 0.0022 * math.sqrt(tf / 60)
    t0 = time.time() - n * tf
    for i in range(n):
        if left <= 0:
            regime = rng.choices(list(params), [40, 22, 22, 8, 8])[0]
            left = rng.randint(4, 30) if regime in ("pump", "dump") else rng.randint(20, 120)
        left -= 1
        drift, volx, sizex, buyp = params[regime]
        o = price
        price *= math.exp(drift * sig * 0.5 + sig * volx * rng.gauss(0, 1))
        hi = max(o, price) * (1 + abs(rng.gauss(0, sig * .4)))
        lo = min(o, price) * (1 - abs(rng.gauss(0, sig * .4)))
        v = 100 * sizex * rng.lognormvariate(0, .5)
        out.append(Candle(symbol, tf, t0 + i * tf, o, hi, lo, price, v, v * min(.95, max(.05, rng.gauss(buyp, .08))), int(v)))
    return out


def run(candles: list[Candle], min_score: int, horizons: list[int]) -> dict:
    pipe = SignalPipeline(min_score=min_score)
    events: list[tuple[int, MarketEvent]] = []
    hist: list[Candle] = []
    for i, c in enumerate(candles):
        hist.append(c)
        if len(hist) > 600:
            hist.pop(0)
        e = pipe.on_candle(c, hist)
        if e:
            events.append((i, e))

    def fwd(i: int, h: int) -> float | None:
        if i + h >= len(candles):
            return None
        return candles[i + h].close / candles[i].close - 1

    rows = []
    for i, e in events:
        r = {"ts": e.ts, "score": e.score, "direction": e.direction, "pattern": e.meta.get("pattern"),
             "detectors": e.detectors, "price": e.price}
        for h in horizons:
            f = fwd(i, h)
            r[f"ret_{h}"] = f
            r[f"hit_{h}"] = None if f is None else (f * e.direction > 0)
        rows.append(r)

    def summarize(subset: list[dict]) -> dict:
        s = {"alerts": len(subset)}
        for h in horizons:
            vals = [x for x in subset if x[f"hit_{h}"] is not None]
            if vals:
                s[f"hit_rate_{h}"] = round(sum(x[f"hit_{h}"] for x in vals) / len(vals), 3)
                s[f"avg_dir_ret_{h}"] = round(statistics.mean(x[f"ret_{h}"] * x["direction"] for x in vals) * 100, 3)
        return s

    by_bucket = {}
    for lo in (40, 60, 80):
        sub = [r for r in rows if lo <= r["score"] < lo + 20 or (lo == 80 and r["score"] == 100)]
        by_bucket[f"{lo}-{lo + 19 if lo < 80 else 100}"] = summarize(sub)
    by_det = defaultdict(list)
    for r in rows:
        for d in r["detectors"]:
            by_det[d].append(r)
    return {"candles": len(candles), "overall": summarize(rows), "by_score": by_bucket,
            "by_detector": {k: summarize(v) for k, v in sorted(by_det.items())}, "alerts": rows}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Backtest StrikePulse detectors")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--csv")
    src.add_argument("--coinbase", action="store_true")
    src.add_argument("--synthetic", action="store_true")
    ap.add_argument("--symbol", default="BTC-USD")
    ap.add_argument("--tf", type=int, default=300, help="timeframe seconds (60, 300, 900)")
    ap.add_argument("--pages", type=int, default=6, help="coinbase: 300 candles per page")
    ap.add_argument("--days", type=float, default=3, help="synthetic: days of data")
    ap.add_argument("--min-score", type=int, default=40)
    ap.add_argument("--horizons", default="3,6,12", help="bars ahead to measure")
    ap.add_argument("--out", help="write full JSON results here")
    a = ap.parse_args(argv)
    horizons = [int(x) for x in a.horizons.split(",")]
    if a.csv:
        candles = load_csv(a.csv, a.symbol, a.tf)
    elif a.coinbase:
        candles = asyncio.run(load_coinbase(a.symbol, a.tf, a.pages))
    else:
        candles = synthetic(a.symbol, a.tf, a.days)
    if len(candles) < 150:
        print(f"Only {len(candles)} candles: need at least 150 for all detectors.", file=sys.stderr)
    res = run(candles, a.min_score, horizons)
    print(f"\n{a.symbol} · {a.tf}s candles · {res['candles']} bars · {res['overall']['alerts']} alerts\n")
    hdr = f"{'group':<22}{'alerts':>8}" + "".join(f"{'hit@' + str(h):>10}{'ret%@' + str(h):>10}" for h in horizons)
    print(hdr)
    print("-" * len(hdr))

    def line(name, s):
        print(f"{name:<22}{s['alerts']:>8}" + "".join(
            f"{s.get(f'hit_rate_{h}', float('nan')):>10.3f}{s.get(f'avg_dir_ret_{h}', float('nan')):>10.3f}" for h in horizons))

    line("ALL", res["overall"])
    for k, v in res["by_score"].items():
        line(f"score {k}", v)
    for k, v in res["by_detector"].items():
        line(k, v)
    print("\nhit = price moved in the alert's direction; ret% = average move in the alert's direction.")
    if a.out:
        with open(a.out, "w") as f:
            json.dump(res, f, indent=2, default=str)
        print(f"Full results written to {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
