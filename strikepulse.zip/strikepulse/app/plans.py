"""Subscription tiers and what each one unlocks."""
from __future__ import annotations

from dataclasses import dataclass, field

from .engine.detectors import ALL_DETECTORS, BASIC_DETECTORS

ALL_CHANNELS = {"telegram", "discord", "email", "ntfy", "webhook"}


@dataclass(frozen=True)
class Plan:
    key: str
    name: str
    price: float                    # USD / month
    price_yearly: float               # USD / year (shown when yearly Stripe prices are set)
    max_watches: int
    timeframes: tuple
    delay_seconds: int
    channels: frozenset
    detectors: frozenset
    min_score_floor: int
    daily_cap: int
    onchain_wallets: int
    security: bool
    depeg: bool
    listings: bool
    gas: bool
    api: bool
    deep_analysis: bool = False     # full Deep Analysis on every coin (free: BTC-USD only)
    quant: bool = False             # Quant Engine stances + model card
    edge_lab: bool = False          # Edge Lab panels + edge alerts
    movers: bool = False            # market-wide big-mover alerts on every major coin
    max_devices: int = 2            # companion devices (watches, ESP32, Pi, extension)
    tagline: str = ""
    features: tuple = field(default_factory=tuple)


PLANS: dict[str, Plan] = {
    "free": Plan(
        key="free", name="Free", price=0, price_yearly=0, max_watches=3, timeframes=("15m",),
        delay_seconds=300, channels=frozenset({"telegram", "email", "ntfy"}),
        detectors=frozenset(BASIC_DETECTORS), min_score_floor=60, daily_cap=20, onchain_wallets=0,
        security=False, depeg=True, listings=False, gas=False, api=False, deep_analysis=False,
        movers=False, max_devices=2, tagline="Try it out",
        features=("3 coins", "Deep Analysis on BTC", "Bet Simulator on BTC (90 days)", "Markets page: top 250 coins", "2 companion devices (watch, ESP32, Pi)", "15-minute timeframe", "4 core detectors", "Alerts delayed 5 minutes",
                  "Telegram, email or push", "Stablecoin de-peg alerts"),
    ),
    "pro": Plan(
        key="pro", name="Pro", price=9.99, price_yearly=99, max_watches=25, timeframes=("1m", "5m", "15m"),
        delay_seconds=0, channels=frozenset({"telegram", "discord", "email", "ntfy"}),
        detectors=frozenset(ALL_DETECTORS), min_score_floor=0, daily_cap=400, onchain_wallets=5,
        security=False, depeg=True, listings=True, gas=True, api=False, deep_analysis=True, quant=True,
        movers=True, max_devices=10, tagline="For active traders",
        features=("Deep Analysis on every coin: Probability Engine, order-flow X-ray, whale vs retail, timing map, target odds",
                  "Quant Engine: ML ensemble stance + risk budget per coin", "Pattern Memory across every coin",
                  "Bet Simulator: 1-year replay + 5,000 Monte Carlo runs", "World & Macro: sentiment, news, GDP, debt, rates", "Historical odds on every alert", "25 coins", "1m / 5m / 15m timeframes", "All 9 detectors incl. CUSUM + Isolation Forest",
                  "Real-time alerts", "Discord + all channels", "New-listing + gas alerts",
                  "Track 5 whale wallets", "Big-mover alerts on every major coin (top 250)", "10 companion devices: Galaxy Watch, Apple Watch, ESP32, Pi, browser"),
    ),
    "elite": Plan(
        key="elite", name="Elite", price=24.99, price_yearly=249, max_watches=200, timeframes=("1m", "5m", "15m"),
        delay_seconds=0, channels=frozenset(ALL_CHANNELS), detectors=frozenset(ALL_DETECTORS),
        min_score_floor=0, daily_cap=3000, onchain_wallets=50, security=True, depeg=True,
        listings=True, gas=True, api=True, deep_analysis=True, quant=True, edge_lab=True,
        movers=True, max_devices=50, tagline="Signals + on-chain security",
        features=("Edge Lab: hidden buyer/seller detection, wash-trade forensics, stop-hunt + liquidation zones, exchange premium & lead-lag, options max pain",
                  "Edge alerts: hidden orders, pump signatures, stop runs", "Unlimited coins (200)", "Everything in Pro", "On-chain security alerts: rug pulls, mints, ownership changes",
                  "Flagged-address detection", "Track 50 wallets, tokens and LP pairs",
                  "Signed webhooks + REST API", "50 companion devices", "Priority support"),
    ),
}

ORDER = ["free", "pro", "elite"]


def plan_for(user) -> Plan:
    key = getattr(user, "plan", "free") or "free"
    status = getattr(user, "plan_status", "active")
    if key != "free" and status not in ("active", "trialing", "past_due"):
        key = "free"
    return PLANS.get(key, PLANS["free"])
