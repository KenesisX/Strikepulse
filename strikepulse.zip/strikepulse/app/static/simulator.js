(() => {
  const form = document.getElementById('sim-form');
  if (!form) return;
  const $ = (id) => document.getElementById(id);
  const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
  const money = (x) => x == null ? '–' : (x < 0 ? '-$' : '$') + Math.abs(x).toLocaleString(undefined, { maximumFractionDigits: 2 });
  const pc = (x, d = 0) => x == null ? '–' : `${(x * 100).toFixed(d)}%`;
  const pct = (x, d = 2) => x == null ? '–' : `${x >= 0 ? '+' : ''}${(x * 100).toFixed(d)}%`;
  const RED = '#e11d2e', WHITE = '#f5f5f5', MUTED = '#8a8a8a';
  function cv(id, h) { const c = $(id); const dpr = window.devicePixelRatio || 1; const w = c.clientWidth; c.width = w * dpr; c.height = h * dpr; c.style.height = h + 'px'; const x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, h); return [x, w, h]; }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = new FormData(form);
    const num = (k) => f.get(k) === '' || f.get(k) == null ? null : Number(f.get(k));
    const body = { symbol: f.get('symbol'), days: num('days'), bankroll: num('bankroll'), stake: num('stake'), stake_mode: f.get('stake_mode'),
      strategy: f.get('strategy'), hold: num('hold'), threshold: (num('threshold') || 0) / 100, entry_hour: num('entry_hour'), entry_weekday: num('entry_weekday'),
      stop: num('stop') ? num('stop') / 100 : null, take: num('take') ? num('take') / 100 : null };
    $('sim-head').textContent = 'Simulating…';
    const t0 = performance.now();
    try {
      const r = await fetch('/api/simulate', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const d = await r.json();
      if (!r.ok || d.error) throw new Error(d.detail || d.error || 'error');
      render(d, body, performance.now() - t0);
    } catch (err) { $('sim-head').textContent = err.message; }
  });

  function render(d, b, ms) {
    const st = $('sim-stats'); st.replaceChildren();
    $('sim-head').textContent = `${b.symbol} · ${d.description} · ${d.days} days${d.simulated_data ? ' · demo data' : ''} · computed in ${Math.round(ms)} ms`;
    const stat = (a, v, s, cls = '') => { const x = el('div', 'stat'); x.append(el('div', 'muted small', a), el('div', 'big-sm ' + cls, v), el('div', 'small muted', s)); st.append(x); };
    if (d.strategy === 'dca') {
      stat('Invested', money(d.invested), `${d.buys} weekly buys`);
      stat('Worth now', money(d.final_value), pct(d.return, 1), d.profit >= 0 ? 'up' : 'down');
      stat('Buy & hold', pct(d.buy_and_hold_return, 1), 'same period');
      $('sim-verdict').textContent = d.profit >= 0 ? `Dollar-cost averaging made ${money(d.profit)}.` : `Dollar-cost averaging lost ${money(-d.profit)}.`;
      return;
    }
    const mc = d.monte_carlo; const hi = d.historical;
    stat('Average result per bet', money(d.expected_dollars_per_bet), `${pct(d.expected_return_per_bet)} of the stake`, d.expected_dollars_per_bet >= 0 ? 'up' : 'down');
    stat('Win rate', pc(d.win_rate, 1), `${d.trades} trades (${d.trades_per_month}/month)`);
    stat('Avg win / avg loss', `${pct(d.avg_win, 1)} / ${pct(d.avg_loss, 1)}`, `worst streak ${d.longest_losing_streak} losses`);
    stat('Last year, actually', money(hi.final_bankroll), `${pct(hi.return, 1)} · max drawdown ${pct(hi.max_drawdown, 1)}`, hi.return >= 0 ? 'up' : 'down');
    stat('Typical year (median)', money(mc.median), `chance of profit ${pc(mc.prob_profit)}`, mc.median >= b.bankroll ? 'up' : 'down');
    stat('Bad year / good year', `${money(mc.p5)} / ${money(mc.p95)}`, `5th / 95th percentile · lose half: ${pc(mc.prob_lose_half, 1)}`);
    const v = $('sim-verdict'); v.replaceChildren();
    const edge = d.expected_return_per_bet;
    v.append(el('p', edge > 0 ? 'up' : 'down', edge > 0 ? `Historically this bet had a positive average of ${money(d.expected_dollars_per_bet)} per ${money(b.stake_mode === 'fixed' ? b.stake : b.bankroll * b.stake / 100)} bet after costs.` :
      `Historically this bet lost ${money(-d.expected_dollars_per_bet)} on average per bet after costs.`),
    el('p', 'small muted', `Buy & hold over the same period: ${pct(d.buy_and_hold_return, 1)}. Kelly-optimal bet size from this history: ${pc(d.kelly_fraction, 1)} of money (most pros use a quarter of that).`));
    // histogram
    const [ctx, W, H] = cv('sim-hist', 220); const h = mc.histogram; const mx = Math.max(...h.counts, 1); const bw = W / h.counts.length;
    h.counts.forEach((c, i) => { const mid = (h.edges[i] + h.edges[i + 1]) / 2; ctx.fillStyle = mid >= b.bankroll ? 'rgba(245,245,245,.8)' : 'rgba(225,29,46,.85)'; const hh = c / mx * (H - 30); ctx.fillRect(i * bw + 1, H - 20 - hh, bw - 2, hh); });
    ctx.fillStyle = MUTED; ctx.font = '11px system-ui'; ctx.fillText(money(h.edges[0]), 2, H - 5); ctx.textAlign = 'right'; ctx.fillText(money(h.edges[h.edges.length - 1]), W - 2, H - 5); ctx.textAlign = 'left';
    $('sim-mc').textContent = `Mean ${money(mc.mean_final)} · 25th–75th percentile ${money(mc.p25)} – ${money(mc.p75)} · typical worst drop along the way ${pct(mc.median_max_drawdown, 1)}`;
    // equity curve
    const [c2, W2, H2] = cv('sim-curve', 200); const cu = hi.curve; const lo = Math.min(...cu, b.bankroll), up = Math.max(...cu, b.bankroll);
    const y = (vv) => 10 + (up - vv) / ((up - lo) || 1) * (H2 - 20);
    c2.strokeStyle = '#333'; c2.beginPath(); c2.moveTo(0, y(b.bankroll)); c2.lineTo(W2, y(b.bankroll)); c2.stroke();
    c2.strokeStyle = hi.return >= 0 ? WHITE : RED; c2.lineWidth = 2; c2.beginPath(); cu.forEach((vv, i) => { const x = i / (cu.length - 1 || 1) * W2; i ? c2.lineTo(x, y(vv)) : c2.moveTo(x, y(vv)); }); c2.stroke();
    // timing
    const hrs = $('sim-hours'); hrs.replaceChildren(); const bh = d.timing.by_hour; const vals = Object.values(bh).map((x) => Math.abs(x.avg)); const m = Math.max(...vals, 1e-6);
    for (let hh = 0; hh < 24; hh++) { const x = bh[hh]; const cell = el('div', 'hour-cell'); cell.append(el('div', 'small muted', String(hh).padStart(2, '0'))); const bar = el('div', 'hour-bar'); if (x) { bar.style.height = Math.max(3, Math.abs(x.avg) / m * 60) + 'px'; bar.style.background = x.avg >= 0 ? WHITE : RED; cell.title = `${hh}:00 UTC · win ${pc(x.win)} · avg ${pct(x.avg)} · n=${x.n}`; } cell.append(bar); hrs.append(cell); }
    const dd = $('sim-days'); dd.replaceChildren(); Object.entries(d.timing.by_weekday).forEach(([k, x]) => dd.append(el('span', 'chip ' + (x.avg >= 0 ? 'up' : 'down'), `${k} ${pct(x.avg, 2)} · win ${pc(x.win)}`)));
    $('sim-timing').textContent = d.timing.best_hour_utc != null ? `Best entry hour: ${String(d.timing.best_hour_utc).padStart(2, '0')}:00 UTC · worst: ${String(d.timing.worst_hour_utc).padStart(2, '0')}:00 UTC (for a ${d.hold_hours}h hold).` : '';
  }
})();
