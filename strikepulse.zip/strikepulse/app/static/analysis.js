// Deep Analysis page renderer (no inline scripts; CSP friendly).
(() => {
  const root = document.getElementById('an');
  if (!root) return;
  const symbol = root.dataset.symbol;
  const css = (v) => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  const C = { up: css('--up') || '#f5f5f5', down: css('--down') || '#e11d2e', grid: '#262626', muted: '#8a8a8a', text: '#f5f5f5', red: css('--accent') || '#e11d2e' };
  const $ = (id) => document.getElementById(id);
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const fmt = (p) => p == null ? '–' : p >= 1000 ? '$' + p.toLocaleString(undefined, { maximumFractionDigits: 2 }) : p >= 1 ? '$' + p.toFixed(4) : '$' + p.toPrecision(4);
  const pct = (x, d = 1) => x == null ? '–' : `${x >= 0 ? '+' : ''}${(x * 100).toFixed(d)}%`;
  const pc = (x, d = 0) => x == null ? '–' : `${(x * 100).toFixed(d)}%`;
  const usd = (x) => x == null ? '–' : (x < 0 ? '-$' : '$') + Math.abs(x).toLocaleString(undefined, { maximumFractionDigits: 0 });
  const dirCls = (x) => x > 0 ? 'up' : x < 0 ? 'down' : 'muted';
  let data = null; let heatMode = 'avg';

  $('an-symbol')?.addEventListener('change', () => $('an-form').submit());

  function canvasCtx(cv, h) {
    const dpr = window.devicePixelRatio || 1; const w = cv.clientWidth;
    cv.width = w * dpr; cv.height = h * dpr; cv.style.height = h + 'px';
    const ctx = cv.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    return [ctx, w, h];
  }

  // ---------------------------------------------------------------- pulse gauge
  function gauge(score) {
    const cv = $('gauge'); const [ctx, w, h] = canvasCtx(cv, 150);
    const cx = w / 2, cy = 130, r = 100;
    ctx.lineWidth = 18; ctx.lineCap = 'butt';
    const seg = [[0, .25, C.down], [.25, .42, '#7a1a22'], [.42, .58, '#555'], [.58, .75, '#bdbdbd'], [.75, 1, C.up]];
    seg.forEach(([a, b, col]) => { ctx.strokeStyle = col; ctx.beginPath(); ctx.arc(cx, cy, r, Math.PI + a * Math.PI, Math.PI + b * Math.PI); ctx.stroke(); });
    if (score == null) return;
    const ang = Math.PI + (score / 100) * Math.PI;
    ctx.strokeStyle = C.text; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(ang) * (r - 6), cy + Math.sin(ang) * (r - 6)); ctx.stroke();
    ctx.fillStyle = C.text; ctx.beginPath(); ctx.arc(cx, cy, 6, 0, Math.PI * 2); ctx.fill();
    ctx.font = 'bold 28px system-ui'; ctx.textAlign = 'center'; ctx.fillText(score, cx, cy - 34);
    ctx.font = '11px system-ui'; ctx.fillStyle = C.muted; ctx.fillText('bearish', cx - r, cy + 16); ctx.fillText('bullish', cx + r, cy + 16);
  }

  function renderPulse(p) {
    gauge(p.score);
    $('pulse-label').textContent = p.label || '';
    $('pulse-label').className = 'pulse-label ' + (p.score == null ? '' : p.score >= 58 ? 'up' : p.score <= 42 ? 'down' : 'muted');
    const box = $('pulse-parts'); box.replaceChildren();
    (p.parts || []).forEach((x) => {
      const row = el('div', 'part'); row.append(el('span', 'part-name', x.name));
      const bar = el('div', 'part-bar'); const fill = el('div', 'part-fill ' + (x.value >= 0 ? 'pos' : 'neg'));
      fill.style.width = Math.abs(x.value) * 50 + '%'; fill.style[x.value >= 0 ? 'left' : 'right'] = '50%';
      bar.append(fill); row.append(bar); box.append(row);
    });
  }

  function renderShifts(list) {
    const ul = $('shifts'); ul.replaceChildren();
    if (!list || !list.length) { ul.append(el('li', 'muted', 'No notable shifts in the last 30 minutes.')); return; }
    list.forEach((s) => { const li = el('li', 'shift ' + dirCls(s.dir)); li.append(el('span', 'shift-ico', s.dir > 0 ? '▲' : s.dir < 0 ? '▼' : '●'), el('span', null, s.text)); ul.append(li); });
  }

  // ---------------------------------------------------------------- probability engine
  function renderOdds(odds) {
    const box = $('odds'); box.replaceChildren();
    const blocks = [['hourly', { 1: '1 hour', 4: '4 hours', 24: '24 hours' }], ['intraday', { 3: '15 min', 12: '1 hour' }]];
    let any = false;
    blocks.forEach(([key, labels]) => {
      const r = odds && odds[key]; if (!r) return; any = true;
      const t = el('table', 'list odds-table');
      const hd = el('tr'); ['Horizon', 'Chance higher', 'Normal', 'Edge', 'Typical move', 'Range (10%-90%)'].forEach((h) => hd.append(el('th', null, h)));
      t.append(hd);
      Object.entries(r.horizons).forEach(([h, v]) => {
        const tr = el('tr');
        tr.append(el('td', null, labels[h] || h + ' bars'));
        const td = el('td'); const bar = el('div', 'prob'); const f = el('div', 'prob-fill ' + (v.p_up >= .5 ? 'pos' : 'neg'));
        f.style.width = (v.p_up * 100) + '%'; bar.append(f); td.append(el('b', dirCls(v.p_up - .5), pc(v.p_up)), bar);
        td.title = `80% confidence: ${pc(v.ci_low)} – ${pc(v.ci_high)}`;
        tr.append(td, el('td', 'muted', pc(v.base_rate)), el('td', dirCls(v.edge), pct(v.edge, 0).replace('%', ' pts')),
          el('td', dirCls(v.median), pct(v.median, 2)), el('td', 'muted', `${pct(v.p10, 2)} to ${pct(v.p90, 2)}`));
        t.append(tr);
      });
      const cap = el('p', 'small muted', `${key === 'hourly' ? 'Hourly' : '5-minute'} analogs: the ${r.n} most similar moments out of ${r.history_bars} bars of history (similarity ${r.similarity}). Hover a % for its confidence range.`);
      box.append(t, cap);
      if (key === 'hourly' && r.matches && r.matches.length) {
        const m = el('div', 'matches small'); m.append(el('span', 'muted', 'Closest past moments: '));
        r.matches.forEach((x) => { const d = new Date(x.t * 1000); m.append(el('span', 'match ' + dirCls(x.fwd), `${d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} ${d.getHours()}:00 → ${pct(x.fwd, 1)}`)); });
        box.append(m);
      }
    });
    if (!any) box.append(el('p', 'muted', 'Needs more history for this coin. Odds appear once enough candles are collected (live mode backfills ~100 days automatically).'));
  }

  // ---------------------------------------------------------------- candles + cone
  function renderCone(d) {
    const cv = $('cone'); const [ctx, W, H] = canvasCtx(cv, 320);
    const cs = d.hourly_candles || []; const cone = d.cone || [];
    if (!cs.length) { ctx.fillStyle = C.muted; ctx.fillText('Collecting hourly candles…', 20, 40); return; }
    const future = 24; const n = cs.length; const padR = 74; const cw = (W - padR) / (n + future);
    let hi = Math.max(...cs.map((c) => c.h)), lo = Math.min(...cs.map((c) => c.l));
    const c24 = cone.find((c) => c.hours === 24);
    if (c24) { hi = Math.max(hi, c24.p95[1]); lo = Math.min(lo, c24.p95[0]); }
    const pad = (hi - lo) * .05; hi += pad; lo -= pad;
    const y = (p) => 10 + (hi - p) / (hi - lo) * (H - 30); const x = (i) => i * cw + cw / 2;
    ctx.strokeStyle = C.grid; ctx.fillStyle = C.muted; ctx.font = '11px system-ui';
    for (let g = 0; g <= 4; g++) { const p = lo + (hi - lo) * g / 4; ctx.beginPath(); ctx.moveTo(0, y(p)); ctx.lineTo(W - padR, y(p)); ctx.stroke(); ctx.fillText(fmt(p), W - padR + 4, y(p) + 4); }
    // day separators
    cs.forEach((c, i) => { const d0 = new Date(c.t * 1000); if (d0.getHours() === 0) { ctx.strokeStyle = '#1c1c1c'; ctx.beginPath(); ctx.moveTo(x(i), 10); ctx.lineTo(x(i), H - 20); ctx.stroke(); ctx.fillStyle = C.muted; ctx.fillText(d0.toLocaleDateString(undefined, { weekday: 'short' }), x(i) + 3, H - 6); } });
    cs.forEach((c, i) => {
      const up = c.c >= c.o; ctx.strokeStyle = ctx.fillStyle = up ? C.up : C.down;
      ctx.beginPath(); ctx.moveTo(x(i), y(c.h)); ctx.lineTo(x(i), y(c.l)); ctx.stroke();
      const top = y(Math.max(c.o, c.c)); const bh = Math.max(1, Math.abs(y(c.o) - y(c.c)));
      if (up) { ctx.fillStyle = '#0a0a0a'; ctx.fillRect(x(i) - cw * .35, top, cw * .7, bh); ctx.strokeRect(x(i) - cw * .35, top, cw * .7, bh); }
      else ctx.fillRect(x(i) - cw * .35, top, cw * .7, bh);
    });
    // cone
    const last = d.price || cs[n - 1].c; const sig = d.sigma_hourly;
    if (sig) {
      const band = (z, col) => {
        ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x(n - 1), y(last));
        for (let k = 1; k <= future; k++) ctx.lineTo(x(n - 1 + k), y(last * Math.exp(z * sig * Math.sqrt(k))));
        for (let k = future; k >= 1; k--) ctx.lineTo(x(n - 1 + k), y(last * Math.exp(-z * sig * Math.sqrt(k))));
        ctx.closePath(); ctx.fill();
      };
      band(2, 'rgba(225,29,46,.12)'); band(1, 'rgba(245,245,245,.14)');
      ctx.setLineDash([4, 4]); ctx.strokeStyle = '#6b6b6b'; ctx.beginPath(); ctx.moveTo(x(n - 1), y(last)); ctx.lineTo(x(n - 1 + future), y(last)); ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.fillStyle = C.red; ctx.fillRect(W - padR + 1, y(last) - 9, padR - 2, 18); ctx.fillStyle = '#fff'; ctx.fillText(fmt(last), W - padR + 4, y(last) + 4);
    const t = $('cone-table'); t.replaceChildren();
    cone.forEach((c) => { const b = el('div', 'cone-cell'); b.append(el('div', 'muted small', `Next ${c.hours}h`), el('div', null, `68%: ${fmt(c.p68[0])} – ${fmt(c.p68[1])}`), el('div', 'small muted', `95%: ${fmt(c.p95[0])} – ${fmt(c.p95[1])}`)); t.append(b); });
    if (!$('target-price').value && last) $('target-price').value = (last * 1.03).toPrecision(6);
  }

  // ---------------------------------------------------------------- order flow
  function renderFlow(f) {
    const cv = $('flow'); const [ctx, W, H] = canvasCtx(cv, 240);
    const s = (f && f.series) || [];
    if (!s.length) { ctx.fillStyle = C.muted; ctx.fillText('Waiting for trades…', 20, 40); }
    else {
      const mid = H * .55; const maxV = Math.max(...s.map((b) => Math.max(b.buy, b.sell))) || 1; const bw = W / s.length;
      s.forEach((b, i) => {
        const hb = b.buy / maxV * (mid - 10), hs = b.sell / maxV * (H - mid - 10);
        ctx.fillStyle = 'rgba(245,245,245,.55)'; ctx.fillRect(i * bw, mid - hb, Math.max(1, bw - 1), hb);
        ctx.fillStyle = 'rgba(225,29,46,.7)'; ctx.fillRect(i * bw, mid, Math.max(1, bw - 1), hs);
      });
      ctx.strokeStyle = '#333'; ctx.beginPath(); ctx.moveTo(0, mid); ctx.lineTo(W, mid); ctx.stroke();
      const line = (key, col, wdt) => {
        const vals = s.map((b) => b[key]); const mx = Math.max(...vals), mn = Math.min(...vals); const rng = (mx - mn) || 1;
        ctx.strokeStyle = col; ctx.lineWidth = wdt; ctx.beginPath();
        vals.forEach((v, i) => { const yy = 12 + (mx - v) / rng * (H - 24); i ? ctx.lineTo(i * bw + bw / 2, yy) : ctx.moveTo(bw / 2, yy); });
        ctx.stroke(); ctx.lineWidth = 1;
      };
      line('cvd', '#ffffff', 2); line('wcvd', '#ff4d5e', 1.5);
    }
    const tb = $('flow-table'); tb.replaceChildren();
    const hd = el('tr'); ['Window', 'Buy share', 'Net flow', 'Whales net', 'Whale buy share', 'Retail net'].forEach((h) => hd.append(el('th', null, h))); tb.append(hd);
    [['30 min', 'm30'], ['1 hour', 'h1'], ['4 hours', 'h4'], ['24 hours', 'h24']].forEach(([lab, k]) => {
      const w = f[k] || {}; const tr = el('tr');
      tr.append(el('td', null, lab), el('td', dirCls((w.buy_share ?? .5) - .5), pc(w.buy_share)), el('td', dirCls(w.net), usd(w.net)),
        el('td', dirCls(w.whale_net), usd(w.whale_net)), el('td', dirCls((w.whale_buy_share ?? .5) - .5), pc(w.whale_buy_share)), el('td', dirCls(w.retail_net), usd(w.retail_net)));
      tb.append(tr);
    });
    if (f.m30 && f.m30.whale_threshold) tb.append(Object.assign(el('caption', 'small muted', `Whale = single trade ≥ ${usd(f.m30.whale_threshold)} (top 3% of trade sizes for this coin)`), {}));
  }

  // ---------------------------------------------------------------- trends
  function renderTrends(list) {
    const t = $('trends'); t.replaceChildren();
    const hd = el('tr'); ['TF', 'Direction', 'Strength', 'Regime', 'RSI'].forEach((h) => hd.append(el('th', null, h))); t.append(hd);
    (list || []).forEach((x) => {
      const tr = el('tr'); const sb = el('div', 'prob'); const f = el('div', 'prob-fill ' + (x.direction >= 0 ? 'pos' : 'neg')); f.style.width = (x.strength * 100) + '%'; sb.append(f);
      const td = el('td'); td.append(sb);
      tr.append(el('td', null, x.tf), el('td', dirCls(x.direction), x.direction > 0 ? '▲ up' : x.direction < 0 ? '▼ down' : '● flat'), td, el('td', null, x.regime), el('td', 'muted', x.rsi));
      t.append(tr);
    });
    if (!list || !list.length) t.append(el('caption', 'muted', 'Collecting candles…'));
  }

  // ---------------------------------------------------------------- seasonality heatmap
  function renderSeason(s) {
    const box = $('heat'); box.replaceChildren(); const sum = $('season-summary'); sum.replaceChildren();
    if (!s) { box.append(el('p', 'muted', 'Needs at least 2 weeks of hourly history.')); return; }
    $('season-tz').textContent = `${s.weeks} weeks of history · times in ${s.tz}`;
    const hh = (h) => `${String(h).padStart(2, '0')}:00`;
    [['Best hour', hh(s.best_hour), pct(s.hour_avg[s.best_hour], 2), 'up'], ['Worst hour', hh(s.worst_hour), pct(s.hour_avg[s.worst_hour], 2), 'down'],
      ['Busiest hour', hh(s.busiest_hour), 'most volume', ''], ['Best day', s.best_day, '', 'up'], ['Worst day', s.worst_day, '', 'down'],
      ['Right now', `${s.now.weekday} ${hh(s.now.hour)}`, s.now.p_up == null ? '' : `${pc(s.now.p_up)} up historically`, s.now.p_up > .5 ? 'up' : 'down']]
      .forEach(([a, b, c, cls]) => { const d = el('div', 'season-cell'); d.append(el('div', 'muted small', a), el('div', 'big-sm ' + cls, b), el('div', 'small muted', c)); sum.append(d); });
    const grid = s[heatMode]; const flat = grid.flat().filter((v) => v != null);
    const mx = Math.max(...flat.map(Math.abs)) || 1; const vmax = Math.max(...flat) || 1;
    box.append(el('div', 'hc corner'));
    for (let h = 0; h < 24; h++) box.append(el('div', 'hc hh', h % 3 === 0 ? String(h) : ''));
    ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].forEach((dn, d) => {
      box.append(el('div', 'hc hd', dn));
      for (let h = 0; h < 24; h++) {
        const v = grid[d][h]; const c = el('div', 'hc cell');
        let a, col;
        if (heatMode === 'avg') { a = Math.min(1, Math.abs(v) / mx); col = v >= 0 ? `rgba(245,245,245,${.08 + a * .8})` : `rgba(225,29,46,${.08 + a * .85})`; }
        else if (heatMode === 'p_up') { const dv = (v ?? .5) - .5; a = Math.min(1, Math.abs(dv) * 4); col = dv >= 0 ? `rgba(245,245,245,${.06 + a * .8})` : `rgba(225,29,46,${.06 + a * .85})`; }
        else { a = Math.min(1, (v || 0) / vmax); col = `rgba(160,160,160,${.06 + a * .9})`; }
        c.style.background = col;
        if (d === ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].indexOf(s.now.weekday) && h === s.now.hour) c.classList.add('now');
        c.title = `${dn} ${hh(h)} · avg ${pct(s.avg[d][h], 2)} · up ${pc(s.p_up[d][h])} · activity ${s.vol[d][h]}x · n=${s.count[d][h]}`;
        box.append(c);
      }
    });
  }
  document.querySelectorAll('#heat-mode button').forEach((b) => b.addEventListener('click', () => {
    document.querySelectorAll('#heat-mode button').forEach((x) => x.classList.remove('on')); b.classList.add('on'); heatMode = b.dataset.mode; if (data) renderSeason(data.season);
  }));

  // ---------------------------------------------------------------- rotation
  function renderRotation(rows, trending) {
    const t = $('rotation'); t.replaceChildren();
    const hd = el('tr'); ['#', 'Coin', 'Share of volume', 'vs normal', 'Volume pace', 'Trade heat', ''].forEach((h) => hd.append(el('th', null, h))); t.append(hd);
    (rows || []).forEach((r) => {
      const tr = el('tr'); if (r.symbol === symbol) tr.className = 'me';
      const a = el('a', null, r.symbol.split('-')[0]); a.href = `/analysis?symbol=${encodeURIComponent(r.symbol)}`;
      const tdc = el('td'); tdc.append(a);
      tr.append(el('td', 'muted', r.rank), tdc, el('td', null, pc(r.share, 1)), el('td', dirCls(r.share_change), r.share_change == null ? '–' : `${r.share_change >= 0 ? '+' : ''}${(r.share_change * 100).toFixed(1)} pts`),
        el('td', r.rel_volume >= 1.5 ? 'up' : 'muted', r.rel_volume ? r.rel_volume.toFixed(2) + 'x' : '–'), el('td', r.heat >= 1.8 ? 'up' : 'muted', r.heat ? r.heat.toFixed(2) + 'x' : '–'),
        el('td', null, r.trending ? '🔥 trending' : ''));
      t.append(tr);
    });
    const tb = $('trending'); tb.replaceChildren();
    if (trending && trending.length) { tb.append(el('span', 'muted small', 'Trending on CoinGecko: ')); trending.slice(0, 10).forEach((c) => tb.append(el('span', 'chip', c.symbol))); }
  }

  // ---------------------------------------------------------------- target calculator
  $('target-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const out = $('target-out'); out.textContent = 'Calculating…';
    try {
      const r = await fetch(`/api/analysis/target?symbol=${encodeURIComponent(symbol)}&price=${$('target-price').value}&hours=${$('target-hours').value}`, { credentials: 'same-origin' });
      const j = await r.json(); if (!r.ok) throw new Error(j.detail || 'error');
      out.replaceChildren();
      const dirWord = j.target >= j.price ? 'above' : 'below';
      out.append(el('div', 'big-sm', `${pc(j.touch)} chance to touch ${fmt(j.target)}`),
        el('div', null, `${pc(j.close_beyond)} chance to be ${dirWord} it at the end of ${j.hours}h`),
        el('div', 'small muted', `A ${pct(j.move_pct, 2)} move is ${j.sigmas} standard deviations for this coin over that time.`));
    } catch (err) { out.textContent = err.message; }
  });

  // ---------------------------------------------------------------- load
  async function load() {
    try {
      const r = await fetch(`/api/analysis?symbol=${encodeURIComponent(symbol)}`, { credentials: 'same-origin' });
      if (!r.ok) return;
      data = await r.json();
      $('an-price').textContent = fmt(data.price);
      $('an-updated').textContent = 'updated ' + new Date().toLocaleTimeString();
      $('an-sim').hidden = !data.simulated;
      root.classList.toggle('locked', !!data.locked);
      renderPulse(data.pulse || {}); renderShifts(data.shifts);
      renderRotation(data.rotation, data.trending);
      if (!data.locked) {
        renderOdds(data.odds); renderCone(data); renderFlow(data.flow); renderTrends(data.trends); renderSeason(data.season);
      } else {
        renderCone({ hourly_candles: data.hourly_candles, cone: [], price: data.price });
      }
    } catch (e) { /* retry */ }
  }
  load(); setInterval(load, 20000);
  window.addEventListener('resize', () => { if (data) { renderPulse(data.pulse || {}); if (!data.locked) { renderCone(data); renderFlow(data.flow); } } });
})();
