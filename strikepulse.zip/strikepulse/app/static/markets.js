// Markets table: search, filters and column sorting (no inline JS, CSP-safe).
(function () {
  const table = document.getElementById('mk-table');
  if (!table) return;
  const body = table.tBodies[0];
  const rows = Array.from(body.rows);
  const search = document.getElementById('mk-search');
  const live = document.getElementById('mk-live');
  const stables = document.getElementById('mk-stables');
  let sortKey = 'rank', asc = true;

  function apply() {
    const q = (search.value || '').trim().toLowerCase();
    rows.forEach((r) => {
      const show = (!q || r.dataset.name.includes(q)) &&
        (!live.checked || r.dataset.live === '1') &&
        (!stables.checked || r.dataset.stable !== '1');
      r.hidden = !show;
    });
  }

  function sort(key) {
    asc = key === sortKey ? !asc : (key === 'rank' || key === 'name');
    sortKey = key;
    const num = key !== 'name';
    rows.sort((a, b) => {
      const x = num ? parseFloat(a.dataset[key]) : a.dataset[key];
      const y = num ? parseFloat(b.dataset[key]) : b.dataset[key];
      return (x > y ? 1 : x < y ? -1 : 0) * (asc ? 1 : -1);
    });
    rows.forEach((r) => body.appendChild(r));
    table.querySelectorAll('th.sortable').forEach((th) => {
      th.classList.toggle('sorted', th.dataset.k === key);
      th.dataset.dir = th.dataset.k === key ? (asc ? 'asc' : 'desc') : '';
    });
  }

  table.querySelectorAll('th.sortable').forEach((th) => th.addEventListener('click', () => sort(th.dataset.k)));
  [search, live, stables].forEach((el) => el.addEventListener('input', apply));
  apply();
})();
