(() => {
  const root = document.getElementById('world');
  if (!root) return;
  const $ = (id) => document.getElementById(id);
  const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
  const pc = (x, d = 0) => x == null ? '–' : `${(x * 100).toFixed(d)}%`;
  const pct = (x, d = 1) => x == null ? '–' : `${x >= 0 ? '+' : ''}${(x * 100).toFixed(d)}%`;
  const big = (x) => x == null ? '–' : x >= 1e12 ? `$${(x / 1e12).toFixed(2)}T` : x >= 1e9 ? `$${(x / 1e9).toFixed(1)}B` : `$${Math.round(x).toLocaleString()}`;
  const num = (x, d = 1) => x == null ? '–' : Number(x).toFixed(d);
  const cls = (x) => x > 0 ? 'up' : x < 0 ? 'down' : 'muted';
  $('w-symbol')?.addEventListener('change', () => $('w-form').submit());

  function table(id, head, rows) { const t = $(id); t.replaceChildren(); const tr = el('tr'); head.forEach((h) => tr.append(el('th', null, h))); t.append(tr); rows.forEach((r) => t.append(r)); }

  async function load() {
    const r = await fetch(`/api/macro?symbol=${encodeURIComponent(root.dataset.symbol)}`, { credentials: 'same-origin' });
    if (!r.ok) return;
    const d = await r.json();
    $('w-sim').hidden = !d.simulated;
    const tb = $('tilts'); tb.replaceChildren();
    if (d.macro_tilt_30d != null) tb.append(el('div', 'big-sm ' + cls(d.macro_tilt_30d), `Macro tilt: ${pct(d.macro_tilt_30d)} vs a normal 30 days`));
    (d.tilts || []).forEach((t) => { const x = el('div', 'edge-item ' + (t.edge >= 0 ? 'up' : 'down')); x.append(el('b', null, `${t.factor}: ${t.now} (${t.value})`), el('div', 'small muted', `next 30 days averaged ${pct(t.fwd_30d_mean)} vs ${pct(t.baseline_30d_mean)} normally · up ${pc(t.p_up)} of the time · ~${t.independent_n} independent periods${t.independent_n < 10 ? ' · weak evidence' : ''}`)); tb.append(x); });
    if (!(d.tilts || []).length) tb.append(el('p', 'muted small', d.locked ? 'Pro unlocks the full comparison.' : 'Collecting history…'));
    const cg = $('conditions'); cg.replaceChildren();
    Object.values(d.conditions || {}).forEach((c) => {
      const box = el('div', 'cond'); box.append(el('h4', null, c.label), el('div', 'small muted', `now: ${c.current_value} (${c.current_bucket}) · ${c.n_days} days`));
      const t = el('table', 'list'); const hr = el('tr'); ['Bucket', '7d avg', '7d up', '30d avg', '30d up'].forEach((h) => hr.append(el('th', null, h))); t.append(hr);
      c.buckets.forEach((b) => { const tr = el('tr', b.bucket === c.current_bucket ? 'me' : ''); const f7 = b.fwd_7d || {}, f30 = b.fwd_30d || {};
        tr.append(el('td', null, b.bucket), el('td', cls(f7.mean), pct(f7.mean)), el('td', 'muted', pc(f7.p_up)), el('td', cls(f30.mean), pct(f30.mean)), el('td', 'muted', pc(f30.p_up))); t.append(tr); });
      box.append(t); cg.append(box);
    });
    const co = $('corr'); co.replaceChildren();
    Object.values(d.correlations || {}).forEach((c) => co.append(el('div', null, `${c.label}: ${num(c.corr_90d, 2)}`)));
    if (!Object.keys(d.correlations || {}).length) co.append(el('p', 'muted small', 'Needs FRED data (set FRED_API_KEY) or demo mode.'));
    table('yearly', ['Year', 'Crypto', 'World GDP growth', 'World inflation'], (d.yearly || []).map((y) => { const tr = el('tr'); tr.append(el('td', null, y.year), el('td', cls(y.return), pct(y.return, 0)), el('td', 'muted', y.world_gdp_growth == null ? '–' : num(y.world_gdp_growth) + '%'), el('td', 'muted', y.world_inflation == null ? '–' : num(y.world_inflation) + '%')); return tr; }));
    const so = $('sources'); so.replaceChildren(); Object.entries(d.status || {}).forEach(([k, v]) => so.append(el('div', v === 'ok' || v === 'demo' ? '' : 'muted', `${k}: ${v}`)));
    table('countries', ['Country', 'GDP', 'Growth', 'GDP / person', 'Inflation', 'Gov. debt % GDP', 'Unemployment'], (d.countries || []).map((c) => { const tr = el('tr');
      tr.append(el('td', null, c.name), el('td', null, big(c.gdp_usd)), el('td', cls(c.gdp_growth), c.gdp_growth == null ? '–' : num(c.gdp_growth) + '%'), el('td', null, c.gdp_per_capita == null ? '–' : '$' + Math.round(c.gdp_per_capita).toLocaleString()),
        el('td', 'muted', c.inflation == null ? '–' : num(c.inflation) + '%'), el('td', 'muted', c.gov_debt_pct_gdp == null ? '–' : num(c.gov_debt_pct_gdp, 0) + '%'), el('td', 'muted', c.unemployment == null ? '–' : num(c.unemployment) + '%')); return tr; }));
  }
  load();
})();
