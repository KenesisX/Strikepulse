// Quant Engine + Edge Lab renderer.
(() => {
  const root = document.getElementById('q');
  if (!root) return;
  const symbol = root.dataset.symbol;
  const $ = (id) => document.getElementById(id);
  const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
  const pc = (x, d = 0) => x == null ? '–' : `${(x * 100).toFixed(d)}%`;
  const pct = (x, d = 2) => x == null ? '–' : `${x >= 0 ? '+' : ''}${(x * 100).toFixed(d)}%`;
  const fmt = (p) => p == null ? '–' : p >= 1000 ? '$' + p.toLocaleString(undefined, { maximumFractionDigits: 2 }) : p >= 1 ? '$' + p.toFixed(4) : '$' + p.toPrecision(4);
  const usd = (x) => x == null ? '–' : '$' + Math.abs(x).toLocaleString(undefined, { maximumFractionDigits: 0 });
  const cls = (x) => x > 0 ? 'up' : x < 0 ? 'down' : 'muted';
  const RED = '#e11d2e', WHITE = '#f5f5f5', GRID = '#262626', MUTED = '#8a8a8a';
  $('q-symbol')?.addEventListener('change', () => $('q-form').submit());

  function cv(id, h) {
    const c = $(id); const dpr = window.devicePixelRatio || 1; const w = c.clientWidth;
    c.width = w * dpr; c.height = h * dpr; c.style.height = h + 'px';
    const ctx = c.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h); return [ctx, w, h];
  }
  const table = (id, head, rows) => {
    const t = $(id); t.replaceChildren(); const tr = el('tr'); head.forEach((h) => tr.append(el('th', null, h))); t.append(tr);
    rows.forEach((r) => t.append(r));
  };

  // ---------------------------------------------------------------- decision + votes
  function renderDecision(st) {
    const d = st.decision;
    const s = $('stance'); s.textContent = d.stance; s.className = 'stance ' + (d.stance === 'LONG BIAS' ? 'up' : d.stance.startsWith('SHORT') ? 'down' : 'muted');
    $('stance-sub').replaceChildren(
      el('div', null, `Probability higher in 4h: ${pc(d.p_up, 1)} · confidence ${pc(d.confidence)}`),
      el('div', null, `Model risk budget: ${pc(d.size, 1)} of a hypothetical portfolio (¼-Kelly, volatility-capped)`),
      el('div', 'small muted', `Expected edge after fees & slippage: ${pct(d.expected_edge_after_costs, 2)} · regime: ${st.regime}`));
    $('stance-reasons').textContent = [d.hist_precision != null ? `historically right ${pc(d.hist_precision, 1)} at this confidence (${d.hist_n} calls)` : '', ...(d.reasons || [])].filter(Boolean).join(' · ');
    const names = { gbdt: 'Gradient-boosted trees', online: 'Online order-flow learner', analogs: 'Historical analogs (kNN)', rules: 'Rule confluence (Pulse)', patterns: 'Pattern Memory (all coins)' };
    table('votes', ['Model', 'P(higher 4h)', 'Weight'], Object.entries(st.components).map(([k, v]) => {
      const tr = el('tr'); const w = st.weights[k];
      let note = v == null ? (k === 'gbdt' ? 'benched by deploy gate' : 'warming up') : pc(v, 1);
      if (k === 'gbdt' && v == null && st.component_raw_gbdt != null) note += ` (raw ${pc(st.component_raw_gbdt, 1)})`;
      tr.append(el('td', null, names[k] || k), el('td', v == null ? 'muted' : cls(v - .5), note), el('td', 'muted', w == null ? '–' : pc(w)));
      return tr;
    }));
    const r = $('regime'); r.replaceChildren(el('h4', null, 'Regime'));
    Object.entries(st.regime_probs || {}).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => {
      const row = el('div', 'part'); row.append(el('span', 'part-name', k));
      const bar = el('div', 'prob'); const f = el('div', 'prob-fill ' + (k.includes('down') || k.includes('stress') ? 'neg' : 'pos')); f.style.width = (v * 100) + '%'; bar.append(f);
      row.append(bar, el('span', 'small muted', pc(v))); r.append(row);
    });
  }

  function renderOverview(rows) {
    table('overview', ['Coin', 'Price', 'P(higher 4h)', 'Stance', 'Risk budget', 'Regime', 'Trap risk', 'Hidden orders'], rows.map((o) => {
      const tr = el('tr', o.symbol === symbol ? 'me' : 'clickable');
      tr.addEventListener('click', () => { location.href = `/quant?symbol=${encodeURIComponent(o.symbol)}`; });
      tr.append(el('td', null, o.symbol.split('-')[0]), el('td', null, fmt(o.price)), el('td', cls(o.p_up - .5), pc(o.p_up, 1)),
        el('td', o.stance === 'LONG BIAS' ? 'up' : o.stance.startsWith('SHORT') ? 'down' : 'muted', o.stance), el('td', null, pc(o.size, 1)),
        el('td', 'muted', o.regime), el('td', (o.trap && o.trap.risk >= .6) ? 'down' : 'muted', o.trap && o.trap.risk != null ? `${o.trap.type} ${pc(o.trap.risk)}` : '–'),
        el('td', o.hidden ? 'up' : 'muted', o.hidden || '–'));
      return tr;
    }));
  }

  // ---------------------------------------------------------------- model card
  function renderCard(m) {
    const c = m.card || {}; const box = $('card-status'); box.replaceChildren();
    const badge = el('span', 'tag ' + (c.status === 'deployed' ? 'ok' : 'warn'), (c.status || 'untrained').toUpperCase());
    box.append(badge, el('span', 'small muted', ` ${c.algo || ''} · ${c.rows || 0} rows · ${c.coins || 0} coins · ${c.folds || 0} walk-forward folds · challenger retrain every ${(m.adaptation || {}).retrain_minutes || 60} min`));
    if (c.reason) box.append(el('p', 'small', c.reason));
    const st = $('card-stats'); st.replaceChildren();
    const o = c.oos || {}; const bt = c.backtest || {}; const hold = c.buy_and_hold || {};
    [['OOS AUC', o.auc == null ? '–' : o.auc.toFixed(3), '0.50 = coin flip'], ['Accuracy', pc(o.accuracy, 1), `base rate ${pc(o.base_rate, 1)}`],
      ['When confident', pc(o.confident_accuracy, 1), `${pc(o.confident_share)} of the time`], ['Backtest return', pct(bt.total_return, 1), `buy & hold ${pct(hold.total_return, 1)}`],
      ['Sharpe (after costs)', bt.sharpe ?? '–', `max drawdown ${pct(bt.max_drawdown, 1)}`], ['Live paper track', pct((m.live.equity || 1) - 1, 2), `${m.live.resolved} trades · hit ${pc(m.live.hit_rate)}`]]
      .forEach(([a, b, x]) => { const d = el('div', 'stat'); d.append(el('div', 'muted small', a), el('div', 'big-sm', String(b)), el('div', 'small muted', x)); st.append(d); });
    // equity curves
    const [ctx, W, H] = cv('equity', 220);
    const series = [[bt.equity || [], WHITE], [c.hold_equity || [], RED], [m.live.curve || [], '#8a8a8a']].filter((s) => s[0].length > 1);
    if (!series.length) { ctx.fillStyle = MUTED; ctx.fillText('Backtest appears after the first training run.', 16, 30); }
    else {
      const all = series.flatMap((s) => s[0]); const t0 = Math.min(...all.map((p) => p[0])), t1 = Math.max(...all.map((p) => p[0]));
      const v0 = Math.min(...all.map((p) => p[1]), 1), v1 = Math.max(...all.map((p) => p[1]), 1);
      const x = (t) => 10 + (t - t0) / ((t1 - t0) || 1) * (W - 60), y = (v) => 10 + (v1 - v) / ((v1 - v0) || 1) * (H - 30);
      ctx.strokeStyle = GRID; ctx.beginPath(); ctx.moveTo(0, y(1)); ctx.lineTo(W, y(1)); ctx.stroke();
      ctx.fillStyle = MUTED; ctx.font = '11px system-ui'; ctx.fillText('start', W - 44, y(1) - 3);
      series.forEach(([pts, col]) => { ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(x(p[0]), y(p[1])) : ctx.moveTo(x(p[0]), y(p[1]))); ctx.stroke(); });
      ctx.lineWidth = 1;
    }
    const imp = $('importance'); imp.replaceChildren();
    const mx = Math.max(...(c.importance || []).map((i) => i.drop), 1e-6);
    (c.importance || []).forEach((i) => { const row = el('div', 'part'); row.append(el('span', 'part-name', i.feature)); const bar = el('div', 'prob'); const f = el('div', 'prob-fill pos'); f.style.width = Math.max(0, i.drop / mx * 100) + '%'; bar.append(f); row.append(bar); imp.append(row); });
    if (!(c.importance || []).length) imp.append(el('p', 'muted small', '–'));
    const on = m.online || {}; const ob = $('online'); ob.replaceChildren(
      el('div', null, `${on.updates || 0} live updates · log-loss ${on.loss ?? '–'} (0.693 = coin flip) · drift resets: ${on.drifts || 0}`));
    const ws = Object.entries(on.weights || {}).filter(([k]) => k !== 'bias').sort((a, b) => Math.abs(b[1]) - Math.abs(a[1])).slice(0, 6);
    ws.forEach(([k, v]) => ob.append(el('div', 'small ' + cls(v), `${k}: ${v > 0 ? '+' : ''}${v.toFixed(3)}`)));
  }

  // ---------------------------------------------------------------- graph
  function renderGraph(g) {
    const [ctx, W, H] = cv('graph', 360);
    const nodes = g.nodes || []; if (nodes.length < 2) { ctx.fillStyle = MUTED; ctx.fillText('Graph appears once enough hourly history is loaded.', 16, 30); return; }
    const cx = W / 2, cy = H / 2, R = Math.min(W, H) / 2 - 50;
    const pos = {}; nodes.forEach((n, i) => { const a = -Math.PI / 2 + i * 2 * Math.PI / nodes.length; pos[n.symbol] = [cx + R * Math.cos(a), cy + R * Math.sin(a)]; });
    (g.edges || []).forEach((e) => {
      const a = pos[e.a], b = pos[e.b]; if (!a || !b || Math.abs(e.corr) < .3) return;
      ctx.strokeStyle = e.corr >= 0 ? `rgba(245,245,245,${(Math.abs(e.corr) - .3) * 1.2})` : `rgba(225,29,46,${(Math.abs(e.corr) - .3) * 1.2})`;
      ctx.lineWidth = 1 + Math.abs(e.corr) * 3; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
      if (e.lead_strength > .05) { // arrow from leader to follower
        const [p, q] = e.leader === e.a ? [a, b] : [b, a]; const mx = p[0] + (q[0] - p[0]) * .6, my = p[1] + (q[1] - p[1]) * .6;
        const ang = Math.atan2(q[1] - p[1], q[0] - p[0]); ctx.fillStyle = RED; ctx.beginPath();
        ctx.moveTo(mx + 8 * Math.cos(ang), my + 8 * Math.sin(ang)); ctx.lineTo(mx + 8 * Math.cos(ang + 2.5), my + 8 * Math.sin(ang + 2.5)); ctx.lineTo(mx + 8 * Math.cos(ang - 2.5), my + 8 * Math.sin(ang - 2.5)); ctx.fill();
      }
    });
    ctx.lineWidth = 1;
    nodes.forEach((n) => {
      const [x, y] = pos[n.symbol]; const r = 14 + n.centrality * 16;
      ctx.fillStyle = n.r24 >= 0 ? '#e5e5e5' : RED; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
      if (n.symbol === symbol) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.stroke(); ctx.lineWidth = 1; }
      ctx.fillStyle = n.r24 >= 0 ? '#0a0a0a' : '#fff'; ctx.font = 'bold 11px system-ui'; ctx.textAlign = 'center'; ctx.fillText(n.symbol.split('-')[0], x, y + 4);
      ctx.fillStyle = MUTED; ctx.font = '10px system-ui'; ctx.fillText(pct(n.r24, 1), x, y + r + 12);
    });
    ctx.textAlign = 'left';
  }

  // ---------------------------------------------------------------- edge lab
  function renderEdge(e) {
    const h = $('hidden'); h.replaceChildren();
    if (!(e.hidden_orders || []).length) h.append(el('p', 'muted small', 'No algorithmic footprints in the last 15 minutes.'));
    (e.hidden_orders || []).forEach((o) => {
      const d = el('div', 'edge-item ' + (o.side === 'buy' ? 'up' : 'down'));
      d.append(el('b', null, `${o.side === 'buy' ? '▲ Hidden buyer' : '▼ Hidden seller'} · ≈${usd(o.usd)}`),
        el('div', 'small muted', `${o.prints} prints of ${o.unit_size} every ~${o.cadence_s}s for ${o.minutes} min · regularity ${pc(o.regularity)}`));
      h.append(d);
    });
    const t = e.trap || {}; $('trap').replaceChildren(t.risk == null ? el('p', 'muted small', 'No fresh 24h breakout to judge.') :
      Object.assign(el('div'), {}));
    if (t.risk != null) { $('trap').append(el('div', 'big-sm ' + (t.risk >= .6 ? 'down' : 'muted'), `${t.type}: ${pc(t.risk)} risk`), el('div', 'small muted', (t.why || []).join(' · ') || 'breakout looks healthy')); }
    const sr = e.stop_run; $('stoprun').replaceChildren(sr ? el('div', cls(sr.direction), `${sr.type} at ${fmt(sr.level)} (wick ${pct(sr.wick)}, volume ${sr.volume_x}x)`) : el('p', 'muted small', 'None on the latest 15m candle.'));
    const s = $('stops'); s.replaceChildren();
    const sc = e.stop_clusters || {};
    [...(sc.above || [])].reverse().forEach((l) => s.append(el('div', 'lvl down', `${fmt(l.price)}  ${pct(l.dist)}  ${'█'.repeat(Math.min(6, Math.round(l.strength * 1.5)))}`)));
    s.append(el('div', 'lvl now', '── price ──'));
    (sc.below || []).forEach((l) => s.append(el('div', 'lvl up', `${fmt(l.price)}  ${pct(l.dist)}  ${'█'.repeat(Math.min(6, Math.round(l.strength * 1.5)))}`)));
    const a = $('auth'); a.replaceChildren();
    if (!(e.authenticity || []).length) a.append(el('p', 'muted small', 'Needs ~300 trades per exchange.'));
    (e.authenticity || []).forEach((x) => { const d = el('div', 'edge-item'); d.append(el('b', x.score >= 75 ? 'up' : 'down', `${x.exchange}: ${x.score}/100, ${x.verdict}`), el('div', 'small muted', `Benford deviation ${x.benford_mad} · round lots ${pc(x.round_lot_share, 1)} · top repeated size ${pc(x.top_size_share, 1)} · n=${x.n}`)); a.append(d); });
    const dv = e.derivatives || {}; const pp = dv.perp; const pb = $('perp'); pb.replaceChildren();
    if (pp) { pb.append(el('div', null, `Funding: ${pct(pp.funding_annual, 1)} / yr (${pp.venue})`), el('div', null, `Open interest: ${usd(pp.oi_usd)} · 1h ${pct(pp.oi_change_1h)} · 24h ${pct(pp.oi_change_24h)}`), el('div', pp.crowding === 'balanced' ? 'muted' : 'down', pp.crowding)); }
    else pb.append(el('p', 'muted small', 'Perpetual data unavailable.'));
    const op = dv.options; const ob = $('options'); ob.replaceChildren();
    if (op && op.max_pain) { ob.append(el('h4', 'mt-sm', `Options · expiry ${op.expiry}`), el('div', null, `Max pain ${fmt(op.max_pain)} (${pct(op.pull)} from price) · put/call OI ${op.put_call_oi}`), el('div', 'small muted', 'Biggest strikes: ' + op.top_strikes.map((s) => `${s.strike}${s.type}`).join(', '))); }
    // liquidation bars
    const lq = dv.liquidations || {}; const [ctx, W, H] = cv('liq', 200);
    if (!lq.edges) { ctx.fillStyle = MUTED; ctx.fillText('Builds up as open interest is sampled (every 5 min).', 16, 30); }
    else {
      const n = lq.longs.length; const mx = Math.max(...lq.longs, ...lq.shorts, 1); const bw = W / n;
      for (let i = 0; i < n; i++) {
        const hl = lq.longs[i] / mx * (H - 30), hs = lq.shorts[i] / mx * (H - 30);
        ctx.fillStyle = 'rgba(245,245,245,.75)'; ctx.fillRect(i * bw + 1, H - 20 - hl, bw - 2, hl);
        ctx.fillStyle = 'rgba(225,29,46,.85)'; ctx.fillRect(i * bw + 1, H - 20 - hs, bw - 2, hs);
      }
      ctx.fillStyle = MUTED; ctx.font = '10px system-ui';
      [0, Math.floor(n / 2), n].forEach((i) => ctx.fillText(fmt(lq.edges[i]), Math.min(W - 70, i * bw), H - 6));
    }
    const xx = e.cross_exchange || {}; const xb = $('xex'); xb.replaceChildren();
    Object.entries(xx.venues || {}).forEach(([k, v]) => xb.append(el('div', null, `${k}: ${fmt(v)} (${(xx.spread_bps || {})[k] ?? '–'} bps)`)));
    if (xx.premium != null) xb.append(el('div', cls(xx.premium), `Coinbase premium: ${xx.premium} bps (smoothed ${xx.premium_ema})`));
    xb.append(el('div', 'small muted', xx.leader ? `${xx.leader} tends to move first (~${xx.lag_s}s, corr ${xx.lead_corr})` : 'Lead-lag needs two live venues.'));
    const rc = $('edge-recent'); rc.replaceChildren();
    (e.recent || []).slice(0, 6).forEach((r) => rc.append(el('li', 'shift ' + cls(r.direction), `${new Date(r.t * 1000).toLocaleTimeString()}  ${r.title}`)));
    if (!(e.recent || []).length) rc.append(el('li', 'muted small', 'Nothing yet.'));
  }

  // ---------------------------------------------------------------- v1.3 panels
  function renderConformal(m, price) {
    const b = $('conformal'); b.replaceChildren();
    const c = m && m.conformal;
    if (!c || !c.interval) { b.append(el('p', 'muted small', 'Calibrating…')); return; }
    b.append(el('div', 'big-sm', `${fmt(c.interval.low)} – ${fmt(c.interval.high)}`),
      el('div', null, `Target hit rate ${pc(c.target)} · ±${(c.interval.width * 100).toFixed(2)}% around ${fmt(price)}`),
      el('div', c.live_coverage == null ? 'small muted' : (Math.abs(c.live_coverage - c.target) < 0.03 ? 'small up' : 'small down'),
        c.live_coverage == null ? `Live coverage: measuring (needs 20 resolved ranges) · calibrated on ${c.calibration_n} past moves` : `Live coverage so far: ${pc(c.live_coverage, 1)} · self-correcting α=${c.alpha_t}`),
      el('p', 'small muted', 'Ranges widen automatically when the market gets wilder and tighten when it calms, so the hit rate stays on target.'));
  }
  function renderPrecision(card, d) {
    const rows = (card.precision_table || []);
    table('precision', ['Only when confidence ≥', 'Right', 'Speaks', 'Calls'], rows.map((r) => {
      const tr = el('tr'); tr.append(el('td', null, pc(r.min_confidence)), el('td', r.precision >= .55 ? 'up' : r.precision < .5 ? 'down' : 'muted', pc(r.precision, 1)), el('td', 'muted', pc(r.coverage)), el('td', 'muted', r.n)); return tr;
    }));
    $('precision-note').textContent = rows.length ? (d && d.hist_precision != null ? `Current call: confidence ${pc(d.confidence)} → historically right ${pc(d.hist_precision, 1)} (${d.hist_n} calls).` : 'Stances need the batch model deployed and a historical hit rate above the bar.') : 'Appears after training.';
  }
  function renderMath(m) {
    const g = $('math'); g.replaceChildren();
    if (!m || !Object.keys(m).length) { g.append(el('p', 'muted small', 'Needs 200+ hourly candles.')); return; }
    const card = (title, big, sub, cl = '') => { const d = el('div', 'math-card'); d.append(el('div', 'muted small', title), el('div', 'big-sm ' + cl, big), el('div', 'small muted', sub)); g.append(d); };
    const k = m.kalman; if (k) card('Kalman trend', `${k.t_stat > 0 ? '▲' : '▼'} t=${k.t_stat}`, `denoised ${fmt(k.smoothed)} · ${pct(k.slope_per_h, 3)}/h`, cls(k.t_stat));
    const ga = m.garch; if (ga) card('GARCH volatility', `±${(ga.sigma_4 * 100).toFixed(2)}% / 4h`, `1h ${(ga.sigma_1 * 100).toFixed(2)}% · 24h ${(ga.sigma_24 * 100).toFixed(2)}% · shocks fade in ${ga.half_life_bars ?? '–'}h`);
    if (m.hurst != null) card('Hurst exponent (DFA)', m.hurst, m.hurst_read, m.hurst > .55 ? 'up' : m.hurst < .45 ? 'down' : '');
    if (m.entropy != null) card('Permutation entropy', m.entropy, `predictability ${pc(m.predictability, 1)} (0% = pure noise)`);
    const cp = m.change_point; if (cp) card('Bayesian change-point', pc(cp.prob_recent), `chance the regime just changed · current run ${cp.run_length}h`, cp.prob_recent > .5 ? 'down' : '');
    const ou = m.ou; if (ou) card('Ornstein-Uhlenbeck', ou.mean_reverting ? `z = ${ou.z}` : 'no pull', ou.mean_reverting ? `fair value ${fmt(ou.equilibrium)} · half-life ${ou.half_life}h` : 'not mean-reverting on 7 days', ou.z > 1.5 ? 'down' : ou.z < -1.5 ? 'up' : '');
    const cy = m.cycle; if (cy) card('Dominant cycle (FFT)', `${cy.period_bars}h`, `${cy.position} · strength ${pc(cy.strength)}`);
    const hw = m.hawkes; card('Hawkes self-excitation', hw ? hw.branching_ratio : '–', hw ? `${hw.state} · ${hw.events} trades` : 'needs 200 trades in 15 min');
  }
  function renderAdaptive(mr) {
    table('history', ['When', 'Trigger', 'Result', 'AUC'], (mr.history || []).slice(0, 6).map((h) => {
      const tr = el('tr'); tr.title = h.why; tr.append(el('td', 'small', new Date(h.t * 1000).toLocaleTimeString()), el('td', 'small muted', h.trigger), el('td', 'small ' + (h.promoted ? 'up' : 'muted'), h.promoted ? `promoted (${h.status})` : 'kept champion'), el('td', 'small muted', h.auc ?? '–')); return tr;
    }));
    const a = mr.adaptation || {}; const dr = mr.drift || {}; const db = $('drift'); db.replaceChildren(
      el('div', null, dr.share_drifting == null ? 'Checking…' : `${pc(dr.share_drifting)} of features drifted (retrain early at ${pc(dr.trigger_share)})`),
      el('div', 'small muted', (dr.top || []).slice(0, 4).map((x) => `${x.feature} ${x.psi}`).join(' · ')),
      el('div', 'small muted', `Challenger every ${a.retrain_minutes} min · recent data weighted (half-life ${a.half_life_days} days) · stances need ≥${pc(a.min_precision)} historical precision`));
    table('coint', ['Pair', 'Spread z', 'Read', 'Half-life'], (mr.cointegration || []).slice(0, 5).map((c) => {
      const tr = el('tr'); tr.append(el('td', null, `${c.pair} (${c.confidence})`), el('td', Math.abs(c.z) > 1.5 ? 'down' : 'muted', c.z), el('td', 'small', c.read), el('td', 'small muted', c.half_life ? c.half_life + 'h' : '–')); return tr;
    }));
    if (!(mr.cointegration || []).length) $('coint').append(el('caption', 'muted small', 'No cointegrated pairs at 90% right now.'));
  }

  // ---------------------------------------------------------------- v1.4 panels
  function renderPatterns(pm) {
    const sm = $('pm-summary'); sm.replaceChildren();
    if (!pm) { sm.append(el('p', 'muted small', 'Builds once a year of hourly history is loaded.')); return; }
    const c4 = (pm.combined || {})['4'] || {}, c24 = (pm.combined || {})['24'] || {};
    sm.append(el('div', 'big-sm ' + cls((c24.p_up ?? .5) - .5), `${pc(c24.p_up)} chance higher in 24h`),
      el('div', null, `4h: ${pc(c4.p_up)} · typical 24h move ${pct(c24.median)} (range ${pct(c24.p10)} to ${pct(c24.p90)})`),
      el('div', 'small muted', `${pm.k} matches (${Object.entries(pm.by_coin).map(([k, v]) => k.split('-')[0] + ' ' + v).join(', ')}) · $${Math.round(pm.current_usd_24h || 0).toLocaleString()} traded in 24h (${pm.volume_vs_normal}x normal)`));
    const [ctx, W, H] = cv('pm-shapes', 180); const all = [pm.current_shape, ...pm.top.map((t) => t.shape)].flat().filter((v) => v != null);
    const mn = Math.min(...all), mx = Math.max(...all); const y = (v) => 10 + (mx - v) / ((mx - mn) || 1) * (H - 20);
    const line = (arr, col, w) => { ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); arr.forEach((v, i) => { const x = 10 + i / (arr.length - 1) * (W - 20); i ? ctx.lineTo(x, y(v)) : ctx.moveTo(x, y(v)); }); ctx.stroke(); };
    pm.top.slice(0, 6).forEach((t) => line(t.shape, 'rgba(245,245,245,.35)', 1)); line(pm.current_shape, RED, 3); ctx.lineWidth = 1;
    const rows = [];
    [['All matches', pm.combined], ['Same coin', pm.own], ['Other coins', pm.cross]].forEach(([lab, g]) => { if (!g) return; const tr = el('tr'); tr.append(el('td', null, `${lab} (n≈${g.effective_n})`)); ['4', '24', '72'].forEach((h) => { const x = g[h] || {}; tr.append(el('td', cls((x.p_up ?? .5) - .5), `${pc(x.p_up)} · ${pct(x.mean)}`)); }); rows.push(tr); });
    const br = el('tr'); br.append(el('td', 'muted', 'Normal (base rate)')); ['4', '24', '72'].forEach((h) => br.append(el('td', 'muted', pc(pm.base_rate[h])))); rows.push(br);
    table('pm-table', ['Group', '4h', '24h', '72h'], rows);
    const u = pm.unlikeliness; const ub = $('pm-unlikely'); ub.replaceChildren();
    if (u) ub.append(el('div', 'edge-item ' + (u.tail_prob < 0.05 ? 'down' : ''), `24h move ${pct(u.move_24h)} is ${u.label}: moves this big happen ${pc(u.tail_prob, 1)} of days${u.happens_every_days ? ` (about 1 in ${u.happens_every_days} days)` : ''}; across all coins ${pc(u.all_coins_tail_prob, 1)}. Volume is in the ${pc(u.volume_percentile)} percentile.`));
    table('pm-top', ['Closest match', 'When', 'Similarity', 'Next 24h'], pm.top.slice(0, 5).map((t) => { const tr = el('tr'); tr.append(el('td', null, t.symbol.split('-')[0]), el('td', 'small', new Date(t.t * 1000).toLocaleDateString()), el('td', 'muted', t.similarity), el('td', cls(t.next_24h), pct(t.next_24h))); return tr; }));
  }
  function renderMultiscale(m, mr) {
    const w = $('wavelets'); w.replaceChildren(); const wv = m && m.wavelets;
    if (wv) { w.append(el('div', null, wv.read)); wv.scales.forEach((s) => { const row = el('div', 'part'); row.append(el('span', 'part-name', `${s.hours}h ${s.direction > 0 ? '▲' : s.direction < 0 ? '▼' : '·'}`)); const bar = el('div', 'prob'); const f = el('div', 'prob-fill ' + (s.direction >= 0 ? 'pos' : 'neg')); f.style.width = (s.energy_share * 100) + '%'; bar.append(f); row.append(bar, el('span', 'small muted', pc(s.energy_share))); w.append(row); }); }
    else w.append(el('p', 'muted small', '–'));
    const vp = m && m.volume_profile_7d; const [ctx, W, H] = cv('vprofile', 220);
    if (vp) { const n = vp.profile.length; const bh = H / n; vp.profile.forEach((v, i) => { const yy = H - (i + 1) * bh; const inVA = vp.edges[i] >= vp.value_low && vp.edges[i + 1] <= vp.value_high; ctx.fillStyle = inVA ? 'rgba(245,245,245,.7)' : 'rgba(120,120,120,.5)'; ctx.fillRect(0, yy, v * (W - 80), bh - 1); });
      const ypos = (p) => H - (p - vp.edges[0]) / (vp.edges[n] - vp.edges[0]) * H; [[vp.poc, RED, 'POC'], [vp.vwap, '#fff', 'VWAP']].forEach(([p, col, lab]) => { if (p == null) return; ctx.strokeStyle = col; ctx.beginPath(); ctx.moveTo(0, ypos(p)); ctx.lineTo(W - 80, ypos(p)); ctx.stroke(); ctx.fillStyle = col; ctx.font = '11px system-ui'; ctx.fillText(`${lab} ${fmt(p)}`, W - 78, ypos(p) + 4); });
      $('vp-text').textContent = `Price is ${vp.position} · ${pct(vp.price_vs_vwap)} vs VWAP · value area ${fmt(vp.value_low)} – ${fmt(vp.value_high)}`; }
    const inf = (mr && mr.information_flow) || {}; const ib = $('infoflow'); ib.replaceChildren();
    (inf.net || []).slice(0, 5).forEach((r) => ib.append(el('div', cls(r.net_bits), `${r.symbol.split('-')[0]}: ${r.net_bits > 0 ? 'leads' : 'follows'} (${r.net_bits} bits net)`)));
    (inf.pairs || []).slice(0, 3).forEach((p) => ib.append(el('div', 'small muted', `${p.from.split('-')[0]} → ${p.to.split('-')[0]}: ${p.bits} bits`)));
    if (!(inf.net || []).length) ib.append(el('p', 'muted small', 'Computed hourly.'));
    const mi = ((mr && mr.card) || {}).mutual_info || []; const mb = $('mutualinfo'); mb.replaceChildren(); const mm = Math.max(...mi.map((x) => x.bits), 1e-6);
    mi.slice(0, 10).forEach((x) => { const row = el('div', 'part'); row.append(el('span', 'part-name', x.feature)); const bar = el('div', 'prob'); const f = el('div', 'prob-fill pos'); f.style.width = (x.bits / mm * 100) + '%'; bar.append(f); row.append(bar); mb.append(row); });
    if (!mi.length) mb.append(el('p', 'muted small', 'After training.'));
  }
  function renderPerf(mr) {
    table('sched', ['Coin', 'Priority', 'Next run', 'Runs'], (mr.scheduler || []).slice(0, 10).map((r) => { const tr = el('tr'); tr.append(el('td', null, r.symbol.split('-')[0]), el('td', r.priority >= 3 ? 'up' : 'muted', r.priority), el('td', 'muted', r.next_in_s + 's'), el('td', 'muted', r.runs)); return tr; }));
    table('timings', ['Stage', 'Avg', 'Calls'], Object.entries(mr.timings || {}).map(([k, v]) => { const tr = el('tr'); tr.append(el('td', null, k), el('td', null, v.avg_ms >= 1000 ? (v.avg_ms / 1000).toFixed(1) + ' s' : v.avg_ms + ' ms'), el('td', 'muted', v.calls)); return tr; }));
  }

  async function load() {
    try {
      const r = await fetch(`/api/quant?symbol=${encodeURIComponent(symbol)}`, { credentials: 'same-origin' });
      if (!r.ok) return;
      const d = await r.json();
      $('q-sim').hidden = !d.simulated;
      const s = d.status || {}; $('q-status').textContent = `model: ${s.training || '–'}${s.last_infer ? ' · updated ' + new Date(s.last_infer * 1000).toLocaleTimeString() : ''}`;
      if (!d.quant_ok) return;
      if (d.state) { renderDecision(d.state); renderConformal(d.state.math, d.state.price); renderMath(d.state.math); renderPatterns(d.state.patterns); }
      else $('stance').textContent = 'Warming up…';
      renderOverview(d.overview || []);
      if (d.model) { renderCard(d.model); renderGraph(d.model.graph || {}); renderAdaptive(d.model); renderPrecision(d.model.card || {}, d.state && d.state.decision); renderMultiscale(d.state && d.state.math, d.model); renderPerf(d.model); }
      if (d.edge) renderEdge(d.edge);
    } catch (e) { /* retry */ }
  }
  load(); setInterval(load, 30000);
})();
