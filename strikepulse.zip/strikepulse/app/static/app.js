// Site-wide helpers (no inline scripts: CSP is script-src 'self').
document.querySelectorAll('input[type=range]').forEach((r) => {
  const out = r.parentElement.querySelector('output');
  if (!out) return;
  const sync = () => { out.textContent = r.value; };
  r.addEventListener('input', sync);
  sync();
});
document.querySelectorAll('form .btn-danger[formaction]').forEach((b) => {
  b.addEventListener('click', (e) => { if (!confirm('Are you sure?')) e.preventDefault(); });
});
const key = document.getElementById('apikey');
if (key) key.addEventListener('click', () => {
  navigator.clipboard && navigator.clipboard.writeText(key.textContent).then(() => { key.dataset.copied = '1'; key.title = 'Copied'; });
});
