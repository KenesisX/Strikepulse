// Dashboard: candlestick chart with EMA/Bollinger overlays, alert markers, live SSE feed.
(() => {
  const canvas = document.getElementById('chart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const symbol = canvas.dataset.symbol;
  const tf = canvas.dataset.tf;
  const focusTs = parseFloat(canvas.dataset.focus || '0');
  const tfSec = { '1m': 60, '5m': 300, '15m': 900, '1h': 3600 }[tf] || 300;
  let candles = [];
  let alerts = [];
  let hover = null;
  try { alerts = JSON.parse(document.getElementById('alerts-data').textContent || '[]'); } catch (e) { alerts = []; }

  document.getElementById('symbol-select')?.addEventListener('change', () => document.getElementById('chart-form').submit());

  // ---------- indicators
  const ema = (arr, p) => { const k = 2 / (p + 1); const out = []; arr.forEach((v, i) => out.push(i ? v * k + out[i - 1] * (1 - k) : v)); return out; };
  const boll = (arr, p = 20, m = 2) => arr.map((_, i) => {
    if (i < p - 1) return null;
    const s = arr.slice(i - p + 1, i + 1); const mean = s.reduce((a, b) => a + b, 0) / p;
    const sd = Math.sqrt(s.reduce((a, b) => a + (b - mean) ** 2, 0) / p); return [mean + m * sd, mean - m * sd];
  });
  const fmt = (p) => p >= 1000 ? p.toLocaleString(undefined, { maximumFractionDigits: 2 }) : p >= 1 ? p.toFixed(4) : p.toPrecision(4);

  function size() {
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth; const h = 360;
    canvas.width = w * dpr; canvas.height = h * dpr; canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return [w, h];
  }

  function draw() {
    const [W, H] = size();
    ctx.clearRect(0, 0, W, H);
    if (!candles.length) {
      ctx.fillStyle = '#8a8a8a'; ctx.font = '14px system-ui'; ctx.fillText('Waiting for candles… (detectors warm up as data arrives)', 20, H / 2); return;
    }
    const data = candles.slice(-140);
    const closes = data.map((c) => c.c);
    const allCloses = candles.map((c) => c.c);
    const off = candles.length - data.length;
    const e9 = ema(allCloses, 9).slice(off); const e21 = ema(allCloses, 21).slice(off); const bb = boll(allCloses).slice(off);
    const padR = 70, volH = 60, top = 10, priceH = H - volH - top - 18;
    let hi = Math.max(...data.map((c) => c.h)); let lo = Math.min(...data.map((c) => c.l));
    bb.forEach((b) => { if (b) { hi = Math.max(hi, b[0]); lo = Math.min(lo, b[1]); } });
    const pad = (hi - lo) * 0.06 || hi * 0.001; hi += pad; lo -= pad;
    const cw = (W - padR) / data.length;
    const y = (p) => top + (hi - p) / (hi - lo) * priceH;
    const x = (i) => i * cw + cw / 2;
    // grid + axis labels
    ctx.strokeStyle = '#222222'; ctx.fillStyle = '#7a7a7a'; ctx.font = '11px system-ui'; ctx.lineWidth = 1;
    for (let g = 0; g <= 4; g++) {
      const p = lo + (hi - lo) * g / 4; const yy = y(p);
      ctx.beginPath(); ctx.moveTo(0, yy); ctx.lineTo(W - padR, yy); ctx.stroke(); ctx.fillText(fmt(p), W - padR + 6, yy + 4);
    }
    // bollinger band fill
    ctx.fillStyle = 'rgba(160,160,160,.08)'; ctx.beginPath(); let started = false;
    bb.forEach((b, i) => { if (!b) return; if (!started) { ctx.moveTo(x(i), y(b[0])); started = true; } else ctx.lineTo(x(i), y(b[0])); });
    for (let i = bb.length - 1; i >= 0; i--) if (bb[i]) ctx.lineTo(x(i), y(bb[i][1]));
    ctx.closePath(); ctx.fill();
    // volume
    const vmax = Math.max(...data.map((c) => c.v)) || 1;
    data.forEach((c, i) => {
      const vh = c.v / vmax * (volH - 6); const buy = c.v ? c.bv / c.v : 0.5;
      ctx.fillStyle = buy >= 0.5 ? 'rgba(245,245,245,.30)' : 'rgba(225,29,46,.45)';
      ctx.fillRect(x(i) - cw * 0.35, H - 18 - vh, cw * 0.7, vh);
    });
    // candles
    data.forEach((c, i) => {
      const up = c.c >= c.o; ctx.strokeStyle = ctx.fillStyle = up ? '#f5f5f5' : '#e11d2e';
      ctx.beginPath(); ctx.moveTo(x(i), y(c.h)); ctx.lineTo(x(i), y(c.l)); ctx.stroke();
      const bt = y(Math.max(c.o, c.c)); const bh = Math.max(1, Math.abs(y(c.o) - y(c.c)));
      ctx.fillRect(x(i) - cw * 0.35, bt, Math.max(1, cw * 0.7), bh);
    });
    const line = (arr, color) => { ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.beginPath(); arr.forEach((v, i) => i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v))); ctx.stroke(); ctx.lineWidth = 1; };
    line(e21, '#e11d2e'); line(e9, '#ffffff');
    // alert markers
    const startT = data[0].t;
    alerts.filter((a) => a.symbol === symbol && a.kind === 'market' && a.timeframe === tf).forEach((a) => {
      const barStart = (a.meta && a.meta.bar_start) || (a.ts - tfSec);
      const i = Math.round((barStart - startT) / tfSec);
      if (i < 0 || i >= data.length) return;
      const c = data[i]; const up = a.direction > 0;
      const yy = up ? y(c.l) + 12 : y(c.h) - 12;
      ctx.fillStyle = up ? '#ffffff' : '#ff3347';
      ctx.beginPath();
      if (up) { ctx.moveTo(x(i), yy - 6); ctx.lineTo(x(i) - 6, yy + 5); ctx.lineTo(x(i) + 6, yy + 5); }
      else { ctx.moveTo(x(i), yy + 6); ctx.lineTo(x(i) - 6, yy - 5); ctx.lineTo(x(i) + 6, yy - 5); }
      ctx.fill();
      if (focusTs && Math.abs(a.ts - focusTs) < 1) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x(i), yy, 10, 0, Math.PI * 2); ctx.stroke(); ctx.lineWidth = 1; }
    });
    // last price line
    const last = data[data.length - 1].c; const ly = y(last);
    ctx.setLineDash([4, 4]); ctx.strokeStyle = '#555555'; ctx.beginPath(); ctx.moveTo(0, ly); ctx.lineTo(W - padR, ly); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = '#e11d2e'; ctx.fillRect(W - padR + 2, ly - 9, padR - 4, 18); ctx.fillStyle = '#ffffff'; ctx.fillText(fmt(last), W - padR + 6, ly + 4);
    // crosshair tooltip
    if (hover !== null && hover >= 0 && hover < data.length) {
      const c = data[hover]; ctx.strokeStyle = '#444444'; ctx.beginPath(); ctx.moveTo(x(hover), top); ctx.lineTo(x(hover), H - 18); ctx.stroke();
      const t = new Date(c.t * 1000);
      const txt = `${t.toLocaleString()}  O ${fmt(c.o)}  H ${fmt(c.h)}  L ${fmt(c.l)}  C ${fmt(c.c)}  V ${c.v.toFixed(2)}`;
      ctx.fillStyle = 'rgba(17,17,17,.94)'; const tw = ctx.measureText(txt).width + 16; ctx.fillRect(8, 8, tw, 22);
      ctx.fillStyle = '#e6edf3'; ctx.fillText(txt, 16, 23);
    }
    const first = data[0].o;
    document.getElementById('chart-last').textContent = '$' + fmt(last);
    const chg = (last / first - 1) * 100; const el = document.getElementById('chart-chg');
    el.textContent = `${chg >= 0 ? '+' : ''}${chg.toFixed(2)}% (${data.length} bars)`; el.className = 'small ' + (chg >= 0 ? 'up' : 'down');
  }

  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect(); const n = Math.min(candles.length, 140);
    hover = Math.floor((e.clientX - rect.left) / ((rect.width - 70) / n)); draw();
  });
  canvas.addEventListener('mouseleave', () => { hover = null; draw(); });
  window.addEventListener('resize', draw);

  async function load() {
    try {
      const r = await fetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&tf=${tf}&limit=400`, { credentials: 'same-origin' });
      if (r.ok) { candles = (await r.json()).candles; draw(); }
    } catch (e) { /* retry next tick */ }
  }
  load(); setInterval(load, 10000);

  // ---------- live feed (SSE)
  const feed = document.getElementById('feed');
  const dot = document.getElementById('live-dot');
  const emoji = (a) => a.kind === 'market' ? (a.direction > 0 ? '▲' : '▼') : ({ security: '🛡️', depeg: '⚠️', listing: '🆕', gas: '⛽', onchain: '🐋', test: '🔔', mover: (a.direction > 0 ? '🚀' : '📉') }[a.kind] || '🔔');
  function card(a) {
    const el = document.createElement('article');
    el.className = `alert-card dir-${a.direction > 0 ? 'up' : a.direction < 0 ? 'down' : 'flat'} kind-${a.kind}`;
    const head = document.createElement('div'); head.className = 'alert-head';
    const e1 = document.createElement('span'); e1.textContent = emoji(a);
    const t = document.createElement('span'); t.className = 'alert-title'; t.textContent = a.title;
    head.append(e1, t);
    if (a.score && a.kind !== 'gas') { const s = document.createElement('span'); s.className = 'score s' + Math.floor(a.score / 20) * 20; s.textContent = a.score; head.append(s); }
    const meta = document.createElement('div'); meta.className = 'alert-meta muted small';
    meta.textContent = `${a.price ? '$' + fmt(a.price) + ' · ' : ''}just now${a.timeframe ? ' · ' + a.timeframe : ''}`;
    const ul = document.createElement('ul'); ul.className = 'reasons';
    (a.reasons || []).slice(0, 5).forEach((r) => { const li = document.createElement('li'); li.textContent = r; ul.append(li); });
    el.append(head, meta, ul);
    if (a.kind === 'market') { const link = document.createElement('a'); link.className = 'small'; link.href = `/dashboard?symbol=${encodeURIComponent(a.symbol)}&tf=${a.timeframe}&alert=${a.id}`; link.textContent = 'View chart →'; el.append(link); }
    return el;
  }
  function notify(a) {
    if (!('Notification' in window) || Notification.permission !== 'granted' || !document.hidden) return;
    try { new Notification(a.title, { body: (a.reasons || []).slice(0, 2).join('\n'), icon: '/static/favicon.svg' }); } catch (e) { /* ignore */ }
  }
  if ('Notification' in window && Notification.permission === 'default') {
    feed?.addEventListener('click', () => Notification.requestPermission(), { once: true });
  }
  function connect() {
    const es = new EventSource('/api/stream');
    es.onopen = () => dot.classList.add('on');
    es.onerror = () => dot.classList.remove('on');
    es.addEventListener('alert', (ev) => {
      const a = JSON.parse(ev.data);
      document.getElementById('feed-empty')?.remove();
      feed.prepend(card(a));
      while (feed.children.length > 60) feed.lastElementChild.remove();
      alerts.push(a); draw(); notify(a);
    });
    es.addEventListener('prices', (ev) => {
      JSON.parse(ev.data).forEach((p) => {
        const row = document.querySelector(`#prices tr[data-sym="${CSS.escape(p.symbol)}"]`);
        if (!row) return;
        const px = row.querySelector('.px'); const old = parseFloat(px.dataset.v || '0');
        px.dataset.v = p.price; px.textContent = '$' + fmt(p.price);
        row.classList.remove('flash-up', 'flash-down');
        if (old) row.classList.add(p.price >= old ? 'flash-up' : 'flash-down');
        const set = (cls, v) => { const c = row.querySelector(cls); if (!c || v == null) return; c.textContent = `${v >= 0 ? '+' : ''}${(v * 100).toFixed(2)}%`; c.className = `r ${cls.slice(1)} ${v >= 0 ? 'up' : 'down'}`; };
        set('.c1', p.change_1h); set('.c24', p.change_24h);
      });
    });
  }
  connect();
})();
