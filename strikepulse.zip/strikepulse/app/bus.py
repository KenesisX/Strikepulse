"""In-process publish/subscribe used to fan events out to the dispatcher and live dashboards."""
from __future__ import annotations

import asyncio
import logging

log = logging.getLogger(__name__)


class Bus:
    def __init__(self) -> None:
        self._subs: set[asyncio.Queue] = set()
        self.published = 0

    def subscribe(self, maxsize: int = 1000) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subs.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subs.discard(q)

    def publish(self, item) -> None:
        self.published += 1
        for q in list(self._subs):
            try:
                q.put_nowait(item)
            except asyncio.QueueFull:
                log.warning("bus subscriber queue full; dropping event")

    @property
    def subscribers(self) -> int:
        return len(self._subs)


bus = Bus()
