from __future__ import annotations

import time

from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Alert
from ..security import current_user_optional
from ..web import render

router = APIRouter()


@router.get("/")
def landing(request: Request, user=Depends(current_user_optional), db: Session = Depends(get_db)):
    # social proof: recent alerts, but at least 15 minutes old so the free feed isn't real-time
    recent = db.scalars(select(Alert).where(Alert.kind.in_(["market", "depeg", "onchain", "listing"]),
                                            Alert.ts < time.time() - 900, Alert.score >= 60)
                        .order_by(Alert.ts.desc()).limit(6)).all()
    return render(request, "landing.html", user, recent=recent)


@router.get("/pricing")
def pricing(request: Request, user=Depends(current_user_optional)):
    return render(request, "pricing.html", user)


@router.get("/about")
def about(request: Request, user=Depends(current_user_optional)):
    return render(request, "about.html", user)


@router.get("/how-it-works")
def how(request: Request, user=Depends(current_user_optional)):
    return render(request, "how.html", user)


@router.get("/help")
def help_center(request: Request, user=Depends(current_user_optional)):
    return render(request, "help.html", user)


@router.get("/legal/{page}")
def legal(page: str, request: Request, user=Depends(current_user_optional)):
    if page not in ("terms", "privacy", "disclaimer"):
        page = "disclaimer"
    return render(request, f"legal/{page}.html", user)


@router.get("/performance")
def performance(request: Request, days: int = 30, user=Depends(current_user_optional)):
    from fastapi import HTTPException

    from ..config import settings
    from ..growth import performance_summary
    if not settings.public_performance and not (user and user.is_admin):
        raise HTTPException(404)
    days = max(1, min(days, 365))
    return render(request, "performance.html", user, perf=performance_summary(days), days=days)


@router.get("/robots.txt")
def robots():
    from fastapi.responses import PlainTextResponse

    from ..config import settings
    return PlainTextResponse(
        "User-agent: *\nAllow: /\nDisallow: /dashboard\nDisallow: /settings\nDisallow: /admin\nDisallow: /api/\n"
        f"Sitemap: {settings.base_url}/sitemap.xml\n")


@router.get("/sitemap.xml")
def sitemap():
    from fastapi.responses import Response

    from ..config import settings
    pages = ["/", "/about", "/pricing", "/how-it-works", "/help", "/markets", "/companions", "/performance", "/signup", "/legal/terms", "/legal/privacy",
             "/legal/disclaimer"]
    urls = "".join(f"<url><loc>{settings.base_url}{p}</loc></url>" for p in pages)
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{urls}</urlset>',
                    media_type="application/xml")


@router.get("/manifest.webmanifest")
def manifest():
    from fastapi.responses import JSONResponse

    from ..config import settings
    return JSONResponse({"name": settings.app_name, "short_name": settings.app_name[:12], "start_url": "/dashboard",
                         "display": "standalone", "background_color": "#07090d", "theme_color": "#07090d",
                         "icons": [{"src": "/static/favicon.svg", "sizes": "any", "type": "image/svg+xml"}]},
                        media_type="application/manifest+json")
