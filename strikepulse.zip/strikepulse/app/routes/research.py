from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..config import settings
from ..models import User
from ..plans import plan_for
from ..quant.betsim import STRATEGIES, simulate
from ..security import current_user
from ..services import get_services
from ..web import render

router = APIRouter()


def _symbols() -> list[str]:
    return [s for s in settings.symbols if s not in settings.stable_symbols]


@router.get("/simulator")
def simulator_page(request: Request, user: User = Depends(current_user)):
    return render(request, "simulator.html", user, symbols=_symbols(), strategies=STRATEGIES, full=plan_for(user).quant)


class SimRequest(BaseModel):
    symbol: str = "BTC-USD"
    bankroll: float = Field(1000, gt=0, le=1e9)
    stake: float = Field(100, gt=0, le=1e9)
    stake_mode: str = "fixed"
    hold: int = Field(24, ge=1, le=24 * 30)
    strategy: str = "every_day"
    threshold: float = Field(0.03, ge=0, le=1)
    entry_hour: int | None = Field(14, ge=0, le=23)
    entry_weekday: int | None = Field(None, ge=0, le=6)
    days: int = Field(365, ge=7, le=400)
    stop: float | None = Field(None, gt=0, lt=1)
    take: float | None = Field(None, gt=0, lt=10)


@router.post("/api/simulate")
def simulate_api(req: SimRequest, user: User = Depends(current_user)):
    if req.symbol not in _symbols() or req.strategy not in STRATEGIES or req.stake_mode not in ("fixed", "percent"):
        raise HTTPException(400, "invalid input")
    full = plan_for(user).quant
    if not full and (req.symbol != "BTC-USD" or req.days > 90):
        raise HTTPException(403, "Free plan: BTC-USD over the last 90 days. Upgrade to Pro for every coin and a full year.")
    svc = get_services()
    cs = svc.analytics.candles(req.symbol, 3600)
    probs = svc.quant.direction.oos_probs.get(req.symbol) if req.strategy == "quant" else None
    if req.strategy == "quant" and not probs:
        raise HTTPException(409, "The Quant Engine hasn't produced out-of-sample history for this coin yet.")
    res = simulate(cs, req.bankroll, req.stake, req.stake_mode, req.hold, req.strategy, req.threshold, req.entry_hour,
                   req.entry_weekday, req.days, stop=req.stop, take=req.take, quant_probs=probs,
                   paths=5000 if full else 1000)
    res["history_days_available"] = round(len(cs) / 24, 1)
    res["simulated_data"] = svc.quant.simulated
    return res


@router.get("/world")
def world_page(request: Request, symbol: str = "BTC-USD", user: User = Depends(current_user)):
    symbol = symbol if symbol in ("BTC-USD", "ETH-USD", "SOL-USD") else "BTC-USD"
    return render(request, "world.html", user, symbol=symbol, full=plan_for(user).quant)


@router.get("/api/macro")
def macro_api(symbol: str = "BTC-USD", user: User = Depends(current_user)):
    s = get_services().macro.summary(symbol if symbol in ("BTC-USD", "ETH-USD", "SOL-USD") else "BTC-USD")
    if not plan_for(user).quant:
        return {"locked": True, "status": s["status"], "simulated": s["simulated"],
                "conditions": {k: v for k, v in s["conditions"].items() if k == "fear_greed"}, "countries": s["countries"][:5]}
    return {"locked": False, **s}
