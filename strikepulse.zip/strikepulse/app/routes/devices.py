"""Companion devices: Galaxy/Wear OS and Apple watches, ESP32 and Raspberry Pi displays, browser
extension, desktop tray, Home Assistant, MicroPython boards.

Each device gets its own read-only token, so losing a watch never exposes the account. Devices with
no keyboard pair with a 6-digit code typed on the device (or entered in its config file).

Endpoints (token via `Authorization: Bearer <token>`, `X-Device-Token`, or `?token=`):
  POST /api/device/pair      {"code": "123456"}  ->  {"token": ..., "base_url": ...}
  GET  /api/device/status    compact JSON: prices, latest alerts, stance, market mood
  GET  /api/device/alerts    alerts newer than ?since=<unix ts>
  GET  /api/device/text      one plain-text line (e-ink, Siri Shortcuts, Tasker, Pebble...)
  GET  /api/device/me        token check
"""
from __future__ import annotations

import hashlib
import secrets
import time

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..models import DEVICE_KINDS, Device, User
from ..plans import plan_for
from ..security import RateLimiter, client_ip, current_user, current_user_optional, flash, verify_csrf
from ..services import get_services
from ..web import render

router = APIRouter()
pair_limiter = RateLimiter(10, 600)
status_limiter = RateLimiter(240, 60)       # per device: plenty for a 15 s refresh, stops runaway loops
API_VERSION = 1


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def _new_token() -> str:
    return "spd_" + secrets.token_urlsafe(24)


def _new_code(db: Session) -> str:
    for _ in range(20):
        code = f"{secrets.randbelow(10**6):06d}"
        if not db.scalar(select(Device).where(Device.pair_code == code, Device.pair_expires > time.time())):
            return code
    raise HTTPException(503, "Try again")


def _arm(db: Session, d: Device) -> None:
    token = _new_token()
    d.token_hash, d.token_prefix = _hash(token), token[:10]
    d.pending_token = token
    d.pair_code = _new_code(db)
    d.pair_expires = time.time() + settings.device_pair_minutes * 60


# ------------------------------------------------------------------ web pages
@router.get("/devices")
def devices_page(request: Request, new: int | None = None, user: User = Depends(current_user),
                 db: Session = Depends(get_db)):
    plan = plan_for(user)
    fresh = None
    now = time.time()
    for d in user.devices:
        if d.pending_token and d.pair_expires and d.pair_expires < now:
            d.pending_token, d.pair_code = None, None      # expired: never keep plaintext tokens around
    db.commit()
    if new:
        d = db.get(Device, new)
        if d and d.user_id == user.id and d.pending_token:
            fresh = d
    return render(request, "devices.html", user, devices=user.devices, kinds=DEVICE_KINDS, fresh=fresh,
                  max_devices=plan.max_devices, now=now)


@router.post("/devices", dependencies=[Depends(verify_csrf)])
async def add_device(request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    form = await request.form()
    plan = plan_for(user)
    if len(user.devices) >= plan.max_devices:
        flash(request, f"Your {plan.name} plan allows {plan.max_devices} devices. Remove one or upgrade.", "err")
        return RedirectResponse("/devices", 303)
    kind = form.get("kind") if form.get("kind") in DEVICE_KINDS else "other"
    name = (str(form.get("name") or "").strip() or DEVICE_KINDS[kind])[:60]
    d = Device(user_id=user.id, name=name, kind=kind, token_hash="pending-" + secrets.token_hex(16))
    _arm(db, d)
    db.add(d)
    db.commit()
    return RedirectResponse(f"/devices?new={d.id}", 303)


@router.post("/devices/{did}/rearm", dependencies=[Depends(verify_csrf)])
def rearm_device(did: int, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    d = db.get(Device, did)
    if not d or d.user_id != user.id:
        raise HTTPException(404)
    _arm(db, d)               # rotates the token: the old one stops working immediately
    db.commit()
    return RedirectResponse(f"/devices?new={d.id}", 303)


@router.post("/devices/{did}/revoke", dependencies=[Depends(verify_csrf)])
def revoke_device(did: int, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    d = db.get(Device, did)
    if d and d.user_id == user.id:
        db.delete(d)
        db.commit()
        flash(request, f"Removed {d.name}. Its token no longer works.", "ok")
    return RedirectResponse("/devices", 303)


@router.get("/companions")
def companions(request: Request, user=Depends(current_user_optional)):
    return render(request, "companions.html", user, kinds=DEVICE_KINDS)


# ------------------------------------------------------------------ device API
def device_from_request(request: Request, db: Session) -> Device:
    auth = request.headers.get("authorization", "")
    token = (auth[7:].strip() if auth.lower().startswith("bearer ") else "") or \
        request.headers.get("x-device-token", "") or request.query_params.get("token", "")
    if not token or not token.startswith("spd_"):
        raise HTTPException(401, "Device token required")
    d = db.scalar(select(Device).where(Device.token_hash == _hash(token)))
    if not d or not d.user or d.user.disabled:
        raise HTTPException(401, "Unknown or revoked device token")
    if not status_limiter.allow(f"dev:{d.id}"):
        raise HTTPException(429, "Slow down: refresh every 15 seconds or more")
    now = time.time()
    if d.pending_token:          # the device is using its token, so the one-time copy is no longer needed
        d.pending_token, d.pair_code = None, None
    if not d.last_seen or now - d.last_seen > 60:
        d.last_seen = now
    db.commit()
    return d


@router.post("/api/device/pair")
async def pair(request: Request, db: Session = Depends(get_db)):
    if not pair_limiter.allow(client_ip(request)):
        raise HTTPException(429, "Too many attempts. Wait 10 minutes.")
    try:
        body = await request.json()
    except Exception:
        body = {}
    code = "".join(ch for ch in str(body.get("code", "")) if ch.isdigit())
    if len(code) != 6:
        raise HTTPException(400, "Enter the 6-digit code from the Devices page")
    d = db.scalar(select(Device).where(Device.pair_code == code, Device.pair_expires > time.time()))
    if not d or not d.pending_token:
        raise HTTPException(404, "Code not found or expired. Make a new one on the Devices page.")
    token = d.pending_token
    d.pending_token, d.pair_code, d.pair_expires = None, None, None
    d.last_seen = time.time()
    db.commit()
    return {"token": token, "base_url": settings.base_url, "name": d.name, "kind": d.kind,
            "app": settings.app_name, "v": API_VERSION}


@router.get("/api/device/me")
def device_me(request: Request, db: Session = Depends(get_db)):
    d = device_from_request(request, db)
    return {"ok": True, "device": d.name, "kind": d.kind, "plan": plan_for(d.user).key, "v": API_VERSION}


def _symbols_for(user: User, requested: str | None, limit: int) -> list[str]:
    if requested:
        syms = []
        for s in requested.split(","):
            s = s.strip().upper()
            if s:
                syms.append(s if "-" in s else f"{s}-USD")
        return syms[:limit]
    watched = [w.symbol for w in user.watches if w.enabled]
    return (watched or ["BTC-USD", "ETH-USD", "SOL-USD"])[:limit]


def _price_row(sym: str, spark: bool) -> dict | None:
    svc = get_services()
    live = svc.engine.prices.get(sym, {})
    coin = svc.universe.get(sym)
    price = live.get("price") or (coin.price if coin else None)
    if price is None:
        return None
    row = {"s": sym.split("-")[0], "p": round(float(price), 8 if price < 1 else 2),
           "c1h": round(coin.ch1h, 2) if coin and coin.ch1h is not None else None,
           "c24": round(coin.ch24h, 2) if coin and coin.ch24h is not None else None,
           "live": bool(live.get("price"))}
    if spark and coin and coin.spark:
        xs = coin.spark[-24:]
        row["sp"] = [round(x, 8 if x < 1 else 2) for x in xs]
    return row


def _alerts_for(user: User, db: Session, limit: int, since: float = 0) -> list[dict]:
    from .dashboard import _user_alerts_query
    out = []
    for a in _user_alerts_query(db, user, max(limit, 1) * 2):
        if a.ts <= since:
            continue
        out.append({"id": a.id[:12], "t": int(a.ts), "k": a.kind, "s": a.symbol.split("-")[0], "d": a.direction,
                    "sc": a.score, "ti": a.title[:90], "p": a.price})
        if len(out) >= limit:
            break
    return out


@router.get("/api/device/status")
def device_status(request: Request, symbols: str | None = None, limit: int = 3, n: int = 6, spark: int = 0,
                  since: float = 0, db: Session = Depends(get_db)):
    d = device_from_request(request, db)
    user = d.user
    plan = plan_for(user)
    svc = get_services()
    syms = _symbols_for(user, symbols, max(1, min(n, 12)))
    prices = [r for r in (_price_row(s, bool(spark)) for s in syms) if r]
    alerts = _alerts_for(user, db, max(0, min(limit, 10)))
    stance = {}
    if plan.quant:
        for s in syms:
            st = svc.quant.state.get(s)
            if st:
                dec = st.get("decision", {})
                stance[s.split("-")[0]] = {"st": dec.get("stance"), "cf": round(float(dec.get("confidence") or 0), 2),
                                           "pu": round(float(st.get("p_up") or 0), 3)}
    fng = None
    try:
        series = svc.macro.series.get("fear_greed") or {}
        if series:
            fng = int(series[max(series)])
    except Exception:
        fng = None
    newest = alerts[0]["t"] if alerts else 0
    body = {"v": API_VERSION, "ts": int(time.time()), "app": settings.app_name, "plan": plan.key,
            "device": d.name, "prices": prices, "alerts": alerts, "stance": stance, "fng": fng,
            "new": sum(1 for a in alerts if a["t"] > since) if since else 0, "newest": newest,
            "refresh": 15 if plan.key != "free" else 60}
    attr = svc.universe.attribution
    if attr:
        body["src"] = attr["text"]
    return JSONResponse(body, headers={"Cache-Control": "no-store"})


@router.get("/api/device/alerts")
def device_alerts(request: Request, since: float = 0, limit: int = 10, db: Session = Depends(get_db)):
    d = device_from_request(request, db)
    return {"v": API_VERSION, "alerts": _alerts_for(d.user, db, max(1, min(limit, 25)), since)}


@router.get("/api/device/text")
def device_text(request: Request, symbols: str | None = None, db: Session = Depends(get_db)):
    d = device_from_request(request, db)
    parts = []
    for s in _symbols_for(d.user, symbols, 4):
        r = _price_row(s, False)
        if r:
            ch = f" {r['c24']:+.1f}%" if r.get("c24") is not None else ""
            parts.append(f"{r['s']} {r['p']:,.2f}{ch}" if r["p"] >= 1 else f"{r['s']} {r['p']:.6f}{ch}")
    al = _alerts_for(d.user, db, 1)
    if al:
        parts.append(f"! {al[0]['ti']}")
    return PlainTextResponse(" | ".join(parts) or "No data yet")
