from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request

from ..config import settings
from ..models import User
from ..plans import plan_for
from ..security import current_user
from ..services import get_services
from ..web import render

router = APIRouter()


def _symbols() -> list[str]:
    return [s for s in settings.symbols if s not in settings.stable_symbols]


@router.get("/quant")
def quant_page(request: Request, symbol: str = "BTC-USD", user: User = Depends(current_user)):
    symbol = symbol if symbol in _symbols() else "BTC-USD"
    p = plan_for(user)
    return render(request, "quant.html", user, symbol=symbol, symbols=_symbols(), quant_ok=p.quant, edge_ok=p.edge_lab)


@router.get("/api/quant")
def quant_api(symbol: str = "BTC-USD", user: User = Depends(current_user)):
    if symbol not in _symbols():
        raise HTTPException(404, "unknown symbol")
    svc = get_services()
    q = svc.quant
    q.scheduler.touch(symbol)
    q.watchers = {}
    for u in svc.dispatcher.users:
        for w in u.watches:
            q.watchers[w.symbol] = q.watchers.get(w.symbol, 0) + 1
    p = plan_for(user)
    st = q.state.get(symbol)
    report = q.model_report()
    out = {"symbol": symbol, "simulated": q.simulated, "quant_ok": p.quant, "edge_ok": p.edge_lab,
           "status": report["status"], "overview": q.overview() if p.quant else []}
    if not p.quant:
        # teaser: show that the engine is live, hide the calls
        out["teaser"] = {"coins": len(q.state), "model_status": report["card"].get("status"),
                         "oos_auc": (report["card"].get("oos") or {}).get("auc")}
        return out
    if st:
        out["state"] = {k: v for k, v in st.items() if k != "edge"}
        if p.edge_lab:
            out["edge"] = st["edge"]
    out["model"] = report
    return out
