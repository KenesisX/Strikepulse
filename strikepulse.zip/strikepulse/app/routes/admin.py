from __future__ import annotations

import time

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..engine.types import MarketEvent
from ..models import Alert, Delivery, User
from ..plans import PLANS
from ..security import admin_user, flash, verify_csrf
from ..services import get_services
from ..web import render

router = APIRouter(prefix="/admin")


@router.get("")
def admin_home(request: Request, user: User = Depends(admin_user), db: Session = Depends(get_db)):
    svc = get_services()
    counts = dict(db.execute(select(User.plan, func.count(User.id)).group_by(User.plan)).all())
    paying = {k: v for k, v in counts.items() if k != "free"}
    mrr = sum(PLANS[k].price * v for k, v in paying.items() if k in PLANS)
    day = time.time() - 86400
    alerts_24h = db.scalar(select(func.count(Alert.id)).where(Alert.ts > day)) or 0
    deliveries_24h = db.scalar(select(func.count(Delivery.id)).where(Delivery.created_at > day)) or 0
    failed_24h = db.scalar(select(func.count(Delivery.id)).where(Delivery.created_at > day, Delivery.ok.is_(False))) or 0
    users = db.scalars(select(User).order_by(User.created_at.desc()).limit(200)).all()
    return render(request, "admin.html", user, counts=counts, mrr=mrr, alerts_24h=alerts_24h,
                  deliveries_24h=deliveries_24h, failed_24h=failed_24h, users=users,
                  feed_status=svc.engine.feed_status, engine=svc.engine, dispatcher=svc.dispatcher,
                  telegram=svc.telegram, listings=svc.listings_status, bloom=svc.registry,
                  perf_status=svc.performance.status, promo_status=svc.promo.status,
                  version=__import__("app").__version__)


@router.post("/users/{uid}", dependencies=[Depends(verify_csrf)])
def admin_user_update(uid: int, request: Request, plan: str = Form(...), disabled: str = Form(""),
                      admin: str = Form(""), user: User = Depends(admin_user), db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if u and plan in PLANS:
        u.plan, u.plan_status = plan, "active"
        u.disabled = disabled == "on" and u.id != user.id
        u.is_admin = admin == "on" or u.id == user.id
        db.commit()
        get_services().dispatcher.invalidate()
        flash(request, f"Updated {u.email}.", "ok")
    return RedirectResponse("/admin", 303)


@router.post("/broadcast", dependencies=[Depends(verify_csrf)])
def broadcast(request: Request, kind: str = Form("depeg"), symbol: str = Form("USDT-USD"),
              title: str = Form(...), body: str = Form(""), score: int = Form(80),
              user: User = Depends(admin_user)):
    """Inject an event into the live pipeline (testing, or manual announcements)."""
    e = MarketEvent(kind=kind, symbol=symbol.upper(), title=title, score=score, direction=0,
                    reasons=[x for x in body.splitlines() if x.strip()] or ["Manual event from admin"],
                    meta={"manual": True, "addresses": [], "threshold": score if kind == "gas" else None,
                          "interval": 300})
    if kind == "market":
        e.timeframe = "15m"
        e.direction = 1
        e.signals = [{"detector": "ema_cross", "direction": 1, "strength": 1.0, "detail": "Manual test signal"},
                     {"detector": "volume_spike", "direction": 1, "strength": 1.0, "detail": "Manual test signal"}]
    get_services().engine.publish(e)
    flash(request, f"Published {kind} event to the pipeline.", "ok")
    return RedirectResponse("/admin", 303)


@router.post("/users/{uid}/reset-password", dependencies=[Depends(verify_csrf)])
def admin_reset_password(uid: int, request: Request, user: User = Depends(admin_user), db: Session = Depends(get_db)):
    """For sites without SMTP: generate a one-time temporary password to give the customer."""
    import secrets as _s

    from ..security import hash_password
    u = db.get(User, uid)
    if u:
        temp = _s.token_urlsafe(9)
        u.password_hash = hash_password(temp)
        db.commit()
        flash(request, f"Temporary password for {u.email}: {temp}  (shown once; ask them to change it in Settings)", "ok")
    return RedirectResponse("/admin", 303)


@router.get("/export.csv")
def export_users(user: User = Depends(admin_user), db: Session = Depends(get_db)):
    import csv
    import io

    from fastapi.responses import Response
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "email", "created_at", "plan", "plan_status", "stripe_customer_id", "watches",
                "telegram", "discord", "push", "email_alerts", "disabled"])
    for u in db.scalars(select(User).order_by(User.id)):
        w.writerow([u.id, u.email, u.created_at.isoformat() if u.created_at else "", u.plan, u.plan_status,
                    u.stripe_customer_id or "", len(u.watches), bool(u.telegram_chat_id), bool(u.discord_webhook),
                    bool(u.ntfy_topic), u.email_alerts, u.disabled])
    return Response(buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{settings.app_name.lower()}-users.csv"'})
