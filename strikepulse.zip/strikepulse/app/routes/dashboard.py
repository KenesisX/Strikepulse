from __future__ import annotations

import json
import re
import secrets
import time
from zoneinfo import available_timezones

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..alerts.channels import validate_outbound_url
from ..config import settings
from ..db import get_db
from ..engine.types import tf_label
from ..models import Alert, Delivery, OnchainWatch, User, Watch, new_api_key
from ..onchain.ethereum import GAS_THRESHOLDS
from ..plans import plan_for
from ..security import current_user, flash, verify_csrf
from ..services import get_services
from ..web import render

router = APIRouter()
ADDR_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")
TOPIC_RE = re.compile(r"^[A-Za-z0-9_-]{6,64}$")
TIMEZONES = sorted(z for z in available_timezones() if "/" in z and not z.startswith(("Etc/", "SystemV/")))


def _symbols() -> list[str]:
    return [s for s in settings.symbols if s not in settings.stable_symbols]


def _snapshot_symbols() -> list[str]:
    """Every other major coin: covered by the market-data snapshot (big-move alerts, devices, Markets page)."""
    live = set(_symbols())
    return [p for p in get_services().universe.pairs() if p not in live]


def _timeframe_labels() -> list[str]:
    return [tf_label(t) for t in settings.timeframes]


def _user_alerts_query(db: Session, user: User, limit: int, offset: int = 0):
    symbols = [w.symbol for w in user.watches]
    delivered = select(Delivery.alert_id).where(Delivery.user_id == user.id)
    q = (select(Alert).where(or_(Alert.id.in_(delivered),
                                 (Alert.kind == "market") & Alert.symbol.in_(symbols) & (Alert.score >= 50)))
         .order_by(Alert.ts.desc()).offset(offset).limit(limit))
    plan = plan_for(user)
    if plan.delay_seconds:
        q = q.where(Alert.ts <= time.time() - plan.delay_seconds)
    return db.scalars(q).all()


@router.get("/dashboard")
def dashboard(request: Request, symbol: str | None = None, tf: str | None = None, alert: str | None = None,
              user: User = Depends(current_user), db: Session = Depends(get_db)):
    svc = get_services()
    watched = [w.symbol for w in user.watches if w.symbol in settings.symbols] or _symbols()[:1]
    symbol = symbol if symbol in settings.symbols else (watched[0] if watched else "BTC-USD")
    tfs = _timeframe_labels()
    tf = tf if tf in tfs else ("5m" if "5m" in tfs else tfs[0])
    focus = db.get(Alert, alert) if alert else None
    alerts = _user_alerts_query(db, user, 25)
    alerts_json = json.dumps([a.to_dict() for a in alerts], default=str).replace("</", "<\\/")
    return render(request, "dashboard.html", user, symbol=symbol, tf=tf, tfs=tfs, symbols=_symbols(),
                  prices=svc.engine.snapshot(), alerts=alerts, alerts_json=alerts_json, focus=focus,
                  feed_status=svc.engine.feed_status, watches=user.watches,
                  snapshot_symbols=_snapshot_symbols())


# ------------------------------------------------------------------ watches
@router.post("/watches", dependencies=[Depends(verify_csrf)])
async def add_watch(request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    form = await request.form()
    plan = plan_for(user)
    symbol = str(form.get("symbol", "")).upper().strip()
    tfs = [t for t in form.getlist("timeframes") if t in plan.timeframes] or list(plan.timeframes[-1:])
    dets = [d for d in form.getlist("detectors") if d in plan.detectors]
    direction = form.get("direction") if form.get("direction") in ("both", "up", "down") else "both"
    try:
        min_score = max(plan.min_score_floor, min(100, int(form.get("min_score", 60))))
    except ValueError:
        min_score = 60
    snapshot = symbol in _snapshot_symbols()
    back = "/markets" if form.get("from") == "markets" else "/dashboard#watchlist"
    if symbol not in _symbols() and not snapshot:
        flash(request, f"{symbol or 'That symbol'} isn't tracked. Pick one from the list.", "err")
    elif len(user.watches) >= plan.max_watches:
        flash(request, f"Your {plan.name} plan allows {plan.max_watches} watches. Upgrade for more.", "err")
    elif any(w.symbol == symbol for w in user.watches):
        flash(request, f"{symbol} is already on your watchlist. Edit it instead.", "err")
    else:
        db.add(Watch(user_id=user.id, symbol=symbol, min_score=min_score, timeframes=",".join(tfs),
                     direction=direction, detectors=",".join(dets)))
        db.commit()
        get_services().dispatcher.invalidate()
        flash(request, f"Watching {symbol}." + (" It isn't live-streamed, so you'll get big-move alerts (from the market "
                                                 "snapshot) and see it on your devices; full detector alerts run on "
                                                 "live-streamed coins." if snapshot else ""), "ok")
    return RedirectResponse(back, 303)


@router.post("/watches/{wid}/update", dependencies=[Depends(verify_csrf)])
async def update_watch(wid: int, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    w = db.get(Watch, wid)
    if not w or w.user_id != user.id:
        return RedirectResponse("/dashboard", 303)
    form = await request.form()
    plan = plan_for(user)
    tfs = [t for t in form.getlist("timeframes") if t in plan.timeframes]
    if tfs:
        w.timeframes = ",".join(tfs)
    w.detectors = ",".join(d for d in form.getlist("detectors") if d in plan.detectors)
    if form.get("direction") in ("both", "up", "down"):
        w.direction = form.get("direction")
    try:
        w.min_score = max(plan.min_score_floor, min(100, int(form.get("min_score", w.min_score))))
    except ValueError:
        pass
    w.enabled = form.get("enabled") == "on"
    db.commit()
    get_services().dispatcher.invalidate()
    flash(request, f"Updated {w.symbol}.", "ok")
    return RedirectResponse("/dashboard#watchlist", 303)


@router.post("/watches/{wid}/delete", dependencies=[Depends(verify_csrf)])
def delete_watch(wid: int, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    w = db.get(Watch, wid)
    if w and w.user_id == user.id:
        db.delete(w)
        db.commit()
        get_services().dispatcher.invalidate()
        flash(request, f"Removed {w.symbol}.", "ok")
    return RedirectResponse("/dashboard#watchlist", 303)


# ------------------------------------------------------------------ on-chain
@router.get("/onchain")
def onchain_page(request: Request, user: User = Depends(current_user)):
    return render(request, "onchain.html", user, items=user.onchain_watches,
                  eth_enabled=bool(settings.eth_ws_url), status=get_services().engine.feed_status.get("ethereum"))


@router.post("/onchain", dependencies=[Depends(verify_csrf)])
def add_onchain(request: Request, kind: str = Form(...), address: str = Form(...), label: str = Form(""),
                min_usd: float = Form(0), user: User = Depends(current_user), db: Session = Depends(get_db)):
    plan = plan_for(user)
    address = address.strip()
    if kind not in ("wallet", "token", "pair"):
        flash(request, "Unknown watch type.", "err")
    elif not ADDR_RE.match(address):
        flash(request, "Enter a valid Ethereum address (0x + 40 hex characters).", "err")
    elif plan.onchain_wallets <= 0:
        flash(request, "On-chain tracking starts on the Pro plan.", "err")
    elif kind in ("token", "pair") and not plan.security:
        flash(request, "Token and LP-pair security monitoring is an Elite feature.", "err")
    elif len(user.onchain_watches) >= plan.onchain_wallets:
        flash(request, f"Your plan tracks up to {plan.onchain_wallets} addresses.", "err")
    elif any(o.address.lower() == address.lower() for o in user.onchain_watches):
        flash(request, "You're already watching that address.", "err")
    else:
        db.add(OnchainWatch(user_id=user.id, kind=kind, address=address.lower(), label=label.strip()[:80],
                            min_usd=max(0.0, min_usd)))
        db.commit()
        get_services().dispatcher.invalidate()
        flash(request, "Address added. The on-chain watcher picks it up within a minute.", "ok")
    return RedirectResponse("/onchain", 303)


@router.post("/onchain/{oid}/delete", dependencies=[Depends(verify_csrf)])
def delete_onchain(oid: int, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    o = db.get(OnchainWatch, oid)
    if o and o.user_id == user.id:
        db.delete(o)
        db.commit()
        get_services().dispatcher.invalidate()
    return RedirectResponse("/onchain", 303)


# ------------------------------------------------------------------ alerts
@router.get("/alerts")
def alerts_page(request: Request, page: int = 1, user: User = Depends(current_user), db: Session = Depends(get_db)):
    page = max(1, page)
    rows = _user_alerts_query(db, user, 50, (page - 1) * 50)
    return render(request, "alerts.html", user, alerts=rows, page=page)


# ------------------------------------------------------------------ settings
@router.get("/settings")
def settings_page(request: Request, user: User = Depends(current_user)):
    tg_link = (f"https://t.me/{settings.telegram_bot_username}?start={user.telegram_link_code}"
               if settings.telegram_bot_username else None)
    return render(request, "settings.html", user, tg_link=tg_link, timezones=TIMEZONES, gas_levels=GAS_THRESHOLDS,
                  suggested_topic="sp-" + secrets.token_hex(6))


@router.post("/settings", dependencies=[Depends(verify_csrf)])
async def save_settings(request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    form = await request.form()
    errors = []

    def opt(name: str) -> str:
        return str(form.get(name, "") or "").strip()

    discord = opt("discord_webhook")
    if discord:
        try:
            user.discord_webhook = validate_outbound_url(discord, "discord", resolve=False)
        except ValueError as e:
            errors.append(str(e))
    else:
        user.discord_webhook = None

    hook = opt("webhook_url")
    if hook:
        try:
            user.webhook_url = validate_outbound_url(hook, "webhook")
        except ValueError as e:
            errors.append(f"Webhook: {e}")
    else:
        user.webhook_url = None

    topic = opt("ntfy_topic")
    if topic and not TOPIC_RE.match(topic):
        errors.append("ntfy topic must be 6-64 letters, numbers, - or _ (make it hard to guess).")
    else:
        user.ntfy_topic = topic or None

    user.email_alerts = form.get("email_alerts") == "on"
    ae = opt("alert_email")
    user.alert_email = ae or None
    tz = opt("timezone")
    if tz in TIMEZONES or tz == "UTC":
        user.timezone = tz

    def hour(name: str):
        v = opt(name)
        return int(v) if v.isdigit() and 0 <= int(v) <= 23 else None

    user.quiet_start, user.quiet_end = hour("quiet_start"), hour("quiet_end")
    user.want_depeg = form.get("want_depeg") == "on"
    user.want_listings = form.get("want_listings") == "on"
    user.want_movers = form.get("want_movers") == "on" and plan_for(user).movers
    try:
        user.movers_min_pct = max(2.0, min(50.0, float(opt("movers_min_pct") or 8)))
    except ValueError:
        pass
    gb = opt("gas_below")
    user.gas_below = int(gb) if gb.isdigit() and int(gb) in GAS_THRESHOLDS else None
    db.commit()
    get_services().dispatcher.invalidate()
    for e in errors:
        flash(request, e, "err")
    if not errors:
        flash(request, "Settings saved.", "ok")
    return RedirectResponse("/settings", 303)


@router.post("/settings/test", dependencies=[Depends(verify_csrf)])
async def test_alert(request: Request, user: User = Depends(current_user)):
    results = await get_services().dispatcher.send_test(user)
    if request.headers.get("accept", "").startswith("application/json"):
        return JSONResponse(results)
    for ch, res in results.items():
        flash(request, f"{ch}: {res}", "ok" if res == "sent" else "err")
    return RedirectResponse("/settings", 303)


@router.post("/settings/telegram/unlink", dependencies=[Depends(verify_csrf)])
def tg_unlink(request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    user.telegram_chat_id = None
    user.telegram_link_code = secrets.token_hex(6)
    db.commit()
    get_services().dispatcher.invalidate()
    flash(request, "Telegram disconnected.", "ok")
    return RedirectResponse("/settings", 303)


@router.post("/settings/telegram/manual", dependencies=[Depends(verify_csrf)])
def tg_manual(request: Request, chat_id: str = Form(...), user: User = Depends(current_user),
              db: Session = Depends(get_db)):
    chat_id = chat_id.strip()
    if re.fullmatch(r"-?\d{3,20}", chat_id):
        user.telegram_chat_id = chat_id
        db.commit()
        get_services().dispatcher.invalidate()
        flash(request, "Telegram chat id saved. Send a test alert to confirm.", "ok")
    else:
        flash(request, "Chat ids are numbers (groups start with -).", "err")
    return RedirectResponse("/settings", 303)


@router.post("/settings/pause", dependencies=[Depends(verify_csrf)])
def pause(request: Request, hours: float = Form(0), user: User = Depends(current_user), db: Session = Depends(get_db)):
    user.paused_until = time.time() + hours * 3600 if hours > 0 else None
    db.commit()
    get_services().dispatcher.invalidate()
    flash(request, f"Alerts paused for {hours:g}h." if hours > 0 else "Alerts resumed.", "ok")
    return RedirectResponse("/settings", 303)


@router.post("/settings/apikey", dependencies=[Depends(verify_csrf)])
def regen_key(request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    user.api_key = new_api_key()
    db.commit()
    get_services().dispatcher.invalidate()
    flash(request, "New API key generated. Update anything that used the old one (it also signs webhooks).", "ok")
    return RedirectResponse("/settings#api", 303)


@router.post("/settings/password", dependencies=[Depends(verify_csrf)])
def change_password(request: Request, current: str = Form(...), new: str = Form(...),
                    user: User = Depends(current_user), db: Session = Depends(get_db)):
    from ..security import hash_password, verify_password
    if not verify_password(current, user.password_hash):
        flash(request, "Current password is wrong.", "err")
    elif len(new) < 8:
        flash(request, "New password must be at least 8 characters.", "err")
    else:
        user.password_hash = hash_password(new)
        db.commit()
        flash(request, "Password changed.", "ok")
    return RedirectResponse("/settings#account", 303)


@router.post("/settings/delete", dependencies=[Depends(verify_csrf)])
def delete_account(request: Request, confirm: str = Form(""), user: User = Depends(current_user),
                   db: Session = Depends(get_db)):
    if confirm.strip().lower() != user.email.lower():
        flash(request, "Type your email exactly to confirm deletion.", "err")
        return RedirectResponse("/settings#account", 303)
    if user.stripe_subscription_id and settings.billing_enabled:
        try:
            import stripe
            stripe.api_key = settings.stripe_secret_key
            stripe.Subscription.cancel(user.stripe_subscription_id)
        except Exception:
            pass
    db.delete(user)
    db.commit()
    get_services().dispatcher.invalidate()
    request.session.clear()
    return RedirectResponse("/?deleted=1", 303)
