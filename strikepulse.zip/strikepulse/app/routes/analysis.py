from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from ..analytics import target_odds
from ..config import settings
from ..models import User
from ..plans import plan_for
from ..security import current_user
from ..services import get_services
from ..web import render

router = APIRouter()
FREE_SYMBOL = "BTC-USD"


def _symbols() -> list[str]:
    return [s for s in settings.symbols if s not in settings.stable_symbols]


def allowed(user: User, symbol: str) -> bool:
    return plan_for(user).deep_analysis or symbol == FREE_SYMBOL


@router.get("/analysis")
def analysis_page(request: Request, symbol: str = FREE_SYMBOL, user: User = Depends(current_user)):
    symbol = symbol if symbol in _symbols() else FREE_SYMBOL
    return render(request, "analysis.html", user, symbol=symbol, symbols=_symbols(), unlocked=allowed(user, symbol),
                  free_symbol=FREE_SYMBOL)


@router.get("/api/analysis")
def analysis_api(symbol: str = FREE_SYMBOL, user: User = Depends(current_user)):
    if symbol not in _symbols():
        raise HTTPException(404, "unknown symbol")
    data = get_services().analytics.full(symbol, user.timezone or "UTC")
    if allowed(user, symbol):
        return {**data, "locked": False}
    # teaser: headline numbers only, the deep sections stay locked
    return {"symbol": symbol, "price": data["price"], "locked": True, "simulated": data["simulated"],
            "pulse": {"score": data["pulse"]["score"], "label": data["pulse"]["label"], "parts": []},
            "shifts": data["shifts"][:1], "rotation": data["rotation"], "trending": data["trending"],
            "hourly_candles": data["hourly_candles"], "flow": {"m30": {"buy_share": data["flow"]["m30"]["buy_share"]}}}


@router.get("/api/analysis/target")
def target_api(symbol: str, price: float = Query(..., gt=0), hours: float = Query(24, gt=0, le=720),
               user: User = Depends(current_user)):
    if symbol not in _symbols():
        raise HTTPException(404, "unknown symbol")
    if not allowed(user, symbol):
        raise HTTPException(403, "Upgrade to use the target calculator on this coin")
    svc = get_services()
    now = svc.engine.prices.get(symbol, {}).get("price")
    sigma = svc.analytics.sigma_hourly(symbol)
    if not now or not sigma:
        raise HTTPException(409, "Not enough data yet for this coin")
    return {"symbol": symbol, "price": now, "target": price, "hours": hours, **target_odds(now, price, sigma, hours)}
