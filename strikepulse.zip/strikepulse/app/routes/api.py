from __future__ import annotations

import asyncio
import json
import time

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..engine.detectors import DETECTOR_INFO
from ..engine.types import LABEL_TF
from ..models import Alert, User
from ..plans import plan_for
from ..security import current_user, current_user_optional
from ..services import get_services

router = APIRouter(prefix="/api")


@router.get("/health")
def health():
    svc = get_services()
    feeds = svc.engine.feed_status
    from .. import __version__
    return {"ok": True, "version": __version__, "uptime": round(time.time() - svc.engine.started), "trades": svc.engine.trades_processed,
            "feeds": {k: {"connected": v.get("connected"), "last_message": v.get("last_message")} for k, v in feeds.items()},
            "events": svc.bus.published, "sent": svc.dispatcher.sent, "failed": svc.dispatcher.failed}


@router.get("/prices")
def prices(user=Depends(current_user_optional)):
    return get_services().engine.snapshot()


@router.get("/candles")
def candles(symbol: str, tf: str = "5m", limit: int = Query(300, le=600), user: User = Depends(current_user)):
    interval = LABEL_TF.get(tf)
    if interval not in settings.timeframes:
        raise HTTPException(400, "unknown timeframe")
    return {"symbol": symbol, "tf": tf, "candles": get_services().engine.candles(symbol, interval, limit)}


@router.get("/performance")
def performance_api(days: int = 30, user=Depends(current_user_optional)):
    from ..growth import performance_summary
    if not settings.public_performance and not (user and user.is_admin):
        raise HTTPException(404)
    return performance_summary(max(1, min(days, 365)))


@router.get("/detectors")
def detectors():
    return DETECTOR_INFO


@router.get("/stream")
async def stream(request: Request, user: User = Depends(current_user)):
    """Server-Sent Events: the exact alerts this user receives, plus price ticks every 5s."""
    disp = get_services().dispatcher
    q = disp.open_stream(user.id)
    uid = user.id

    async def gen():
        try:
            yield "retry: 5000\n\n"
            last_px = 0.0
            while True:
                if await request.is_disconnected():
                    break
                try:
                    item = await asyncio.wait_for(q.get(), timeout=5)
                    yield f"event: alert\ndata: {json.dumps(item, default=str)}\n\n"
                except asyncio.TimeoutError:
                    pass
                if time.time() - last_px >= 5:
                    last_px = time.time()
                    yield f"event: prices\ndata: {json.dumps(get_services().engine.snapshot(), default=str)}\n\n"
        finally:
            disp.close_stream(uid, q)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"})


# ------------------------------------------------------------------ public REST API (Elite)
def api_user(x_api_key: str | None = Header(None), db: Session = Depends(get_db)) -> User:
    if not x_api_key:
        raise HTTPException(401, "Missing X-API-Key header")
    user = db.scalar(select(User).where(User.api_key == x_api_key))
    if not user or user.disabled:
        raise HTTPException(401, "Invalid API key")
    if not plan_for(user).api:
        raise HTTPException(403, "API access requires the Elite plan")
    return user


@router.get("/v1/alerts")
def v1_alerts(since: float = 0, symbol: str | None = None, kind: str | None = None, min_score: int = 0,
              limit: int = Query(100, le=500), user: User = Depends(api_user), db: Session = Depends(get_db)):
    q = select(Alert).where(Alert.ts > since, Alert.score >= min_score)
    if symbol:
        q = q.where(Alert.symbol == symbol.upper())
    if kind:
        q = q.where(Alert.kind == kind)
    rows = db.scalars(q.order_by(Alert.ts.desc()).limit(limit)).all()
    return {"alerts": [a.to_dict() for a in rows]}


@router.get("/v1/prices")
def v1_prices(user: User = Depends(api_user)):
    return {"prices": get_services().engine.snapshot()}


@router.get("/v1/candles")
def v1_candles(symbol: str, tf: str = "5m", limit: int = Query(300, le=600), user: User = Depends(api_user)):
    interval = LABEL_TF.get(tf)
    if interval not in settings.timeframes:
        raise HTTPException(400, "unknown timeframe")
    return {"symbol": symbol, "tf": tf, "candles": get_services().engine.candles(symbol.upper(), interval, limit)}


@router.get("/v1/watches")
def v1_watches(user: User = Depends(api_user)):
    return {"watches": [{"id": w.id, "symbol": w.symbol, "min_score": w.min_score, "timeframes": w.tf_list,
                         "direction": w.direction, "detectors": w.detector_list, "enabled": w.enabled}
                        for w in user.watches]}
