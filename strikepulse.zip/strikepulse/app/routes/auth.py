from __future__ import annotations

import re

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import User, Watch
from ..security import (client_ip, current_user_optional, flash, hash_password, login_limiter, signup_limiter,
                        verify_csrf, verify_password)
from ..services import get_services
from ..web import render

router = APIRouter()
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _safe_next(nxt: str | None) -> str:
    return nxt if nxt and nxt.startswith("/") and not nxt.startswith("//") else "/dashboard"


@router.get("/signup")
def signup_page(request: Request, user=Depends(current_user_optional)):
    if user:
        return RedirectResponse("/dashboard", 303)
    return render(request, "signup.html", user)


@router.post("/signup", dependencies=[Depends(verify_csrf)])
async def signup(request: Request, email: str = Form(...), password: str = Form(...), agree: str = Form(""),
           db: Session = Depends(get_db)):
    email = email.strip().lower()
    err = None
    if not signup_limiter.allow(client_ip(request)):
        err = "Too many sign-ups from your network. Try again later."
    elif not EMAIL_RE.match(email):
        err = "Enter a valid email address."
    elif len(password) < 8:
        err = "Password must be at least 8 characters."
    elif not agree:
        err = "Please accept the terms and risk disclaimer."
    elif db.scalar(select(User).where(func.lower(User.email) == email)):
        err = "An account with that email already exists."
    if err:
        return render(request, "signup.html", None, status_code=400, error=err, email=email)
    first = db.scalar(select(func.count(User.id))) == 0
    user = User(email=email, password_hash=hash_password(password), is_admin=first)
    db.add(user)
    db.flush()
    # starter watchlist so the dashboard is useful immediately
    for sym in ("BTC-USD", "ETH-USD"):
        db.add(Watch(user_id=user.id, symbol=sym, min_score=60, timeframes="15m"))
    db.commit()
    request.session.clear()
    request.session["uid"] = user.id
    get_services().dispatcher.invalidate()
    _welcome_email(user.email)
    flash(request, "Welcome! We added BTC and ETH to your watchlist. Connect a channel in Settings to get alerts.", "ok")
    return RedirectResponse("/dashboard", 303)


def _welcome_email(email: str) -> None:
    from ..config import settings as s
    if not s.email_enabled:
        return
    import asyncio

    from ..alerts.channels import send_email as _send
    text = (f"Welcome to {s.app_name}!\n\n1. Connect Telegram, Discord or phone push: {s.base_url}/settings\n"
            f"2. Add the coins you trade: {s.base_url}/dashboard\n3. Pick a minimum score (60 is a good start).\n\n"
            f"Alerts are automated market data, not financial advice.")
    html = "<p>" + text.replace("\n", "<br>") + "</p>"
    try:
        asyncio.get_running_loop().create_task(_send(s, email, f"Welcome to {s.app_name}", text, html))
    except RuntimeError:
        pass


@router.get("/login")
def login_page(request: Request, next: str | None = None, user=Depends(current_user_optional)):
    if user:
        return RedirectResponse(_safe_next(next), 303)
    return render(request, "login.html", None, next=next or "")


@router.post("/login", dependencies=[Depends(verify_csrf)])
def login(request: Request, email: str = Form(...), password: str = Form(...), next: str = Form(""),
          db: Session = Depends(get_db)):
    key = f"{client_ip(request)}:{email.strip().lower()}"
    if not login_limiter.allow(key):
        return render(request, "login.html", None, status_code=429, error="Too many attempts. Wait a few minutes.",
                      email=email, next=next)
    user = db.scalar(select(User).where(func.lower(User.email) == email.strip().lower()))
    if not user or not verify_password(password, user.password_hash) or user.disabled:
        return render(request, "login.html", None, status_code=400, error="Wrong email or password.",
                      email=email, next=next)
    request.session.clear()
    request.session["uid"] = user.id
    return RedirectResponse(_safe_next(next), 303)


@router.post("/logout", dependencies=[Depends(verify_csrf)])
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", 303)


# ------------------------------------------------------------------ password reset
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer  # noqa: E402

from ..alerts.channels import send_email  # noqa: E402
from ..config import settings  # noqa: E402

from ..security import RateLimiter  # noqa: E402

forgot_limiter = RateLimiter(5, 3600)
RESET_MAX_AGE = 3600


def _serializer() -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(settings.secret_key, salt="password-reset")


def make_reset_token(user: User) -> str:
    # includes a fingerprint of the current hash, so the link dies once the password changes
    return _serializer().dumps({"uid": user.id, "fp": user.password_hash[-16:]})


def read_reset_token(token: str, db: Session) -> User | None:
    try:
        data = _serializer().loads(token, max_age=RESET_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None
    user = db.get(User, int(data.get("uid", 0)))
    if not user or user.disabled or user.password_hash[-16:] != data.get("fp"):
        return None
    return user


@router.get("/forgot")
def forgot_page(request: Request):
    return render(request, "forgot.html", None)


@router.post("/forgot", dependencies=[Depends(verify_csrf)])
async def forgot(request: Request, email: str = Form(...), db: Session = Depends(get_db)):
    if not settings.email_enabled:
        return render(request, "forgot.html", None, sent=False,
                      error=f"Password reset by email isn't enabled on this site. Contact {settings.support_email}.")
    if forgot_limiter.allow(client_ip(request)):
        user = db.scalar(select(User).where(func.lower(User.email) == email.strip().lower()))
        if user and not user.disabled:
            link = f"{settings.base_url}/reset?token={make_reset_token(user)}"
            text = (f"Someone asked to reset the password for your {settings.app_name} account.\n\n"
                    f"Reset it here (valid for 1 hour): {link}\n\nIf this wasn't you, ignore this email.")
            html = (f"<p>Someone asked to reset the password for your {settings.app_name} account.</p>"
                    f"<p><a href=\"{link}\" style=\"background:#111;color:#fff;padding:10px 16px;border-radius:8px;"
                    f"text-decoration:none\">Reset password</a></p><p style=\"color:#666\">Valid for 1 hour. "
                    f"If this wasn't you, ignore this email.</p>")
            try:
                await send_email(settings, user.email, f"Reset your {settings.app_name} password", text, html)
            except Exception:
                import logging
                logging.getLogger(__name__).exception("reset email failed")
    # same answer whether or not the account exists (no account enumeration)
    return render(request, "forgot.html", None, sent=True)


@router.get("/reset")
def reset_page(request: Request, token: str = "", db: Session = Depends(get_db)):
    user = read_reset_token(token, db)
    return render(request, "reset.html", None, token=token, valid=user is not None)


@router.post("/reset", dependencies=[Depends(verify_csrf)])
def reset(request: Request, token: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = read_reset_token(token, db)
    if not user:
        return render(request, "reset.html", None, token=token, valid=False, status_code=400)
    if len(password) < 8:
        return render(request, "reset.html", None, token=token, valid=True, error="Use at least 8 characters.",
                      status_code=400)
    user.password_hash = hash_password(password)
    db.commit()
    request.session.clear()
    request.session["uid"] = user.id
    flash(request, "Password updated. You're logged in.", "ok")
    return RedirectResponse("/dashboard", 303)
