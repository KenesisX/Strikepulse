from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy.orm import Session

from .. import billing
from ..config import settings
from ..db import get_db
from ..models import User
from ..security import current_user, flash, verify_csrf
from ..services import get_services
from ..web import render

router = APIRouter()
log = logging.getLogger(__name__)


@router.get("/billing")
def billing_page(request: Request, success: int = 0, user: User = Depends(current_user)):
    if success:
        flash(request, "Thanks for subscribing! Your plan updates as soon as Stripe confirms the payment.", "ok")
    return render(request, "billing.html", user)


@router.post("/billing/checkout/{plan}", dependencies=[Depends(verify_csrf)])
async def checkout(plan: str, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    interval = "year" if (await request.form()).get("interval") == "year" else "month"
    if plan not in ("pro", "elite"):
        raise HTTPException(404)
    if settings.dev_fake_billing and not settings.billing_enabled:
        billing.fake_upgrade(user, plan)
        db.commit()
        get_services().dispatcher.invalidate()
        flash(request, f"[dev] Switched to {plan.title()} without payment (DEV_FAKE_BILLING=1).", "ok")
        return RedirectResponse("/billing", 303)
    if not settings.billing_enabled:
        flash(request, "Billing isn't configured yet. Add your Stripe keys to .env.", "err")
        return RedirectResponse("/pricing", 303)
    if user.stripe_subscription_id and user.plan != "free":
        # existing subscribers change plans in the Stripe portal (handles proration)
        return RedirectResponse(billing.create_portal(user), 303)
    try:
        return RedirectResponse(billing.create_checkout(user, plan, interval), 303)
    except Exception as e:
        log.exception("checkout failed")
        flash(request, f"Couldn't start checkout: {e}", "err")
        return RedirectResponse("/pricing", 303)


@router.post("/billing/portal", dependencies=[Depends(verify_csrf)])
def portal(request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if settings.dev_fake_billing and not settings.billing_enabled:
        billing.fake_upgrade(user, "free")
        user.plan = "free"
        db.commit()
        get_services().dispatcher.invalidate()
        flash(request, "[dev] Downgraded to Free.", "ok")
        return RedirectResponse("/billing", 303)
    try:
        return RedirectResponse(billing.create_portal(user), 303)
    except Exception as e:
        flash(request, f"Couldn't open the billing portal: {e}", "err")
        return RedirectResponse("/billing", 303)


@router.post("/billing/webhook")
async def webhook(request: Request, db: Session = Depends(get_db)):
    if not settings.stripe_webhook_secret:
        raise HTTPException(503, "Webhook secret not configured")
    payload = await request.body()
    try:
        event = billing.verify_event(payload, request.headers.get("stripe-signature", ""))
    except Exception:
        raise HTTPException(400, "Invalid signature")
    result = billing.handle_event(db, event)
    db.commit()
    get_services().dispatcher.invalidate()
    log.info("stripe %s: %s", event.get("type"), result)
    return JSONResponse({"received": True, "result": result})
