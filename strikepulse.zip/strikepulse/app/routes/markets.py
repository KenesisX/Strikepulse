"""Markets: every major cryptocurrency on one page, plus its JSON API."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse

from ..security import current_user_optional
from ..services import get_services
from ..web import render

router = APIRouter()


def spark_points(xs: list[float], w: int = 120, h: int = 32) -> str:
    if len(xs) < 2:
        return ""
    lo, hi = min(xs), max(xs)
    rng = (hi - lo) or 1.0
    step = w / (len(xs) - 1)
    return " ".join(f"{i * step:.1f},{h - (x - lo) / rng * (h - 2) - 1:.1f}" for i, x in enumerate(xs))


def fmt_big(v: float | None) -> str:
    if v is None:
        return "—"
    for div, suf in ((1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "K")):
        if abs(v) >= div:
            return f"${v / div:.2f}{suf}"
    return f"${v:,.0f}"


def fmt_price(p: float | None) -> str:
    if p is None:
        return "—"
    if p >= 1000:
        return f"${p:,.0f}"
    if p >= 1:
        return f"${p:,.2f}"
    if p >= 0.01:
        return f"${p:.4f}"
    return f"${p:.8f}".rstrip("0")


@router.get("/markets")
def markets(request: Request, q: str = "", user=Depends(current_user_optional)):
    uni = get_services().universe
    watched = {w.symbol for w in user.watches} if user else set()
    rows = []
    for c in uni.coins:
        d = c.to_dict()
        d.update(points=spark_points(c.spark), price_s=fmt_price(c.price), mcap_s=fmt_big(c.mcap),
                 vol_s=fmt_big(c.volume), watched=c.pair in watched,
                 up7=(c.spark[-1] >= c.spark[0]) if len(c.spark) > 1 else None)
        rows.append(d)
    return render(request, "markets.html", user, rows=rows, uni=uni, movers=uni.top_movers(5), q=q[:30])


@router.get("/api/universe")
def api_universe(spark: int = 0, limit: int = 250):
    uni = get_services().universe
    snap = uni.snapshot(spark=bool(spark))
    snap["coins"] = snap["coins"][: max(1, min(limit, 250))]
    return JSONResponse(snap, headers={"Cache-Control": "public, max-age=30"})
