"""Bet Simulator: "if an average person with $X bets $Y on coin Z for H hours using
strategy S, what happened over the last year, and what range of outcomes should they expect?"

* Replays the strategy on real hourly history (fees + slippage on every trade).
* Supports stop-loss / take-profit checked against each hour's high/low (stop wins ties,
  the conservative assumption).
* Compounds the bankroll trade by trade with a fixed-dollar or percent-of-bankroll stake.
* Monte Carlo: 5,000 bootstrap re-orderings/resamplings of the historical trades give the
  distribution of ending bankrolls, chance of profit, chance of losing half, and drawdowns.
* Timing map: the same bet entered at every hour of the day / day of the week, so you can
  see *when* this coin has historically been best to enter.
"""
from __future__ import annotations

import math
from datetime import datetime, timezone

import numpy as np

from ..engine.types import Candle

STRATEGIES = {
    "every_day": "Buy once a day at the chosen hour",
    "dip": "Buy after a 24h drop of at least X%",
    "momentum": "Buy after a 24h rise of at least X%",
    "quant": "Buy when the Quant Engine's out-of-sample probability is above 55%",
    "dca": "Dollar-cost average: buy every week, hold to the end",
}
WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def _r(x, n=4):
    if x is None:
        return None
    try:
        if not math.isfinite(x):
            return None
    except TypeError:
        return x
    return round(float(x), n)


def _trade(o, h, l, c, i, hold, stop, take, cost):
    """Return of a long trade entered at close[i] and held `hold` bars, with optional stop/take."""
    entry = c[i]
    end = min(i + hold, len(c) - 1)
    for j in range(i + 1, end + 1):
        if stop and l[j] <= entry * (1 - stop):
            return -stop - cost, j
        if take and h[j] >= entry * (1 + take):
            return take - cost, j
    return c[end] / entry - 1 - cost, end


def simulate(cs: list[Candle], bankroll: float = 1000, stake: float = 100, stake_mode: str = "fixed",
             hold: int = 24, strategy: str = "every_day", threshold: float = 0.03, entry_hour: int | None = 14,
             entry_weekday: int | None = None, days: int = 365, fee: float = 0.001, slippage: float = 0.0005,
             stop: float | None = None, take: float | None = None, quant_probs: dict[int, float] | None = None,
             paths: int = 5000, seed: int = 7) -> dict:
    cs = cs[-(days * 24 + hold + 30):]
    n = len(cs)
    if n < hold + 48:
        return {"error": "not enough history for this coin yet"}
    o = np.array([x.open for x in cs], float)
    h = np.array([x.high for x in cs], float)
    l = np.array([x.low for x in cs], float)
    c = np.array([x.close for x in cs], float)
    t = np.array([x.start for x in cs])
    dts = [datetime.fromtimestamp(x, timezone.utc) for x in t]
    hours = np.array([d.hour for d in dts])
    wdays = np.array([d.weekday() for d in dts])
    cost = 2 * (fee + slippage)
    r24 = np.full(n, np.nan)
    r24[24:] = c[24:] / c[:-24] - 1

    # ---- DCA is a different animal: accumulate, value at the end
    if strategy == "dca":
        invested, units, buys = 0.0, 0.0, 0
        for i in range(24, n):
            if hours[i] == (entry_hour if entry_hour is not None else 14) and wdays[i] == (entry_weekday if entry_weekday is not None else 0):
                amt = stake if stake_mode == "fixed" else bankroll * stake / 100
                units += amt * (1 - fee - slippage) / c[i]
                invested += amt
                buys += 1
        final = units * c[-1] * (1 - fee - slippage)
        return {"strategy": strategy, "description": STRATEGIES[strategy], "buys": buys, "invested": _r(invested, 2),
                "final_value": _r(final, 2), "profit": _r(final - invested, 2),
                "return": _r(final / invested - 1, 4) if invested else None,
                "buy_and_hold_return": _r(c[-1] / c[24] - 1, 4), "days": days}

    # ---- entry signals
    def is_entry(i):
        if i < 24 or i + 1 >= n:
            return False
        if entry_weekday is not None and wdays[i] != entry_weekday:
            return False
        if strategy == "every_day":
            return hours[i] == (entry_hour if entry_hour is not None else 14)
        if entry_hour is not None and hours[i] != entry_hour:
            return False
        if strategy == "dip":
            return r24[i] <= -abs(threshold)
        if strategy == "momentum":
            return r24[i] >= abs(threshold)
        if strategy == "quant":
            p = (quant_probs or {}).get(int(t[i]))
            return p is not None and p > 0.55
        return False

    trades = []
    i = 24
    while i < n - 1:
        if is_entry(i):
            ret, exit_i = _trade(o, h, l, c, i, hold, stop, take, cost)
            trades.append({"t": int(t[i]), "ret": ret, "exit": int(t[exit_i]), "hour": int(hours[i]), "wday": int(wdays[i])})
            i = exit_i + 1          # one position at a time
        else:
            i += 1
    if not trades:
        return {"error": "the strategy never triggered in this period; try a different threshold or hour",
                "strategy": strategy}
    rets = np.array([x["ret"] for x in trades])

    def run_bankroll(seq):
        b, peak, mdd, curve = bankroll, bankroll, 0.0, [bankroll]
        for r in seq:
            amt = min(b, stake) if stake_mode == "fixed" else b * stake / 100
            if amt <= 0.01:
                curve.append(b)
                continue
            b += amt * r
            peak = max(peak, b)
            mdd = min(mdd, b / peak - 1)
            curve.append(b)
        return b, mdd, curve

    final, mdd, curve = run_bankroll(rets)
    # Monte Carlo, vectorised across all paths: one numpy step per trade instead of per path×trade
    rng = np.random.default_rng(seed)
    draws = rng.choice(rets, size=(paths, len(rets)), replace=True)
    b = np.full(paths, float(bankroll))
    peak = b.copy()
    mdds = np.zeros(paths)
    for k in range(len(rets)):
        amt = np.minimum(b, stake) if stake_mode == "fixed" else b * stake / 100
        amt = np.where(amt > 0.01, amt, 0.0)
        b = b + amt * draws[:, k]
        peak = np.maximum(peak, b)
        mdds = np.minimum(mdds, b / peak - 1)
    finals = b
    wins, losses = rets[rets > 0], rets[rets <= 0]
    winrate = float((rets > 0).mean())
    avg_w = float(wins.mean()) if len(wins) else 0.0
    avg_l = float(losses.mean()) if len(losses) else 0.0
    b_ratio = avg_w / abs(avg_l) if avg_l else 0.0
    kelly = (winrate * b_ratio - (1 - winrate)) / b_ratio if b_ratio > 0 else 0.0
    streak = longest = 0
    for r in rets:
        streak = streak + 1 if r <= 0 else 0
        longest = max(longest, streak)
    hist, edges = np.histogram(finals, bins=30)

    # ---- timing map: same bet at every hour / weekday (non-overlapping per hour)
    def timing():
        by_h, by_d = {}, {}
        for hh in range(24):
            idx = np.where(hours[:-hold] == hh)[0]
            idx = idx[idx >= 24]
            rr = c[np.minimum(idx + hold, n - 1)] / c[idx] - 1 - cost
            if len(rr):
                by_h[hh] = {"win": _r(float((rr > 0).mean()), 3), "avg": _r(float(rr.mean()), 5), "n": int(len(rr))}
        for dd in range(7):
            idx = np.where((wdays[:-hold] == dd) & (hours[:-hold] == (entry_hour if entry_hour is not None else 14)))[0]
            idx = idx[idx >= 24]
            rr = c[np.minimum(idx + hold, n - 1)] / c[idx] - 1 - cost
            if len(rr):
                by_d[WEEKDAYS[dd]] = {"win": _r(float((rr > 0).mean()), 3), "avg": _r(float(rr.mean()), 5), "n": int(len(rr))}
        return by_h, by_d

    by_hour, by_day = timing()
    best_h = max(by_hour, key=lambda k: by_hour[k]["avg"]) if by_hour else None
    worst_h = min(by_hour, key=lambda k: by_hour[k]["avg"]) if by_hour else None
    ev_bet = float(rets.mean())
    stake_now = stake if stake_mode == "fixed" else bankroll * stake / 100
    return {
        "strategy": strategy, "description": STRATEGIES.get(strategy), "days": days, "hold_hours": hold,
        "trades": int(len(rets)), "trades_per_month": _r(len(rets) / max(1, days / 30), 1),
        "win_rate": _r(winrate, 3), "avg_win": _r(avg_w, 4), "avg_loss": _r(avg_l, 4),
        "expected_return_per_bet": _r(ev_bet, 5), "expected_dollars_per_bet": _r(ev_bet * stake_now, 2),
        "best_trade": _r(float(rets.max()), 4), "worst_trade": _r(float(rets.min()), 4), "longest_losing_streak": int(longest),
        "kelly_fraction": _r(max(0.0, kelly), 3),
        "historical": {"final_bankroll": _r(final, 2), "return": _r(final / bankroll - 1, 4), "max_drawdown": _r(mdd, 4),
                       "curve": [_r(x, 2) for x in curve[:: max(1, len(curve) // 300)]]},
        "monte_carlo": {"paths": paths, "mean_final": _r(float(finals.mean()), 2), "p5": _r(float(np.percentile(finals, 5)), 2),
                        "p25": _r(float(np.percentile(finals, 25)), 2), "median": _r(float(np.median(finals)), 2),
                        "p75": _r(float(np.percentile(finals, 75)), 2), "p95": _r(float(np.percentile(finals, 95)), 2),
                        "prob_profit": _r(float((finals > bankroll).mean()), 3),
                        "prob_lose_half": _r(float((finals <= bankroll * 0.5).mean()), 3),
                        "median_max_drawdown": _r(float(np.median(mdds)), 4),
                        "histogram": {"counts": hist.tolist(), "edges": [_r(e, 2) for e in edges]}},
        "buy_and_hold_return": _r(c[-1] / c[24] - 1, 4),
        "timing": {"by_hour": by_hour, "by_weekday": by_day, "best_hour_utc": best_h, "worst_hour_utc": worst_h},
        "costs": {"fee_per_side": fee, "slippage_per_side": slippage},
    }
