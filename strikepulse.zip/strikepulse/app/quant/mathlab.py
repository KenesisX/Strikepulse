"""Math Lab: classical and modern quantitative tools, implemented from first principles.

kalman_trend      local-linear-trend Kalman filter: denoised level, slope and its t-stat
ewma_vol / garch  volatility: RiskMetrics EWMA (look-ahead-free features) and GARCH(1,1) MLE forecasts
hurst_dfa         detrended fluctuation analysis: H>0.5 persistent/trending, H<0.5 mean-reverting
perm_entropy      Bandt-Pompe permutation entropy: low = structured/predictable, ~1 = pure noise
bocpd             Bayesian online change-point detection (Adams & MacKay 2007), Student-t model
ou_fit            Ornstein-Uhlenbeck fit: mean-reversion speed, half-life, equilibrium, z-score
hawkes_fit        self-exciting point process on trade arrivals: branching ratio = herding/cascades
dominant_cycle    FFT spectral peak of detrended price: cycle length, strength, current phase
cointegration     Engle-Granger + ADF on every coin pair: mean-reverting spreads and their z-score
AdaptiveConformal adaptive conformal inference (Gibbs & Candès 2021): price ranges whose hit rate
                  is held at the target (e.g. 95%) even as the market changes
"""
from __future__ import annotations

import math
from collections import deque
from itertools import combinations, permutations

import numpy as np


def _r(x, n=4):
    if x is None:
        return None
    try:
        if not math.isfinite(x):
            return None
    except TypeError:
        return x
    return round(float(x), n)


# ============================================================================ Kalman
def kalman_trend(prices: np.ndarray, calib: int = 300):
    """Local linear trend on log price. Noise levels are estimated from the first `calib`
    bars only, so later values never depend on the future."""
    y = np.log(np.maximum(np.asarray(prices, float), 1e-12))
    n = len(y)
    if n < 30:
        return None
    d = np.diff(y[: min(calib, n)])
    var = float(np.var(d)) or 1e-8
    R, Ql, Qs = var * 0.5, var * 0.25, var * 0.0025
    x = np.array([y[0], 0.0])
    P = np.eye(2) * var
    F = np.array([[1.0, 1.0], [0.0, 1.0]])
    Q = np.diag([Ql, Qs])
    level, slope, sstd = np.empty(n), np.empty(n), np.empty(n)
    for t in range(n):
        x = F @ x
        P = F @ P @ F.T + Q
        S = P[0, 0] + R
        K = P[:, 0] / S
        x = x + K * (y[t] - x[0])
        P = P - np.outer(K, P[0, :])
        level[t], slope[t], sstd[t] = x[0], x[1], math.sqrt(max(P[1, 1], 1e-18))
    return level, slope, sstd


# ============================================================================ volatility
def ewma_vol(returns: np.ndarray, lam: float = 0.94) -> np.ndarray:
    r = np.nan_to_num(np.asarray(returns, float))
    out = np.empty(len(r))
    v = float(np.var(r[:50])) if len(r) >= 50 else (float(np.var(r)) or 1e-8)
    for i, x in enumerate(r):
        out[i] = math.sqrt(v)
        v = lam * v + (1 - lam) * x * x
    return out


def garch_fit(returns: np.ndarray) -> dict | None:
    """GARCH(1,1) by maximum likelihood (Gaussian), with multi-step variance forecasts."""
    from scipy.optimize import minimize
    r = np.asarray(returns, float)
    r = r[np.isfinite(r)]
    if len(r) < 200:
        return None
    r = r - r.mean()
    v0 = r.var()

    from scipy.signal import lfilter
    r2 = np.concatenate([[v0], r[:-1] ** 2])

    def nll(p):
        w, a, b = p
        if w <= 0 or a < 0 or b < 0 or a + b >= 0.999:
            return 1e10
        # s2[t] = w + a*r[t-1]^2 + b*s2[t-1]  → one IIR filter call in C instead of a Python loop
        drive = w + a * r2
        drive[0] = v0
        s2, _ = lfilter([1.0], [1.0, -b], drive, zi=[0.0])
        s2[0] = v0
        s2 = np.maximum(s2, 1e-18)
        return 0.5 * float(np.sum(np.log(s2) + r * r / s2))

    best = None
    for a0, b0 in ((0.08, 0.88), (0.15, 0.6)):   # second start only if the first looks degenerate
        res = minimize(nll, [v0 * (1 - a0 - b0), a0, b0], method="Nelder-Mead",
                       options={"maxiter": 350, "xatol": 1e-9, "fatol": 1e-4})
        if best is None or res.fun < best.fun:
            best = res
        if 0.3 < best.x[1] + best.x[2] < 0.995:
            break
    w, a, b = best.x
    s2 = v0
    for x in r:
        s2 = w + a * x * x + b * s2
    V = w / max(1e-12, 1 - a - b)

    def horizon(h):
        tot = 0.0
        for k in range(1, h + 1):
            tot += V + (a + b) ** (k - 1) * (s2 - V)
        return math.sqrt(max(tot, 0))

    return {"omega": _r(w, 10), "alpha": _r(a, 4), "beta": _r(b, 4), "persistence": _r(a + b, 4),
            "half_life_bars": _r(math.log(0.5) / math.log(a + b), 1) if 0 < a + b < 1 else None,
            "sigma_next": _r(math.sqrt(s2), 6), "sigma_long_run": _r(math.sqrt(V), 6),
            "sigma_1": _r(horizon(1), 6), "sigma_4": _r(horizon(4), 6), "sigma_24": _r(horizon(24), 6)}


# ============================================================================ fractal / entropy
def hurst_dfa(returns: np.ndarray, scales=(8, 16, 32, 64, 128)) -> float | None:
    r = np.asarray(returns, float)
    r = r[np.isfinite(r)]
    if len(r) < max(scales) * 2:
        return None
    prof = np.cumsum(r - r.mean())
    F = []
    for s in scales:
        n = len(prof) // s
        segs = prof[: n * s].reshape(n, s)
        tt = np.arange(s)
        A = np.vstack([tt, np.ones(s)]).T
        coef = np.linalg.lstsq(A, segs.T, rcond=None)[0]
        resid = segs - (A @ coef).T
        F.append(math.sqrt(float((resid ** 2).mean())))
    h = np.polyfit(np.log(scales), np.log(np.maximum(F, 1e-18)), 1)[0]
    return float(h)


_PATTERNS = {p: i for i, p in enumerate(permutations(range(4)))}


def perm_entropy_series(x: np.ndarray, m: int = 4, window: int = 48) -> np.ndarray:
    """Rolling normalised permutation entropy (vectorised)."""
    x = np.asarray(x, float)
    n = len(x)
    out = np.full(n, np.nan)
    if n < window + m:
        return out
    view = np.lib.stride_tricks.sliding_window_view(x, m)
    ranks = np.argsort(view, axis=1)
    mult = m ** np.arange(m)[::-1]
    raw = ranks @ mult
    uniq = {int(k): i for i, k in enumerate(sorted({int(sum(p[j] * mult[j] for j in range(m))) for p in permutations(range(m))}))}
    codes = np.array([uniq[int(c)] for c in raw])
    K = len(uniq)
    onehot = np.zeros((len(codes) + 1, K))
    onehot[np.arange(1, len(codes) + 1), codes] = 1
    cum = np.cumsum(onehot, axis=0)
    w = window - m + 1
    for i in range(w, len(codes) + 1):
        cnt = cum[i] - cum[i - w]
        p = cnt[cnt > 0] / w
        out[i + m - 2] = float(-(p * np.log(p)).sum() / math.log(K))
    return out


# ============================================================================ change points
def bocpd(x: np.ndarray, hazard: float = 1 / 120, rmax: int = 200, mu0=0.0, kappa0=1.0, alpha0=1.0, beta0=1.0):
    """Adams & MacKay BOCPD with a Normal-Gamma prior (Student-t predictive).
    Returns (prob of a change within the last 5 bars, MAP run length) per step.
    Speed: alpha and kappa depend only on run length, so the gamma-function terms are
    precomputed once; each step is a handful of vector operations."""
    from scipy.special import gammaln
    x = np.nan_to_num(np.asarray(x, float))
    n = len(x)
    cp = np.zeros(n)
    rl = np.zeros(n, int)
    k = np.arange(rmax + 1)
    al_k = alpha0 + 0.5 * k
    ka_k = kappa0 + k
    df_k = 2 * al_k
    const_k = gammaln((df_k + 1) / 2) - gammaln(df_k / 2) - 0.5 * np.log(np.pi * df_k)
    R = np.array([1.0])
    mu = np.array([mu0])
    be = np.array([beta0])
    for t in range(n):
        m = len(R)
        al, ka, df = al_k[:m], ka_k[:m], df_k[:m]
        scale = np.sqrt(be * (ka + 1) / (al * ka))
        z = (x[t] - mu) / scale
        logpdf = const_k[:m] - np.log(scale) - (df + 1) / 2 * np.log1p(z * z / df)
        pred = np.exp(logpdf - logpdf.max())
        rp = R * pred
        change = float(rp.sum() * hazard)
        R = np.empty(m + 1)
        R[0] = change
        R[1:] = rp * (1 - hazard)
        R /= R.sum() or 1
        be_new = be + ka * (x[t] - mu) ** 2 / (2 * (ka + 1))
        mu_new = (ka * mu + x[t]) / (ka + 1)
        mu = np.concatenate([[mu0], mu_new])
        be = np.concatenate([[beta0], be_new])
        if len(R) > rmax:
            R, mu, be = R[:rmax], mu[:rmax], be[:rmax]
            R /= R.sum()
        cp[t] = float(R[:5].sum())
        rl[t] = int(np.argmax(R))
    return cp, rl


# ============================================================================ mean reversion
def ou_fit(log_prices: np.ndarray) -> dict | None:
    x = np.asarray(log_prices, float)
    if len(x) < 50:
        return None
    dx, xl = np.diff(x), x[:-1]
    A = np.vstack([np.ones(len(xl)), xl]).T
    (a, b), *_ = np.linalg.lstsq(A, dx, rcond=None)
    resid = dx - (a + b * xl)
    if b >= 0:
        return {"mean_reverting": False, "theta": _r(-b, 6), "half_life": None, "z": None}
    theta = -b
    mu = -a / b
    sd_eq = float(resid.std() / math.sqrt(max(1e-12, 2 * theta - theta * theta)))
    return {"mean_reverting": True, "theta": _r(theta, 6), "half_life": _r(math.log(2) / theta, 1),
            "equilibrium": _r(math.exp(mu), 8), "z": _r((x[-1] - mu) / sd_eq if sd_eq > 0 else 0, 2)}


# ============================================================================ Hawkes
def hawkes_fit(times: np.ndarray) -> dict | None:
    """Exponential-kernel Hawkes MLE. Branching ratio n = alpha/beta: share of trades
    triggered by earlier trades (herding / cascades) rather than arriving independently."""
    from scipy.optimize import minimize
    t = np.sort(np.asarray(times, float))
    if len(t) < 200:
        return None
    t = t - t[0]
    T = float(t[-1]) or 1.0
    dt = np.diff(t)

    def nll(p):
        mu, a, b = np.exp(p)
        if a >= b:
            return 1e12
        A = np.zeros(len(t))
        decay = np.exp(-b * dt)
        for i in range(1, len(t)):
            A[i] = decay[i - 1] * (1 + A[i - 1])
        lam = mu + a * A
        comp = mu * T + (a / b) * float(np.sum(1 - np.exp(-b * (T - t))))
        return comp - float(np.sum(np.log(np.maximum(lam, 1e-12))))

    base = len(t) / T
    res = minimize(nll, np.log([base * 0.5, 0.5, 1.0]), method="Nelder-Mead", options={"maxiter": 400})
    mu, a, b = np.exp(res.x)
    n = a / b
    return {"baseline_rate": _r(mu, 4), "branching_ratio": _r(n, 3), "decay_s": _r(1 / b, 2), "events": int(len(t)),
            "state": "cascading / herding" if n > 0.7 else "moderate clustering" if n > 0.4 else "independent flow"}


# ============================================================================ cycles
def dominant_cycle(prices: np.ndarray, min_p: int = 6, max_p: int = 168) -> dict | None:
    y = np.log(np.maximum(np.asarray(prices, float), 1e-12))
    n = len(y)
    if n < 128:
        return None
    y = y[-512:] if n > 512 else y
    n = len(y)
    tt = np.arange(n)
    y = y - np.polyval(np.polyfit(tt, y, 1), tt)
    win = np.hanning(n)
    spec = np.fft.rfft(y * win)
    freqs = np.fft.rfftfreq(n)
    power = np.abs(spec) ** 2
    mask = (freqs > 0) & (freqs >= 1 / max_p) & (freqs <= 1 / min_p)
    if not mask.any():
        return None
    k = np.argmax(np.where(mask, power, 0))
    period = 1 / freqs[k]
    strength = float(power[k] / power[mask].sum())
    phase = float(np.angle(spec[k]))
    pos = ((2 * math.pi * freqs[k] * (n - 1) + phase) % (2 * math.pi)) / (2 * math.pi)
    where = "near peak" if pos < 0.125 or pos > 0.875 else "falling" if pos < 0.375 else "near trough" if pos < 0.625 else "rising"
    return {"period_bars": _r(period, 1), "strength": _r(strength, 3), "phase": _r(pos, 3), "position": where}


# ============================================================================ cointegration
def adf_t(series: np.ndarray, lags: int = 1) -> float:
    y = np.asarray(series, float)
    dy = np.diff(y)
    X = [y[lags:-1]]
    for i in range(1, lags + 1):
        X.append(dy[lags - i:-i])
    X.append(np.ones(len(dy) - lags))
    X = np.vstack(X).T
    Y = dy[lags:]
    beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
    resid = Y - X @ beta
    s2 = resid @ resid / max(1, len(Y) - X.shape[1])
    cov = s2 * np.linalg.pinv(X.T @ X)
    return float(beta[0] / math.sqrt(max(cov[0, 0], 1e-18)))


def cointegration(closes: dict[str, np.ndarray], window: int = 720) -> list[dict]:
    out = []
    logs = {s: np.log(np.maximum(c[-window:], 1e-12)) for s, c in closes.items() if len(c) >= 300}
    for a, b in combinations(sorted(logs), 2):
        n = min(len(logs[a]), len(logs[b]))
        y, x = logs[a][-n:], logs[b][-n:]
        A = np.vstack([np.ones(n), x]).T
        (c0, hedge), *_ = np.linalg.lstsq(A, y, rcond=None)
        spread = y - (c0 + hedge * x)
        t = adf_t(spread)
        if t < -3.04:     # Engle-Granger 10% critical value for two series (~-3.04); 5% ≈ -3.34
            ou = ou_fit(spread)
            z = float((spread[-1] - spread.mean()) / (spread.std() or 1))
            out.append({"pair": f"{a.split('-')[0]}/{b.split('-')[0]}", "a": a, "b": b, "hedge_ratio": _r(hedge, 3),
                        "adf_t": _r(t, 2), "confidence": "95%" if t < -3.34 else "90%", "z": _r(z, 2),
                        "half_life": (ou or {}).get("half_life"),
                        "read": (f"{a.split('-')[0]} rich vs {b.split('-')[0]}" if z > 1.5 else
                                 f"{a.split('-')[0]} cheap vs {b.split('-')[0]}" if z < -1.5 else "near fair value")})
    return sorted(out, key=lambda r: r["adf_t"])[:8]


# ============================================================================ conformal
class AdaptiveConformal:
    """Price ranges with a self-correcting hit rate. Score = |realised return| / predicted sigma.
    The interval uses the (1-alpha_t) quantile of recent scores; after each outcome
    alpha_t += gamma * (alpha - miss), so coverage converges to 1-alpha even under drift."""

    def __init__(self, alpha: float = 0.05, gamma: float = 0.005, maxlen: int = 1000):
        self.alpha, self.gamma = alpha, gamma
        self.alpha_t = alpha
        self.scores: deque = deque(maxlen=maxlen)
        self.hits: deque = deque(maxlen=500)

    def seed(self, returns: np.ndarray, sigmas: np.ndarray) -> None:
        for r, s in zip(returns, sigmas):
            if s > 0 and np.isfinite(r):
                self.scores.append(abs(r) / s)

    def quantile(self) -> float | None:
        if len(self.scores) < 50:
            return None
        a = min(max(self.alpha_t, 0.001), 0.5)
        return float(np.quantile(np.fromiter(self.scores, float), 1 - a))

    def interval(self, price: float, sigma: float) -> dict | None:
        q = self.quantile()
        if q is None or not sigma:
            return None
        w = q * sigma
        return {"low": _r(price * math.exp(-w), 8), "high": _r(price * math.exp(w), 8), "width": _r(w, 5)}

    def update(self, realised: float, sigma: float, low_hit: bool | None = None) -> None:
        if sigma <= 0:
            return
        score = abs(realised) / sigma
        q = self.quantile()
        miss = int(q is not None and score > q) if low_hit is None else int(not low_hit)
        self.hits.append(1 - miss)
        self.scores.append(score)
        self.alpha_t += self.gamma * (self.alpha - miss)

    def coverage(self) -> float | None:
        return float(np.mean(self.hits)) if len(self.hits) >= 20 else None


def precision_table(p: np.ndarray, y: np.ndarray) -> list[dict]:
    """Selective prediction: accuracy vs how often the model speaks, by confidence threshold."""
    conf = np.abs(p - 0.5) * 2
    out = []
    for c in (0.0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4):
        m = conf >= c
        if m.sum() < 30:
            break
        out.append({"min_confidence": c, "coverage": _r(float(m.mean()), 3), "n": int(m.sum()),
                    "precision": _r(float(((p[m] > 0.5) == y[m]).mean()), 3)})
    return out


# ============================================================================ multi-scale (wavelets)
def wavelet_scales(prices: np.ndarray, levels: int = 6) -> dict | None:
    """Stationary (à trous) Haar wavelet decomposition of log price: splits the price into
    time scales of 2, 4, 8 … 64 hours plus a smooth trend, and reports which scale carries
    the most energy and the direction of each scale right now."""
    y = np.log(np.maximum(np.asarray(prices, float), 1e-12))
    n = len(y)
    if n < 2 ** levels * 4:
        return None
    approx = y.copy()
    details = []
    for j in range(levels):
        step = 2 ** j
        shifted = np.concatenate([np.full(step, approx[0]), approx[:-step]])   # causal: only the past
        smooth = 0.5 * (approx + shifted)
        details.append(approx - smooth)
        approx = smooth
    energy = np.array([float(np.var(d[-500:])) for d in details])
    share = energy / (energy.sum() or 1)
    scales = []
    for j, d in enumerate(details):
        recent = d[-max(2, 2 ** j):]
        scales.append({"hours": 2 ** (j + 1), "energy_share": _r(share[j], 3),
                       "direction": int(np.sign(recent[-1] - recent[0])) if len(recent) > 1 else 0,
                       "amplitude": _r(float(np.std(d[-200:])), 5)})
    trend = approx
    slope = float(trend[-1] - trend[-25]) if n > 25 else 0.0
    dom = int(np.argmax(share))
    return {"scales": scales, "dominant_hours": 2 ** (dom + 1), "trend_24h": _r(slope, 5),
            "trend_price": _r(float(math.exp(trend[-1])), 8),
            "read": f"most movement is happening on the ~{2 ** (dom + 1)}h scale; slow trend {'up' if slope > 0 else 'down'}"}


# ============================================================================ volume profile / VWAP
def volume_profile(candles, bins: int = 40, value_area: float = 0.7) -> dict | None:
    """Where the money actually traded: point of control, 70% value area, VWAP."""
    if not candles or len(candles) < 20:
        return None
    hi = max(c.high for c in candles)
    lo = min(c.low for c in candles)
    if hi <= lo:
        return None
    edges = np.linspace(lo, hi, bins + 1)
    vol = np.zeros(bins)
    pv = vv = 0.0
    for c in candles:
        typ = (c.high + c.low + c.close) / 3
        pv += typ * c.volume
        vv += c.volume
        a = max(0, min(bins - 1, int((c.low - lo) / (hi - lo) * bins)))
        b = max(0, min(bins - 1, int((c.high - lo) / (hi - lo) * bins)))
        vol[a:b + 1] += c.volume / (b - a + 1)                        # spread each candle's volume over its range
    poc = int(np.argmax(vol))
    lo_i = hi_i = poc                      # grow the value area outward from the point of control
    cum = vol[poc]
    target = value_area * vol.sum()
    while cum < target and (lo_i > 0 or hi_i < bins - 1):
        up = vol[hi_i + 1] if hi_i < bins - 1 else -1
        dn = vol[lo_i - 1] if lo_i > 0 else -1
        if up >= dn:
            hi_i += 1
            cum += vol[hi_i]
        else:
            lo_i -= 1
            cum += vol[lo_i]
    vah, val = edges[hi_i + 1], edges[lo_i]
    price = candles[-1].close
    vwap = pv / vv if vv else None
    return {"poc": _r((edges[poc] + edges[poc + 1]) / 2, 8), "value_high": _r(vah, 8), "value_low": _r(val, 8),
            "vwap": _r(vwap, 8), "price_vs_vwap": _r(price / vwap - 1, 4) if vwap else None,
            "position": "above value area" if price > vah else "below value area" if price < val else "inside value area",
            "profile": [_r(v / (vol.max() or 1), 3) for v in vol], "edges": [_r(e, 8) for e in edges]}


# ============================================================================ information theory
def transfer_entropy(x: np.ndarray, y: np.ndarray, bins: int = 3) -> float:
    """TE(X→Y): how much X's past reduces uncertainty about Y's next move beyond Y's own past
    (Schreiber 2000), on tercile-discretised returns, in bits."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    n = min(len(x), len(y))
    if n < 100:
        return 0.0
    x, y = x[-n:], y[-n:]
    qx = np.digitize(x, np.quantile(x, [1 / 3, 2 / 3]))
    qy = np.digitize(y, np.quantile(y, [1 / 3, 2 / 3]))
    yt1, yt, xt = qy[1:], qy[:-1], qx[:-1]
    joint = np.zeros((bins, bins, bins))
    np.add.at(joint, (yt1, yt, xt), 1)
    joint /= joint.sum()
    p_yt_xt = joint.sum(axis=0)
    p_yt1_yt = joint.sum(axis=2)
    p_yt = joint.sum(axis=(0, 2))
    te = 0.0
    for a in range(bins):
        for b in range(bins):
            for c in range(bins):
                pj = joint[a, b, c]
                if pj > 0 and p_yt_xt[b, c] > 0 and p_yt1_yt[a, b] > 0 and p_yt[b] > 0:
                    te += pj * math.log2(pj * p_yt[b] / (p_yt_xt[b, c] * p_yt1_yt[a, b]))
    return max(0.0, te)


def information_flow(returns: dict[str, np.ndarray], window: int = 720) -> dict:
    syms = sorted(s for s, r in returns.items() if len(r) >= 200)
    if len(syms) < 2:
        return {"pairs": [], "net": []}
    R = {s: returns[s][-window:] for s in syms}
    net = {s: 0.0 for s in syms}
    pairs = []
    for a, b in combinations(syms, 2):
        ab, ba = transfer_entropy(R[a], R[b]), transfer_entropy(R[b], R[a])
        net[a] += ab - ba
        net[b] += ba - ab
        if max(ab, ba) > 0.002:
            pairs.append({"from": a if ab > ba else b, "to": b if ab > ba else a, "bits": _r(max(ab, ba), 4),
                          "asymmetry": _r(abs(ab - ba), 4)})
    pairs.sort(key=lambda p: -p["asymmetry"])
    ranking = sorted(({"symbol": s, "net_bits": _r(v, 4)} for s, v in net.items()), key=lambda r: -r["net_bits"])
    return {"pairs": pairs[:10], "net": ranking}
