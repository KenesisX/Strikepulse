"""Models and guardrails for the Quant Engine.

* GBDT direction model (scikit-learn HistGradientBoosting = the LightGBM algorithm; uses
  LightGBM itself if installed) trained with *purged, embargoed walk-forward* validation.
* Isotonic calibration on out-of-sample predictions only.
* Fee- and slippage-aware backtest of the out-of-sample predictions, with a deploy gate:
  if the model can't beat a coin flip after costs, it is benched automatically.
* Regime classifier (Gaussian mixture) labelled trending-up / trending-down / range / stress.
* Online logistic learner (AdaGrad SGD) with Page-Hinkley drift detection for live-only
  microstructure features (order flow, whales, book, premium, funding).
* Hedge (exponential-weights) ensemble with separate weights per regime, so the blend
  re-weights itself toward whatever has been working lately in the current regime.
* Decision layer: probability → bias + fractional-Kelly, volatility-targeted size, with
  regime and drawdown circuit breakers.
"""
from __future__ import annotations

import logging
import math
import time

import numpy as np

from .features import FEATURES, HORIZON, REGIME_FEATURES
from .mathlab import precision_table

log = logging.getLogger(__name__)

FEE = 0.001        # per side (0.10%)
SLIPPAGE = 0.0005  # per side
ROUND_TRIP = 2 * (FEE + SLIPPAGE)


def _clf():
    try:
        import lightgbm as lgb  # optional, faster
        return lgb.LGBMClassifier(n_estimators=300, learning_rate=0.03, num_leaves=15, min_child_samples=80,
                                  subsample=0.8, subsample_freq=1, colsample_bytree=0.8, reg_lambda=1.0, verbose=-1)
    except Exception:
        from sklearn.ensemble import HistGradientBoostingClassifier
        return HistGradientBoostingClassifier(max_iter=300, learning_rate=0.03, max_leaf_nodes=15, min_samples_leaf=80,
                                              l2_regularization=1.0, early_stopping=False, random_state=7)


def fit_weighted(model, X, y, w, seed: int = 0):
    """Recency weighting without the slow weighted-binning path of HistGradientBoosting:
    LightGBM takes weights natively; otherwise rows are resampled in proportion to weight."""
    if type(model).__name__.startswith("LGBM") or w is None:
        return model.fit(X, y, sample_weight=w)
    p = w / w.sum()
    idx = np.random.default_rng(seed).choice(len(y), size=len(y), replace=True, p=p)
    return model.fit(X[idx], y[idx])


def stack_panel(panel: dict, warmup: int = 200):
    """Pool all coins into one table, sorted by time. Rows with unknown future are kept
    separately for live inference."""
    Xs, ys, rs, ts, syms = [], [], [], [], []
    for s, (T, X, fwd, _close) in panel.items():
        ok = np.arange(len(T)) >= warmup
        ok &= ~np.isnan(fwd)
        ok &= np.isfinite(X).sum(axis=1) >= X.shape[1] * 0.8
        Xs.append(X[ok])
        ys.append((fwd[ok] > 0).astype(int))
        rs.append(fwd[ok])
        ts.append(T[ok])
        syms += [s] * int(ok.sum())
    if not Xs:
        return None
    X, y, r, t = np.vstack(Xs), np.concatenate(ys), np.concatenate(rs), np.concatenate(ts)
    order = np.argsort(t, kind="stable")
    return X[order], y[order], r[order], t[order], np.array(syms)[order]


def purged_walk_forward(t: np.ndarray, folds: int = 5, embargo_h: int = 24):
    """Expanding-window splits on time. Training rows whose label window overlaps the
    test period (horizon) or sit inside the embargo are dropped: no leakage."""
    uniq = np.unique(t)
    edges = np.linspace(0, len(uniq), folds + 2).astype(int)
    for k in range(1, folds + 1):
        test_start, test_end = uniq[edges[k]], uniq[min(edges[k + 1], len(uniq) - 1)]
        cut = test_start - (HORIZON + embargo_h) * 3600
        tr = np.where(t < cut)[0]
        te = np.where((t >= test_start) & (t < test_end))[0]
        if len(tr) > 500 and len(te) > 100:
            yield tr, te


def backtest(p: np.ndarray, r: np.ndarray, t: np.ndarray, syms: np.ndarray, lo: float = 0.45, hi: float = 0.55,
             long_only: bool = False) -> dict:
    """Non-overlapping 4h trades per coin, every trade pays round-trip fees + slippage."""
    trades = []
    for s in np.unique(syms):
        m = np.where(syms == s)[0]
        last_t = -1e18
        for i in m:
            if t[i] < last_t + HORIZON * 3600:
                continue
            pos = 1 if p[i] > hi else (-1 if (p[i] < lo and not long_only) else 0)
            if pos == 0:
                continue
            ret = math.exp(r[i]) - 1
            trades.append((t[i], pos * ret - ROUND_TRIP))
            last_t = t[i]
    if not trades:
        return {"trades": 0}
    trades.sort()
    tt = np.array([x[0] for x in trades])
    pnl = np.array([x[1] for x in trades])
    # equal-risk: average across coins per 4h bucket → equity curve
    buckets = (tt // (HORIZON * 3600)).astype(int)
    ub, inv = np.unique(buckets, return_inverse=True)
    per = np.bincount(inv, weights=pnl) / np.bincount(inv)
    eq = np.cumprod(1 + per)
    peak = np.maximum.accumulate(eq)
    dd = float((eq / peak - 1).min())
    periods_per_year = 365 * 24 / HORIZON
    sharpe = float(per.mean() / per.std() * math.sqrt(periods_per_year)) if per.std() > 0 else 0.0
    wins, losses = pnl[pnl > 0], pnl[pnl <= 0]
    return {"trades": int(len(pnl)), "win_rate": round(float((pnl > 0).mean()), 3),
            "avg_win": round(float(wins.mean()), 5) if len(wins) else 0.0,
            "avg_loss": round(float(losses.mean()), 5) if len(losses) else 0.0,
            "total_return": round(float(eq[-1] - 1), 4), "sharpe": round(sharpe, 2), "max_drawdown": round(dd, 4),
            "equity": [[int(ub[i] * HORIZON * 3600), round(float(eq[i]), 5)] for i in range(0, len(eq), max(1, len(eq) // 200))]}


class DirectionModel:
    """GBDT on engineered features, validated walk-forward, calibrated, gated."""

    def __init__(self):
        self.model = None
        self.calibrator = None
        self.bins = None
        self.oos_probs: dict[str, dict[int, float]] = {}
        self.card: dict = {"status": "untrained"}

    def forward_logloss(self, panel: dict) -> tuple[float | None, int]:
        """True forward test: log-loss on rows that arrived after this model was trained."""
        from sklearn.metrics import log_loss
        if self.model is None or not self.card.get("data_end"):
            return None, 0
        data = stack_panel(panel)
        if data is None:
            return None, 0
        X, y, r, t, _ = data
        m = t > self.card["data_end"]
        if m.sum() < 100 or len(np.unique(y[m])) < 2:
            return None, int(m.sum())
        p = self.model.predict_proba(X[m])[:, 1]
        if self.calibrator is not None:
            p = self.calibrator.predict(p)
        return float(log_loss(y[m], np.clip(p, 1e-4, 1 - 1e-4))), int(m.sum())

    def train(self, panel: dict, half_life_days: float | None = None) -> dict:
        from sklearn.isotonic import IsotonicRegression
        from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score
        started = time.time()
        data = stack_panel(panel)
        if data is None or len(data[0]) < 3000:
            self.card = {"status": "insufficient data", "rows": 0 if data is None else int(len(data[0]))}
            return self.card
        X, y, r, t, syms = data
        # recency weighting: recent market behaviour counts more (adapts to a changing market)
        if half_life_days:
            sw = 0.5 ** ((t.max() - t) / (half_life_days * 86400))
        else:
            sw = np.ones(len(t))
        oos_p = np.full(len(y), np.nan)
        folds = 0
        for tr, te in purged_walk_forward(t):
            m = fit_weighted(_clf(), X[tr], y[tr], sw[tr] if half_life_days else None, seed=folds)
            oos_p[te] = m.predict_proba(X[te])[:, 1]
            folds += 1
        mask = ~np.isnan(oos_p)
        if folds == 0 or mask.sum() < 500:
            self.card = {"status": "insufficient data", "rows": int(len(y))}
            return self.card
        yo, po, ro, to, so = y[mask], oos_p[mask], r[mask], t[mask], syms[mask]
        base = float(yo.mean())
        auc = float(roc_auc_score(yo, po))
        ll = float(log_loss(yo, np.clip(po, 1e-4, 1 - 1e-4)))
        ll_base = float(log_loss(yo, np.full(len(yo), base)))
        # cross-fitted calibration: each half of the out-of-sample period is calibrated by a
        # calibrator fitted on the other half, so calibration never sees its own answers
        half = len(po) // 2
        mk = lambda a, b: IsotonicRegression(out_of_bounds="clip", y_min=0.02, y_max=0.98).fit(a, b)
        pc = np.empty_like(po)
        pc[half:] = mk(po[:half], yo[:half]).predict(po[half:])
        pc[:half] = mk(po[half:], yo[half:]).predict(po[:half])
        cal = mk(po, yo)                     # final calibrator for live use
        ll_cal = float(log_loss(yo, np.clip(pc, 1e-4, 1 - 1e-4)))
        bt = backtest(pc, ro, to, so)
        bt_long = backtest(pc, ro, to, so, long_only=True)
        hold = backtest(np.ones(len(pc)), ro, to, so, long_only=True)
        # high-confidence slice: how often the model is right when it's sure
        conf = np.abs(pc - 0.5) >= 0.08
        conf_acc = float(((pc[conf] > 0.5) == yo[conf]).mean()) if conf.any() else None
        deployed = auc >= 0.52 and ll_cal < ll_base and bt.get("sharpe", 0) > 0 and bt.get("trades", 0) >= 50
        # final model on everything we know the answer to
        self.model = fit_weighted(_clf(), X, y, sw if half_life_days else None, seed=99)
        self.calibrator = cal
        imp = self._importance(X[mask][-4000:], yo[-4000:])
        # nonlinear dependency of each feature with the next move (mutual information)
        try:
            from sklearn.feature_selection import mutual_info_classif
            Xm = np.nan_to_num(X[mask][-6000:])
            mi = mutual_info_classif(Xm, yo[-6000:], random_state=0, n_neighbors=5)
            mi_rank = sorted(zip(FEATURES, mi), key=lambda z: -z[1])[:12]
        except Exception:
            mi_rank = []
        # out-of-sample probabilities per coin and hour (used by the Bet Simulator's "quant" strategy)
        self.oos_probs = {}
        for sy, tt, pp in zip(so, to, pc):
            self.oos_probs.setdefault(str(sy), {})[int(tt)] = float(pp)
        self.card = {
            "status": "deployed" if deployed else "benched",
            "reason": None if deployed else "Out-of-sample results did not beat the base rate after costs; "
                                            "the ensemble ignores this model until it does.",
            "algo": type(self.model).__name__, "rows": int(len(y)), "coins": int(len(np.unique(syms))),
            "folds": folds, "horizon_h": HORIZON, "trained_at": time.time(), "train_seconds": round(time.time() - started, 1),
            "oos": {"auc": round(auc, 4), "log_loss": round(ll, 4), "log_loss_calibrated": round(ll_cal, 4),
                    "log_loss_base": round(ll_base, 4),
                    "brier": round(float(brier_score_loss(yo, pc)), 4), "base_rate": round(base, 4),
                    "accuracy": round(float(((pc > 0.5) == yo).mean()), 4),
                    "confident_accuracy": round(conf_acc, 4) if conf_acc is not None else None,
                    "confident_share": round(float(conf.mean()), 3)},
            "backtest": bt, "backtest_long_only": {k: v for k, v in bt_long.items() if k != "equity"},
            "buy_and_hold": {k: v for k, v in hold.items() if k != "equity"}, "hold_equity": hold.get("equity", []),
            "costs": {"fee_per_side": FEE, "slippage_per_side": SLIPPAGE},
            "importance": imp,
            "precision_table": precision_table(pc, yo),
            "mutual_info": [{"feature": f, "bits": round(float(v) / math.log(2), 4)} for f, v in mi_rank],
            "half_life_days": half_life_days, "data_end": float(t.max()),
        }
        recent = t > t.max() - 30 * 86400
        self.bins = feature_bins(X[recent] if recent.sum() > 500 else X[-5000:])
        return self.card

    def _importance(self, X, y, top: int = 12) -> list[dict]:
        """Permutation importance (AUC drop) on recent out-of-sample-sized data."""
        from sklearn.metrics import roc_auc_score
        if self.model is None or len(y) < 300 or len(np.unique(y)) < 2:
            return []
        rng = np.random.default_rng(0)
        base = roc_auc_score(y, self.model.predict_proba(X)[:, 1])
        out = []
        for j, name in enumerate(FEATURES):
            Xp = X.copy()
            Xp[:, j] = rng.permutation(Xp[:, j])
            out.append((name, float(base - roc_auc_score(y, self.model.predict_proba(Xp)[:, 1]))))
        out.sort(key=lambda x: -x[1])
        return [{"feature": n, "drop": round(d, 4)} for n, d in out[:top]]

    def predict(self, x: np.ndarray) -> float | None:
        if self.model is None:
            return None
        x = np.asarray(x, float).reshape(1, -1)
        p = float(self.model.predict_proba(x)[:, 1][0])
        return float(self.calibrator.predict([p])[0]) if self.calibrator is not None else p


def feature_bins(X: np.ndarray, q: int = 10) -> list:
    bins = []
    for j in range(X.shape[1]):
        col = X[:, j][np.isfinite(X[:, j])]
        bins.append(np.unique(np.quantile(col, np.linspace(0, 1, q + 1))) if len(col) > 100 else None)
    return bins


def psi(bins: list, X_new: np.ndarray) -> list[float]:
    """Population Stability Index per feature: >0.25 = the market looks different from training."""
    out = []
    for j, edges in enumerate(bins):
        col = X_new[:, j][np.isfinite(X_new[:, j])] if X_new.size else np.array([])
        if edges is None or len(edges) < 3 or len(col) < 30:
            out.append(0.0)
            continue
        e = np.histogram(np.clip(col, edges[0], edges[-1]), bins=edges)[0] / len(col)
        base = np.full(len(edges) - 1, 1 / (len(edges) - 1))
        e = np.clip(e, 1e-4, None)
        out.append(float(np.sum((e - base) * np.log(e / base))))
    return out


class RegimeModel:
    NAMES = ("trending up", "trending down", "range / mean-reverting", "high-volatility stress")

    def __init__(self):
        self.gmm = None
        self.labels: dict[int, str] = {}
        self.mu = self.sd = None
        self.idx = [FEATURES.index(f) for f in REGIME_FEATURES]

    def fit(self, X: np.ndarray) -> None:
        from sklearn.mixture import GaussianMixture
        Z = X[:, self.idx]
        Z = Z[np.isfinite(Z).all(axis=1)]
        if len(Z) < 500:
            return
        self.mu, self.sd = Z.mean(0), Z.std(0) + 1e-9
        Zs = (Z - self.mu) / self.sd
        self.gmm = GaussianMixture(4, covariance_type="full", random_state=3).fit(Zs)
        cent = self.gmm.means_  # columns: rv24, er24, ac48, slope20 (standardised)
        k_stress = int(np.argmax(cent[:, 0]))
        rest = [k for k in range(4) if k != k_stress]
        k_range = min(rest, key=lambda k: cent[k, 1] + abs(cent[k, 3]))
        rest = [k for k in rest if k != k_range]
        k_up = max(rest, key=lambda k: cent[k, 3])
        k_down = [k for k in rest if k != k_up][0]
        self.labels = {k_up: self.NAMES[0], k_down: self.NAMES[1], k_range: self.NAMES[2], k_stress: self.NAMES[3]}

    def predict(self, x: np.ndarray) -> tuple[str, dict]:
        if self.gmm is None:
            return "unknown", {}
        z = np.asarray(x, float)[self.idx]
        if not np.isfinite(z).all():
            return "unknown", {}
        pr = self.gmm.predict_proba(((z - self.mu) / self.sd).reshape(1, -1))[0]
        probs = {self.labels[k]: round(float(p), 3) for k, p in enumerate(pr)}
        return max(probs, key=probs.get), probs


class OnlineLogit:
    """Incremental logistic regression (AdaGrad) + Page-Hinkley drift detector on log-loss."""

    def __init__(self, n: int, lr: float = 0.05, l2: float = 1e-4):
        self.w = np.zeros(n + 1)
        self.g2 = np.full(n + 1, 1e-8)
        self.lr, self.l2 = lr, l2
        self.n_updates = 0
        self.loss_ema = math.log(2)
        self.ph_mean, self.ph_sum, self.ph_min = 0.0, 0.0, 0.0
        self.drifts = 0

    def _x(self, x):
        return np.concatenate([[1.0], np.nan_to_num(np.clip(np.asarray(x, float), -10, 10))])

    def predict(self, x) -> float:
        z = float(self._x(x) @ self.w)
        return 1 / (1 + math.exp(-max(-30, min(30, z))))

    def update(self, x, y: int) -> float:
        xv = self._x(x)
        p = self.predict(x)
        loss = -math.log(max(1e-6, p if y else 1 - p))
        g = (p - y) * xv + self.l2 * self.w
        self.g2 += g * g
        self.w -= self.lr * g / np.sqrt(self.g2)
        self.n_updates += 1
        self.loss_ema = 0.98 * self.loss_ema + 0.02 * loss
        # Page-Hinkley: alarm when the loss drifts up persistently → partial reset (adapt to new regime)
        self.ph_mean += (loss - self.ph_mean) / self.n_updates
        self.ph_sum += loss - self.ph_mean - 0.005
        self.ph_min = min(self.ph_min, self.ph_sum)
        if self.n_updates > 200 and self.ph_sum - self.ph_min > 8.0:
            self.w *= 0.3
            self.g2 = np.full_like(self.g2, 1e-8)
            self.ph_sum = self.ph_min = 0.0
            self.drifts += 1
        return loss

    def state(self) -> dict:
        return {"w": self.w.tolist(), "g2": self.g2.tolist(), "n": self.n_updates, "loss": self.loss_ema, "drifts": self.drifts}

    def load(self, st: dict) -> None:
        if st and len(st.get("w", [])) == len(self.w):
            self.w, self.g2 = np.array(st["w"]), np.array(st["g2"])
            self.n_updates, self.loss_ema, self.drifts = st.get("n", 0), st.get("loss", math.log(2)), st.get("drifts", 0)


class HedgeEnsemble:
    """Exponential weights over components, one weight vector per regime."""

    def __init__(self, components: list[str], eta: float = 0.5):
        self.components = components
        self.eta = eta
        self.loss: dict[str, dict[str, float]] = {}
        self.n: dict[str, int] = {}

    def weights(self, regime: str, available: list[str] | None = None) -> dict[str, float]:
        L = self.loss.get(regime, {})
        comps = available or self.components
        raw = {c: math.exp(-self.eta * L.get(c, 0.0)) for c in comps}
        s = sum(raw.values()) or 1
        return {c: v / s for c, v in raw.items()}

    def combine(self, regime: str, probs: dict[str, float | None]) -> tuple[float, dict]:
        avail = [c for c, p in probs.items() if p is not None]
        if not avail:
            return 0.5, {}
        w = self.weights(regime, avail)
        # combine in log-odds space (proper probability pooling)
        lo = sum(w[c] * math.log(max(1e-4, probs[c]) / max(1e-4, 1 - probs[c])) for c in avail)
        return 1 / (1 + math.exp(-lo)), w

    def update(self, regime: str, probs: dict[str, float | None], y: int, decay: float = 0.995) -> None:
        L = self.loss.setdefault(regime, {})
        for c, p in probs.items():
            if p is None:
                continue
            l = -math.log(max(1e-4, p if y else 1 - p)) - math.log(2)   # loss relative to a coin flip
            L[c] = decay * L.get(c, 0.0) + l
        self.n[regime] = self.n.get(regime, 0) + 1

    def state(self) -> dict:
        return {"loss": self.loss, "n": self.n}

    def load(self, st: dict) -> None:
        if st:
            self.loss, self.n = st.get("loss", {}), st.get("n", {})


def historical_precision(card: dict, confidence: float) -> tuple[float | None, int]:
    rows = [r for r in (card.get("precision_table") or []) if r["min_confidence"] <= confidence + 1e-9]
    if not rows:
        return None, 0
    r = rows[-1]
    return r["precision"], r["n"]


def decide(p: float, sigma_h: float | None, regime: str, card: dict, live_dd: float = 0.0,
           threshold: float = 0.55, max_size: float = 0.2, risk_per_trade: float = 0.01,
           min_precision: float = 0.0) -> dict:
    """Turn a probability into a general, rules-based model stance (not personal advice)."""
    edge = p - 0.5
    bt = card.get("backtest") or {}
    b = abs(bt.get("avg_win", 0.012)) / max(1e-6, abs(bt.get("avg_loss", -0.012))) if bt.get("trades") else 1.0
    q = 1 - p if edge > 0 else p
    pw = max(p, 1 - p)
    kelly = max(0.0, (pw * b - q) / b) if b > 0 else 0.0
    size = 0.25 * kelly                               # fractional Kelly
    if sigma_h:
        vol_cap = risk_per_trade / max(1e-6, sigma_h * math.sqrt(HORIZON) * 2)
        size = min(size, vol_cap)
    reasons = []
    if regime == "high-volatility stress":
        size *= 0.5
        reasons.append("stress regime: size halved")
    if live_dd <= -0.10:
        size = 0.0
        reasons.append("circuit breaker: model live drawdown beyond -10%")
    size = round(min(max_size, size), 4)
    exp_move = edge * 2 * (sigma_h or 0.01) * math.sqrt(HORIZON)
    ev = abs(exp_move) - ROUND_TRIP
    hist_p, hist_n = historical_precision(card, abs(edge) * 2) if card.get("status") == "deployed" else (None, 0)
    if min_precision and hist_p is not None and hist_p < min_precision:
        size = 0.0
        reasons.append(f"historical hit rate at this confidence {hist_p * 100:.0f}% is below the {min_precision * 100:.0f}% bar")
    if abs(edge) < threshold - 0.5 or size == 0 or ev <= 0:
        stance = "STAND ASIDE"
        if ev <= 0 and abs(edge) >= threshold - 0.5:
            reasons.append("expected edge smaller than fees + slippage")
    else:
        stance = "LONG BIAS" if edge > 0 else "SHORT / CASH BIAS"
    return {"stance": stance, "p_up": round(p, 4), "confidence": round(abs(edge) * 2, 3), "size": size,
            "hist_precision": hist_p, "hist_n": hist_n,
            "kelly_fraction": 0.25, "expected_edge_after_costs": round(ev, 5), "reasons": reasons}
