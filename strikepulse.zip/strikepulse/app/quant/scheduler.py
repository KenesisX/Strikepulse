"""Attention-based priority scheduler: spend compute where information is arriving.

priority = 1 + activity heat + price-move urgency + user interest + recent events
interval = base / priority   (clamped), and any 5-minute candle close or edge event makes a
symbol due immediately. Each stage's run time is tracked for the admin performance panel.
"""
from __future__ import annotations

import time
from collections import defaultdict


class PriorityScheduler:
    def __init__(self, base_interval: float = 300, min_interval: float = 10, per_tick: int = 4):
        self.base, self.min, self.per_tick = base_interval, min_interval, per_tick
        self.next_due: dict[str, float] = {}
        self.priority: dict[str, float] = defaultdict(lambda: 1.0)
        self.viewed: dict[str, float] = {}
        self.events: dict[str, float] = {}
        self.runs: dict[str, int] = defaultdict(int)

    def touch(self, sym: str) -> None:
        """Someone is looking at this coin right now."""
        self.viewed[sym] = time.time()
        self.next_due[sym] = min(self.next_due.get(sym, 0), time.time() + 5)

    def trigger(self, sym: str) -> None:
        """New information (candle close, edge event): run soon."""
        self.events[sym] = time.time()
        self.next_due[sym] = min(self.next_due.get(sym, 0), time.time())

    def score(self, sym: str, heat: float | None, move_z: float, watchers: int) -> float:
        now = time.time()
        p = 1.0
        p += min(3.0, max(0.0, (heat or 1.0) - 1.0) * 2)          # trading faster than usual
        p += min(3.0, abs(move_z) * 0.8)                          # unusual price move
        p += min(2.0, watchers * 0.25)                            # users care about it
        if now - self.viewed.get(sym, 0) < 120:
            p += 3.0                                              # someone is on the page
        if now - self.events.get(sym, 0) < 600:
            p += 1.5                                              # fresh edge / alert activity
        self.priority[sym] = round(p, 2)
        return p

    def due(self, symbols: list[str]) -> list[str]:
        now = time.time()
        ready = [s for s in symbols if self.next_due.get(s, 0) <= now]
        ready.sort(key=lambda s: -self.priority[s])
        return ready[: self.per_tick]

    def done(self, sym: str) -> None:
        self.runs[sym] += 1
        interval = max(self.min, self.base / self.priority[sym])
        self.next_due[sym] = time.time() + interval

    def report(self) -> list[dict]:
        now = time.time()
        return sorted(({"symbol": s, "priority": self.priority[s], "next_in_s": round(max(0, self.next_due.get(s, now) - now)),
                        "runs": self.runs[s]} for s in self.next_due), key=lambda r: -r["priority"])


class StageTimer:
    """Exponential moving average of each stage's duration in milliseconds."""

    def __init__(self):
        self.ms: dict[str, float] = {}
        self.calls: dict[str, int] = defaultdict(int)

    def add(self, stage: str, seconds: float) -> None:
        v = seconds * 1000
        self.ms[stage] = v if stage not in self.ms else 0.8 * self.ms[stage] + 0.2 * v
        self.calls[stage] += 1

    def report(self) -> dict:
        return {k: {"avg_ms": round(v, 1), "calls": self.calls[k]} for k, v in sorted(self.ms.items())}
