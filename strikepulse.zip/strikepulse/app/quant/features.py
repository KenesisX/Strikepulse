"""Feature engineering for the Quant Engine.

Everything here uses only information available at time t (no look-ahead):
multi-timeframe momentum, realized volatility, volume, trend-distance, efficiency,
autocorrelation, variance ratio, calendar features, cross-asset features vs BTC, and
graph "message passing" features over the live correlation network of coins.
"""
from __future__ import annotations

import math

import numpy as np

from ..engine import indicators as ind
from ..engine.types import Candle

FEATURES = [
    "r1", "r3", "r6", "r12", "r24", "r72", "rv6", "rv24", "rv72", "rv_ratio", "vol_rel", "range", "close_loc",
    "rsi14", "d_ema20", "d_ema50", "d_ema200", "slope20", "er24", "ac48", "vr4", "dd72", "ru72",
    "hour_sin", "hour_cos", "dow_sin", "dow_cos",
    "btc_r1", "btc_r6", "btc_r24", "beta168", "corr168", "rel24",
    "g_mom6", "g_mom24", "g_central", "breadth24", "mkt_r6",
    "kf_t", "ewma_vol", "pe48", "cp_prob", "z72",
]
REGIME_FEATURES = ["rv24", "er24", "ac48", "slope20"]
HORIZON = 4  # hours


def _roll(a: np.ndarray, w: int, fn) -> np.ndarray:
    out = np.full(len(a), np.nan)
    if len(a) < w:
        return out
    view = np.lib.stride_tricks.sliding_window_view(a, w)
    out[w - 1:] = fn(view)
    return out


def _trail(a: np.ndarray, w: int, op) -> np.ndarray:
    """Trailing-window max/min in O(n log w) using a sparse-table style doubling."""
    a = np.asarray(a, float)
    out = a.copy()
    span = 1
    while span * 2 <= w:
        out = op(out[:-span], out[span:]) if span else out
        out = np.concatenate([np.full(span, np.nan), out])
        span *= 2
    rest = w - span
    if rest > 0:
        shifted = np.concatenate([np.full(rest, np.nan), out[:-rest]])
        out = op(out, shifted)
    return out[w - 1:]


def coin_features(cs: list[Candle]) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    """Per-coin features. Returns (timestamps, {feature: array})."""
    t = np.array([c.start for c in cs], float)
    c = np.array([c_.close for c_ in cs], float)
    h = np.array([c_.high for c_ in cs], float)
    lo = np.array([c_.low for c_ in cs], float)
    v = np.array([c_.volume for c_ in cs], float)
    lc = np.log(np.maximum(c, 1e-12))
    r = np.concatenate([[0.0], np.diff(lc)])

    def lag(k):
        out = np.full(len(c), np.nan)
        out[k:] = lc[k:] - lc[:-k]
        return out

    f: dict[str, np.ndarray] = {}
    for k in (1, 3, 6, 12, 24, 72):
        f[f"r{k}"] = lag(k)
    for w in (6, 24, 72):
        f[f"rv{w}"] = ind.rolling_std(r, w)
    f["rv_ratio"] = f["rv6"] / np.maximum(f["rv72"], 1e-9)
    vm = ind.rolling_mean(v, 24)
    f["vol_rel"] = np.log1p(v) - np.log1p(np.maximum(vm, 1e-12))
    f["range"] = (h - lo) / np.maximum(c, 1e-12)
    f["close_loc"] = np.where(h > lo, (c - lo) / np.maximum(h - lo, 1e-12), 0.5)
    f["rsi14"] = ind.rsi(c, 14) / 100.0
    for p in (20, 50, 200):
        e = ind.ema(c, p)
        f[f"d_ema{p}"] = c / np.maximum(e, 1e-12) - 1
        if p == 20:
            sl = np.full(len(c), np.nan)
            sl[5:] = e[5:] / np.maximum(e[:-5], 1e-12) - 1
            f["slope20"] = sl
    path = ind.rolling_mean(np.abs(r), 24) * 24
    f["er24"] = np.abs(f["r24"]) / np.maximum(path, 1e-12)

    def ac(x):
        a, b = x[:, :-1], x[:, 1:]
        a = a - a.mean(axis=1, keepdims=True)
        b = b - b.mean(axis=1, keepdims=True)
        return (a * b).sum(1) / np.maximum(np.sqrt((a * a).sum(1) * (b * b).sum(1)), 1e-12)

    f["ac48"] = _roll(r, 48, ac)
    # variance ratio VR(4): >1 trending, <1 mean-reverting
    r4 = np.full(len(c), np.nan)
    r4[4:] = lc[4:] - lc[:-4]
    v1 = ind.rolling_std(r, 72) ** 2
    v4 = ind.rolling_std(np.nan_to_num(r4), 72) ** 2
    f["vr4"] = v4 / np.maximum(4 * v1, 1e-12)
    hi72 = np.full(len(h), np.nan)
    lo72 = np.full(len(lo), np.nan)
    if len(h) >= 72:
        hi72[71:] = _trail(h, 72, np.maximum)
        lo72[71:] = _trail(lo, 72, np.minimum)
    f["dd72"] = c / np.maximum(hi72, 1e-12) - 1
    f["ru72"] = c / np.maximum(lo72, 1e-12) - 1
    hrs = (t // 3600) % 24
    dow = ((t // 86400) + 3) % 7  # 1970-01-01 was a Thursday → Monday = 0
    f["hour_sin"], f["hour_cos"] = np.sin(2 * math.pi * hrs / 24), np.cos(2 * math.pi * hrs / 24)
    f["dow_sin"], f["dow_cos"] = np.sin(2 * math.pi * dow / 7), np.cos(2 * math.pi * dow / 7)
    # ---- Math Lab features (all causal) ----
    from .mathlab import bocpd, ewma_vol, kalman_trend, perm_entropy_series
    kf = kalman_trend(c)
    f["kf_t"] = kf[1] / np.maximum(kf[2], 1e-12) if kf else np.full(len(c), np.nan)
    ev = ewma_vol(r)
    f["ewma_vol"] = ev
    f["pe48"] = perm_entropy_series(r, 4, 48)
    std_r = r / np.maximum(ev, 1e-9)
    f["cp_prob"] = bocpd(np.clip(std_r, -8, 8))[0]
    m72 = ind.rolling_mean(lc, 72)
    s72 = ind.rolling_std(lc, 72)
    f["z72"] = (lc - m72) / np.maximum(s72, 1e-12)
    f["_r"] = r
    f["_close"] = c
    return t, f


_FEATURE_CACHE: dict[str, tuple[tuple, tuple]] = {}
_POOL = None


def _pool():
    """Process pool for per-coin feature work (divide-and-conquer across CPU cores).
    Uses the 'spawn' start method: forked children would inherit the web server's
    listening socket and threads (and can deadlock); spawned children start clean."""
    global _POOL
    if _POOL is None:
        import multiprocessing as mp
        import os
        from concurrent.futures import ProcessPoolExecutor
        cfg = os.getenv("QUANT_WORKERS")
        workers = int(cfg) if cfg and cfg.isdigit() else min(4, max(1, (os.cpu_count() or 2) - 1))
        _POOL = ProcessPoolExecutor(max_workers=workers, mp_context=mp.get_context("spawn")) if workers > 1 else False
    return _POOL


def shutdown_pool() -> None:
    global _POOL
    if _POOL:
        _POOL.shutdown(wait=False, cancel_futures=True)
    _POOL = None


def all_coin_features(series: dict[str, list[Candle]], parallel: bool = True) -> dict:
    """Per-coin features, recomputed only for coins with new candles; misses run in parallel."""
    out, todo = {}, {}
    for s, cs in series.items():
        if len(cs) < 260:
            continue
        key = (len(cs), cs[-1].start, cs[-1].close)
        hit = _FEATURE_CACHE.get(s)
        if hit and hit[0] == key:
            out[s] = hit[1]
        else:
            todo[s] = (key, cs)
    if todo:
        pool = _pool() if parallel and len(todo) > 1 else None
        results = {}
        if pool:
            try:
                futs = {s: pool.submit(coin_features, cs) for s, (_, cs) in todo.items()}
                results = {s: f.result(timeout=120) for s, f in futs.items()}
            except Exception:
                results = {}
        for s, (key, cs) in todo.items():
            res = results.get(s) or coin_features(cs)
            _FEATURE_CACHE[s] = (key, res)
            out[s] = res
    return out


def build_panel(series: dict[str, list[Candle]], btc: str = "BTC-USD", corr_window: int = 168, parallel: bool = True):
    """Align all coins on BTC's hourly timeline and add cross-asset + graph features.

    Returns dict symbol -> (timestamps, feature matrix [n, len(FEATURES)], forward return, close).
    """
    per = all_coin_features(series, parallel)
    if btc not in per or len(per) < 2:
        anchor = max(per, key=lambda s: len(per[s][0])) if per else None
        if anchor is None:
            return {}
        btc_key = anchor
    else:
        btc_key = btc
    T = per[btc_key][0]
    idx = {s: {ts: i for i, ts in enumerate(tt)} for s, (tt, _) in per.items()}
    syms = sorted(per)
    # matrix of hourly returns on the common timeline (nan where missing)
    R = np.full((len(syms), len(T)), np.nan)
    for a, s in enumerate(syms):
        tt, f = per[s]
        m = idx[s]
        for j, ts in enumerate(T):
            i = m.get(ts)
            if i is not None:
                R[a, j] = f["_r"][i]

    pos = {s: np.array([idx[s].get(ts, -1) for ts in T]) for s in syms}

    def take(s, name):
        arr = per[s][1][name]
        p = pos[s]
        out = np.where(p >= 0, arr[np.maximum(p, 0)], np.nan)
        return out.astype(float)

    btc_r1, btc_r6, btc_r24 = take(btc_key, "r1"), take(btc_key, "r6"), take(btc_key, "r24")
    r6m = np.vstack([take(s, "r6") for s in syms])
    r24m = np.vstack([take(s, "r24") for s in syms])
    n = len(T)
    beta = np.full((len(syms), n), np.nan)
    corrb = np.full((len(syms), n), np.nan)
    gm6 = np.full((len(syms), n), np.nan)
    gm24 = np.full((len(syms), n), np.nan)
    cent = np.full((len(syms), n), np.nan)
    bi = syms.index(btc_key)
    step = 6  # recompute the correlation graph every 6 hours (forward-filled), keeps training fast
    last = None
    for j in range(corr_window, n):
        if last is None or (j - corr_window) % step == 0:
            W = np.nan_to_num(R[:, j - corr_window + 1: j + 1])
            sd = W.std(axis=1)
            C = np.corrcoef(W) if np.all(sd > 0) else np.eye(len(syms))
            C = np.nan_to_num(C)
            A = np.abs(C) - np.eye(len(syms))
            ev = np.linalg.eigh(A)[1][:, -1]
            ev = np.abs(ev) / (np.abs(ev).sum() or 1)
            vb = W[bi].var()
            b = (W @ W[bi] / len(W[bi]) - W.mean(1) * W[bi].mean()) / vb if vb > 0 else np.zeros(len(syms))
            last = (C, A, ev, b)
        C, A, ev, b = last
        wsum = A.sum(axis=1)
        wsum[wsum == 0] = 1
        gm6[:, j] = (A @ np.nan_to_num(r6m[:, j])) / wsum     # one step of message passing
        gm24[:, j] = (A @ np.nan_to_num(r24m[:, j])) / wsum
        cent[:, j] = ev
        beta[:, j] = b
        corrb[:, j] = C[:, bi]
    with np.errstate(all="ignore"):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            breadth = np.nanmean(np.where(np.isnan(r24m), np.nan, r24m > 0), axis=0)
            mkt6 = np.nanmean(r6m, axis=0)

    out = {}
    for a, s in enumerate(syms):
        cols = []
        for name in FEATURES:
            if name in ("btc_r1", "btc_r6", "btc_r24"):
                cols.append({"btc_r1": btc_r1, "btc_r6": btc_r6, "btc_r24": btc_r24}[name])
            elif name == "beta168":
                cols.append(beta[a])
            elif name == "corr168":
                cols.append(corrb[a])
            elif name == "rel24":
                cols.append(take(s, "r24") - btc_r24)
            elif name == "g_mom6":
                cols.append(gm6[a])
            elif name == "g_mom24":
                cols.append(gm24[a])
            elif name == "g_central":
                cols.append(cent[a])
            elif name == "breadth24":
                cols.append(breadth)
            elif name == "mkt_r6":
                cols.append(mkt6)
            else:
                cols.append(take(s, name))
        X = np.column_stack(cols)
        close = take(s, "_close")
        fwd = np.full(n, np.nan)
        fwd[:-HORIZON] = np.log(close[HORIZON:] / close[:-HORIZON])
        out[s] = (T.copy(), X, fwd, close)
    return out


def latest_graph(series: dict[str, list[Candle]], window: int = 168) -> dict:
    """Correlation network + lead-lag for the UI."""
    rets = {}
    for s, cs in series.items():
        if len(cs) < window + 2:
            continue
        c = np.array([x.close for x in cs[-(window + 1):]], float)
        rets[s] = np.diff(np.log(np.maximum(c, 1e-12)))
    syms = sorted(rets)
    if len(syms) < 2:
        return {"nodes": [], "edges": []}
    M = np.vstack([rets[s] for s in syms])
    C = np.nan_to_num(np.corrcoef(M))
    A = np.abs(C) - np.eye(len(syms))
    ev = np.abs(np.linalg.eigh(A)[1][:, -1])
    ev = ev / (ev.max() or 1)
    edges = []
    for i in range(len(syms)):
        for j in range(i + 1, len(syms)):
            # lead-lag: corr(i_t, j_{t+1}) vs corr(j_t, i_{t+1})
            a = np.corrcoef(M[i, :-1], M[j, 1:])[0, 1]
            b = np.corrcoef(M[j, :-1], M[i, 1:])[0, 1]
            leader = syms[i] if a > b else syms[j]
            edges.append({"a": syms[i], "b": syms[j], "corr": round(float(C[i, j]), 3),
                          "leader": leader, "lead_strength": round(float(abs(a - b)), 3)})
    nodes = [{"symbol": s, "centrality": round(float(ev[k]), 3),
              "r24": round(float(M[k, -24:].sum()), 5)} for k, s in enumerate(syms)]
    return {"nodes": nodes, "edges": edges}
