"""Pattern Memory: "what happened before will happen again", tested properly.

1. Describe the last 24 hours as a *shape* (volatility-normalised price path) plus how much
   money traded (absolute dollar volume) and how unusual that volume was for the coin.
2. Search every coin's entire history for the most similar moments (k-nearest neighbours,
   vectorised over tens of thousands of windows).
3. Measure what happened next (4h / 24h / 72h), separately for this coin and for other coins,
   in units of each coin's own volatility, then rescale to this coin's current volatility
   (so a calm coin's history and a wild coin's history are comparable).
4. Blend own-coin and cross-coin evidence by effective sample size into one probability,
   and compare with the base rate.
5. Unlikeliness: how rare is the current move and volume surge (percentile, "1 in N days").
"""
from __future__ import annotations

import math

import numpy as np

from ..engine.types import Candle

L = 24                    # pattern length (hours)
HORIZONS = (4, 24, 72)    # hours ahead


def _r(x, n=4):
    if x is None:
        return None
    try:
        if not math.isfinite(x):
            return None
    except TypeError:
        return x
    return round(float(x), n)


def _windows(cs: list[Candle]):
    c = np.array([x.close for x in cs], float)
    v = np.array([x.volume * x.close for x in cs], float)              # dollar volume
    lc = np.log(np.maximum(c, 1e-12))
    r = np.diff(lc, prepend=lc[0])
    n = len(c)
    if n < L + max(HORIZONS) + 50:
        return None
    # rolling volatility (72h) for normalisation, causal
    vol = np.full(n, np.nan)
    if n > 72:
        cs1 = np.cumsum(np.insert(r, 0, 0))
        cs2 = np.cumsum(np.insert(r * r, 0, 0))
        m = (cs1[72:] - cs1[:-72]) / 72
        vol[71:] = np.sqrt(np.maximum((cs2[72:] - cs2[:-72]) / 72 - m * m, 1e-14))
    # shape: path of the last L log-prices relative to the window end, divided by vol*sqrt(L)
    W = np.lib.stride_tricks.sliding_window_view(lc, L)                # [n-L+1, L], window ending at i+L-1
    end = np.arange(L - 1, n)
    scale = vol[end] * math.sqrt(L)
    shape = (W - W[:, -1:]) / np.where(scale > 0, scale, np.nan)[:, None]
    usd24 = np.convolve(v, np.ones(L), "valid")                        # dollar volume of the window
    usd_avg = np.convolve(v, np.ones(24 * 30), "full")[: n] / np.minimum(np.arange(1, n + 1), 24 * 30)
    rel = np.log(np.maximum(usd24, 1e-9)) - np.log(np.maximum(usd_avg[end] * L, 1e-9))
    fwd = {h: np.full(len(end), np.nan) for h in HORIZONS}
    for h in HORIZONS:
        ok = end + h < n
        fwd[h][ok] = (lc[end[ok] + h] - lc[end[ok]]) / np.where(vol[end[ok]] > 0, vol[end[ok]] * math.sqrt(h), np.nan)
    move24 = W[:, -1] - W[:, 0]
    return {"end": end, "t": np.array([x.start for x in cs])[end], "shape": shape, "logusd": np.log(np.maximum(usd24, 1e-9)),
            "rel": rel, "vol": vol[end], "fwd": fwd, "move24": move24, "close": c[end]}


class PatternMemory:
    def __init__(self, k: int = 60):
        self.k = k
        self.cache = {}

    def build(self, series: dict[str, list[Candle]]) -> None:
        self.cache = {}
        for s, cs in series.items():
            w = _windows(cs)
            if w is not None:
                self.cache[s] = w

    def query(self, symbol: str, w_usd: float = 0.35, w_rel: float = 0.5) -> dict | None:
        if symbol not in self.cache:
            return None
        me = self.cache[symbol]
        cur_i = len(me["end"]) - 1
        q = me["shape"][cur_i]
        if not np.isfinite(q).all():
            return None
        q_usd, q_rel, q_vol = me["logusd"][cur_i], me["rel"][cur_i], me["vol"][cur_i]
        rows = []
        for s, w in self.cache.items():
            valid = np.isfinite(w["shape"]).all(axis=1) & np.isfinite(w["fwd"][HORIZONS[0]])
            if s == symbol:
                valid &= np.arange(len(w["end"])) < cur_i - L - max(HORIZONS)     # no overlap with now
            idx = np.where(valid)[0]
            if not len(idx):
                continue
            d_shape = np.sqrt(((w["shape"][idx] - q) ** 2).mean(axis=1))
            d = d_shape + w_usd * np.abs(w["logusd"][idx] - q_usd) / 3 + w_rel * np.abs(w["rel"][idx] - q_rel)
            rows.append((s, idx, d))
        if not rows:
            return None
        def pick(group, k, spacing=12):
            """Best matches with no near-duplicates: picks from the same coin must be >= spacing hours apart."""
            cand = []
            for s, idx, d in group:
                top = np.argsort(d)[: k * 25]
                cand += [(float(d[j]), s, int(idx[j])) for j in top]
            cand.sort()
            chosen, taken = [], {}
            for dist, s, i in cand:
                if any(abs(i - j) < spacing for j in taken.get(s, ())):
                    continue
                chosen.append((dist, s, i))
                taken.setdefault(s, []).append(i)
                if len(chosen) >= k:
                    break
            return chosen

        half = self.k // 2
        matches = pick([r for r in rows if r[0] == symbol], half) + pick([r for r in rows if r[0] != symbol], self.k - half)
        matches.sort()
        dists = np.array([m[0] for m in matches])
        bw = np.median(dists) or 1e-6
        wts = np.exp(-(dists / bw) ** 2)                                  # Gaussian kernel weights

        def summarize(sel):
            if not sel:
                return None
            out = {"n": len(sel)}
            ww = np.array([wts[j] for j in sel])
            out["effective_n"] = _r(ww.sum() ** 2 / (ww ** 2).sum(), 1)
            for h in HORIZONS:
                z = np.array([self.cache[matches[j][1]]["fwd"][h][matches[j][2]] for j in sel])
                ok = np.isfinite(z)
                if not ok.any():
                    continue
                zz, w2 = z[ok], ww[ok]
                move = zz * q_vol * math.sqrt(h)                         # rescaled to THIS coin's volatility
                order = np.argsort(move)
                cw = np.cumsum(w2[order]) / w2.sum()
                pct = lambda p: float(move[order][min(len(move) - 1, np.searchsorted(cw, p))])
                out[str(h)] = {"p_up": _r(float((w2 * (zz > 0)).sum() / w2.sum()), 3), "mean": _r(float((w2 * move).sum() / w2.sum()), 5),
                               "p10": _r(pct(0.1), 5), "median": _r(pct(0.5), 5), "p90": _r(pct(0.9), 5)}
            return out

        own = [j for j, m in enumerate(matches) if m[1] == symbol]
        cross = [j for j, m in enumerate(matches) if m[1] != symbol]
        res_own, res_cross, res_all = summarize(own), summarize(cross), summarize(list(range(len(matches))))
        # base rate for comparison
        base = {}
        for h in HORIZONS:
            zs = np.concatenate([w["fwd"][h][np.isfinite(w["fwd"][h])] for w in self.cache.values()])
            base[str(h)] = _r(float((zs > 0).mean()), 3) if len(zs) else None
        # difference: does this coin react differently from other coins to the same setup?
        diff = {}
        if res_own and res_cross:
            for h in HORIZONS:
                a, b = res_own.get(str(h)), res_cross.get(str(h))
                if a and b:
                    diff[str(h)] = {"p_up_diff": _r(a["p_up"] - b["p_up"], 3), "mean_diff": _r(a["mean"] - b["mean"], 5)}
        by_coin: dict[str, int] = {}
        for m in matches:
            by_coin[m[1]] = by_coin.get(m[1], 0) + 1
        top = []
        for dist, s, i in matches[:8]:
            w = self.cache[s]
            top.append({"symbol": s, "t": int(w["t"][i]), "similarity": _r(1 / (1 + dist), 3),
                        "next_24h": _r(float(w["fwd"][24][i] * w["vol"][i] * math.sqrt(24)) if np.isfinite(w["fwd"][24][i]) else None, 4),
                        "usd_24h": _r(float(np.exp(w["logusd"][i])), 0), "shape": [_r(x, 3) for x in w["shape"][i]]})
        return {"pattern_hours": L, "k": len(matches), "own": res_own, "cross": res_cross, "combined": res_all, "base_rate": base,
                "difference": diff, "by_coin": by_coin, "top": top, "current_shape": [_r(x, 3) for x in q],
                "current_usd_24h": _r(float(np.exp(q_usd)), 0), "volume_vs_normal": _r(float(np.exp(q_rel)), 2),
                "unlikeliness": self.unlikeliness(symbol)}

    def p_up(self, symbol: str, horizon: int = 4) -> float | None:
        r = self.query(symbol)
        c = (r or {}).get("combined") or {}
        return (c.get(str(horizon)) or {}).get("p_up")

    def unlikeliness(self, symbol: str) -> dict | None:
        me = self.cache.get(symbol)
        if not me:
            return None
        hist = me["move24"][:-1]
        hist = hist[np.isfinite(hist)]
        cur = float(me["move24"][-1])
        if len(hist) < 200:
            return None
        sample = hist[::24] if len(hist) > 24 * 30 else hist        # ~daily, non-overlapping
        pct = float((np.abs(sample) >= abs(cur)).mean())
        z = (cur - sample.mean()) / (sample.std() or 1)
        rel = me["rel"]
        vol_pct = float((rel[:-1][np.isfinite(rel[:-1])] <= rel[-1]).mean())
        every = (1 / pct) if pct > 0 else None
        # same-size move across all coins, in volatility units
        all_z = np.concatenate([w["move24"][::24] / np.where(w["vol"][::24] > 0, w["vol"][::24] * math.sqrt(24), np.nan)
                                for w in self.cache.values()])
        all_z = all_z[np.isfinite(all_z)]
        cur_z = cur / (me["vol"][-1] * math.sqrt(24)) if me["vol"][-1] > 0 else 0
        return {"move_24h": _r(math.exp(cur) - 1, 4), "z": _r(z, 2), "tail_prob": _r(pct, 4),
                "happens_every_days": _r(every, 1) if every else None,
                "volume_percentile": _r(vol_pct, 3),
                "all_coins_tail_prob": _r(float((np.abs(all_z) >= abs(cur_z)).mean()), 4) if len(all_z) else None,
                "label": ("extremely rare" if pct < 0.01 else "rare" if pct < 0.05 else "uncommon" if pct < 0.2 else "ordinary")}
