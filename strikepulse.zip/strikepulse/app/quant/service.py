"""Quant Engine service: trains, infers, learns online, scores itself live, emits events."""
from __future__ import annotations

import asyncio
import logging
import math
import time
from collections import defaultdict, deque

import numpy as np

from ..analytics import probability_engine
from ..engine.types import MarketEvent, Trade
from .edge import (AuthenticityScorer, CrossExchange, Derivatives, HiddenOrderDetector, detect_pump, detect_stop_run,
                   stop_clusters, trap_score)
from .features import FEATURES, HORIZON, build_panel, latest_graph
from .scheduler import PriorityScheduler, StageTimer
from .patterns import PatternMemory
from . import mathlab as M
from .models import ROUND_TRIP, DirectionModel, HedgeEnsemble, OnlineLogit, RegimeModel, decide, psi

MODEL_PATH = "data/quant_model.pkl"

log = logging.getLogger(__name__)
COMPONENTS = ["gbdt", "online", "analogs", "rules", "patterns"]
MICRO = ["buy_share", "whale_share", "divergence", "book_imb", "r5_1", "r5_3", "r5_12", "vol_z5", "premium",
         "funding", "oi_1h", "hidden_net", "stop_run"]


class QuantEngine:
    def __init__(self, engine, analytics, settings, bus, simulated: bool = False, kv_load=None, kv_save=None):
        self.engine, self.analytics, self.s, self.bus = engine, analytics, settings, bus
        self.simulated = simulated
        self.kv_load, self.kv_save = kv_load, kv_save
        self.hidden = HiddenOrderDetector()
        self.auth = AuthenticityScorer()
        self.xex = CrossExchange()
        self.deriv = Derivatives(simulated, lambda s: self.engine.prices.get(s, {}).get("price"))
        self.direction = DirectionModel()
        self.regime = RegimeModel()
        self.online = OnlineLogit(len(MICRO))
        self.hedge = HedgeEnsemble(COMPONENTS)
        self.panel: dict = {}
        self.graph: dict = {"nodes": [], "edges": []}
        self.state: dict[str, dict] = {}
        self.pending: deque = deque(maxlen=20_000)
        self.live = {"equity": 1.0, "peak": 1.0, "dd": 0.0, "resolved": 0, "hits": 0, "curve": deque(maxlen=500)}
        self.recent_edge: dict[str, deque] = defaultdict(lambda: deque(maxlen=20))
        self.last_stance: dict[str, str] = {}
        self.status = {"training": "waiting for data", "last_train": None, "last_infer": None}
        self._last_save = 0.0
        self.history: deque = deque(maxlen=50)          # retrain log (champion / challenger)
        self.drift: dict = {"max_psi": 0.0, "top": [], "checked": None}
        self._drift_trigger = False
        self.conformal: dict[str, M.AdaptiveConformal] = {}
        self.math_cache: dict[tuple, tuple[float, object]] = {}
        self.scheduler = PriorityScheduler(base_interval=120 if simulated else 300)
        self.timer = StageTimer()
        self.watchers: dict[str, int] = {}
        self._panel_key = None
        self.patterns = PatternMemory()
        self._pattern_cache: dict[str, tuple] = {}

    # ------------------------------------------------------------------ inputs
    def on_trade(self, t: Trade) -> None:
        self.hidden.on_trade(t)
        self.auth.on_trade(t)
        self.xex.on_trade(t)

    def _series(self) -> dict:
        return {s: self.analytics.candles(s, 3600) for s in list(self.analytics.hourly)
                if s not in self.engine.stable_symbols}

    # ------------------------------------------------------------------ training
    def train_now(self) -> dict:
        """Train a challenger; promote it if it beats the champion on data the champion never saw."""
        series = self._series()
        panel = build_panel(series)
        if not panel:
            self.status["training"] = "insufficient data"
            return {}
        self.panel = panel
        challenger = DirectionModel()
        t0 = time.perf_counter()
        card = challenger.train(panel, half_life_days=self.s.quant_half_life_days)
        self.timer.add("train", time.perf_counter() - t0)
        champ = self.direction
        promote, why = True, "first model"
        if champ.model is not None and challenger.model is not None:
            fwd_ll, n = champ.forward_logloss(panel)
            ch_ll = (card.get("oos") or {}).get("log_loss_calibrated")
            if fwd_ll is not None and ch_ll is not None:
                promote = ch_ll <= fwd_ll + 0.002 or card.get("status") == "deployed" and champ.card.get("status") != "deployed"
                why = f"challenger OOS log-loss {ch_ll:.4f} vs champion forward {fwd_ll:.4f} on {n} new rows"
            else:
                promote = True
                why = "not enough new data to forward-test the champion; refreshed on latest data"
        if challenger.model is None:
            promote, why = False, card.get("status", "training failed")
        if promote:
            self.direction = challenger
            X = np.vstack([p[1] for p in panel.values()])
            self.regime.fit(X)
            self._persist()
        self.graph = latest_graph(series)
        if not self.patterns.cache:
            self.patterns.build(series)
        self.history.append({"t": time.time(), "promoted": promote, "why": why, "status": card.get("status"),
                             "auc": (card.get("oos") or {}).get("auc"), "rows": card.get("rows"),
                             "trigger": "drift" if self._drift_trigger else "schedule"})
        self._drift_trigger = False
        self.status.update(training=self.direction.card.get("status"), last_train=time.time())
        log.info("quant retrain: promoted=%s (%s)", promote, why)
        return card

    async def run_training(self) -> None:
        await asyncio.sleep(5)
        self._load_model()
        last = 0.0
        while True:
            btc = self.analytics.candles("BTC-USD", 3600)
            if len(btc) < 400:
                self.status["training"] = f"waiting for history ({len(btc)}/400 hourly candles)"
                await asyncio.sleep(60)
                continue
            due = time.time() - last >= self.s.quant_retrain_minutes * 60
            drift_due = self._drift_trigger and time.time() - last >= 1800
            if self.direction.model is None or due or drift_due:
                try:
                    await asyncio.to_thread(self.train_now)
                except Exception:
                    log.exception("quant training failed")
                    self.status["training"] = "error"
                last = time.time()
            await asyncio.sleep(30)

    def _persist(self) -> None:
        import pickle
        from pathlib import Path
        try:
            Path(MODEL_PATH).parent.mkdir(parents=True, exist_ok=True)
            with open(MODEL_PATH + ".tmp", "wb") as f:
                pickle.dump({"direction": self.direction, "regime": self.regime}, f)
            Path(MODEL_PATH + ".tmp").replace(MODEL_PATH)
        except Exception:
            log.exception("model persist failed")

    def _load_model(self) -> None:
        import pickle
        from pathlib import Path
        if not Path(MODEL_PATH).exists():
            return
        try:
            with open(MODEL_PATH, "rb") as f:
                d = pickle.load(f)
            m = d["direction"].model
            if m is not None and getattr(m, "n_features_in_", -1) == len(FEATURES):
                self.direction, self.regime = d["direction"], d["regime"]
                self.status["training"] = self.direction.card.get("status")
                log.info("loaded saved quant model (%s)", self.direction.card.get("status"))
        except Exception:
            log.exception("model load failed")

    def check_drift(self) -> None:
        """PSI of the last 7 days vs the training distribution. Calendar features are skipped
        (a week always looks 'different' from months). Retrain early when >=30% of features drift."""
        bins = self.direction.bins
        if not bins or not self.panel:
            return
        cutoff = time.time() - 7 * 86400
        rows = [p[1][p[0] > cutoff] for p in self.panel.values()]
        rows = [r for r in rows if len(r)]
        if not rows:
            return
        vals = psi(bins, np.vstack(rows))
        skip = {"hour_sin", "hour_cos", "dow_sin", "dow_cos"}
        pairs = [(f, v) for f, v in zip(FEATURES, vals) if f not in skip]
        share = sum(1 for _, v in pairs if v > self.s.quant_drift_psi) / max(1, len(pairs))
        top = sorted(pairs, key=lambda x: -x[1])[:6]
        self.drift = {"share_drifting": round(share, 3), "max_psi": round(top[0][1], 3) if top else 0.0,
                      "top": [{"feature": f, "psi": round(v, 3)} for f, v in top], "checked": time.time(),
                      "threshold": self.s.quant_drift_psi, "trigger_share": 0.3}
        if share >= 0.3:
            self._drift_trigger = True

    # ------------------------------------------------------------------ math lab
    def _cached(self, key: tuple, ttl: float, fn):
        hit = self.math_cache.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
        try:
            val = fn()
        except Exception:
            log.exception("math lab %s failed", key)
            val = None
        self.math_cache[key] = (time.time(), val)
        return val

    def _conformal_for(self, sym: str, h1) -> M.AdaptiveConformal:
        c = self.conformal.get(sym)
        if c is None:
            c = self.conformal[sym] = M.AdaptiveConformal(alpha=self.s.conformal_alpha)
            if len(h1) > 200:
                cl = np.array([x.close for x in h1], float)
                r = np.diff(np.log(np.maximum(cl, 1e-12)))
                ev = M.ewma_vol(r)
                idx = np.arange(100, len(cl) - HORIZON, HORIZON)
                c.seed(np.log(cl[idx + HORIZON] / cl[idx]), ev[idx - 1] * math.sqrt(HORIZON))
        return c

    def math_lab(self, sym: str, price: float) -> dict:
        h1 = self.analytics.candles(sym, 3600)
        if len(h1) < 200:
            return {}
        hour_key = (sym, h1[-1].start, len(h1))
        hit = self.math_cache.get(("hourly_block", sym))
        if hit and hit[1][0] == hour_key:          # hourly maths only changes when a new hourly candle closes
            kf, garch, hurst, pe, ev, cp, rl, ou, cyc = hit[1][1]
        else:
            t0 = time.perf_counter()
            cl = np.array([x.close for x in h1[-1000:]], float)
            r = np.diff(np.log(np.maximum(cl, 1e-12)))
            kf = M.kalman_trend(cl[-500:])
            garch = M.garch_fit(r)
            hurst = M.hurst_dfa(r)
            pe = M.perm_entropy_series(r[-200:], 4, 48)
            ev = M.ewma_vol(r)
            cp, rl = M.bocpd(np.clip(r[-500:] / np.maximum(ev[-500:], 1e-9), -8, 8))
            ou = M.ou_fit(np.log(cl[-168:]))
            cyc = M.dominant_cycle(cl)
            wav = M.wavelet_scales(cl[-600:])
            vp7 = M.volume_profile(h1[-24 * 7:])
            self.math_cache[("wav", sym)] = (time.time(), (wav, vp7))
            self.math_cache[("hourly_block", sym)] = (time.time(), (hour_key, (kf, garch, hurst, pe, ev, cp, rl, ou, cyc)))
            self.timer.add("math_lab_hourly", time.perf_counter() - t0)
        trades = self.hidden.trades.get(sym)
        times = np.array([x[0] for x in tuple(trades) if x[0] > time.time() - 900]) if trades else np.array([])
        hawkes = self._cached(("hawkes", sym), 300, lambda: M.hawkes_fit(times[-3000:]) if len(times) >= 200 else None)
        sigma4 = (garch or {}).get("sigma_4") or float(ev[-1] * math.sqrt(HORIZON))
        conf = self._conformal_for(sym, h1)
        interval = conf.interval(price, sigma4)
        ptn = float(np.nanmean(pe[-5:])) if np.isfinite(pe[-5:]).any() else None
        wav, vp7 = (self.math_cache.get(("wav", sym)) or (0, (None, None)))[1]
        vp24 = M.volume_profile(self.analytics.candles(sym, 900)[-96:])
        return {
            "wavelets": wav, "volume_profile_7d": vp7, "volume_profile_24h": vp24,
            "kalman": {"smoothed": round(float(math.exp(kf[0][-1])), 8), "slope_per_h": round(float(kf[1][-1]), 6),
                       "t_stat": round(float(kf[1][-1] / max(kf[2][-1], 1e-12)), 2)} if kf else None,
            "garch": garch, "hurst": round(hurst, 3) if hurst is not None else None,
            "hurst_read": None if hurst is None else ("persistent / trending" if hurst > 0.55 else "mean-reverting" if hurst < 0.45 else "random-walk like"),
            "entropy": round(ptn, 3) if ptn is not None else None,
            "predictability": round(1 - ptn, 3) if ptn is not None else None,
            "change_point": {"prob_recent": round(float(cp[-1]), 3), "run_length": int(rl[-1])},
            "ou": ou, "cycle": cyc, "hawkes": hawkes,
            "conformal": {"target": 1 - self.s.conformal_alpha, "horizon_h": HORIZON, "interval": interval,
                          "live_coverage": conf.coverage(), "alpha_t": round(conf.alpha_t, 4), "calibration_n": len(conf.scores)},
            "sigma4": sigma4,
        }

    # ------------------------------------------------------------------ live inference
    def _micro(self, sym: str, an: dict, deriv: dict, hidden: list[dict], stop_run: dict | None) -> list[float]:
        f30 = an["flow"]["m30"] if an.get("flow") else {}
        m5 = self.analytics.candles(sym, 300)
        c = np.array([x.close for x in m5[-40:]], float) if m5 else np.array([])

        def ret(k):
            return float(np.log(c[-1] / c[-1 - k])) if len(c) > k else 0.0

        v = np.array([x.volume for x in m5[-40:]], float) if m5 else np.array([])
        vz = float((np.log1p(v[-1]) - np.log1p(v[:-1]).mean()) / (np.log1p(v[:-1]).std() + 1e-9)) if len(v) > 10 else 0.0
        wn, rn = f30.get("whale_net") or 0, f30.get("retail_net") or 0
        div = (1 if wn > 0 else -1 if wn < 0 else 0) if (wn and rn and (wn > 0) != (rn > 0)) else 0
        perp = deriv.get("perp") or {}
        xr = self.xex.report(sym)
        hn = sum(h["usd"] * (1 if h["side"] == "buy" else -1) for h in hidden) / 1e6
        return [((f30.get("buy_share") or 0.5) - 0.5) * 4, ((f30.get("whale_buy_share") or 0.5) - 0.5) * 4, div,
                self.engine.book_imbalance.get(sym, 0.0) * 2, ret(1) * 100, ret(3) * 60, ret(12) * 30, vz / 3,
                (xr.get("premium") or 0) / 10, (perp.get("funding_annual") or 0), (perp.get("oi_change_1h") or 0) * 20,
                max(-3, min(3, hn)), (stop_run or {}).get("direction", 0)]

    def infer(self, sym: str, now: float | None = None) -> dict | None:
        now = now or time.time()
        pinfo = self.engine.prices.get(sym, {})
        price = pinfo.get("price")
        if not price:
            return None
        data_age = max(0.0, now - (pinfo.get("ts") or now))
        p = self.panel.get(sym)
        x = None
        if p is not None:
            T, X, _fwd, _c = p
            ok = np.where(np.isfinite(X).sum(axis=1) >= X.shape[1] * 0.8)[0]
            if len(ok):
                x = X[ok[-1]]
        regime, rprobs = self.regime.predict(x) if x is not None else ("unknown", {})
        an = self.analytics.full(sym, "UTC")
        gbdt = self.direction.predict(np.nan_to_num(x)) if x is not None else None
        h4 = ((an.get("odds") or {}).get("hourly") or {}).get("horizons", {}).get("4")
        analogs = h4["p_up"] if h4 else None
        score = (an.get("pulse") or {}).get("score")
        rules = 0.5 + (score - 50) / 250 if score is not None else None
        deriv = self.deriv.report(sym)
        hidden = self.hidden.scan(sym, now)
        sr = detect_stop_run(self.analytics.candles(sym, 900))
        micro = self._micro(sym, an, deriv, hidden, sr)
        online = self.online.predict(micro) if self.online.n_updates >= 50 else None
        pat = self._pattern_cache.get(sym)
        if pat is None:
            t0 = time.perf_counter()
            pat = self.patterns.query(sym) if self.patterns.cache else None
            self._pattern_cache[sym] = pat
            self.timer.add("pattern_memory", time.perf_counter() - t0)
        pat_p = (((pat or {}).get("combined") or {}).get("4") or {}).get("p_up")
        probs = {"gbdt": gbdt if self.direction.card.get("status") == "deployed" else None,
                 "online": online, "analogs": analogs, "rules": rules, "patterns": pat_p}
        p_ens, weights = self.hedge.combine(regime, probs)
        sigma = self.analytics.sigma_hourly(sym)
        dec = decide(p_ens, sigma, regime, self.direction.card, self.live["dd"], min_precision=self.s.quant_min_precision)
        if data_age > 120:            # never act on stale information
            dec.update(stance="STAND ASIDE", size=0.0)
            dec["reasons"] = dec.get("reasons", []) + [f"market data is {int(data_age)}s old"]
        math_lab = self.math_lab(sym, price)
        # trap check on a fresh 24h breakout
        h1 = self.analytics.candles(sym, 3600)
        bdir = 0
        if len(h1) > 25:
            hi, lo = max(c.high for c in h1[-25:-1]), min(c.low for c in h1[-25:-1])
            bdir = 1 if price > hi else -1 if price < lo else 0
        f30 = (an.get("flow") or {}).get("m30") or {}
        vol_rel = float(np.log(h1[-1].volume / np.mean([c.volume for c in h1[-25:-1]]))) if len(h1) > 25 and h1[-1].volume > 0 else None
        trap = trap_score(bdir, vol_rel, f30.get("whale_buy_share"), (deriv.get("perp") or {}).get("funding_annual"))
        st = {
            "symbol": sym, "ts": now, "price": price, "regime": regime, "regime_probs": rprobs,
            "components": {k: (round(v, 4) if v is not None else None) for k, v in probs.items()},
            "component_raw_gbdt": round(gbdt, 4) if gbdt is not None else None,
            "weights": {k: round(v, 3) for k, v in weights.items()}, "p_up": round(p_ens, 4), "decision": dec,
            "micro": dict(zip(MICRO, [round(float(m), 4) for m in micro])),
            "edge": {"hidden_orders": hidden[:5], "authenticity": self.auth.report(sym), "cross_exchange": self.xex.report(sym),
                     "stop_clusters": stop_clusters(h1, price), "stop_run": sr, "pump": detect_pump(self.analytics.candles(sym, 60)),
                     "derivatives": deriv, "trap": trap, "recent": list(self.recent_edge[sym])[::-1]},
            "patterns": pat, "data_age_s": round(data_age, 1), "priority": self.scheduler.priority[sym],
            "sigma_hourly": sigma, "math": {k: v for k, v in math_lab.items() if k != "sigma4"},
        }
        self.state[sym] = st
        self.pending.append({"sym": sym, "ts": now, "price": price, "probs": probs, "regime": regime, "micro": micro,
                             "stance": dec["stance"], "size": dec["size"], "sigma4": math_lab.get("sigma4"),
                             "interval": (math_lab.get("conformal") or {}).get("interval")})
        return st

    def resolve(self, now: float | None = None) -> int:
        now = now or time.time()
        n = 0
        while self.pending and now - self.pending[0]["ts"] >= HORIZON * 3600:
            r = self.pending.popleft()
            px = self.engine.prices.get(r["sym"], {}).get("price")
            if not px:
                continue
            ret = px / r["price"] - 1
            y = int(ret > 0)
            self.hedge.update(r["regime"], r["probs"], y)
            self.online.update(r["micro"], y)
            hourly = int(r["ts"] // 300) % 12 == 0
            # adaptive conformal update: did the price land inside the range we published?
            if hourly and r.get("sigma4") and r.get("interval"):
                inside = r["interval"]["low"] <= px <= r["interval"]["high"]
                c = self.conformal.get(r["sym"])
                if c:
                    c.update(math.log(px / r["price"]), r["sigma4"], low_hit=inside)
            # live paper track of the stance (one in every 12 samples ≈ hourly, to avoid overlap inflation)
            if hourly and r["stance"] != "STAND ASIDE" and r["size"] > 0:
                d = 1 if r["stance"] == "LONG BIAS" else -1
                pnl = r["size"] * (d * ret - ROUND_TRIP)
                L = self.live
                L["equity"] *= 1 + pnl / 10          # spread over ~10 coins
                L["peak"] = max(L["peak"], L["equity"])
                L["dd"] = L["equity"] / L["peak"] - 1
                L["resolved"] += 1
                L["hits"] += int(d * ret > 0)
                L["curve"].append((int(now), round(L["equity"], 5)))
            n += 1
        return n

    def _edge_events(self, sym: str, st: dict) -> list[MarketEvent]:
        evs = self.hidden.new_events(sym, st["edge"]["hidden_orders"])
        pump = st["edge"]["pump"]
        if pump:
            key = f"pump:{sym}:{int(time.time() // 1800)}"
            if key not in self.last_stance:
                self.last_stance[key] = "x"
                evs.append(MarketEvent(kind="edge", symbol=sym, title=f"Pump signature on {sym}", direction=-1, score=80,
                                       reasons=[f"Volume {pump['volume_z']}σ above normal with a {pump['move'] * 100:+.1f}% move in {pump['minutes']} min",
                                                "Coordinated pumps usually reverse; late buyers tend to be the exit liquidity"],
                                       meta={"pattern": "pump", **pump}))
        sr = st["edge"]["stop_run"]
        if sr:
            key = f"sr:{sym}:{sr['t']}"
            if key not in self.last_stance:
                self.last_stance[key] = "x"
                evs.append(MarketEvent(kind="edge", symbol=sym, title=f"{sr['type'].capitalize()} on {sym}", direction=sr["direction"],
                                       score=72, reasons=[f"Price swept the {sr['level']} level by {sr['wick'] * 100:.2f}% then closed back inside",
                                                          f"Volume {sr['volume_x']}x average: stops were triggered and absorbed"],
                                       meta={"pattern": "stop_run", **sr}))
        d = st["decision"]
        prev = self.last_stance.get(sym)
        self.last_stance[sym] = d["stance"]
        if prev and prev != d["stance"] and d["stance"] != "STAND ASIDE" and d["confidence"] >= 0.24:
            evs.append(MarketEvent(kind="quant", symbol=sym, title=f"Quant Engine: {d['stance'].lower()} on {sym}",
                                   direction=1 if d["stance"] == "LONG BIAS" else -1, score=int(50 + d["confidence"] * 100),
                                   price=st["price"], reasons=[f"Ensemble probability higher in 4h: {d['p_up'] * 100:.0f}% (regime: {st['regime']})",
                                                               f"Component votes: " + ", ".join(f"{k} {v * 100:.0f}%" for k, v in st["components"].items() if v is not None),
                                                               f"Model risk budget: {d['size'] * 100:.1f}% of a hypothetical portfolio"],
                                   meta={"pattern": "quant_flip", "p_up": d["p_up"], "regime": st["regime"]}))
        for e in evs:
            self.recent_edge[sym].append({"t": time.time(), "title": e.title, "direction": e.direction})
        return evs

    def on_candle(self, c) -> None:
        if c.interval == 300:
            self.scheduler.trigger(c.symbol)

    def _priority_inputs(self) -> None:
        rot = {r["symbol"]: r for r in self.analytics.rotation()}
        for sym in self.s.symbols:
            m1 = self.analytics.candles(sym, 60)
            z = 0.0
            if len(m1) > 60:
                c = np.array([x.close for x in m1[-61:]], float)
                rr = np.diff(np.log(np.maximum(c, 1e-12)))
                sd = rr[:-15].std() * math.sqrt(15)
                z = float(np.log(c[-1] / c[-16]) / sd) if sd > 0 else 0.0
            self.scheduler.score(sym, (rot.get(sym) or {}).get("heat"), z, self.watchers.get(sym, 0))

    async def run(self) -> None:
        self._load()
        await asyncio.sleep(15)
        last_aux = 0.0
        tick = 5
        while True:
            try:
                syms = [s for s in self.s.symbols if s not in self.engine.stable_symbols]
                if self.direction.model is not None:
                    series = self._series()
                    key = tuple((s, cs[-1].start) for s, cs in sorted(series.items()) if cs)
                    if key != self._panel_key:             # rebuild only when a new hourly candle exists
                        t0 = time.perf_counter()
                        self.panel = await asyncio.to_thread(build_panel, series)
                        self.graph = await asyncio.to_thread(latest_graph, series)
                        await asyncio.to_thread(self.patterns.build, series)
                        self._pattern_cache.clear()
                        self._panel_key = key
                        self.timer.add("panel_rebuild", time.perf_counter() - t0)
                if time.time() - last_aux > 30:
                    await asyncio.to_thread(self._priority_inputs)
                    self.resolve()
                    self.check_drift()
                    closes = {sym: np.array([c.close for c in cs], float) for sym, cs in self._series().items()}
                    self._cached(("coint",), 1800, lambda: M.cointegration(closes))
                    rets = {k: np.diff(np.log(np.maximum(v, 1e-12))) for k, v in closes.items()}
                    self._cached(("infoflow",), 3600, lambda: M.information_flow(rets))
                    last_aux = time.time()
                for sym in self.scheduler.due(syms):
                    t0 = time.perf_counter()
                    st = await asyncio.to_thread(self.infer, sym)
                    self.timer.add("infer", time.perf_counter() - t0)
                    self.scheduler.done(sym)
                    if st:
                        for e in self._edge_events(sym, st):
                            self.scheduler.trigger(sym)
                            self.engine.publish(e)
                self.status["last_infer"] = time.time()
                if time.time() - self._last_save > 600:
                    self._save()
            except asyncio.CancelledError:
                self._save()
                raise
            except Exception:
                log.exception("quant inference loop failed")
            await asyncio.sleep(tick)

    # ------------------------------------------------------------------ persistence
    def _save(self) -> None:
        if not self.kv_save:
            return
        try:
            self.kv_save("quant_state", {"online": self.online.state(), "hedge": self.hedge.state(),
                                         "live": {k: v for k, v in self.live.items() if k != "curve"},
                                         "curve": list(self.live["curve"])})
            self._last_save = time.time()
        except Exception:
            log.exception("quant state save failed")

    def _load(self) -> None:
        if not self.kv_load:
            return
        try:
            st = self.kv_load("quant_state")
            if st:
                self.online.load(st.get("online"))
                self.hedge.load(st.get("hedge"))
                self.live.update(st.get("live", {}))
                self.live["curve"] = deque(st.get("curve", []), maxlen=500)
        except Exception:
            log.exception("quant state load failed")

    # ------------------------------------------------------------------ reporting
    def overview(self) -> list[dict]:
        rows = []
        for sym, st in sorted(self.state.items()):
            d = st["decision"]
            rows.append({"symbol": sym, "price": st["price"], "p_up": st["p_up"], "stance": d["stance"],
                         "confidence": d["confidence"], "size": d["size"], "regime": st["regime"],
                         "trap": st["edge"]["trap"], "hidden": len(st["edge"]["hidden_orders"])})
        return rows

    def model_report(self) -> dict:
        L = self.live
        return {"card": self.direction.card, "status": self.status,
                "online": {"updates": self.online.n_updates, "loss": round(self.online.loss_ema, 4), "drifts": self.online.drifts,
                           "weights": dict(zip(["bias"] + MICRO, [round(float(w), 4) for w in self.online.w]))},
                "hedge_samples": self.hedge.n, "features": FEATURES,
                "history": list(self.history)[::-1], "drift": self.drift,
                "scheduler": self.scheduler.report(), "timings": self.timer.report(),
                "cointegration": (self.math_cache.get(("coint",)) or (0, []))[1] or [],
                "information_flow": (self.math_cache.get(("infoflow",)) or (0, {}))[1] or {},
                "adaptation": {"retrain_minutes": self.s.quant_retrain_minutes, "half_life_days": self.s.quant_half_life_days,
                               "drift_threshold": self.s.quant_drift_psi, "min_precision": self.s.quant_min_precision},
                "live": {"equity": round(L["equity"], 5), "drawdown": round(L["dd"], 4), "resolved": L["resolved"],
                         "hit_rate": round(L["hits"] / L["resolved"], 3) if L["resolved"] else None, "curve": list(L["curve"])},
                "graph": self.graph}
