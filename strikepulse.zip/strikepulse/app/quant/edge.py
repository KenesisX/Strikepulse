"""Edge Lab: market-structure intelligence built only from public data.

* Hidden order detector: algorithmic TWAP / iceberg execution (same-size trades at a
  regular cadence on one side): someone quietly accumulating or distributing.
* Volume authenticity: wash-trading forensics per exchange (Benford's law on trade sizes,
  round-lot clustering, repeated identical prints), the methods used in academic studies
  of fake exchange volume.
* Pump signature: coordinated-pump pattern (volume explosion + vertical move from quiet).
* Stop clusters + stop runs: where stop-losses likely sit (swing highs/lows, round numbers)
  and when price sweeps them and snaps back (a "stop hunt").
* Cross-exchange intel: price premium between venues (e.g. the Coinbase premium) and
  which venue moves first (lead-lag).
* Derivatives positioning: perpetual funding, open interest, estimated liquidation zones,
  options max-pain / put-call ratio / biggest strikes.
* Trap detector: breakouts that look weak under the hood (low volume, whales selling into
  it, crowded funding).
"""
from __future__ import annotations

import asyncio
import logging
import math
import random
import re
import time
from collections import defaultdict, deque
from datetime import datetime, timezone

import httpx
import numpy as np

from ..engine.types import Candle, MarketEvent, Trade

log = logging.getLogger(__name__)
BENFORD = np.log10(1 + 1 / np.arange(1, 10))


def _r(x, n=4):
    if x is None:
        return None
    try:
        if math.isnan(x) or math.isinf(x):
            return None
    except TypeError:
        return x
    return round(float(x), n)


# ============================================================================ hidden orders
class HiddenOrderDetector:
    def __init__(self, window_s: int = 900, min_trades: int = 12, min_usd: float = 50_000):
        self.window_s, self.min_trades, self.min_usd = window_s, min_trades, min_usd
        self.trades: dict[str, deque] = defaultdict(lambda: deque(maxlen=20_000))
        self.active: dict[str, list[dict]] = {}
        self.seen: dict[tuple, float] = {}

    def on_trade(self, t: Trade) -> None:
        self.trades[t.symbol].append((t.ts, t.side, t.size, t.price))

    @staticmethod
    def _bucket(size: float) -> float:
        if size <= 0:
            return 0.0
        mag = 10 ** math.floor(math.log10(size))
        return round(size / mag, 2) * mag   # 3 significant figures

    def scan(self, symbol: str, now: float | None = None) -> list[dict]:
        now = now or time.time()
        dq = self.trades.get(symbol)
        if not dq:
            return []
        groups: dict[tuple, list] = defaultdict(list)
        for ts, side, size, price in tuple(dq):          # snapshot: live trades keep arriving on another thread
            if now - ts <= self.window_s:
                groups[(side, self._bucket(size))].append((ts, price, size))
        found = []
        for (side, unit), rows in groups.items():
            if len(rows) < self.min_trades or unit <= 0:
                continue
            rows.sort()
            ts = np.array([r[0] for r in rows])
            # merge prints in the same second (one child order may fill against several makers)
            uniq = np.unique(np.round(ts))
            if len(uniq) < self.min_trades:
                continue
            gaps = np.diff(uniq)
            span = uniq[-1] - uniq[0]
            if span < 180:
                continue
            cv = float(gaps.std() / gaps.mean()) if gaps.mean() > 0 else 9
            usd = float(sum(r[1] * r[2] for r in rows))
            if cv > 0.75 or usd < self.min_usd:
                continue
            found.append({"side": side, "unit_size": _r(unit, 8), "prints": len(uniq), "cadence_s": _r(float(gaps.mean()), 1),
                          "regularity": _r(1 - min(1, cv), 3), "usd": _r(usd, 0), "minutes": _r(span / 60, 1),
                          "avg_price": _r(float(np.mean([r[1] for r in rows])), 8), "started": float(uniq[0])})
        found.sort(key=lambda x: -x["usd"])
        self.active[symbol] = found
        return found

    def new_events(self, symbol: str, found: list[dict], alert_usd: float = 250_000) -> list[MarketEvent]:
        out = []
        for f in found:
            key = (symbol, f["side"], f["unit_size"])
            if f["usd"] < alert_usd or time.time() - self.seen.get(key, 0) < 3600:
                continue
            self.seen[key] = time.time()
            who = "buyer" if f["side"] == "buy" else "seller"
            out.append(MarketEvent(
                kind="edge", symbol=symbol, title=f"Hidden {who} detected on {symbol}", direction=1 if f["side"] == "buy" else -1,
                score=min(95, 60 + int(math.log10(max(f['usd'], 1)) * 4)),
                reasons=[f"{f['prints']} identical {f['side']} prints of {f['unit_size']} every ~{f['cadence_s']}s for {f['minutes']} min",
                         f"≈ ${f['usd']:,.0f} executed so far (algorithmic TWAP / iceberg pattern)",
                         "Large players slice orders to hide them; this one left a footprint"],
                meta={"pattern": "hidden_order", **f}))
        return out


# ============================================================================ authenticity
class AuthenticityScorer:
    """Wash-trading forensics on trade sizes, per exchange and symbol."""

    def __init__(self, n: int = 3000):
        self.sizes: dict[tuple, deque] = defaultdict(lambda: deque(maxlen=n))

    def on_trade(self, t: Trade) -> None:
        if t.size > 0:
            self.sizes[(t.exchange, t.symbol)].append(t.size)

    @staticmethod
    def analyse(sizes: np.ndarray) -> dict | None:
        sizes = sizes[sizes > 0]
        if len(sizes) < 300:
            return None
        first = (sizes / 10 ** np.floor(np.log10(sizes))).astype(int).clip(1, 9)
        obs = np.bincount(first, minlength=10)[1:] / len(first)
        mad = float(np.abs(obs - BENFORD).mean())                     # Nigrini MAD
        # round-lot clustering: humans trade round sizes (genuine markets cluster at them)
        mant = sizes / 10 ** np.floor(np.log10(sizes))
        round_share = float(np.isclose(mant, np.round(mant), atol=1e-6).mean())
        uniq, counts = np.unique(np.round(sizes, 10), return_counts=True)
        top_repeat = float(counts.max() / len(sizes))
        score = 100.0
        score -= min(45, max(0, (mad - 0.006) * 3000))                 # Benford non-conformity
        score -= min(25, max(0, (0.04 - round_share) * 500))           # missing human clustering
        score -= min(30, max(0, (top_repeat - 0.05) * 300))            # one size repeated a lot
        verdict = "looks genuine" if score >= 75 else "some anomalies" if score >= 50 else "suspicious volume"
        return {"score": int(round(max(0, score))), "verdict": verdict, "benford_mad": _r(mad, 4),
                "round_lot_share": _r(round_share, 3), "top_size_share": _r(top_repeat, 3), "n": int(len(sizes)),
                "digits": [_r(x, 3) for x in obs]}

    def report(self, symbol: str) -> list[dict]:
        out = []
        for (ex, sym), dq in list(self.sizes.items()):
            if sym != symbol:
                continue
            a = self.analyse(np.array(tuple(dq), float))
            if a:
                out.append({"exchange": ex, **a})
        return sorted(out, key=lambda x: -x["score"])


# ============================================================================ cross-exchange
class CrossExchange:
    def __init__(self, seconds: int = 600):
        self.last: dict[str, dict[str, tuple[float, float]]] = defaultdict(dict)
        self.grid: dict[str, dict[str, deque]] = defaultdict(lambda: defaultdict(lambda: deque(maxlen=seconds)))
        self.prem_ema: dict[str, float] = {}

    def on_trade(self, t: Trade) -> None:
        self.last[t.symbol][t.exchange] = (t.price, t.ts)
        g = self.grid[t.symbol][t.exchange]
        sec = int(t.ts)
        if g and g[-1][0] == sec:
            g[-1] = (sec, t.price)
        else:
            g.append((sec, t.price))

    def report(self, symbol: str, now: float | None = None) -> dict:
        now = now or time.time()
        venues = {ex: p for ex, (p, ts) in dict(self.last.get(symbol, {})).items() if now - ts < 120}
        out = {"venues": {k: _r(v, 8) for k, v in venues.items()}, "premium": None, "leader": None, "lag_s": None}
        if len(venues) < 2:
            return out
        ref = np.median(list(venues.values()))
        out["spread_bps"] = {k: _r((v / ref - 1) * 1e4, 2) for k, v in venues.items()}
        cb = next((v for k, v in venues.items() if "coinbase" in k), None)
        if cb:
            others = [v for k, v in venues.items() if "coinbase" not in k]
            prem = cb / np.mean(others) - 1
            self.prem_ema[symbol] = 0.9 * self.prem_ema.get(symbol, prem) + 0.1 * prem
            out["premium"] = _r(prem * 1e4, 2)          # basis points
            out["premium_ema"] = _r(self.prem_ema[symbol] * 1e4, 2)
        # lead-lag via cross-correlation of 1-second returns
        series = {}
        start = int(now) - 300
        for ex, g in list(self.grid[symbol].items()):
            px = {s: p for s, p in tuple(g) if s >= start}
            if len(px) < 30:
                continue
            arr, last = [], None
            for s in range(start, int(now)):
                last = px.get(s, last)
                arr.append(last if last is not None else np.nan)
            arr = np.array(arr, float)
            if np.isnan(arr).all():
                continue
            arr = np.where(np.isnan(arr), np.nanmean(arr), arr)
            series[ex] = np.diff(np.log(arr))
        if len(series) >= 2:
            exs = sorted(series)
            best = (0.0, None, 0)
            a, b = series[exs[0]], series[exs[1]]
            for lag in range(1, 6):
                c1 = np.corrcoef(a[:-lag], b[lag:])[0, 1] if a[:-lag].std() > 0 and b[lag:].std() > 0 else 0
                c2 = np.corrcoef(b[:-lag], a[lag:])[0, 1] if b[:-lag].std() > 0 and a[lag:].std() > 0 else 0
                if c1 > best[0]:
                    best = (c1, exs[0], lag)
                if c2 > best[0]:
                    best = (c2, exs[1], lag)
            if best[1] and best[0] > 0.1:
                out["leader"], out["lag_s"], out["lead_corr"] = best[1], best[2], _r(best[0], 3)
        return out


# ============================================================================ levels, stop runs, pumps, traps
def swing_levels(cs: list[Candle], k: int = 3) -> tuple[list[float], list[float]]:
    highs, lows = [], []
    for i in range(k, len(cs) - k):
        win = cs[i - k: i + k + 1]
        if cs[i].high == max(c.high for c in win):
            highs.append(cs[i].high)
        if cs[i].low == min(c.low for c in win):
            lows.append(cs[i].low)
    return highs, lows


def round_levels(price: float, n: int = 3) -> list[float]:
    mag = 10 ** math.floor(math.log10(price))
    steps = [mag, mag / 2, mag / 4] if price / mag < 3 else [mag, mag / 2]
    step = next((s for s in steps if price * 0.004 < s < price * 0.08), mag / 10)
    base = math.floor(price / step) * step
    return sorted({round(base + i * step, 10) for i in range(-n + 1, n + 1)})


def stop_clusters(hourly: list[Candle], price: float) -> dict:
    """Where stop-losses most likely sit: just beyond swing highs/lows and round numbers."""
    if not hourly or not price:
        return {"above": [], "below": []}
    recent = hourly[-24 * 7:]
    highs, lows = swing_levels(recent)
    cand: dict[float, float] = defaultdict(float)
    for lv in highs:
        cand[round(lv * 1.002, 8)] += 1.0    # buy-stops of shorts just above highs
    for lv in lows:
        cand[round(lv * 0.998, 8)] += 1.0    # sell-stops of longs just below lows
    for lv in round_levels(price):
        cand[lv] += 0.8
    # merge levels within 0.3%
    merged: list[list[float]] = []
    for lv in sorted(cand):
        if merged and lv / merged[-1][0] - 1 < 0.003:
            merged[-1][1] += cand[lv]
        else:
            merged.append([lv, cand[lv]])
    above = [{"price": _r(lv, 8), "strength": _r(w, 2), "dist": _r(lv / price - 1, 4)} for lv, w in merged if lv > price]
    below = [{"price": _r(lv, 8), "strength": _r(w, 2), "dist": _r(lv / price - 1, 4)} for lv, w in merged if lv < price]
    above = sorted(above, key=lambda x: x["dist"])[:5]
    below = sorted(below, key=lambda x: -x["dist"])[:5]
    return {"above": above, "below": below}


def detect_stop_run(c15: list[Candle], lookback: int = 48) -> dict | None:
    if len(c15) < lookback + 2:
        return None
    last = c15[-1]
    prior = c15[-lookback - 1:-1]
    swing_low = min(c.low for c in prior)
    swing_high = max(c.high for c in prior)
    vol_avg = np.mean([c.volume for c in prior]) or 1
    if last.low < swing_low * 0.999 and last.close > swing_low and last.volume > 1.5 * vol_avg:
        return {"type": "bullish stop run", "direction": 1, "level": _r(swing_low, 8), "wick": _r(last.low / swing_low - 1, 4),
                "volume_x": _r(last.volume / vol_avg, 2), "t": last.start}
    if last.high > swing_high * 1.001 and last.close < swing_high and last.volume > 1.5 * vol_avg:
        return {"type": "bearish stop run", "direction": -1, "level": _r(swing_high, 8), "wick": _r(last.high / swing_high - 1, 4),
                "volume_x": _r(last.volume / vol_avg, 2), "t": last.start}
    return None


def detect_pump(m1: list[Candle]) -> dict | None:
    if len(m1) < 70:
        return None
    base = m1[-63:-3]
    vols = np.array([c.volume for c in base])
    lv = np.log1p(vols)
    recent = m1[-3:]
    rv = np.log1p(sum(c.volume for c in recent) / 3)
    z = (rv - lv.mean()) / (lv.std() + 1e-9)
    move = recent[-1].close / recent[0].open - 1
    quiet = np.std([c.close / c.open - 1 for c in base])
    if z > 5 and move > max(0.025, 8 * quiet):
        return {"volume_z": _r(z, 1), "move": _r(move, 4), "minutes": 3}
    return None


def trap_score(breakout_dir: int, vol_rel: float | None, whale_share: float | None, funding_ann: float | None) -> dict:
    if breakout_dir == 0:
        return {"risk": None}
    risk, why = 0.0, []
    if vol_rel is not None and vol_rel < 0:
        risk += 0.35
        why.append("breakout on below-average volume")
    if whale_share is not None and ((breakout_dir > 0 and whale_share < 0.45) or (breakout_dir < 0 and whale_share > 0.55)):
        risk += 0.35
        why.append("whales trading against the breakout")
    if funding_ann is not None and ((breakout_dir > 0 and funding_ann > 0.3) or (breakout_dir < 0 and funding_ann < -0.3)):
        risk += 0.3
        why.append("crowded positioning (extreme funding)")
    return {"risk": _r(risk, 2), "type": "bull trap" if breakout_dir > 0 else "bear trap", "why": why}


# ============================================================================ derivatives
KRAKEN_PERP = {"BTC": "PF_XBTUSD", "ETH": "PF_ETHUSD", "SOL": "PF_SOLUSD", "XRP": "PF_XRPUSD", "DOGE": "PF_DOGEUSD",
               "ADA": "PF_ADAUSD", "AVAX": "PF_AVAXUSD", "LINK": "PF_LINKUSD", "LTC": "PF_LTCUSD", "DOT": "PF_DOTUSD"}
OPT_RE = re.compile(r"^(BTC|ETH)-(\d{1,2}[A-Z]{3}\d{2})-(\d+)-(C|P)$")
LEVERAGE_MIX = [(5, 0.25), (10, 0.35), (20, 0.2), (50, 0.15), (100, 0.05)]


class Derivatives:
    def __init__(self, simulated: bool, price_of):
        self.simulated = simulated
        self.price_of = price_of
        self.perps: dict[str, dict] = {}
        self.oi_hist: dict[str, deque] = defaultdict(lambda: deque(maxlen=24 * 12 * 2))  # 5-min samples, 2 days
        self.liq: dict[str, dict[float, float]] = defaultdict(dict)
        self.options: dict[str, dict] = {}
        self.status = {"perps": "pending", "options": "pending"}

    # ---- liquidation estimator: new OI at each price → liquidation prices per leverage tier
    def _record_oi(self, base: str, price: float, oi: float, ts: float) -> None:
        hist = self.oi_hist[base]
        if hist:
            d_oi = oi - hist[-1][2]
            book = self.liq[base]
            if d_oi > 0:
                for lev, w in LEVERAGE_MIX:
                    for side, lp in ((1, price * (1 - 1 / lev)), (-1, price * (1 + 1 / lev))):
                        k = round(lp, -int(math.floor(math.log10(price))) + 3)
                        book[side * k] = book.get(side * k, 0) + d_oi * price * w * 0.5
            # positions get liquidated when price crosses their level
            for key in list(book):
                lvl = abs(key)
                if (key > 0 and price <= lvl) or (key < 0 and price >= lvl):
                    del book[key]
        hist.append((ts, price, oi))

    def liq_zones(self, base: str, price: float, bins: int = 24) -> dict:
        book = self.liq.get(base) or {}
        if not book or not price:
            return {"longs": [], "shorts": []}
        lo, hi = price * 0.85, price * 1.15
        edges = np.linspace(lo, hi, bins + 1)
        longs, shorts = np.zeros(bins), np.zeros(bins)
        for key, usd in book.items():
            lvl = abs(key)
            if lo <= lvl < hi:
                i = min(bins - 1, int((lvl - lo) / (hi - lo) * bins))
                (longs if key > 0 else shorts)[i] += usd
        return {"edges": [_r(e, 8) for e in edges], "longs": [_r(x, 0) for x in longs], "shorts": [_r(x, 0) for x in shorts],
                "nearest_long": _r(max((abs(k) for k in book if k > 0 and abs(k) < price), default=0), 8),
                "nearest_short": _r(min((abs(k) for k in book if k < 0 and abs(k) > price), default=0), 8)}

    def oi_change(self, base: str, hours: float) -> float | None:
        hist = self.oi_hist.get(base)
        if not hist or len(hist) < 2:
            return None
        cutoff = hist[-1][0] - hours * 3600
        old = next((h for h in hist if h[0] >= cutoff), hist[0])
        return (hist[-1][2] / old[2] - 1) if old[2] else None

    # ---- data sources
    async def poll(self) -> None:
        async with httpx.AsyncClient(timeout=20, headers={"User-Agent": "StrikePulse/1.2"}) as client:
            while True:
                if self.simulated:
                    self._synthetic()
                else:
                    await self._poll_kraken(client)
                    await self._poll_deribit(client)
                # sample quickly until data exists, then every 5 minutes
                await asyncio.sleep(300 if self.perps else 15)

    async def _poll_kraken(self, client) -> None:
        try:
            r = await client.get("https://futures.kraken.com/derivatives/api/v3/tickers")
            r.raise_for_status()
            tick = {t["symbol"]: t for t in r.json().get("tickers", [])}
            now = time.time()
            for base, sym in KRAKEN_PERP.items():
                t = tick.get(sym)
                if not t or not t.get("markPrice"):
                    continue
                mark = float(t["markPrice"])
                fr = float(t.get("fundingRate") or 0)          # absolute USD per contract per hour
                rel_h = fr / mark if mark else 0.0
                oi = float(t.get("openInterest") or 0)
                self.perps[base] = {"venue": "Kraken Futures", "mark": mark, "funding_hourly": rel_h,
                                    "funding_annual": rel_h * 24 * 365, "open_interest": oi, "oi_usd": oi * mark, "ts": now}
                self._record_oi(base, mark, oi, now)
            self.status["perps"] = "ok"
        except Exception as e:
            self.status["perps"] = f"unavailable: {str(e)[:80]}"

    async def _poll_deribit(self, client) -> None:
        for cur in ("BTC", "ETH"):
            try:
                r = await client.get("https://www.deribit.com/api/v2/public/get_book_summary_by_currency",
                                     params={"currency": cur, "kind": "option"})
                r.raise_for_status()
                rows = r.json().get("result", [])
                self.options[cur] = self.options_summary(rows)
                self.status["options"] = "ok"
            except Exception as e:
                self.status["options"] = f"unavailable: {str(e)[:80]}"

    @staticmethod
    def options_summary(rows: list[dict]) -> dict:
        by_exp: dict[str, list] = defaultdict(list)
        for r in rows:
            m = OPT_RE.match(r.get("instrument_name", ""))
            if m:
                by_exp[m.group(2)].append((float(m.group(3)), m.group(4), float(r.get("open_interest") or 0)))
        if not by_exp:
            return {}

        def exp_dt(s):
            return datetime.strptime(s, "%d%b%y").replace(hour=8, tzinfo=timezone.utc)

        now = datetime.now(timezone.utc)
        future = sorted((e for e in by_exp if exp_dt(e) > now), key=exp_dt)
        if not future:
            return {}
        nearest = future[0]
        opts = by_exp[nearest]
        strikes = sorted({k for k, _, _ in opts})
        calls = {k: oi for k, t, oi in opts if t == "C"}
        puts = {k: oi for k, t, oi in opts if t == "P"}
        pain = []
        for s in strikes:
            payout = sum(oi * max(0, s - k) for k, oi in calls.items()) + sum(oi * max(0, k - s) for k, oi in puts.items())
            pain.append((payout, s))
        max_pain = min(pain)[1]
        tot_c = sum(oi for _, t, oi in (x for e in by_exp.values() for x in e) if t == "C")
        tot_p = sum(oi for _, t, oi in (x for e in by_exp.values() for x in e) if t == "P")
        top = sorted(((oi, k, t) for k, t, oi in opts), reverse=True)[:6]
        return {"expiry": nearest, "expiry_ts": exp_dt(nearest).timestamp(), "max_pain": max_pain,
                "put_call_oi": _r(tot_p / tot_c, 3) if tot_c else None,
                "top_strikes": [{"strike": k, "type": t, "oi": _r(oi, 1)} for oi, k, t in top]}

    def _synthetic(self) -> None:
        """Demo mode: plausible derivatives data so every panel can be explored."""
        now = time.time()
        for base in KRAKEN_PERP:
            px = self.price_of(f"{base}-USD")
            if not px:
                continue
            prev = self.perps.get(base, {})
            fr = prev.get("funding_hourly", 0.00001) * 0.9 + random.gauss(0.000004, 0.000012)
            oi = prev.get("open_interest", 1e8 / px) * (1 + random.gauss(0.002, 0.01))
            self.perps[base] = {"venue": "demo", "mark": px, "funding_hourly": fr, "funding_annual": fr * 24 * 365,
                                "open_interest": oi, "oi_usd": oi * px, "ts": now}
            self._record_oi(base, px, oi, now)
        for cur in ("BTC", "ETH"):
            px = self.price_of(f"{cur}-USD")
            if not px:
                continue
            step = 1000 if cur == "BTC" else 50
            rows = []
            exp = datetime.fromtimestamp(now + 3 * 86400, timezone.utc).strftime("%d%b%y").upper()
            for i in range(-12, 13):
                k = int(round(px / step) * step + i * step)
                for t in ("C", "P"):
                    oi = max(1, random.gauss(400 if cur == "BTC" else 4000, 150) * math.exp(-abs(i) / 6))
                    rows.append({"instrument_name": f"{cur}-{exp}-{k}-{t}", "open_interest": oi})
            self.options[cur] = self.options_summary(rows)
        self.status = {"perps": "demo", "options": "demo"}

    def report(self, symbol: str) -> dict:
        base = symbol.split("-")[0]
        price = self.price_of(symbol)
        p = self.perps.get(base)
        out = {"perp": None, "options": self.options.get(base), "liquidations": self.liq_zones(base, price)}
        if p:
            fa = p["funding_annual"]
            crowd = ("longs crowded: squeeze-down risk" if fa > 0.3 else "shorts crowded: short-squeeze risk" if fa < -0.1
                     else "balanced")
            out["perp"] = {**{k: _r(v, 8) if isinstance(v, float) else v for k, v in p.items()},
                           "oi_change_1h": _r(self.oi_change(base, 1), 4), "oi_change_24h": _r(self.oi_change(base, 24), 4),
                           "crowding": crowd}
        if out["options"] and price:
            mp = out["options"]["max_pain"]
            out["options"] = {**out["options"], "pull": _r(mp / price - 1, 4)}
        return out
