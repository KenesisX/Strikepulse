"""Macro & world context: how crypto behaved under different world conditions.

Sources (all free; FRED needs a free key):
* Coinbase daily candles         ~4 years of daily crypto prices
* alternative.me Fear & Greed    crypto crowd sentiment, daily since 2018
* GDELT 2.0                      world-news tone about crypto/economy + volume of crisis news
                                 (war, sanctions, recession, bank failures, defaults)
* World Bank                     GDP, growth, GDP per person, inflation, government debt,
                                 unemployment for 20 major economies + world history
* FRED (optional FRED_API_KEY)   Fed funds rate, 10-year yield, yield curve, dollar index,
                                 VIX, S&P 500

For every daily series we bucket history (e.g. Fear & Greed zones, low/mid/high terciles)
and measure crypto's forward 7- and 30-day returns in each bucket: "when the world looked
like it does now, this is what crypto did next", with sample sizes.
"""
from __future__ import annotations

import asyncio
import logging
import math
import random
import time
from datetime import datetime, timezone

import httpx
import numpy as np

log = logging.getLogger(__name__)

COUNTRIES = ["USA", "CHN", "JPN", "DEU", "IND", "GBR", "FRA", "BRA", "CAN", "KOR", "RUS", "AUS", "MEX", "IDN",
             "TUR", "SAU", "ARG", "ZAF", "NGA", "VNM"]
WB_INDICATORS = {
    "gdp_usd": "NY.GDP.MKTP.CD", "gdp_growth": "NY.GDP.MKTP.KD.ZG", "gdp_per_capita": "NY.GDP.PCAP.CD",
    "inflation": "FP.CPI.TOTL.ZG", "gov_debt_pct_gdp": "GC.DOD.TOTL.GD.ZS", "unemployment": "SL.UEM.TOTL.ZS",
}
FRED_SERIES = {"fed_funds": "DFF", "us10y": "DGS10", "yield_curve": "T10Y2Y", "dollar_index": "DTWEXBGS",
               "vix": "VIXCLS", "sp500": "SP500"}
FNG_ZONES = [(0, 25, "extreme fear"), (25, 45, "fear"), (45, 56, "neutral"), (56, 76, "greed"), (76, 101, "extreme greed")]


def _r(x, n=4):
    if x is None:
        return None
    try:
        if not math.isfinite(x):
            return None
    except TypeError:
        return x
    return round(float(x), n)


def day(ts: float) -> int:
    return int(ts // 86400)


def conditional_stats(series: dict[int, float], prices: dict[int, float], zones=None, horizons=(7, 30)) -> dict | None:
    """Bucket a daily series and measure forward crypto returns in each bucket."""
    days = sorted(d for d in series if d in prices)
    if len(days) < 120:
        return None
    vals = np.array([series[d] for d in days], float)
    if zones is None:
        q1, q2 = np.quantile(vals, [1 / 3, 2 / 3])
        zones = [(-np.inf, q1, "low"), (q1, q2, "middle"), (q2, np.inf, "high")]
    out = {"buckets": [], "n_days": len(days)}
    for lo, hi, name in zones:
        b = {"bucket": name, "range": [_r(lo, 3) if np.isfinite(lo) else None, _r(hi, 3) if np.isfinite(hi) else None]}
        sel = [d for d, v in zip(days, vals) if lo <= v < hi]
        b["days"] = len(sel)
        for h in horizons:
            rets = np.array([prices[d + h] / prices[d] - 1 for d in sel if d + h in prices])
            if len(rets) >= 10:
                # non-overlapping effective sample (one observation per horizon length)
                b[f"fwd_{h}d"] = {"mean": _r(float(rets.mean()), 4), "median": _r(float(np.median(rets)), 4),
                                  "p_up": _r(float((rets > 0).mean()), 3), "n": int(len(rets)),
                                  "independent_n": int(max(1, len(rets) // h))}
        out["buckets"].append(b)
    cur = series[max(series)]
    out["current_value"] = _r(cur, 3)
    out["current_bucket"] = next((name for lo, hi, name in zones if lo <= cur < hi), None)
    # unconditional baseline
    for h in horizons:
        rets = np.array([prices[d + h] / prices[d] - 1 for d in days if d + h in prices])
        out[f"baseline_{h}d"] = {"mean": _r(float(rets.mean()), 4), "p_up": _r(float((rets > 0).mean()), 3)} if len(rets) else None
    return out


def rolling_corr(a: dict[int, float], b: dict[int, float], window: int = 90) -> float | None:
    days = sorted(set(a) & set(b))[-window - 1:]
    if len(days) < 30:
        return None
    x = np.diff(np.log([a[d] for d in days]))
    y = np.diff(np.log([max(b[d], 1e-9) for d in days]))
    if x.std() == 0 or y.std() == 0:
        return None
    return float(np.corrcoef(x, y)[0, 1])


class MacroContext:
    def __init__(self, settings, simulated: bool, hourly_provider=None):
        self.s = settings
        self.simulated = simulated
        self.hourly_provider = hourly_provider
        self.daily: dict[str, dict[int, float]] = {}          # symbol -> day -> close
        self.series: dict[str, dict[int, float]] = {}         # macro name -> day -> value
        self.countries: list[dict] = []
        self.world_history: dict[str, dict[int, float]] = {}  # indicator -> year -> value
        self.status: dict[str, str] = {}
        self.updated = 0.0
        self._summary = None

    # ------------------------------------------------------------------ fetchers
    async def _get(self, client, url, **params):
        r = await client.get(url, params=params or None)
        r.raise_for_status()
        return r.json()

    async def fetch_daily_prices(self, client, symbols=("BTC-USD", "ETH-USD", "SOL-USD")):
        for sym in symbols:
            rows: dict[int, float] = {}
            end = int(time.time() // 86400) * 86400
            for _ in range(5):
                start = end - 300 * 86400
                try:
                    data = await self._get(client, f"https://api.exchange.coinbase.com/products/{sym}/candles", granularity=86400,
                                           start=datetime.fromtimestamp(start, timezone.utc).isoformat(),
                                           end=datetime.fromtimestamp(end, timezone.utc).isoformat())
                except Exception as e:
                    self.status["prices"] = f"unavailable: {str(e)[:80]}"
                    break
                if not data:
                    break
                for t, lo, hi, o, c, v in data:
                    rows[day(t)] = float(c)
                end = start
                await asyncio.sleep(0.35)
            if rows:
                self.daily[sym] = rows
                self.status["prices"] = "ok"

    async def fetch_fng(self, client):
        try:
            data = await self._get(client, "https://api.alternative.me/fng/", limit=0, format="json")
            self.series["fear_greed"] = {day(int(x["timestamp"])): float(x["value"]) for x in data.get("data", [])}
            self.status["fear_greed"] = "ok"
        except Exception as e:
            self.status["fear_greed"] = f"unavailable: {str(e)[:80]}"

    async def fetch_gdelt(self, client):
        base = "https://api.gdeltproject.org/api/v2/doc/doc"
        try:
            data = await self._get(client, base, query="(bitcoin OR cryptocurrency OR economy)", mode="timelinetone",
                                   timespan="12m", format="json")
            pts = (data.get("timeline") or [{}])[0].get("data", [])
            self.series["news_tone"] = {day(datetime.strptime(p["date"][:8], "%Y%m%d").replace(tzinfo=timezone.utc).timestamp()): float(p["value"])
                                        for p in pts}
            await asyncio.sleep(6)   # GDELT asks for ~1 request per 5 seconds
            data = await self._get(client, base, query='(war OR sanctions OR recession OR "bank failure" OR default OR tariffs)',
                                   mode="timelinevol", timespan="12m", format="json")
            pts = (data.get("timeline") or [{}])[0].get("data", [])
            self.series["crisis_news"] = {day(datetime.strptime(p["date"][:8], "%Y%m%d").replace(tzinfo=timezone.utc).timestamp()): float(p["value"])
                                          for p in pts}
            self.status["gdelt"] = "ok"
        except Exception as e:
            self.status["gdelt"] = f"unavailable: {str(e)[:80]}"

    async def fetch_world_bank(self, client):
        try:
            by_country: dict[str, dict] = {}
            for key, ind in WB_INDICATORS.items():
                data = await self._get(client, f"https://api.worldbank.org/v2/country/{';'.join(COUNTRIES)}/indicator/{ind}",
                                       format="json", mrnev=1, per_page=200)
                for row in (data[1] if isinstance(data, list) and len(data) > 1 and data[1] else []):
                    c = row["countryiso3code"] or row["country"]["id"]
                    d = by_country.setdefault(c, {"code": c, "name": row["country"]["value"]})
                    d[key] = row["value"]
                    d[key + "_year"] = row["date"]
                await asyncio.sleep(0.3)
            self.countries = sorted(by_country.values(), key=lambda d: -(d.get("gdp_usd") or 0))
            for key in ("gdp_growth", "inflation"):
                data = await self._get(client, f"https://api.worldbank.org/v2/country/WLD/indicator/{WB_INDICATORS[key]}",
                                       format="json", date="2012:2025", per_page=100)
                rows = data[1] if isinstance(data, list) and len(data) > 1 and data[1] else []
                self.world_history[key] = {int(r["date"]): r["value"] for r in rows if r["value"] is not None}
            self.status["world_bank"] = "ok"
        except Exception as e:
            self.status["world_bank"] = f"unavailable: {str(e)[:80]}"

    async def fetch_fred(self, client):
        if not self.s.fred_api_key:
            self.status["fred"] = "off (set FRED_API_KEY, free at fred.stlouisfed.org)"
            return
        try:
            start = datetime.fromtimestamp(time.time() - 5 * 365 * 86400, timezone.utc).strftime("%Y-%m-%d")
            for name, sid in FRED_SERIES.items():
                data = await self._get(client, "https://api.stlouisfed.org/fred/series/observations", series_id=sid,
                                       api_key=self.s.fred_api_key, file_type="json", observation_start=start)
                vals = {}
                for o in data.get("observations", []):
                    if o["value"] not in (".", ""):
                        vals[day(datetime.strptime(o["date"], "%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp())] = float(o["value"])
                if vals:
                    self.series[name] = vals
                await asyncio.sleep(0.3)
            self.status["fred"] = "ok"
        except Exception as e:
            self.status["fred"] = f"unavailable: {str(e)[:80]}"

    def synthetic(self) -> None:
        """Demo mode: daily prices from the simulator's hourly history + plausible macro series."""
        rng = random.Random(42)
        if self.hourly_provider:
            for sym in ("BTC-USD", "ETH-USD", "SOL-USD"):
                hs = self.hourly_provider(sym)
                if hs:
                    self.daily[sym] = {day(c.start): c.close for c in hs}
        days = sorted(self.daily.get("BTC-USD", {}))
        if not days:
            return
        btc = self.daily["BTC-USD"]
        fg, tone, crisis, vix, dxy = {}, {}, {}, {}, {}
        f, v, x = 50.0, 18.0, 103.0
        for i, d in enumerate(days):
            r7 = btc[d] / btc[days[max(0, i - 7)]] - 1
            f = min(99, max(1, 0.8 * f + 0.2 * (50 + r7 * 400) + rng.gauss(0, 4)))
            v = max(10, 0.9 * v + 0.1 * (18 - r7 * 60) + rng.gauss(0, 1))
            x = x * math.exp(rng.gauss(0, 0.003))
            fg[d], vix[d], dxy[d] = round(f), round(v, 2), round(x, 2)
            tone[d] = round(-1.5 + r7 * 8 + rng.gauss(0, 0.4), 3)
            crisis[d] = round(max(0.1, 1 + rng.gauss(0, 0.3) - r7 * 2), 3)
        self.series.update(fear_greed=fg, news_tone=tone, crisis_news=crisis, vix=vix, dollar_index=dxy)
        self.countries = [
            {"code": "USA", "name": "United States", "gdp_usd": 2.9e13, "gdp_growth": 2.8, "gdp_per_capita": 85800, "inflation": 2.9, "gov_debt_pct_gdp": 120, "unemployment": 4.1},
            {"code": "CHN", "name": "China", "gdp_usd": 1.87e13, "gdp_growth": 5.0, "gdp_per_capita": 13300, "inflation": 0.2, "gov_debt_pct_gdp": None, "unemployment": 4.6},
            {"code": "DEU", "name": "Germany", "gdp_usd": 4.7e12, "gdp_growth": -0.2, "gdp_per_capita": 55800, "inflation": 2.3, "gov_debt_pct_gdp": 45, "unemployment": 3.4},
            {"code": "JPN", "name": "Japan", "gdp_usd": 4.0e12, "gdp_growth": 0.1, "gdp_per_capita": 32500, "inflation": 2.7, "gov_debt_pct_gdp": 215, "unemployment": 2.5},
            {"code": "IND", "name": "India", "gdp_usd": 3.9e12, "gdp_growth": 6.5, "gdp_per_capita": 2700, "inflation": 4.9, "gov_debt_pct_gdp": 55, "unemployment": 4.2},
        ]
        for c in self.countries:
            c["demo"] = True
        self.world_history = {"gdp_growth": {y: 3 + rng.gauss(0, 1.2) for y in range(2014, 2025)},
                              "inflation": {y: 3.5 + rng.gauss(0, 1.5) for y in range(2014, 2025)}}
        self.status = {k: "demo" for k in ("prices", "fear_greed", "gdelt", "world_bank", "fred")}

    async def refresh(self) -> None:
        if self.simulated:
            self.synthetic()
        else:
            async with httpx.AsyncClient(timeout=30, headers={"User-Agent": "StrikePulse/1.4"}) as client:
                await self.fetch_daily_prices(client)
                await self.fetch_fng(client)
                await self.fetch_gdelt(client)
                await self.fetch_world_bank(client)
                await self.fetch_fred(client)
        self.updated = time.time()
        self._summary = None

    async def run(self) -> None:
        await asyncio.sleep(10 if self.simulated else 60)
        while True:
            try:
                await self.refresh()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("macro refresh failed")
            await asyncio.sleep(6 * 3600)

    # ------------------------------------------------------------------ analysis
    def summary(self, symbol: str = "BTC-USD") -> dict:
        if self._summary and self._summary.get("symbol") == symbol:
            return self._summary
        prices = self.daily.get(symbol) or self.daily.get("BTC-USD") or {}
        out = {"symbol": symbol, "updated": self.updated, "status": self.status, "simulated": self.simulated,
               "conditions": {}, "correlations": {}, "countries": self.countries, "yearly": []}
        labels = {"fear_greed": "Crypto Fear & Greed", "news_tone": "World news tone (GDELT)",
                  "crisis_news": "Crisis-news volume (war, sanctions, recession…)", "vix": "VIX (stock-market fear)",
                  "dollar_index": "US dollar index", "fed_funds": "Fed funds rate", "us10y": "US 10-year yield",
                  "yield_curve": "Yield curve (10y-2y)", "sp500": "S&P 500"}
        for name, ser in self.series.items():
            zones = [(lo, hi, n) for lo, hi, n in FNG_ZONES] if name == "fear_greed" else None
            st = conditional_stats(ser, prices, zones)
            if st:
                st["label"] = labels.get(name, name)
                out["conditions"][name] = st
            if name in ("sp500", "dollar_index", "vix"):
                c = rolling_corr(prices, ser)
                if c is not None:
                    out["correlations"][name] = {"label": labels.get(name, name), "corr_90d": _r(c, 3)}
        # yearly: crypto return vs world growth / inflation
        yearly = {}
        for d, p in prices.items():
            y = datetime.fromtimestamp(d * 86400, timezone.utc).year
            yearly.setdefault(y, []).append((d, p))
        for y, pts in sorted(yearly.items()):
            pts.sort()
            if len(pts) > 200:
                out["yearly"].append({"year": y, "return": _r(pts[-1][1] / pts[0][1] - 1, 4),
                                      "world_gdp_growth": _r(self.world_history.get("gdp_growth", {}).get(y), 2),
                                      "world_inflation": _r(self.world_history.get("inflation", {}).get(y), 2)})
        # macro tilt: compare each condition's current-bucket 30d mean to its baseline
        tilts = []
        for name, st in out["conditions"].items():
            b = next((x for x in st["buckets"] if x["bucket"] == st["current_bucket"]), None)
            base = st.get("baseline_30d")
            if b and base and b.get("fwd_30d") and b["fwd_30d"]["independent_n"] >= 3:
                tilts.append({"factor": st["label"], "now": st["current_bucket"], "value": st["current_value"],
                              "fwd_30d_mean": b["fwd_30d"]["mean"], "baseline_30d_mean": base["mean"],
                              "edge": _r(b["fwd_30d"]["mean"] - base["mean"], 4), "p_up": b["fwd_30d"]["p_up"],
                              "independent_n": b["fwd_30d"]["independent_n"]})
        out["tilts"] = sorted(tilts, key=lambda t: -abs(t["edge"] or 0))
        if tilts:
            w = np.array([math.sqrt(t["independent_n"]) for t in tilts])
            e = np.array([t["edge"] for t in tilts])
            out["macro_tilt_30d"] = _r(float((w * e).sum() / w.sum()), 4)
        self._summary = out
        return out
