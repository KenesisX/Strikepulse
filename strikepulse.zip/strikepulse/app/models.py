"""ORM models."""
from __future__ import annotations

import secrets
import time
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def new_api_key() -> str:
    return "sp_" + secrets.token_urlsafe(32)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    disabled: Mapped[bool] = mapped_column(Boolean, default=False)

    # billing
    plan: Mapped[str] = mapped_column(String(20), default="free")
    plan_status: Mapped[str] = mapped_column(String(30), default="active")
    stripe_customer_id: Mapped[str | None] = mapped_column(String(64), index=True, nullable=True)
    stripe_subscription_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    current_period_end: Mapped[float | None] = mapped_column(Float, nullable=True)

    # delivery channels
    telegram_chat_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    telegram_link_code: Mapped[str] = mapped_column(String(32), default=lambda: secrets.token_hex(6))
    discord_webhook: Mapped[str | None] = mapped_column(String(500), nullable=True)
    ntfy_topic: Mapped[str | None] = mapped_column(String(120), nullable=True)
    webhook_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    email_alerts: Mapped[bool] = mapped_column(Boolean, default=False)
    alert_email: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # preferences
    timezone: Mapped[str] = mapped_column(String(64), default="America/Denver")
    quiet_start: Mapped[int | None] = mapped_column(Integer, nullable=True)   # hour 0-23
    quiet_end: Mapped[int | None] = mapped_column(Integer, nullable=True)
    paused_until: Mapped[float | None] = mapped_column(Float, nullable=True)
    want_depeg: Mapped[bool] = mapped_column(Boolean, default=True)
    want_listings: Mapped[bool] = mapped_column(Boolean, default=False)
    gas_below: Mapped[int | None] = mapped_column(Integer, nullable=True)
    want_movers: Mapped[bool] = mapped_column(Boolean, default=False)       # market-wide big-move alerts
    movers_min_pct: Mapped[float] = mapped_column(Float, default=8.0)

    api_key: Mapped[str] = mapped_column(String(80), unique=True, index=True, default=new_api_key)

    watches: Mapped[list["Watch"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    onchain_watches: Mapped[list["OnchainWatch"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    devices: Mapped[list["Device"]] = relationship(back_populates="user", cascade="all, delete-orphan")

    @property
    def paused(self) -> bool:
        return bool(self.paused_until and self.paused_until > time.time())


class Watch(Base):
    __tablename__ = "watches"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    symbol: Mapped[str] = mapped_column(String(30), index=True)
    min_score: Mapped[int] = mapped_column(Integer, default=60)
    timeframes: Mapped[str] = mapped_column(String(50), default="5m,15m")
    direction: Mapped[str] = mapped_column(String(10), default="both")   # both | up | down
    detectors: Mapped[str] = mapped_column(String(300), default="")       # empty = all allowed
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    user: Mapped[User] = relationship(back_populates="watches")

    @property
    def tf_list(self) -> list[str]:
        return [t for t in self.timeframes.split(",") if t]

    @property
    def detector_list(self) -> list[str]:
        return [d for d in self.detectors.split(",") if d]


class OnchainWatch(Base):
    __tablename__ = "onchain_watches"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(10))          # wallet | token | pair
    address: Mapped[str] = mapped_column(String(42), index=True)
    label: Mapped[str] = mapped_column(String(80), default="")
    min_usd: Mapped[float] = mapped_column(Float, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    user: Mapped[User] = relationship(back_populates="onchain_watches")


class Alert(Base):
    __tablename__ = "alerts"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    kind: Mapped[str] = mapped_column(String(20), index=True)
    symbol: Mapped[str] = mapped_column(String(60), index=True)
    title: Mapped[str] = mapped_column(String(255))
    direction: Mapped[int] = mapped_column(Integer, default=0)
    score: Mapped[int] = mapped_column(Integer, default=0)
    price: Mapped[float | None] = mapped_column(Float, nullable=True)
    timeframe: Mapped[str] = mapped_column(String(10), default="")
    reasons: Mapped[list] = mapped_column(JSON, default=list)
    signals: Mapped[list] = mapped_column(JSON, default=list)
    meta: Mapped[dict] = mapped_column(JSON, default=dict)
    ts: Mapped[float] = mapped_column(Float, index=True)

    def to_dict(self) -> dict:
        return {"id": self.id, "kind": self.kind, "symbol": self.symbol, "title": self.title,
                "direction": self.direction, "score": self.score, "price": self.price,
                "timeframe": self.timeframe, "reasons": self.reasons, "signals": self.signals,
                "meta": self.meta, "ts": self.ts}


class Delivery(Base):
    __tablename__ = "deliveries"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    alert_id: Mapped[str] = mapped_column(String(32), index=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True)
    channel: Mapped[str] = mapped_column(String(20))
    ok: Mapped[bool] = mapped_column(Boolean, default=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[float] = mapped_column(Float, default=time.time, index=True)


class KV(Base):
    __tablename__ = "kv"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[dict | list | None] = mapped_column(JSON, nullable=True)


class OutcomeCheck(Base):
    """Live accuracy tracking: what the price did N minutes after each market alert."""
    __tablename__ = "outcome_checks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    alert_id: Mapped[str] = mapped_column(String(32), index=True)
    symbol: Mapped[str] = mapped_column(String(30))
    timeframe: Mapped[str] = mapped_column(String(10), default="")
    direction: Mapped[int] = mapped_column(Integer)
    score: Mapped[int] = mapped_column(Integer)
    horizon: Mapped[int] = mapped_column(Integer)            # minutes
    price0: Mapped[float] = mapped_column(Float)
    due_ts: Mapped[float] = mapped_column(Float, index=True)
    price1: Mapped[float | None] = mapped_column(Float, nullable=True)
    ret: Mapped[float | None] = mapped_column(Float, nullable=True)   # signed move in the alert's direction
    status: Mapped[str] = mapped_column(String(10), default="pending", index=True)


DEVICE_KINDS = {
    "esp32": "ESP32 display", "pi": "Raspberry Pi monitor", "wearos": "Galaxy / Wear OS watch",
    "watchos": "Apple Watch", "extension": "Browser extension", "desktop": "Desktop tray app",
    "homeassistant": "Home Assistant", "micropython": "MicroPython board", "other": "Other / custom",
}


class Device(Base):
    """A companion device (watch, ESP32, Pi, extension...) with its own read-only token."""
    __tablename__ = "devices"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(60), default="My device")
    kind: Mapped[str] = mapped_column(String(20), default="other")
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    token_prefix: Mapped[str] = mapped_column(String(12), default="")
    pair_code: Mapped[str | None] = mapped_column(String(8), nullable=True, index=True)
    pair_expires: Mapped[float | None] = mapped_column(Float, nullable=True)
    pending_token: Mapped[str | None] = mapped_column(String(80), nullable=True)   # handed out once on pairing
    created_at: Mapped[float] = mapped_column(Float, default=time.time)
    last_seen: Mapped[float | None] = mapped_column(Float, nullable=True)
    user: Mapped[User] = relationship(back_populates="devices")

    @property
    def kind_label(self) -> str:
        return DEVICE_KINDS.get(self.kind, self.kind)
