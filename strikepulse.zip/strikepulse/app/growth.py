"""Growth features that help sell subscriptions:

* PerformanceTracker: measures what price actually did 15/60/240 minutes after every
  market alert, powering the public /performance page (proof that alerts are useful).
* PromoPoster: posts strong alerts, delayed, to a free public Telegram channel and/or
  Discord server with an "upgrade for real-time" link. Free users become paying users.
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import deque

import httpx
from sqlalchemy import select

from .alerts import channels, formatting
from .config import Settings
from .db import session_scope
from .engine.types import MarketEvent
from .models import OutcomeCheck

log = logging.getLogger(__name__)


class PerformanceTracker:
    def __init__(self, settings: Settings, bus, engine):
        self.s, self.bus, self.engine = settings, bus, engine
        self.status = {"scheduled": 0, "completed": 0, "expired": 0}

    def price_at(self, symbol: str, ts: float) -> float | None:
        """Close of the 1-minute candle covering `ts`, else the live price if it's fresh."""
        series = self.engine.book.series.get((symbol, 60))
        if series:
            for c in reversed(series.history(include_current=True)):
                if c.start <= ts < c.start + 60:
                    return c.close
                if c.start < ts - 120:
                    break
        p = self.engine.prices.get(symbol)
        if p and abs(p.get("ts", 0) - ts) <= 120:
            return p["price"]
        return None

    def schedule(self, e: MarketEvent) -> None:
        if e.kind != "market" or not e.price or not e.direction or e.meta.get("manual"):
            return
        with session_scope() as db:
            for h in self.s.outcome_horizons:
                db.add(OutcomeCheck(alert_id=e.id, symbol=e.symbol, timeframe=e.timeframe, direction=e.direction,
                                    score=e.score, horizon=h, price0=e.price, due_ts=e.ts + h * 60))
        self.status["scheduled"] += len(self.s.outcome_horizons)

    def resolve_due(self, now: float | None = None) -> int:
        now = now or time.time()
        done = 0
        with session_scope() as db:
            rows = db.scalars(select(OutcomeCheck).where(OutcomeCheck.status == "pending",
                                                         OutcomeCheck.due_ts <= now).limit(500)).all()
            for r in rows:
                px = self.price_at(r.symbol, r.due_ts)
                if px:
                    r.price1 = px
                    r.ret = (px / r.price0 - 1) * r.direction
                    r.status = "done"
                    done += 1
                    self.status["completed"] += 1
                elif now - r.due_ts > 900:          # no data for that moment (e.g. server was down)
                    r.status = "expired"
                    self.status["expired"] += 1
        return done

    async def run(self) -> None:
        q = self.bus.subscribe(maxsize=5000)
        last = 0.0
        try:
            while True:
                try:
                    e = await asyncio.wait_for(q.get(), timeout=15)
                    await asyncio.to_thread(self.schedule, e)
                except asyncio.TimeoutError:
                    pass
                if time.time() - last > 30:
                    last = time.time()
                    try:
                        await asyncio.to_thread(self.resolve_due)
                    except Exception:
                        log.exception("outcome resolution failed")
        finally:
            self.bus.unsubscribe(q)


def performance_summary(days: int = 30) -> dict:
    """Aggregate finished checks for the /performance page and the API."""
    since = time.time() - days * 86400
    with session_scope() as db:
        rows = db.scalars(select(OutcomeCheck).where(OutcomeCheck.status == "done", OutcomeCheck.due_ts >= since)).all()
        rows = [(r.horizon, r.score, r.timeframe, r.ret, r.alert_id, r.symbol, r.direction, r.price0, r.price1, r.due_ts)
                for r in rows]

    def agg(sub):
        if not sub:
            return {"n": 0, "hit": None, "avg": None}
        rets = [x[3] for x in sub]
        return {"n": len(sub), "hit": sum(1 for r in rets if r > 0) / len(sub), "avg": sum(rets) / len(rets)}

    horizons = sorted({r[0] for r in rows})
    out = {"days": days, "horizons": horizons, "overall": {}, "by_score": {}, "by_tf": {}, "alerts": 0}
    out["alerts"] = len({r[4] for r in rows})
    buckets = [("40-59", 40, 59), ("60-79", 60, 79), ("80-100", 80, 100)]
    for h in horizons:
        hs = [r for r in rows if r[0] == h]
        out["overall"][h] = agg(hs)
        out["by_score"][h] = {name: agg([r for r in hs if lo <= r[1] <= hi]) for name, lo, hi in buckets}
        out["by_tf"][h] = {tf: agg([r for r in hs if r[2] == tf]) for tf in sorted({r[2] for r in hs})}
    mid = horizons[len(horizons) // 2] if horizons else None
    recent = sorted((r for r in rows if r[0] == mid), key=lambda r: -r[9])[:25] if mid else []
    out["recent"] = [{"symbol": r[5], "direction": r[6], "score": r[1], "tf": r[2], "p0": r[7], "p1": r[8],
                      "ret": r[3], "ts": r[9]} for r in recent]
    out["recent_horizon"] = mid
    return out


class PromoPoster:
    KINDS = ("market", "depeg", "listing")

    def __init__(self, settings: Settings, bus):
        self.s, self.bus = settings, bus
        self.posted: deque[float] = deque()
        self.status = {"posted": 0, "skipped": 0, "errors": 0}
        self._tasks: set[asyncio.Task] = set()

    def wants(self, e: MarketEvent) -> bool:
        if e.kind not in self.KINDS or e.meta.get("manual"):
            return False
        return e.score >= self.s.promo_min_score or e.kind == "depeg"

    def _rate_ok(self) -> bool:
        now = time.time()
        while self.posted and now - self.posted[0] > 3600:
            self.posted.popleft()
        if len(self.posted) >= self.s.promo_max_per_hour:
            return False
        self.posted.append(now)
        return True

    def render(self, e: MarketEvent) -> tuple[str, dict]:
        delay_min = max(1, self.s.promo_delay // 60)
        cta = f"⚡ Members got this {delay_min} min earlier. Real-time alerts: {self.s.base_url}/pricing"
        tg = formatting.telegram_html(e) + f"\n\n{cta}"
        dc = formatting.discord_payload(e, self.s.base_url, app_name=self.s.app_name)
        dc["content"] = cta
        return tg, dc

    async def post(self, client: httpx.AsyncClient, e: MarketEvent) -> None:
        await asyncio.sleep(self.s.promo_delay)
        if not self._rate_ok():
            self.status["skipped"] += 1
            return
        tg, dc = self.render(e)
        try:
            if self.s.promo_telegram_chat and self.s.telegram_bot_token:
                await channels.send_telegram(client, self.s.telegram_bot_token, self.s.promo_telegram_chat, tg,
                                             f"{self.s.base_url}/pricing")
            if self.s.promo_discord_webhook:
                await channels.send_discord(client, self.s.promo_discord_webhook, dc)
            self.status["posted"] += 1
        except Exception as ex:
            self.status["errors"] += 1
            self.status["last_error"] = str(ex)[:200]
            log.warning("promo post failed: %s", ex)

    async def run(self) -> None:
        q = self.bus.subscribe(maxsize=2000)
        async with httpx.AsyncClient(timeout=15) as client:
            try:
                while True:
                    e = await q.get()
                    if self.wants(e):
                        t = asyncio.create_task(self.post(client, e))
                        self._tasks.add(t)
                        t.add_done_callback(self._tasks.discard)
            finally:
                self.bus.unsubscribe(q)
