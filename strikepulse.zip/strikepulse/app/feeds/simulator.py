"""Synthetic market feed for demos, development and testing (FEEDS=simulator).

Prices follow a regime-switching random walk (calm / uptrend / downtrend / pump / dump)
with matching volume and order-flow behaviour, so every detector gets realistic
triggers. On start it quickly generates a few hours of history so detectors are warm.
"""
from __future__ import annotations

import asyncio
import math
import random
import time

from ..engine.types import BookTop, Trade

BASE_PRICES = {
    "BTC-USD": 97000, "ETH-USD": 3400, "SOL-USD": 190, "XRP-USD": 1.25, "DOGE-USD": 0.32,
    "ADA-USD": 0.85, "AVAX-USD": 38, "LINK-USD": 21, "LTC-USD": 105, "DOT-USD": 7.2,
    "USDT-USD": 1.0, "USDC-USD": 1.0,
}

REGIMES = {
    #           drift(σ/s) vol x  size x  buy p   duration (s)
    "calm":     (0.00,     1.0,   1.0,    0.50,   (300, 900)),
    "uptrend":  (0.07,     1.2,   1.4,    0.56,   (240, 720)),
    "downtrend": (-0.07,   1.2,   1.4,    0.44,   (240, 720)),
    "pump":     (0.45,     2.5,   4.0,    0.72,   (60, 180)),
    "dump":     (-0.45,    2.5,   4.0,    0.28,   (60, 180)),
}
NEXT = {
    "calm": [("calm", 30), ("uptrend", 25), ("downtrend", 25), ("pump", 10), ("dump", 10)],
    "uptrend": [("calm", 50), ("downtrend", 20), ("pump", 15), ("uptrend", 15)],
    "downtrend": [("calm", 50), ("uptrend", 20), ("dump", 15), ("downtrend", 15)],
    "pump": [("calm", 60), ("uptrend", 25), ("dump", 15)],
    "dump": [("calm", 60), ("downtrend", 25), ("pump", 15)],
}


class _Sym:
    def __init__(self, symbol: str, rng: random.Random, vol_mult: float):
        self.symbol = symbol
        self.stable = symbol.startswith(("USDT", "USDC", "DAI", "PYUSD"))
        self.price = BASE_PRICES.get(symbol, rng.uniform(1, 500))
        self.base = self.price
        self.sigma = (0.00004 if self.stable else 0.00022) * vol_mult   # per-second log vol
        self.base_size = 2500.0 / self.price
        self.rng = rng
        self.regime = "calm"
        self.until = 0.0
        self.premium = 0.0            # sim "Coinbase premium" (fraction)
        self.twap = None              # active hidden order: dict(side, unit, next, until)

    def maybe_switch(self, now: float) -> None:
        if self.stable or now < self.until:
            return
        opts = NEXT[self.regime]
        total = sum(w for _, w in opts)
        pick, acc = self.rng.uniform(0, total), 0.0
        for name, w in opts:
            acc += w
            if pick <= acc:
                self.regime = name
                break
        lo, hi = REGIMES[self.regime][4]
        self.until = now + self.rng.uniform(lo, hi)

    def step(self, now: float, dt: float, rate: float, common: float = 0.0) -> list:
        self.maybe_switch(now)
        drift, volx, sizex, buyp, _ = REGIMES[self.regime]
        out: list = []
        if self.stable:
            self.price = 1.0 + 0.6 * (self.price - 1.0) + self.rng.gauss(0, 0.00015)
        else:
            # gentle mean reversion keeps long demos from drifting to absurd prices
            revert = -0.00002 * math.log(self.price / self.base)
            self.price *= math.exp((drift * self.sigma + revert) * dt
                                   + self.sigma * volx * math.sqrt(dt) * (0.6 * self.rng.gauss(0, 1) + 0.8 * common))
        lam = rate * dt * math.sqrt(sizex)
        n = self._poisson(lam)
        self.premium = 0.995 * self.premium + self.rng.gauss(0, 0.00002) + (0.00001 if buyp > 0.55 else -0.00001 if buyp < 0.45 else 0)
        for i in range(n):
            side = "buy" if self.rng.random() < buyp else "sell"
            venue = "sim-coinbase" if self.rng.random() < 0.5 else "sim-kraken"
            px = self.price * (1 + self.rng.gauss(0, self.sigma * 0.3)) * (1 + (self.premium if venue == "sim-coinbase" else 0))
            size = self.base_size * sizex * self.rng.lognormvariate(0, 0.8)
            if self.rng.random() < 0.15:          # humans like round sizes
                mag = 10 ** math.floor(math.log10(size))
                size = max(mag, round(size / mag) * mag)
            out.append(Trade(venue, self.symbol, round(px, 8), size, side, now + dt * i / max(n, 1)))
        # occasional hidden TWAP order (same size, steady cadence, one side)
        if not self.stable:
            if self.twap is None and self.rng.random() < dt / 2400:
                unit = self.base_size * 4
                mag = 10 ** math.floor(math.log10(unit))
                self.twap = {"side": "buy" if self.rng.random() < 0.55 else "sell", "unit": round(unit / mag, 2) * mag,
                             "next": now, "until": now + self.rng.uniform(480, 1200), "every": self.rng.uniform(7, 14)}
            tw = self.twap
            if tw:
                while tw["next"] <= now + dt and tw["next"] <= tw["until"]:
                    out.append(Trade("sim-coinbase", self.symbol, round(self.price, 8), tw["unit"], tw["side"], tw["next"]))
                    tw["next"] += tw["every"] * self.rng.uniform(0.9, 1.1)
                if tw["next"] > tw["until"]:
                    self.twap = None
        return out

    def book(self, now: float) -> BookTop:
        buyp = REGIMES[self.regime][3]
        spread = self.price * 0.0001
        depth = self.base_size * 20
        tilt = (buyp - 0.5) * 3.2
        return BookTop("simulator", self.symbol, self.price - spread / 2, depth * (1 + tilt) * self.rng.uniform(0.7, 1.3),
                       self.price + spread / 2, depth * (1 - tilt) * self.rng.uniform(0.7, 1.3), now)

    def _poisson(self, lam: float) -> int:
        if lam <= 0:
            return 0
        if lam > 30:
            return max(0, int(round(self.rng.gauss(lam, math.sqrt(lam)))))
        L, k, p = math.exp(-lam), 0, 1.0
        while True:
            p *= self.rng.random()
            if p <= L:
                return k
            k += 1


class SimulatorFeed:
    name = "simulator"

    def __init__(self, engine, symbols: list[str], stables: list[str] | None = None,
                 volatility: float = 1.0, trades_per_sec: float = 4.0, history_minutes: int = 240,
                 seed: int | None = None):
        self.engine = engine
        self.rng = random.Random(seed)
        names = list(dict.fromkeys(list(symbols) + list(stables or [])))
        self.syms = [_Sym(s, self.rng, volatility) for s in names]
        self.rate = trades_per_sec
        self.history_minutes = history_minutes
        self.status = engine.status_for(self.name)

    async def backfill(self) -> None:
        self.engine.backfilling += 1
        try:
            await self._backfill()
        finally:
            self.engine.backfilling -= 1

    async def _backfill(self) -> None:
        now = time.time()
        t = now - self.history_minutes * 60
        dt = 5.0
        batch: list = []
        while t < now - dt:
            common = self.rng.gauss(0, 1)
            for s in self.syms:
                batch.extend(s.step(t, dt, self.rate * 0.25, common))
            t += dt
            if len(batch) > 3000:
                self.engine.process(batch)
                batch = []
                await asyncio.sleep(0)
        if batch:
            self.engine.process(batch)

    async def run(self) -> None:
        self.status.update(connected=True, connected_at=time.time())
        await self.backfill()
        dt = 0.25
        last_book = 0.0
        while True:
            now = time.time()
            items: list = []
            common = self.rng.gauss(0, 1)
            for s in self.syms:
                items.extend(s.step(now, dt, self.rate, common))
            if now - last_book >= 1.0:
                last_book = now
                items.extend(s.book(now) for s in self.syms)
            for it in items:
                self.engine.submit(it)
            self.status["messages"] += len(items)
            self.status["last_message"] = now
            await asyncio.sleep(dt)
