"""Shared WebSocket feed machinery: connect, subscribe, parse, reconnect with backoff."""
from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from datetime import datetime

import websockets

log = logging.getLogger(__name__)


def parse_iso(s: str) -> float:
    """ISO-8601 → unix seconds. Handles 'Z' and >6 fractional digits."""
    if not s:
        return time.time()
    s = s.replace("Z", "+00:00")
    if "." in s:
        head, _, rest = s.partition(".")
        frac, tz = rest, ""
        for sep in ("+", "-"):
            if sep in rest:
                frac, _, tzpart = rest.partition(sep)
                tz = sep + tzpart
                break
        s = f"{head}.{frac[:6]}{tz}"
    try:
        return datetime.fromisoformat(s).timestamp()
    except ValueError:
        return time.time()


class Feed:
    name = "base"
    url = ""

    def __init__(self, engine, symbols: list[str], stables: list[str] | None = None):
        self.engine = engine
        self.symbols = list(symbols)
        self.stables = [s for s in (stables or []) if s in self.supported_stables()]
        self.status = engine.status_for(self.name)

    # -- override -----------------------------------------------------------
    def supported_stables(self) -> set[str]:
        return set()

    def all_symbols(self) -> list[str]:
        return self.symbols + [s for s in self.stables if s not in self.symbols]

    def ws_url(self) -> str:
        return self.url

    async def subscribe(self, ws) -> None:  # pragma: no cover
        raise NotImplementedError

    def parse(self, msg) -> list:  # pragma: no cover
        raise NotImplementedError

    # -- loop ---------------------------------------------------------------
    async def run(self) -> None:
        backoff = 1.0
        while True:
            started = time.time()
            try:
                async with websockets.connect(self.ws_url(), ping_interval=20, ping_timeout=20,
                                              max_size=2 ** 23, open_timeout=15, close_timeout=5) as ws:
                    self.status.update(connected=True, connected_at=time.time())
                    log.info("%s connected", self.name)
                    await self.subscribe(ws)
                    async for raw in ws:
                        self.status["messages"] += 1
                        self.status["last_message"] = time.time()
                        try:
                            msg = json.loads(raw)
                        except ValueError:
                            continue
                        for item in self.parse(msg):
                            self.engine.submit(item)
            except asyncio.CancelledError:
                self.status["connected"] = False
                raise
            except Exception as e:
                self.status["errors"] += 1
                self.status["last_error"] = f"{type(e).__name__}: {e}"[:300]
                log.warning("%s feed error: %s", self.name, e)
            self.status["connected"] = False
            self.status["reconnects"] += 1
            if time.time() - started > 60:
                backoff = 1.0
            await asyncio.sleep(backoff + random.random())
            backoff = min(60.0, backoff * 2)
