"""Builds the configured feeds."""
from __future__ import annotations

from ..config import Settings
from .exchanges import BinanceUSFeed, CoinbaseFeed, KrakenFeed
from .simulator import SimulatorFeed

FEED_CLASSES = {"coinbase": CoinbaseFeed, "kraken": KrakenFeed, "binanceus": BinanceUSFeed}


def build_feeds(engine, settings: Settings) -> list:
    feeds = []
    for name in settings.feeds:
        name = name.lower()
        if name == "simulator":
            feeds.append(SimulatorFeed(engine, settings.symbols, settings.stable_symbols,
                                       volatility=settings.sim_volatility, trades_per_sec=settings.sim_trades_per_sec))
        elif name in FEED_CLASSES:
            feeds.append(FEED_CLASSES[name](engine, settings.symbols, settings.stable_symbols))
    return feeds
