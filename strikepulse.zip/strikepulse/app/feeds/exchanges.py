"""Public market-data WebSocket feeds. No API keys needed."""
from __future__ import annotations

import json
import time

from ..engine.types import BookTop, Trade
from .base import Feed, parse_iso


def _f(x, default=0.0) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


class CoinbaseFeed(Feed):
    """Coinbase Exchange public feed: `matches` (trades) + `ticker` (best bid/ask)."""
    name = "coinbase"
    url = "wss://ws-feed.exchange.coinbase.com"

    def supported_stables(self):
        return {"USDT-USD", "DAI-USD", "PYUSD-USD"}

    async def subscribe(self, ws):
        # one product per message: an unknown product then only fails itself
        for sym in self.all_symbols():
            await ws.send(json.dumps({"type": "subscribe", "product_ids": [sym], "channels": ["matches", "ticker"]}))

    def parse(self, msg) -> list:
        t = msg.get("type")
        if t == "match":   # 'last_match' is a replay of an old trade on subscribe: skip it
            maker = msg.get("side")
            return [Trade(self.name, msg["product_id"], _f(msg.get("price")), _f(msg.get("size")),
                          "sell" if maker == "buy" else "buy", parse_iso(msg.get("time", "")))]
        if t == "ticker" and msg.get("best_bid"):
            return [BookTop(self.name, msg["product_id"], _f(msg.get("best_bid")), _f(msg.get("best_bid_size")),
                            _f(msg.get("best_ask")), _f(msg.get("best_ask_size")), parse_iso(msg.get("time", "")))]
        if t == "error":
            self.status["last_error"] = f"{msg.get('message')}: {msg.get('reason', '')}"[:300]
        return []


class KrakenFeed(Feed):
    """Kraken WebSocket v2: `trade` + `ticker`."""
    name = "kraken"
    url = "wss://ws.kraken.com/v2"

    def supported_stables(self):
        return {"USDT-USD", "USDC-USD", "DAI-USD", "PYUSD-USD"}

    @staticmethod
    def to_kraken(sym: str) -> str:
        return sym.replace("-", "/")

    @staticmethod
    def from_kraken(sym: str) -> str:
        return sym.replace("/", "-").replace("XBT", "BTC")

    async def subscribe(self, ws):
        for sym in self.all_symbols():
            k = self.to_kraken(sym)
            await ws.send(json.dumps({"method": "subscribe", "params": {"channel": "trade", "symbol": [k], "snapshot": False}}))
            await ws.send(json.dumps({"method": "subscribe", "params": {"channel": "ticker", "symbol": [k]}}))

    def parse(self, msg) -> list:
        ch = msg.get("channel")
        out: list = []
        if ch == "trade" and msg.get("type") == "update":
            for d in msg.get("data", []):
                out.append(Trade(self.name, self.from_kraken(d["symbol"]), _f(d.get("price")), _f(d.get("qty")),
                                 "buy" if d.get("side") == "buy" else "sell", parse_iso(d.get("timestamp", ""))))
        elif ch == "ticker":
            for d in msg.get("data", []):
                out.append(BookTop(self.name, self.from_kraken(d["symbol"]), _f(d.get("bid")), _f(d.get("bid_qty")),
                                   _f(d.get("ask")), _f(d.get("ask_qty")), time.time()))
        elif msg.get("method") == "subscribe" and msg.get("success") is False:
            self.status["last_error"] = str(msg.get("error"))[:300]
        return out


class BinanceUSFeed(Feed):
    """Binance.US combined stream (`@trade` + `@bookTicker`). Regular Binance blocks US IPs."""
    name = "binanceus"
    base = "wss://stream.binance.us:9443/stream?streams="

    def supported_stables(self):
        return {"USDT-USD", "USDC-USD"}

    def __init__(self, engine, symbols, stables=None):
        super().__init__(engine, symbols, stables)
        self.map = {s.replace("-", "").upper(): s for s in self.all_symbols()}

    def ws_url(self) -> str:
        streams = []
        for s in self.all_symbols():
            k = s.replace("-", "").lower()
            streams += [f"{k}@trade", f"{k}@bookTicker"]
        return self.base + "/".join(streams)

    async def subscribe(self, ws):
        return  # streams are in the URL

    def parse(self, msg) -> list:
        d = msg.get("data", msg)
        sym = self.map.get(str(d.get("s", "")).upper())
        if not sym:
            return []
        if d.get("e") == "trade":
            # m = buyer is the maker → the taker sold
            return [Trade(self.name, sym, _f(d.get("p")), _f(d.get("q")), "sell" if d.get("m") else "buy",
                          _f(d.get("T"), time.time() * 1000) / 1000)]
        if "b" in d and "a" in d and "B" in d:
            return [BookTop(self.name, sym, _f(d["b"]), _f(d["B"]), _f(d["a"]), _f(d["A"]), time.time())]
        return []
