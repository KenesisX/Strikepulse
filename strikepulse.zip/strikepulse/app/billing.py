"""Stripe subscriptions: Checkout, Customer Portal and webhooks.

Payouts: Stripe deposits your balance to whatever bank account you add in the Stripe
dashboard (Settings → Payouts). Any US account with a routing + account number works.
"""
from __future__ import annotations

import json
import logging
import time

import stripe
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import settings
from .models import User

log = logging.getLogger(__name__)


def _client() -> None:
    stripe.api_key = settings.stripe_secret_key


def price_for(plan: str, interval: str = "month") -> str:
    if interval == "year":
        return {"pro": settings.stripe_price_pro_yearly, "elite": settings.stripe_price_elite_yearly}.get(plan, "")
    return {"pro": settings.stripe_price_pro, "elite": settings.stripe_price_elite}.get(plan, "")


def plan_for_price(price_id: str) -> str:
    if not price_id:
        return "free"
    if price_id in (settings.stripe_price_elite, settings.stripe_price_elite_yearly):
        return "elite"
    if price_id in (settings.stripe_price_pro, settings.stripe_price_pro_yearly):
        return "pro"
    return "free"


def create_checkout(user: User, plan: str, interval: str = "month") -> str:
    _client()
    price = price_for(plan, interval)
    if not price:
        raise ValueError(f"No Stripe {interval}ly price configured for plan '{plan}'")
    params: dict = {
        "mode": "subscription",
        "line_items": [{"price": price, "quantity": 1}],
        "success_url": f"{settings.base_url}/billing?success=1&session_id={{CHECKOUT_SESSION_ID}}",
        "cancel_url": f"{settings.base_url}/pricing?canceled=1",
        "client_reference_id": str(user.id),
        "allow_promotion_codes": True,
        "metadata": {"user_id": str(user.id), "plan": plan},
        "subscription_data": {"metadata": {"user_id": str(user.id), "plan": plan}},
    }
    if settings.trial_days > 0 and user.stripe_subscription_id is None:
        params["subscription_data"]["trial_period_days"] = settings.trial_days
    if user.stripe_customer_id:
        params["customer"] = user.stripe_customer_id
    else:
        params["customer_email"] = user.email
    session = stripe.checkout.Session.create(**params)
    return session.url


def create_portal(user: User) -> str:
    _client()
    if not user.stripe_customer_id:
        raise ValueError("No billing account yet")
    s = stripe.billing_portal.Session.create(customer=user.stripe_customer_id, return_url=f"{settings.base_url}/billing")
    return s.url


def verify_event(payload: bytes, sig_header: str) -> dict:
    """Verify the Stripe signature, then return the raw event as a plain dict."""
    stripe.Webhook.construct_event(payload, sig_header, settings.stripe_webhook_secret)
    return json.loads(payload)


def _find_user(db: Session, obj: dict) -> User | None:
    meta = obj.get("metadata") or {}
    uid = meta.get("user_id") or obj.get("client_reference_id")
    if uid and str(uid).isdigit():
        u = db.get(User, int(uid))
        if u:
            return u
    cust = obj.get("customer")
    if cust:
        return db.scalar(select(User).where(User.stripe_customer_id == cust))
    return None


def _apply_subscription(user: User, sub: dict) -> None:
    items = (sub.get("items") or {}).get("data") or []
    price_id = items[0]["price"]["id"] if items else ""
    plan = plan_for_price(price_id)
    if plan == "free":
        plan = (sub.get("metadata") or {}).get("plan", "free")
    status = sub.get("status", "active")
    user.stripe_subscription_id = sub.get("id")
    user.stripe_customer_id = sub.get("customer") or user.stripe_customer_id
    period_end = sub.get("current_period_end") or (items[0].get("current_period_end") if items else None)
    user.current_period_end = float(period_end) if period_end else None
    if status in ("active", "trialing", "past_due"):
        user.plan, user.plan_status = plan, status
    else:  # canceled, unpaid, incomplete_expired, paused
        user.plan, user.plan_status = "free", status


def handle_event(db: Session, event: dict) -> str:
    etype = event.get("type", "")
    obj = (event.get("data") or {}).get("object") or {}
    if etype == "checkout.session.completed":
        user = _find_user(db, obj)
        if not user:
            return "user not found"
        user.stripe_customer_id = obj.get("customer") or user.stripe_customer_id
        user.stripe_subscription_id = obj.get("subscription") or user.stripe_subscription_id
        plan = (obj.get("metadata") or {}).get("plan")
        if plan in ("pro", "elite"):
            user.plan, user.plan_status = plan, "active"
        return f"checkout linked user {user.id}"
    if etype in ("customer.subscription.created", "customer.subscription.updated", "customer.subscription.deleted"):
        user = _find_user(db, obj)
        if not user:
            return "user not found"
        if etype == "customer.subscription.deleted":
            user.plan, user.plan_status, user.stripe_subscription_id = "free", "canceled", None
        else:
            _apply_subscription(user, obj)
        return f"subscription {etype.rsplit('.', 1)[-1]} for user {user.id}: {user.plan}/{user.plan_status}"
    if etype == "invoice.payment_failed":
        user = _find_user(db, obj)
        if user:
            user.plan_status = "past_due"
            return f"payment failed for user {user.id}"
    if etype == "invoice.paid":
        user = _find_user(db, obj)
        if user and user.plan_status == "past_due":
            user.plan_status = "active"
            return f"payment recovered for user {user.id}"
    return "ignored"


def fake_upgrade(user: User, plan: str) -> None:
    """DEV_FAKE_BILLING=1 only: instant plan switch for local testing without Stripe."""
    user.plan, user.plan_status = plan, "active"
    user.current_period_end = time.time() + 30 * 86400
