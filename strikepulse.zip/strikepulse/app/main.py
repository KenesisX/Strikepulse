"""StrikePulse: crypto market + on-chain alert SaaS.

Run:  uvicorn app.main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.sessions import SessionMiddleware

from . import db as dbmod
from .config import settings
from .models import User
from .routes import admin, analysis, api, auth, billing_routes, dashboard, devices, markets, pages, quant, research
from .security import LoginRequired, hash_password
from .services import get_services
from .web import render

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("strikepulse")


def ensure_admin() -> None:
    if not (settings.admin_email and settings.admin_password):
        return
    with dbmod.session_scope() as db:
        email = settings.admin_email.strip().lower()
        u = db.scalar(select(User).where(func.lower(User.email) == email))
        if not u:
            db.add(User(email=email, password_hash=hash_password(settings.admin_password), is_admin=True, plan="elite"))
            log.info("created admin account %s", email)
        elif not u.is_admin:
            u.is_admin = True


@asynccontextmanager
async def lifespan(app: FastAPI):
    dbmod.init_db(settings.database_url)
    ensure_admin()
    if settings.secret_key == "dev-insecure-change-me":
        log.warning("SECRET_KEY is the insecure default. Set it in .env before going live!")
    svc = get_services()
    background = os.getenv("DISABLE_BACKGROUND", "") not in ("1", "true")
    if background:
        await svc.start()
    yield
    if background:
        await svc.stop()


app = FastAPI(title=settings.app_name, lifespan=lifespan, docs_url="/api/docs", redoc_url=None)
app.add_middleware(SessionMiddleware, secret_key=settings.secret_key, session_cookie="sp_session",
                   max_age=30 * 86400, same_site="lax", https_only=settings.cookie_secure)
app.mount("/static", StaticFiles(directory=str(Path(__file__).parent / "static")), name="static")

for r in (pages.router, auth.router, dashboard.router, analysis.router, quant.router, research.router, markets.router,
          devices.router, api.router, billing_routes.router, admin.router):
    app.include_router(r)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if not request.url.path.startswith("/api/docs"):
        resp.headers.setdefault("Content-Security-Policy",
                                "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
                                "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; "
                                "form-action 'self' https://checkout.stripe.com https://billing.stripe.com")
    if settings.cookie_secure:
        resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return resp


@app.exception_handler(LoginRequired)
async def login_required(request: Request, exc: LoginRequired):
    if request.url.path.startswith("/api/"):
        from fastapi.responses import JSONResponse
        return JSONResponse({"detail": "Not logged in"}, status_code=401)
    return RedirectResponse(f"/login?next={request.url.path}", 303)


@app.exception_handler(StarletteHTTPException)
async def http_error(request: Request, exc: StarletteHTTPException):
    if request.url.path.startswith("/api/") or request.url.path.startswith("/billing/webhook"):
        from fastapi.responses import JSONResponse
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
    return render(request, "error.html", None, status_code=exc.status_code, code=exc.status_code, detail=exc.detail)
