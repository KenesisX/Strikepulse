"""Signal detectors. Each one looks at the closed-candle history of one symbol on one
timeframe and returns a Signal (or None) for the candle that just closed.

Detectors that need memory between candles keep it in ctx["state"], which the pipeline
stores per (symbol, timeframe).
"""
from __future__ import annotations

import math

import numpy as np

from . import indicators as ind
from .isoforest import IsolationForest
from .types import Candle, Signal


def _arr(candles: list[Candle], attr: str) -> np.ndarray:
    return np.fromiter((getattr(c, attr) for c in candles), dtype=float, count=len(candles))


def _pct(x: float) -> str:
    return f"{x * 100:+.2f}%"


class Detector:
    name = "base"
    label = "Base"
    weight = 1.0
    min_history = 30
    tier = "basic"          # basic | pro  (free plan only gets basic detectors)
    description = ""

    def evaluate(self, candles: list[Candle], ctx: dict) -> Signal | None:  # pragma: no cover
        raise NotImplementedError

    def st(self, ctx: dict) -> dict:
        return ctx.setdefault("state", {}).setdefault(self.name, {})


class EMACross(Detector):
    name, label, weight, tier = "ema_cross", "EMA crossover", 1.0, "basic"
    description = "Fast EMA crossing the slow EMA: classic trend reversal signal."

    def __init__(self, fast: int = 9, slow: int = 21, trend: int = 50):
        self.fast, self.slow, self.trend = fast, slow, trend
        self.min_history = max(slow * 2, trend + 2)

    def evaluate(self, candles, ctx):
        c = _arr(candles, "close")
        f, s, t = ind.ema(c, self.fast), ind.ema(c, self.slow), ind.ema(c, self.trend)
        prev, now = f[-2] - s[-2], f[-1] - s[-1]
        if prev <= 0 < now:
            direction = 1
        elif prev >= 0 > now:
            direction = -1
        else:
            return None
        sep = abs(now) / max(c[-1], 1e-12)
        strength = 0.55 + min(0.3, sep / 0.002 * 0.3)
        with_trend = (direction > 0 and c[-1] > t[-1]) or (direction < 0 and c[-1] < t[-1])
        if with_trend:
            strength += 0.15
        word = "bullish" if direction > 0 else "bearish"
        extra = f", {'above' if c[-1] > t[-1] else 'below'} EMA{self.trend}"
        return Signal(self.name, direction, min(1.0, strength), f"EMA {self.fast}/{self.slow} {word} cross{extra}")


class VolumeSpike(Detector):
    name, label, weight, tier = "volume_spike", "Volume spike", 0.9, "basic"
    description = "Volume far above its recent norm, a sign of sudden buying or selling pressure."

    def __init__(self, window: int = 30, threshold: float = 3.0):
        self.window, self.threshold = window, threshold
        self.min_history = window + 2

    def evaluate(self, candles, ctx):
        v = _arr(candles, "volume")
        if v[-1] <= 0:
            return None
        z = ind.zscore_last(np.log1p(v), self.window)
        if z < self.threshold:
            return None
        ref = v[-self.window - 1:-1]
        mult = v[-1] / max(np.median(ref), 1e-12)
        last = candles[-1]
        body = last.close - last.open
        if abs(body) > 1e-12:
            direction = 1 if body > 0 else -1
        else:
            direction = 1 if last.buy_volume >= last.sell_volume else -1
        strength = min(1.0, 0.5 + (z - self.threshold) / (2 * self.threshold))
        side = "buying" if direction > 0 else "selling"
        return Signal(self.name, direction, strength, f"Volume {mult:.1f}x normal ({side} pressure, z={z:.1f})")


class CUSUMShift(Detector):
    """Two-sided CUSUM change-point detection on standardised log returns.
    Fires on the exact candle where the cumulative drift crosses the alarm threshold."""
    name, label, weight, tier = "cusum_shift", "Trend shift (CUSUM)", 1.1, "pro"
    description = "Change-point detection: spots the moment the market's drift changes."

    def __init__(self, baseline: int = 100, k: float = 0.5, h: float = 5.0, run: int = 60):
        self.baseline, self.k, self.h, self.run = baseline, k, h, run
        self.min_history = baseline + 2

    def evaluate(self, candles, ctx):
        c = _arr(candles, "close")
        if np.any(c <= 0):
            return None
        r = np.diff(np.log(c))[-self.baseline:]
        med = np.median(r)
        mad = np.median(np.abs(r - med)) * 1.4826
        sd = mad if mad > 1e-12 else r.std()
        if sd <= 1e-12:
            return None
        zr = (r[-self.run:] - med) / sd
        sp = sn = 0.0
        alarm_dir, alarm_i, peak = 0, -1, 0.0
        for i, x in enumerate(zr):
            sp = max(0.0, sp + x - self.k)
            sn = max(0.0, sn - x - self.k)
            if sp > self.h:
                alarm_dir, alarm_i, peak, sp, sn = 1, i, sp, 0.0, 0.0
            elif sn > self.h:
                alarm_dir, alarm_i, peak, sn, sp = -1, i, sn, 0.0, 0.0
        if alarm_i != len(zr) - 1:
            return None
        lookback = min(10, len(c) - 1)
        move = c[-1] / c[-1 - lookback] - 1
        strength = min(1.0, 0.6 + (peak - self.h) / (2 * self.h))
        word = "upward" if alarm_dir > 0 else "downward"
        return Signal(self.name, alarm_dir, strength, f"Change-point: {word} drift shift ({_pct(move)} over {lookback} bars)")


class BollingerBreakout(Detector):
    name, label, weight, tier = "bollinger", "Bollinger breakout", 0.8, "basic"
    description = "Close breaking out of the Bollinger Bands, stronger after a squeeze."

    def __init__(self, period: int = 20, k: float = 2.0, squeeze_lookback: int = 100):
        self.period, self.k, self.squeeze_lookback = period, k, squeeze_lookback
        self.min_history = period + 5

    def evaluate(self, candles, ctx):
        c = _arr(candles, "close")
        mid, up, lo = ind.bollinger(c, self.period, self.k)
        if np.isnan(up[-2]):
            return None
        if c[-2] <= up[-2] and c[-1] > up[-1]:
            direction = 1
        elif c[-2] >= lo[-2] and c[-1] < lo[-1]:
            direction = -1
        else:
            return None
        bw = (up - lo) / np.where(mid == 0, np.nan, mid)
        hist = bw[-self.squeeze_lookback - 1:-1]
        hist = hist[~np.isnan(hist)]
        squeeze = len(hist) > 20 and bw[-2] <= np.percentile(hist, 20)
        strength = 0.55 + (0.3 if squeeze else 0.0)
        beyond = abs(c[-1] - (up[-1] if direction > 0 else lo[-1])) / max(c[-1], 1e-12)
        strength = min(1.0, strength + min(0.15, beyond / 0.003 * 0.15))
        where = "upper" if direction > 0 else "lower"
        return Signal(self.name, direction, strength,
                      f"Closed beyond {where} Bollinger Band" + (" after a squeeze" if squeeze else ""))


class RSIReversal(Detector):
    name, label, weight, tier = "rsi", "RSI reversal", 0.6, "basic"
    description = "RSI leaving oversold (<30) or overbought (>70) territory."

    def __init__(self, period: int = 14, low: float = 30, high: float = 70):
        self.period, self.low, self.high = period, low, high
        self.min_history = period * 3

    def evaluate(self, candles, ctx):
        c = _arr(candles, "close")
        r = ind.rsi(c, self.period)
        if np.isnan(r[-2]):
            return None
        recent = r[-6:]
        if r[-2] < self.low <= r[-1]:
            ext = float(np.nanmin(recent))
            strength = min(1.0, 0.5 + (self.low - ext) / 40)
            return Signal(self.name, 1, strength, f"RSI recovered from oversold (low {ext:.0f} → {r[-1]:.0f})")
        if r[-2] > self.high >= r[-1]:
            ext = float(np.nanmax(recent))
            strength = min(1.0, 0.5 + (ext - self.high) / 40)
            return Signal(self.name, -1, strength, f"RSI rolled over from overbought (high {ext:.0f} → {r[-1]:.0f})")
        return None


class MomentumBurst(Detector):
    name, label, weight, tier = "momentum", "Momentum burst", 0.9, "pro"
    description = "A multi-candle move far larger than usual for this asset."

    def __init__(self, span: int = 3, window: int = 100, threshold: float = 3.0):
        self.span, self.window, self.threshold = span, window, threshold
        self.min_history = window + span + 2

    def evaluate(self, candles, ctx):
        c = _arr(candles, "close")
        if np.any(c <= 0):
            return None
        lr = np.log(c[self.span:] / c[:-self.span])
        z = ind.zscore_last(lr, self.window)
        st = self.st(ctx)
        fired_prev = st.get("prev_z", 0.0)
        st["prev_z"] = z
        if abs(z) < self.threshold or abs(fired_prev) >= self.threshold:
            return None  # only on the first bar of a burst
        direction = 1 if z > 0 else -1
        strength = min(1.0, 0.5 + (abs(z) - self.threshold) / (2 * self.threshold))
        move = math.exp(lr[-1]) - 1
        return Signal(self.name, direction, strength, f"Momentum burst {_pct(move)} in {self.span} bars (z={z:+.1f})")


class TakerFlowImbalance(Detector):
    name, label, weight, tier = "taker_flow", "Taker flow imbalance", 0.7, "pro"
    description = "Aggressive buyers or sellers dominating recent trades."

    def __init__(self, span: int = 5, threshold: float = 0.3, window: int = 50):
        self.span, self.threshold, self.window = span, threshold, window
        self.min_history = window + span

    def evaluate(self, candles, ctx):
        b = _arr(candles, "buy_volume")
        v = _arr(candles, "volume")
        tot = v[-self.span:].sum()
        if tot <= 0:
            return None
        imb = (2 * b[-self.span:].sum() - tot) / tot
        sums = np.convolve(v, np.ones(self.span), "valid")[-self.window:]
        st = self.st(ctx)
        prev = st.get("prev", 0.0)
        st["prev"] = imb
        if tot < np.median(sums):
            return None
        if abs(imb) < self.threshold or abs(prev) >= self.threshold:
            return None
        direction = 1 if imb > 0 else -1
        strength = min(1.0, 0.5 + (abs(imb) - self.threshold) / 0.5)
        who = "buyers" if direction > 0 else "sellers"
        share = (1 + abs(imb)) / 2 * 100
        return Signal(self.name, direction, strength, f"Aggressive {who} took {share:.0f}% of volume over {self.span} bars")


class BookImbalance(Detector):
    name, label, weight, tier = "book_imbalance", "Order book imbalance", 0.5, "pro"
    description = "Resting bids heavily outweigh asks (or vice versa) at the top of the book."
    min_history = 2

    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold

    def evaluate(self, candles, ctx):
        imb = ctx.get("book_imbalance")
        if imb is None:
            return None
        st = self.st(ctx)
        prev = st.get("prev", 0.0)
        st["prev"] = imb
        if abs(imb) < self.threshold or abs(prev) >= self.threshold:
            return None
        direction = 1 if imb > 0 else -1
        side = "bids" if direction > 0 else "asks"
        ratio = (1 + abs(imb)) / max(1 - abs(imb), 1e-6)
        return Signal(self.name, direction, min(1.0, 0.5 + (abs(imb) - self.threshold)),
                      f"Order book {side} outweigh the other side {ratio:.1f}:1")


class AnomalyDetector(Detector):
    """Isolation Forest over per-candle behaviour features. Flags candles that look
    unlike anything in the recent past (a mix of return, range, volume, flow, trade count)."""
    name, label, weight, tier = "anomaly", "Behaviour anomaly (Isolation Forest)", 0.8, "pro"
    description = "Machine-learning outlier detection on price, volume and order-flow behaviour."

    def __init__(self, train: int = 300, refit_every: int = 50, threshold: float = 0.68):
        self.train, self.refit_every, self.threshold = train, refit_every, threshold
        self.min_history = 150

    @staticmethod
    def features(candles: list[Candle]) -> np.ndarray:
        c = _arr(candles, "close")
        h, l = _arr(candles, "high"), _arr(candles, "low")
        v = _arr(candles, "volume")
        b = _arr(candles, "buy_volume")
        n = _arr(candles, "trades")
        prev = np.concatenate([[c[0]], c[:-1]])
        r = np.log(np.maximum(c, 1e-12) / np.maximum(prev, 1e-12))
        rng = (h - l) / np.maximum(c, 1e-12)
        lv = np.log1p(v)
        flow = np.where(v > 0, b / np.maximum(v, 1e-12) - 0.5, 0.0)
        return np.column_stack([r, np.abs(r), rng, lv, flow, np.log1p(n)])

    def evaluate(self, candles, ctx):
        st = self.st(ctx)
        hist = candles[-self.train:]
        X = self.features(hist)
        st["since_fit"] = st.get("since_fit", self.refit_every) + 1
        if "model" not in st or st["since_fit"] >= self.refit_every:
            st["model"] = IsolationForest(n_trees=60, sample_size=128).fit(X[:-1])
            st["since_fit"] = 0
        s = float(st["model"].score(X[-1:])[0])
        if s < self.threshold:
            return None
        r = X[-1, 0]
        direction = 1 if r > 0 else -1 if r < 0 else (1 if X[-1, 4] >= 0 else -1)
        strength = min(1.0, 0.45 + (s - self.threshold) / 0.15 * 0.4)
        return Signal(self.name, direction, strength, f"Unusual market behaviour (anomaly score {s:.2f})")


def default_detectors() -> list[Detector]:
    return [
        EMACross(), VolumeSpike(), CUSUMShift(), BollingerBreakout(), RSIReversal(),
        MomentumBurst(), TakerFlowImbalance(), BookImbalance(), AnomalyDetector(),
    ]


DETECTOR_INFO = {d.name: {"label": d.label, "tier": d.tier, "weight": d.weight, "description": d.description}
                 for d in default_detectors()}
BASIC_DETECTORS = {k for k, v in DETECTOR_INFO.items() if v["tier"] == "basic"}
ALL_DETECTORS = set(DETECTOR_INFO)
