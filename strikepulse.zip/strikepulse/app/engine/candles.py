"""Turns a stream of trades into OHLCV candles on several timeframes at once."""
from __future__ import annotations

from collections import deque

from .types import Candle, Trade

HISTORY = 600  # candles kept per (symbol, timeframe)


class CandleSeries:
    """Candles for one symbol on one timeframe."""

    def __init__(self, symbol: str, interval: int, maxlen: int = HISTORY):
        self.symbol = symbol
        self.interval = interval
        self.closed: deque[Candle] = deque(maxlen=maxlen)
        self.current: Candle | None = None

    def bucket(self, ts: float) -> float:
        return float(int(ts // self.interval) * self.interval)

    def _new(self, start: float, price: float) -> Candle:
        return Candle(self.symbol, self.interval, start, price, price, price, price)

    def add_trade(self, t: Trade) -> list[Candle]:
        """Add a trade; returns any candles that closed because of it."""
        out: list[Candle] = []
        b = self.bucket(t.ts)
        if self.current is None:
            self.current = self._new(b, t.price)
        elif b < self.current.start:
            # late trade for an already-closed bucket: fold into the current one
            b = self.current.start
        elif b > self.current.start:
            out.extend(self._roll_to(b))
        c = self.current
        if c.trades == 0 and c.volume == 0:
            c.open = c.high = c.low = t.price
        c.high = max(c.high, t.price)
        c.low = min(c.low, t.price)
        c.close = t.price
        c.volume += t.size
        if t.side == "buy":
            c.buy_volume += t.size
        c.trades += 1
        return out

    def _roll_to(self, new_start: float) -> list[Candle]:
        """Close the current candle, fill empty gaps with flat candles, open the new one."""
        out: list[Candle] = []
        assert self.current is not None
        last_close = self.current.close
        self.closed.append(self.current)
        out.append(self.current)
        gap_start = self.current.start + self.interval
        # cap gap filling so a long outage doesn't create thousands of candles
        max_fill = 60
        while gap_start < new_start and max_fill > 0:
            flat = self._new(gap_start, last_close)
            self.closed.append(flat)
            out.append(flat)
            gap_start += self.interval
            max_fill -= 1
        self.current = self._new(new_start, last_close)
        return out

    def tick(self, now: float) -> list[Candle]:
        """Close the current candle if its time is up even when no trades arrived."""
        if self.current is None:
            return []
        b = self.bucket(now)
        if b > self.current.start:
            return self._roll_to(b)
        return []

    def seed(self, candles: list[Candle]) -> None:
        """Load historical candles (oldest first) from a REST backfill."""
        for c in sorted(candles, key=lambda x: x.start):
            if self.closed and c.start <= self.closed[-1].start:
                continue
            self.closed.append(c)

    def history(self, include_current: bool = False) -> list[Candle]:
        h = list(self.closed)
        if include_current and self.current is not None:
            h.append(self.current)
        return h


class CandleBook:
    """All candle series for all symbols / timeframes."""

    def __init__(self, timeframes: list[int]):
        self.timeframes = sorted(timeframes)
        self.series: dict[tuple[str, int], CandleSeries] = {}

    def get(self, symbol: str, interval: int) -> CandleSeries:
        key = (symbol, interval)
        s = self.series.get(key)
        if s is None:
            s = self.series[key] = CandleSeries(symbol, interval)
        return s

    def add_trade(self, t: Trade) -> list[Candle]:
        out: list[Candle] = []
        for tf in self.timeframes:
            out.extend(self.get(t.symbol, tf).add_trade(t))
        return out

    def tick(self, now: float) -> list[Candle]:
        out: list[Candle] = []
        for s in list(self.series.values()):
            out.extend(s.tick(now))
        return out

    def symbols(self) -> list[str]:
        return sorted({k[0] for k in list(self.series)})
