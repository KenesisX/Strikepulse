"""Confluence scoring: combine signals from several detectors into one 0-100 score,
with cooldowns so users aren't spammed."""
from __future__ import annotations

import logging
import math

from .detectors import DETECTOR_INFO, Detector, default_detectors
from .types import Candle, MarketEvent, Signal, tf_label

log = logging.getLogger(__name__)

TF_MULT = {60: 0.85, 300: 1.0, 900: 1.1, 3600: 1.15}
SATURATION = 1.2       # raw weight needed to reach ~63 points
CONFLICT_PENALTY = 0.5


def confluence(signals: list[Signal], interval: int) -> tuple[int, int]:
    """Return (score 0-100, direction +1/-1/0)."""
    bull = sum(DETECTOR_INFO.get(s.detector, {}).get("weight", 1.0) * s.strength for s in signals if s.direction > 0)
    bear = sum(DETECTOR_INFO.get(s.detector, {}).get("weight", 1.0) * s.strength for s in signals if s.direction < 0)
    if bull == bear:
        return 0, 0
    direction = 1 if bull > bear else -1
    raw = max(bull, bear) - CONFLICT_PENALTY * min(bull, bear)
    if raw <= 0:
        return 0, 0
    score = 100.0 * (1.0 - math.exp(-raw / SATURATION)) * TF_MULT.get(interval, 1.0)
    return int(max(0, min(100, round(score)))), direction


def classify(aligned: list[Signal], direction: int) -> str:
    names = {s.detector for s in aligned}
    if names & {"cusum_shift", "ema_cross"}:
        return "trend shift"
    if names & {"momentum", "volume_spike", "bollinger", "taker_flow"}:
        return "breakout" if direction > 0 else "breakdown"
    if "rsi" in names:
        return "reversal"
    return "anomaly"


class SignalPipeline:
    def __init__(self, detectors: list[Detector] | None = None, min_score: int = 40,
                 cooldown_bars: int = 4, window_bars: int = 3, skip_symbols: set[str] | None = None):
        self.detectors = detectors or default_detectors()
        self.min_score = min_score
        self.cooldown_bars = cooldown_bars
        self.window_bars = window_bars
        self.skip_symbols = skip_symbols or set()
        self.recent: dict[tuple[str, int], dict[str, Signal]] = {}
        self.state: dict[tuple[str, int], dict] = {}
        self.last_alert: dict[tuple[str, int, int], tuple[float, int]] = {}

    def on_candle(self, candle: Candle, history: list[Candle], book_imbalance: float | None = None) -> MarketEvent | None:
        if candle.symbol in self.skip_symbols:
            return None
        key = (candle.symbol, candle.interval)
        ctx = {"state": self.state.setdefault(key, {}), "book_imbalance": book_imbalance}
        now = candle.start + candle.interval
        new: list[Signal] = []
        for d in self.detectors:
            if len(history) < d.min_history:
                continue
            try:
                sig = d.evaluate(history, ctx)
            except Exception:  # a broken detector must never kill the engine
                log.exception("detector %s failed on %s", d.name, key)
                continue
            if sig:
                sig.ts = now
                new.append(sig)

        recent = self.recent.setdefault(key, {})
        horizon = self.window_bars * candle.interval
        for name in [n for n, s in recent.items() if now - s.ts > horizon]:
            del recent[name]
        for s in new:
            recent[s.detector] = s
        if not new:
            return None

        score, direction = confluence(list(recent.values()), candle.interval)
        if direction == 0 or score < self.min_score:
            return None
        if not any(s.direction == direction for s in new):
            return None

        ck = (candle.symbol, candle.interval, direction)
        last = self.last_alert.get(ck)
        if last and now - last[0] < self.cooldown_bars * candle.interval and score < last[1] + 15:
            return None
        self.last_alert[ck] = (now, score)

        aligned = sorted((s for s in recent.values() if s.direction == direction), key=lambda s: -s.strength)
        opposing = [s for s in recent.values() if s.direction != direction]
        kind = classify(aligned, direction)
        word = "bullish" if direction > 0 else "bearish"
        tf = tf_label(candle.interval)
        return MarketEvent(
            kind="market",
            symbol=candle.symbol,
            title=f"{candle.symbol} {word} {kind} · {tf}",
            direction=direction,
            score=score,
            price=candle.close,
            timeframe=tf,
            reasons=[s.detail for s in aligned],
            signals=[{"detector": s.detector, "direction": s.direction, "strength": round(s.strength, 3),
                      "detail": s.detail} for s in aligned],
            meta={"bar_start": candle.start, "interval": candle.interval, "pattern": kind,
                  "opposing": [s.detail for s in opposing], "volume": candle.volume},
            ts=now,
        )
