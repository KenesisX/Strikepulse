"""The market engine: consumes trades / order-book tops from every feed, builds candles,
runs the signal pipeline and publishes MarketEvents to the bus."""
from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from typing import Callable

import httpx

from ..bus import Bus
from .candles import CandleBook
from .scoring import SignalPipeline
from .types import BookTop, Candle, MarketEvent, Trade

log = logging.getLogger(__name__)


class Engine:
    def __init__(self, timeframes: list[int], bus: Bus, min_score: int = 40,
                 event_max_age: int = 600, stable_symbols: list[str] | None = None):
        self.bus = bus
        self.timeframes = sorted(timeframes)
        self.book = CandleBook(self.timeframes)
        self.stable_symbols = set(stable_symbols or [])
        self.pipeline = SignalPipeline(min_score=min_score, skip_symbols=self.stable_symbols)
        self.event_max_age = event_max_age
        self.queue: asyncio.Queue = asyncio.Queue(maxsize=100_000)
        self.prices: dict[str, dict] = {}
        self.book_tops: dict[str, dict[str, BookTop]] = {}
        self.book_imbalance: dict[str, float] = {}
        self.feed_status: dict[str, dict] = {}
        self.price_listeners: list[Callable[[str, float, float], None]] = []
        self.trade_listeners: list[Callable[[Trade], None]] = []
        self.enricher: Callable[[MarketEvent], None] | None = None
        self.candle_listeners: list[Callable[[Candle], None]] = []
        self.recent_events: deque[MarketEvent] = deque(maxlen=200)
        self.clock = 0.0
        self.backfilling = 0     # >0 while a feed replays history: suspend wall-clock candle closing
        self.trades_processed = 0
        self.dropped = 0
        self.started = time.time()

    # ------------------------------------------------------------------ input
    def submit(self, item) -> None:
        try:
            self.queue.put_nowait(item)
        except asyncio.QueueFull:
            self.dropped += 1

    def status_for(self, feed: str) -> dict:
        return self.feed_status.setdefault(feed, {
            "connected": False, "messages": 0, "last_message": None, "errors": 0,
            "last_error": None, "reconnects": 0,
        })

    # ------------------------------------------------------------------ loop
    async def run(self) -> None:
        last_tick = 0.0
        while True:
            try:
                item = await asyncio.wait_for(self.queue.get(), timeout=1.0)
                self.process(item)
                # drain quickly without awaiting each time
                for _ in range(2000):
                    if self.queue.empty():
                        break
                    self.process(self.queue.get_nowait())
            except asyncio.TimeoutError:
                pass
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("engine loop error")
            wall = time.time()
            if wall - last_tick >= 1.0 and not self.backfilling:
                last_tick = wall
                now = max(wall, self.clock) if self.clock - wall < 5 else self.clock
                self.handle_closed(self.book.tick(now))

    def process(self, item) -> None:
        if isinstance(item, Trade):
            self._on_trade(item)
        elif isinstance(item, BookTop):
            self._on_book(item)
        elif isinstance(item, list):
            for x in item:
                self.process(x)

    def _on_trade(self, t: Trade) -> None:
        if t.price <= 0 or t.size < 0:
            return
        self.trades_processed += 1
        self.clock = max(self.clock, t.ts)
        p = self.prices.setdefault(t.symbol, {"symbol": t.symbol})
        p.update(price=t.price, ts=t.ts, exchange=t.exchange)
        for fn in self.price_listeners:
            try:
                fn(t.symbol, t.price, t.ts)
            except Exception:
                log.exception("price listener failed")
        for fn in self.trade_listeners:
            try:
                fn(t)
            except Exception:
                log.exception("trade listener failed")
        self.handle_closed(self.book.add_trade(t))

    def _on_book(self, b: BookTop) -> None:
        if b.bid <= 0 or b.ask <= 0:
            return
        tops = self.book_tops.setdefault(b.symbol, {})
        tops[b.exchange] = b
        bs = sum(x.bid_size * x.bid for x in tops.values())
        as_ = sum(x.ask_size * x.ask for x in tops.values())
        if bs + as_ <= 0:
            return
        imb = (bs - as_) / (bs + as_)
        prev = self.book_imbalance.get(b.symbol, imb)
        self.book_imbalance[b.symbol] = 0.9 * prev + 0.1 * imb   # smooth out flicker
        if b.symbol not in self.prices:
            mid = (b.bid + b.ask) / 2
            self.prices[b.symbol] = {"symbol": b.symbol, "price": mid, "ts": b.ts, "exchange": b.exchange}
            for fn in self.price_listeners:
                try:
                    fn(b.symbol, mid, b.ts)
                except Exception:
                    log.exception("price listener failed")

    def handle_closed(self, candles: list[Candle]) -> None:
        for c in candles:
            for fn in self.candle_listeners:
                try:
                    fn(c)
                except Exception:
                    log.exception("candle listener failed")
            series = self.book.get(c.symbol, c.interval)
            event = self.pipeline.on_candle(c, series.history(), self.book_imbalance.get(c.symbol))
            if event is None:
                continue
            if time.time() - event.ts > self.event_max_age:
                continue  # stale (backfill / reconnect catch-up): don't alert
            if self.enricher:
                self.enricher(event)
            self.publish(event)

    def publish(self, event: MarketEvent) -> None:
        self.recent_events.append(event)
        self.bus.publish(event)

    # ------------------------------------------------------------------ queries
    def candles(self, symbol: str, interval: int, limit: int = 300) -> list[dict]:
        if (symbol, interval) not in self.book.series:
            return []
        h = self.book.get(symbol, interval).history(include_current=True)
        return [c.to_dict() for c in h[-limit:]]

    def change(self, symbol: str, seconds: int) -> float | None:
        price = self.prices.get(symbol, {}).get("price")
        if not price:
            return None
        for tf in sorted(self.timeframes, reverse=True):
            if seconds % tf:
                continue
            series = self.book.series.get((symbol, tf))
            if not series:
                continue
            n = seconds // tf
            h = series.history()
            if len(h) >= n:
                ref = h[-n].open
                return (price / ref - 1) if ref else None
        return None

    def snapshot(self) -> list[dict]:
        out = []
        for sym, p in sorted(self.prices.items()):
            d = dict(p)
            d["change_1h"] = self.change(sym, 3600)
            d["change_24h"] = self.change(sym, 86400)
            d["book_imbalance"] = round(self.book_imbalance.get(sym, 0.0), 3)
            d["stable"] = sym in self.stable_symbols
            out.append(d)
        return out

    # ------------------------------------------------------------------ backfill
    async def backfill_coinbase(self, symbols: list[str]) -> int:
        """Seed candle history from Coinbase's public REST API so detectors are warm on boot."""
        loaded, failures = 0, 0
        async with httpx.AsyncClient(timeout=15, headers={"User-Agent": "StrikePulse/1.0"}) as client:
            for sym in symbols:
                if sym in self.stable_symbols:
                    continue
                for tf in self.timeframes:
                    if tf not in (60, 300, 900, 3600, 21600, 86400):
                        continue
                    url = f"https://api.exchange.coinbase.com/products/{sym}/candles"
                    try:
                        r = await client.get(url, params={"granularity": tf})
                        if r.status_code != 200:
                            continue
                        rows = r.json()
                    except Exception as e:  # network blocked, rate limited, etc.
                        log.warning("backfill %s %s failed: %s", sym, tf, e)
                        failures += 1
                        if failures >= 3 and loaded == 0:
                            log.warning("backfill aborted: Coinbase REST unreachable; detectors will warm up from live data")
                            return 0
                        continue
                    candles = [Candle(sym, tf, float(t), float(o), float(h), float(l), float(c), float(v), float(v) / 2, 0)
                               for t, l, h, o, c, v in rows]
                    # drop the still-open bucket
                    now_bucket = int(time.time() // tf) * tf
                    candles = [c for c in candles if c.start < now_bucket]
                    self.book.get(sym, tf).seed(candles)
                    loaded += len(candles)
                    await asyncio.sleep(0.15)  # be polite to the public API
        log.info("backfilled %d candles from Coinbase", loaded)
        return loaded
