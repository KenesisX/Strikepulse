"""Vectorised technical indicators (numpy only)."""
from __future__ import annotations

import numpy as np


try:
    from scipy.signal import lfilter as _lfilter
except Exception:  # pragma: no cover
    _lfilter = None


def _ema_alpha(values: np.ndarray, alpha: float) -> np.ndarray:
    """y[t] = a*x[t] + (1-a)*y[t-1], y[0] = x[0]. Runs in C via an IIR filter (~50x a Python loop)."""
    values = np.asarray(values, dtype=float)
    if len(values) == 0:
        return values.copy()
    if _lfilter is not None:
        y, _ = _lfilter([alpha], [1.0, alpha - 1.0], values, zi=[(1.0 - alpha) * values[0]])
        return y
    out = np.empty_like(values)
    out[0] = values[0]
    for i in range(1, len(values)):
        out[i] = alpha * values[i] + (1 - alpha) * out[i - 1]
    return out


def ema(values: np.ndarray, period: int) -> np.ndarray:
    return _ema_alpha(values, 2.0 / (period + 1.0))


def sma(values: np.ndarray, period: int) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    out = np.full_like(values, np.nan)
    if len(values) >= period:
        c = np.cumsum(np.insert(values, 0, 0.0))
        out[period - 1:] = (c[period:] - c[:-period]) / period
    return out


def rolling_mean(values: np.ndarray, period: int) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    out = np.full_like(values, np.nan)
    if len(values) >= period:
        c = np.cumsum(np.insert(values, 0, 0.0))
        out[period - 1:] = (c[period:] - c[:-period]) / period
    return out


def rolling_std(values: np.ndarray, period: int) -> np.ndarray:
    """O(n) rolling population std via cumulative sums (shifted for numerical stability)."""
    values = np.asarray(values, dtype=float)
    out = np.full_like(values, np.nan)
    if len(values) < period:
        return out
    x = values - np.nanmean(values)
    c1 = np.cumsum(np.insert(x, 0, 0.0))
    c2 = np.cumsum(np.insert(x * x, 0, 0.0))
    s1 = c1[period:] - c1[:-period]
    s2 = c2[period:] - c2[:-period]
    out[period - 1:] = np.sqrt(np.maximum(s2 / period - (s1 / period) ** 2, 0.0))
    return out


def rsi(closes: np.ndarray, period: int = 14) -> np.ndarray:
    """Wilder's RSI."""
    closes = np.asarray(closes, dtype=float)
    out = np.full_like(closes, np.nan)
    if len(closes) <= period:
        return out
    delta = np.diff(closes)
    gain = np.where(delta > 0, delta, 0.0)
    loss = np.where(delta < 0, -delta, 0.0)
    # Wilder smoothing = EMA with alpha 1/period, seeded with the first `period` average
    g = np.concatenate([[gain[:period].mean()], gain[period:]])
    l_ = np.concatenate([[loss[:period].mean()], loss[period:]])
    ag = _ema_alpha(g, 1.0 / period)
    al = _ema_alpha(l_, 1.0 / period)
    with np.errstate(divide="ignore", invalid="ignore"):
        rs = np.where(al == 0, np.inf, ag / np.where(al == 0, 1, al))
        out[period:] = np.where(al == 0, 100.0, 100 - 100 / (1 + rs))
    return out


def bollinger(closes: np.ndarray, period: int = 20, k: float = 2.0):
    mid = sma(closes, period)
    sd = rolling_std(closes, period)
    return mid, mid + k * sd, mid - k * sd


def atr(highs, lows, closes, period: int = 14) -> np.ndarray:
    highs, lows, closes = (np.asarray(x, dtype=float) for x in (highs, lows, closes))
    prev = np.concatenate([[closes[0]], closes[:-1]])
    tr = np.maximum(highs - lows, np.maximum(abs(highs - prev), abs(lows - prev)))
    return ema(tr, period)


def zscore_last(values: np.ndarray, window: int) -> float:
    """z-score of the last value against the `window` values before it."""
    values = np.asarray(values, dtype=float)
    if len(values) < window + 1:
        return 0.0
    ref = values[-window - 1:-1]
    sd = ref.std()
    if sd <= 1e-12:
        return 0.0
    return float((values[-1] - ref.mean()) / sd)
