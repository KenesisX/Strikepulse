"""Core data types shared by feeds, engine, on-chain monitor and alert dispatcher."""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class Trade:
    exchange: str
    symbol: str          # canonical "BTC-USD"
    price: float
    size: float
    side: str            # TAKER side: "buy" or "sell"
    ts: float            # unix seconds


@dataclass(slots=True)
class BookTop:
    exchange: str
    symbol: str
    bid: float
    bid_size: float
    ask: float
    ask_size: float
    ts: float


@dataclass(slots=True)
class Candle:
    symbol: str
    interval: int        # seconds
    start: float         # bucket start (unix seconds)
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0
    buy_volume: float = 0.0
    trades: int = 0

    @property
    def sell_volume(self) -> float:
        return max(0.0, self.volume - self.buy_volume)

    def to_dict(self) -> dict:
        return {
            "t": int(self.start), "o": self.open, "h": self.high, "l": self.low,
            "c": self.close, "v": round(self.volume, 8), "bv": round(self.buy_volume, 8),
            "n": self.trades,
        }


@dataclass(slots=True)
class Signal:
    detector: str
    direction: int       # +1 bullish, -1 bearish
    strength: float      # 0..1
    detail: str
    ts: float = 0.0


TF_LABEL = {60: "1m", 300: "5m", 900: "15m", 3600: "1h", 14400: "4h", 86400: "1d"}
LABEL_TF = {v: k for k, v in TF_LABEL.items()}


def tf_label(seconds: int) -> str:
    return TF_LABEL.get(seconds, f"{seconds}s")


@dataclass
class MarketEvent:
    kind: str                    # market | onchain | security | depeg | listing | gas | test
    symbol: str
    title: str
    direction: int = 0
    score: int = 0
    price: float | None = None
    timeframe: str = ""
    reasons: list[str] = field(default_factory=list)
    signals: list[dict] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)
    ts: float = field(default_factory=time.time)
    id: str = field(default_factory=lambda: uuid.uuid4().hex)

    @property
    def detectors(self) -> list[str]:
        return [s["detector"] for s in self.signals]

    @property
    def critical(self) -> bool:
        return self.score >= 90 or self.kind in ("security", "depeg")

    def to_dict(self) -> dict:
        d = asdict(self)
        d["critical"] = self.critical
        return d
