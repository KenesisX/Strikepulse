"""Small, dependency-free Isolation Forest (Liu et al. 2008) using numpy.

Anomaly score s(x) in (0, 1]: ~0.5 = normal, > 0.65 = unusual, > 0.75 = very unusual.
"""
from __future__ import annotations

import math

import numpy as np

EULER = 0.5772156649


def _c(n: int) -> float:
    """Average path length of an unsuccessful BST search."""
    if n <= 1:
        return 0.0
    if n == 2:
        return 1.0
    return 2.0 * (math.log(n - 1) + EULER) - 2.0 * (n - 1) / n


class _Node:
    __slots__ = ("feature", "split", "left", "right", "size")

    def __init__(self, size: int, feature=-1, split=0.0, left=None, right=None):
        self.size, self.feature, self.split, self.left, self.right = size, feature, split, left, right


def _build(X: np.ndarray, depth: int, limit: int, rng: np.random.Generator) -> _Node:
    n = len(X)
    if depth >= limit or n <= 1:
        return _Node(n)
    mins, maxs = X.min(axis=0), X.max(axis=0)
    usable = np.where(maxs > mins)[0]
    if len(usable) == 0:
        return _Node(n)
    f = int(rng.choice(usable))
    split = float(rng.uniform(mins[f], maxs[f]))
    mask = X[:, f] < split
    return _Node(n, f, split, _build(X[mask], depth + 1, limit, rng), _build(X[~mask], depth + 1, limit, rng))


def _path(x: np.ndarray, node: _Node, depth: int = 0) -> float:
    while node.feature != -1:
        node = node.left if x[node.feature] < node.split else node.right
        depth += 1
    return depth + _c(node.size)


class IsolationForest:
    def __init__(self, n_trees: int = 100, sample_size: int = 128, seed: int | None = 7):
        self.n_trees = n_trees
        self.sample_size = sample_size
        self.rng = np.random.default_rng(seed)
        self.trees: list[_Node] = []
        self._psi = sample_size
        self.mean = None
        self.std = None

    def fit(self, X: np.ndarray) -> "IsolationForest":
        X = np.asarray(X, dtype=float)
        self.mean = X.mean(axis=0)
        self.std = X.std(axis=0) + 1e-9
        Xs = (X - self.mean) / self.std
        psi = min(self.sample_size, len(Xs))
        self._psi = psi
        limit = int(math.ceil(math.log2(max(psi, 2))))
        self.trees = []
        for _ in range(self.n_trees):
            idx = self.rng.choice(len(Xs), size=psi, replace=False)
            self.trees.append(_build(Xs[idx], 0, limit, self.rng))
        return self

    def score(self, X: np.ndarray) -> np.ndarray:
        if not self.trees:
            raise RuntimeError("fit() first")
        X = (np.atleast_2d(np.asarray(X, dtype=float)) - self.mean) / self.std
        cn = _c(self._psi)
        out = np.empty(len(X))
        for i, x in enumerate(X):
            h = np.mean([_path(x, t) for t in self.trees])
            out[i] = 2.0 ** (-h / cn) if cn > 0 else 0.5
        return out
