"""Template rendering helpers shared by all routes."""
from __future__ import annotations

import time
from datetime import datetime, timezone
from pathlib import Path

from fastapi import Request
from fastapi.templating import Jinja2Templates

from .alerts.formatting import fmt_price
from .config import settings
from .engine.detectors import DETECTOR_INFO
from .plans import ORDER, PLANS, plan_for
from .security import csrf_token, pop_flashes

templates = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))


def _ago(ts: float | None) -> str:
    if not ts:
        return "never"
    d = time.time() - ts
    if d < 60:
        return f"{int(d)}s ago"
    if d < 3600:
        return f"{int(d // 60)}m ago"
    if d < 86400:
        return f"{int(d // 3600)}h ago"
    return f"{int(d // 86400)}d ago"


def _dt(ts: float | None) -> str:
    if not ts:
        return ""
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def _pct(x: float | None) -> str:
    return "–" if x is None else f"{x * 100:+.2f}%"


templates.env.filters["ago"] = _ago
templates.env.filters["dt"] = _dt
templates.env.filters["price"] = fmt_price
templates.env.filters["pct"] = _pct
templates.env.globals["year"] = datetime.now().year


def render(request: Request, name: str, user=None, status_code: int = 200, **ctx):
    base = {
        "request": request, "user": user, "plan": plan_for(user) if user else None,
        "settings": settings, "plans": PLANS, "plan_order": ORDER, "detectors": DETECTOR_INFO,
        "csrf": csrf_token(request), "flashes": pop_flashes(request), "now": time.time(),
    }
    base.update(ctx)
    return templates.TemplateResponse(request, name, base, status_code=status_code)
