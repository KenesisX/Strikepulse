@echo off
cd /d "%~dp0"
if not exist .venv (echo Run install.bat first. & pause & exit /b 1)
if not exist .env .venv\Scripts\python -m app.setup
start "" http://localhost:8000
.venv\Scripts\uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1
pause
