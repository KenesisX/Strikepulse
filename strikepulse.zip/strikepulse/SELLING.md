# Selling StrikePulse: the playbook

There are two ways to make money with this. You can do both at once.

| | **A. Run it as your own subscription business** | **B. Sell the source code to other people** |
|---|---|---|
| Income | Recurring: $9.99-24.99 per user per month | One-time: $79-499 per sale |
| Work after launch | Low: keep the server up, answer support | Very low: answer buyer questions, ship updates |
| Startup cost | ~$6/mo server + $10/yr domain | $0 (Gumroad / Lemon Squeezy take a cut per sale) |
| Best for | Building monthly income | Fast cash, no customers to support day to day |

> Doing both is fine, but sell code buyers a license to run **their own** copy, not to resell the code (see `LICENSE.txt`).

---

## A. Run it as your own subscription business

### 1. Launch (one afternoon)
1. Buy a domain (Namecheap, Cloudflare, Porkbun) and rent a $5-6/mo VPS (Hetzner CX22, DigitalOcean, Vultr).
2. On the server: `git clone` or upload the zip, then `./install.sh`. The wizard asks for everything. Pick **live data**.
3. Stripe: `python scripts/setup_stripe.py https://yourdomain.com`, paste the printed keys into `.env`, then add your payout bank in Stripe → Settings → Payouts.
4. HTTPS: `DOMAIN=yourdomain.com docker compose --profile https up -d` (or put Caddy / Cloudflare Tunnel in front of `./start.sh`).
5. Create your Telegram bot (@BotFather) **and** a free public channel. Add the bot as a channel admin and set `PROMO_TELEGRAM_CHAT=@yourchannel`.
6. Sign up as a normal user, connect Telegram, and send a test alert from Settings.
7. Let it run 1-2 weeks so the **/performance** page fills with real, live results before you advertise heavily.

### 2. Get your first 100 users
* **The free promo channel does the selling.** It posts strong alerts 15 minutes late with an upgrade link. Share the channel everywhere; people join for free signals and upgrade for speed.
* **Show the receipts.** Link `/performance` in every post. Real, uncherry-picked hit rates build trust faster than anything.
* Where to post: r/CryptoCurrency daily threads, r/algotrading, r/CryptoMarkets, crypto Twitter/X, TradingView ideas (link in profile), crypto Discord servers (ask the mods), Telegram crypto groups, a Product Hunt launch, and indie hacker forums.
* Content that works: a screenshot of an alert next to the chart 1 hour later; "our bot caught the SOL breakout 12 minutes early"; weekly "best alerts this week" posts.
* **Offers:** the 7-day free trial is already on. Stripe promotion codes are enabled at checkout, so create `LAUNCH50` for 50% off the first month. Yearly plans give "2 months free" automatically once yearly prices exist.
* **Affiliates:** give crypto influencers a 30% recurring code (Stripe promotion codes + track redemptions in the Stripe dashboard).

### 3. Numbers to expect
* Typical free → paid conversion for signal products: 2-5%.
* 1,000 free users × 3% × $9.99 ≈ **$300/mo**; 100 Pro + 20 Elite ≈ **$1,500/mo**.
* Costs stay ~flat: one $6-12/mo server handles thousands of users (the work scales with the number of coins, not users).

### 4. Weekly maintenance (≈30 min)
* Glance at **Admin** (MRR, feed status, failed deliveries).
* `python scripts/backup.py` runs nightly from cron (see the script header).
* Answer support email. Most questions: "how do I connect Telegram" (Settings has the button).

### 5. Money and legal
* Payouts: Stripe → your bank (2 business days). If Stripe is under **Strikebacktech**, pay out to a business account in the business's name, then transfer to your personal account, to avoid name-mismatch rejections and keep finances clean.
* Taxes: Stripe sends a 1099-K. Set aside ~25-30%.
* Keep it **alerts only**, the same for every subscriber, with the disclaimers that are already on every alert and page. Have a lawyer review `app/templates/legal/` before launch.
* Never promise returns or accuracy numbers in ads. Link the live `/performance` page instead.

---

## B. Sell the source code

### Where to sell
| Marketplace | Fee | Notes |
|---|---|---|
| **Gumroad** | 10% + processing | Easiest. Upload the zip, done. Handles license keys + updates. |
| **Lemon Squeezy** | 5% + 50¢ | Handles sales tax/VAT for you (merchant of record). |
| **CodeCanyon (Envato)** | 37.5-55% | Huge audience but strict review, and you must follow their licenses. |
| Your own site | Stripe fees only | Run StrikePulse itself as the live demo + a "Buy the code" button. |

### Suggested pricing
| Tier | Price | What the buyer gets |
|---|---|---|
| **Personal** | $79 | Run 1 site for themselves, no paying customers |
| **Commercial** | $199 | Run 1 site and charge subscribers |
| **Agency / Extended** | $499 | Up to 10 sites, white-label (own name, colors, logo) |
| **Done-for-you setup** | +$300 | You install it on their server with their Stripe + Telegram (about 1 hour of work) |

### Make a demo (sells far better than screenshots)
Run a copy with `./install.sh --demo` on a cheap VPS at `demo.yourdomain.com`. It uses simulated data and fake billing, so visitors can sign up and click every upgrade button safely. Post the demo admin login in the listing, or reset it nightly.

### Listing copy (paste and edit)

**Title:** StrikePulse: Crypto Trend & On-Chain Alert SaaS (Python, Stripe, Telegram)

**Short description:** A complete, ready-to-sell crypto analysis and alert subscription business with a Probability Engine, whale-vs-retail order flow and timing maps. Live exchange feeds, 9 trading-signal detectors with machine-learning anomaly detection, whale and rug-pull radar, Stripe subscriptions, and alerts to Telegram, Discord, email and phone push. Install with one command.

**Full description:**
> Launch your own crypto signals business this weekend. StrikePulse streams live trades from Coinbase, Kraken and Binance.US 24/7 and alerts your subscribers the moment the market shifts.
>
> **Deep Analysis (the part no one else has)**
> - Probability Engine: odds from the most similar past moments, with confidence ranges
> - Whale vs retail order-flow X-ray, cumulative delta, divergence alerts
> - Hour x weekday timing heatmaps, probability cone and price-target odds
> - Money rotation / attention tracking and a 0-100 Pulse Score
>
> **Quant Engine + Edge Lab**
> - Machine-learning ensemble (gradient boosting + online learning + regime-weighted Hedge blend) with honest walk-forward validation and an automatic "no edge" bench
> - Regime detection, quarter-Kelly risk budgets, drawdown circuit breakers
> - Retrains itself every hour (champion vs challenger), detects market drift, and publishes 95% price ranges whose hit rate self-corrects
> - Math Lab: Kalman, GARCH, Hurst, entropy, Bayesian change-points, Ornstein-Uhlenbeck, Hawkes, FFT cycles, cointegration, wavelets, transfer entropy
> - Pattern Memory across every coin, a one-year Bet Simulator with 5,000 Monte Carlo runs, and a World & Macro page (sentiment, news tone, GDP, debt, rates)
> - Hidden buyer/seller detection, wash-trade forensics, stop-hunt and liquidation zones, exchange premium and lead-lag, options max pain
>
> **Signal engine**
> - 9 detectors: EMA crossovers, volume spikes, CUSUM change-point detection, Bollinger breakouts, RSI reversals, momentum bursts, taker-flow and order-book imbalance, and an Isolation Forest anomaly model
> - Confluence scoring (0-100) with cooldowns, so subscribers get fewer, better alerts
> - 1m / 5m / 15m timeframes, built-in backtester to tune it
>
> **On-chain radar**
> - Whale deposits and withdrawals on exchange wallets, Bloom-filter accelerated
> - Rug-pull warnings: liquidity removal, surprise mints, ownership changes, flagged addresses
> - Stablecoin de-peg, new exchange listings, and cheap gas alerts
>
> **Ready-made business**
> - Stripe subscriptions: Free / Pro / Elite, monthly + yearly, free trials, promo codes, customer portal
> - Alerts via Telegram bot (one-click connect), Discord, email, ntfy phone push, signed webhooks
> - Live dashboard with charts, a public **live accuracy page**, and an auto-posting **free promo channel** that converts free users
> - Admin panel: MRR, users, feed health, CSV export, manual broadcasts
> - REST API for top-tier customers
>
> **Easy to run**
> - One-command installer + setup wizard (Linux, macOS, Windows, Raspberry Pi)
> - Docker + automatic HTTPS, or a systemd service
> - SQLite out of the box, Postgres supported; automatic database upgrades
> - White-label: your name, logo, colors, tagline from one settings file
>
> **Secure by default:** hashed passwords, CSRF protection, rate limiting, strict CSP, SSRF-safe webhooks, Stripe signature checks. 89 automated tests.
>
> **Tech:** Python 3.10+, FastAPI, SQLAlchemy, NumPy, vanilla JS. No paid APIs required.

**Tags:** crypto, bitcoin, trading signals, saas, telegram bot, stripe, fastapi, python, alerts, whale tracker, defi, subscription

### Before each code sale release
- [ ] `python -m pytest -q` passes
- [ ] Remove `.env`, `data/*.db`, `backups/` from the zip (the packaged zip already excludes them)
- [ ] Bump `app/__init__.py` version and add a `CHANGELOG.md` entry
- [ ] Screenshots in `docs/screenshots/` are current

### Buyer support policy (suggested, put it in the listing)
"6 months of email support for installation questions and bugs. Customization is a paid service. Updates are free for 12 months."
