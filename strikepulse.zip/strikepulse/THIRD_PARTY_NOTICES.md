# Third-party components

StrikePulse depends on these open-source packages, installed by pip from requirements.txt
(not bundled in this archive). All permit commercial use; keep their notices if you redistribute them.

| Package | License |
|---|---|
| FastAPI | MIT |
| Uvicorn | BSD-3-Clause |
| SQLAlchemy | MIT |
| NumPy | BSD-3-Clause (plus 0BSD/MIT/Zlib/CC0 for bundled parts) |
| HTTPX | BSD-3-Clause |
| websockets | BSD-3-Clause |
| Jinja2 | BSD-3-Clause |
| itsdangerous | BSD-3-Clause |
| python-multipart | Apache-2.0 |
| stripe-python | MIT |

Market data comes from the public APIs of Coinbase, Kraken and Binance.US. Review each exchange's
API terms before commercial use; they generally allow redistribution of derived signals but not of raw
market data feeds.
