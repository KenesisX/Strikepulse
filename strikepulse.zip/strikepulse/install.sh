#!/usr/bin/env bash
# StrikePulse installer for Linux, macOS and Raspberry Pi OS.
#   ./install.sh            install + run the setup wizard
#   ./install.sh --demo     install with demo settings (simulated data, fake billing)
#   ./install.sh --service  also install a systemd service that starts on boot (Linux)
set -euo pipefail
cd "$(dirname "$0")"

PY=${PYTHON:-python3}
if ! command -v "$PY" >/dev/null; then
  echo "Python 3.10+ is required. On Debian/Ubuntu/Pi: sudo apt install -y python3 python3-venv"; exit 1
fi
"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' || { echo "Python 3.10+ required (found $("$PY" -V))"; exit 1; }

echo "==> Creating virtual environment"
"$PY" -m venv .venv || { echo "Install venv support: sudo apt install -y python3-venv"; exit 1; }
.venv/bin/pip install --upgrade pip -q
echo "==> Installing dependencies (a few minutes on a Raspberry Pi)"
.venv/bin/pip install -r requirements.txt -q
mkdir -p data

if [[ " $* " == *" --demo "* ]]; then
  .venv/bin/python -m app.setup --demo
elif [[ ! -f .env ]]; then
  .venv/bin/python -m app.setup
fi

if [[ " $* " == *" --service "* ]]; then
  SVC=/etc/systemd/system/strikepulse.service
  echo "==> Installing systemd service ($SVC)"
  sudo tee "$SVC" >/dev/null <<UNIT
[Unit]
Description=StrikePulse crypto alerts
After=network-online.target
Wants=network-online.target
[Service]
User=$(whoami)
WorkingDirectory=$(pwd)
ExecStart=$(pwd)/.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port \${PORT:-8000} --workers 1 --proxy-headers
EnvironmentFile=$(pwd)/.env
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
UNIT
  sudo systemctl daemon-reload && sudo systemctl enable --now strikepulse
  echo "Service running: sudo systemctl status strikepulse   logs: journalctl -u strikepulse -f"
fi

echo
echo "✅ Installed. Start with:  ./start.sh   then open http://localhost:8000"
