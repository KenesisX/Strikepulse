"""Hot backup of the SQLite database (safe while the app is running).

    python scripts/backup.py                 # → backups/strikepulse-YYYYmmdd-HHMM.db, keeps last 14
    python scripts/backup.py --keep 30

Cron (daily 3:15am):  15 3 * * *  cd /path/to/strikepulse && .venv/bin/python scripts/backup.py
For Postgres use pg_dump instead.
"""
from __future__ import annotations

import os
import sqlite3
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
from app.config import settings  # noqa: E402


def main() -> int:
    keep = int(sys.argv[sys.argv.index("--keep") + 1]) if "--keep" in sys.argv else 14
    url = settings.database_url
    if not url.startswith("sqlite"):
        print("Not SQLite. Use pg_dump for Postgres.")
        return 1
    src = Path(url.split("///", 1)[-1])
    if not src.exists():
        print(f"No database at {src}")
        return 1
    out_dir = ROOT / "backups"
    out_dir.mkdir(exist_ok=True)
    dest = out_dir / f"strikepulse-{time.strftime('%Y%m%d-%H%M')}.db"
    with sqlite3.connect(src) as s, sqlite3.connect(dest) as d:
        s.backup(d)
    olds = sorted(out_dir.glob("strikepulse-*.db"))[:-keep]
    for o in olds:
        o.unlink()
    total = len(list(out_dir.glob("strikepulse-*.db")))
    print(f"Backup written: {dest} ({dest.stat().st_size // 1024} KB). {total} backup(s) kept.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
