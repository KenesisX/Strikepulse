"""Reset any account's password from the server command line (works without email set up).

    python scripts/reset_password.py you@example.com            # prompts for the new password
    python scripts/reset_password.py you@example.com --admin    # also makes the account an admin
    docker compose exec app python scripts/reset_password.py you@example.com
"""
from __future__ import annotations

import getpass
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

from sqlalchemy import func, select  # noqa: E402

from app import db as dbmod  # noqa: E402
from app.config import settings  # noqa: E402
from app.models import User  # noqa: E402
from app.security import hash_password  # noqa: E402


def main(argv: list[str]) -> int:
    args = [a for a in argv if not a.startswith("--")]
    if not args:
        print(__doc__)
        return 1
    email = args[0].strip().lower()
    pw = os.getenv("NEW_PASSWORD") or getpass.getpass("New password (min 8 chars): ")
    if len(pw) < 8:
        print("Password must be at least 8 characters.")
        return 1
    dbmod.init_db(settings.database_url)
    with dbmod.session_scope() as db:
        u = db.scalar(select(User).where(func.lower(User.email) == email))
        if not u:
            print(f"No account with email {email}.")
            return 1
        u.password_hash = hash_password(pw)
        if "--admin" in argv:
            u.is_admin = True
    print(f"Password updated for {email}." + (" Account is admin." if "--admin" in argv else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
