"""One-time Stripe setup: creates the Pro and Elite products/prices and the webhook endpoint,
then prints the values to paste into .env.

    STRIPE_SECRET_KEY=sk_test_... python scripts/setup_stripe.py https://yourdomain.com

Run it once with your TEST key, then again with your LIVE key when you launch.
"""
from __future__ import annotations

import os
import sys

import stripe

PLANS = [("pro", "StrikePulse Pro", 999, 9900), ("elite", "StrikePulse Elite", 2499, 24900)]  # monthly, yearly cents
EVENTS = ["checkout.session.completed", "customer.subscription.created", "customer.subscription.updated",
          "customer.subscription.deleted", "invoice.payment_failed", "invoice.paid"]


def main() -> int:
    key = os.getenv("STRIPE_SECRET_KEY")
    if not key:
        print("Set STRIPE_SECRET_KEY first.")
        return 1
    if len(sys.argv) < 2 or not sys.argv[1].startswith("https://"):
        print("Usage: python scripts/setup_stripe.py https://your-public-domain.com")
        return 1
    base = sys.argv[1].rstrip("/")
    stripe.api_key = key
    out = {}
    for code, name, cents, yearly in PLANS:
        existing = stripe.Product.search(query=f"metadata['strikepulse_plan']:'{code}'").data
        product = existing[0] if existing else stripe.Product.create(name=name, metadata={"strikepulse_plan": code})
        prices = stripe.Price.list(product=product.id, active=True, limit=10).data
        price = next((p for p in prices if p.unit_amount == cents and p.recurring and p.recurring.interval == "month"), None)
        if not price:
            price = stripe.Price.create(product=product.id, unit_amount=cents, currency="usd",
                                        recurring={"interval": "month"}, metadata={"strikepulse_plan": code})
        out[f"STRIPE_PRICE_{code.upper()}"] = price.id
        yprice = next((p for p in prices if p.unit_amount == yearly and p.recurring and p.recurring.interval == "year"), None)
        if not yprice:
            yprice = stripe.Price.create(product=product.id, unit_amount=yearly, currency="usd",
                                         recurring={"interval": "year"}, metadata={"strikepulse_plan": code})
        out[f"STRIPE_PRICE_{code.upper()}_YEARLY"] = yprice.id
    url = f"{base}/billing/webhook"
    hooks = [h for h in stripe.WebhookEndpoint.list(limit=100).data if h.url == url]
    if hooks:
        print(f"Webhook already exists for {url} (secret is only shown at creation; find it in the Dashboard).")
    else:
        hook = stripe.WebhookEndpoint.create(url=url, enabled_events=EVENTS)
        out["STRIPE_WEBHOOK_SECRET"] = hook.secret
    print("\nAdd these to your .env:\n")
    print(f"STRIPE_SECRET_KEY={key}")
    for k, v in out.items():
        print(f"{k}={v}")
    print("\nAlso: Dashboard → Settings → Billing → Customer portal → enable plan switching & cancellation.")
    print("Payouts: Dashboard → Settings → Payouts → add your bank account (routing + account number).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
